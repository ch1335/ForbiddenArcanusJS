package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.mixin.AccessorFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public class ModFlammables {
   public static void registerFlammables() {
      registerLeaves((Block)ModBlocks.AURUM_LEAVES.get());
      registerLeaves((Block)ModBlocks.NUGGETY_AURUM_LEAVES.get());
      registerLog((Block)ModBlocks.AURUM_LOG.get());
      registerLog((Block)ModBlocks.EDELWOOD_LOG.get());
      registerLog((Block)ModBlocks.CARVED_EDELWOOD_LOG.get());
      registerLog((Block)ModBlocks.STRIPPED_AURUM_LOG.get());
      registerLog((Block)ModBlocks.AURUM_WOOD.get());
      registerLog((Block)ModBlocks.STRIPPED_AURUM_WOOD.get());
      registerWoodenBlock((Block)ModBlocks.EDELWOOD_PLANKS.get());
      registerWoodenBlock((Block)ModBlocks.ARCANE_EDELWOOD_PLANKS.get());
      registerWoodenBlock((Block)ModBlocks.EDELWOOD_SLAB.get());
      registerWoodenBlock((Block)ModBlocks.EDELWOOD_STAIRS.get());
      registerWoodenBlock((Block)ModBlocks.EDELWOOD_FENCE.get());
      registerWoodenBlock((Block)ModBlocks.EDELWOOD_FENCE_GATE.get());
      registerWoodenBlock((Block)ModBlocks.AURUM_PLANKS.get());
      registerWoodenBlock((Block)ModBlocks.AURUM_SLAB.get());
      registerWoodenBlock((Block)ModBlocks.AURUM_STAIRS.get());
      registerWoodenBlock((Block)ModBlocks.AURUM_FENCE.get());
      registerWoodenBlock((Block)ModBlocks.AURUM_FENCE_GATE.get());
      registerPlant((Block)ModBlocks.YELLOW_ORCHID.get());
   }

   private static void register(Block block, int encouragement, int flammability) {
      ((AccessorFireBlock)Blocks.FIRE).forbiddenArcanus_setFireInfo(block, encouragement, flammability);
   }

   private static void registerLog(Block block) {
      register(block, 5, 5);
   }

   private static void registerWoodenBlock(Block block) {
      register(block, 5, 20);
   }

   private static void registerLeaves(Block block) {
      register(block, 30, 60);
   }

   private static void registerPlant(Block block) {
      register(block, 60, 100);
   }
}
