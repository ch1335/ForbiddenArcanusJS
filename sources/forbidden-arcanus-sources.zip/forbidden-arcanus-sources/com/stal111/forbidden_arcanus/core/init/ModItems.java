package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.entity.ModBoat;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import com.stal111.forbidden_arcanus.common.item.ArcaneBoneMealItem;
import com.stal111.forbidden_arcanus.common.item.AurealBottleItem;
import com.stal111.forbidden_arcanus.common.item.AurealTankItem;
import com.stal111.forbidden_arcanus.common.item.BloodTestTubeItem;
import com.stal111.forbidden_arcanus.common.item.DarkMatterItem;
import com.stal111.forbidden_arcanus.common.item.DarkSoulItem;
import com.stal111.forbidden_arcanus.common.item.DracoArcanusScepterItem;
import com.stal111.forbidden_arcanus.common.item.EdelwoodOilItem;
import com.stal111.forbidden_arcanus.common.item.FAArmorMaterials;
import com.stal111.forbidden_arcanus.common.item.FerrogneticMixtureItem;
import com.stal111.forbidden_arcanus.common.item.MagicWandItem;
import com.stal111.forbidden_arcanus.common.item.ModArrowItem;
import com.stal111.forbidden_arcanus.common.item.ModBoatItem;
import com.stal111.forbidden_arcanus.common.item.ModFoods;
import com.stal111.forbidden_arcanus.common.item.ModTiers;
import com.stal111.forbidden_arcanus.common.item.QuantumCatcherItem;
import com.stal111.forbidden_arcanus.common.item.SmelterPrismItem;
import com.stal111.forbidden_arcanus.common.item.SmithingTemplateConstants;
import com.stal111.forbidden_arcanus.common.item.SoulExtractorItem;
import com.stal111.forbidden_arcanus.common.item.SpectralEyeAmuletItem;
import com.stal111.forbidden_arcanus.common.item.SplashAurealBottleItem;
import com.stal111.forbidden_arcanus.common.item.WhirlwindPrismItem;
import com.stal111.forbidden_arcanus.common.item.XpetrifiedOrbItem;
import com.stal111.forbidden_arcanus.common.item.bucket.BucketFamily;
import com.stal111.forbidden_arcanus.common.item.bucket.CapacityBucketItem;
import com.stal111.forbidden_arcanus.common.item.bucket.CapacityMilkBucketItem;
import com.stal111.forbidden_arcanus.common.item.bucket.SolidCapacityBucketItem;
import com.stal111.forbidden_arcanus.common.item.component.AurealCost;
import com.stal111.forbidden_arcanus.common.item.component.RitualStarter;
import com.stal111.forbidden_arcanus.common.item.component.ToggleableState;
import com.stal111.forbidden_arcanus.common.item.component.WandParts;
import com.stal111.forbidden_arcanus.common.item.mundabitur.MundabiturDustItem;
import com.stal111.forbidden_arcanus.common.item.wand.WandPart;
import com.stal111.forbidden_arcanus.common.item.wand.WandStats;
import com.stal111.forbidden_arcanus.data.enhancer.ModEnhancerDefinitions;
import com.stal111.forbidden_arcanus.util.ModTags;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Unit;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluids;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.item.ItemEntrySet;
import net.valhelsia.valhelsia_core.api.common.registry.helper.item.ItemRegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.item.ItemRegistryHelper;

public class ModItems implements RegistryClass {
   public static final ItemRegistryHelper HELPER;
   public static final ItemRegistryEntry<Item> ARCANE_CRYSTAL;
   public static final ItemRegistryEntry<Item> CORRUPTED_ARCANE_CRYSTAL;
   public static final ItemRegistryEntry<Item> ARCANE_CRYSTAL_DUST;
   public static final ItemRegistryEntry<Item> DEORUM_INGOT;
   public static final ItemRegistryEntry<Item> DEORUM_NUGGET;
   public static final ItemRegistryEntry<Item> XPETRIFIED_ORB;
   public static final ItemRegistryEntry<Item> ETERNAL_STELLA;
   public static final ItemRegistryEntry<Item> MUNDABITUR_DUST;
   public static final ItemRegistryEntry<Item> CORRUPTI_DUST;
   public static final ItemRegistryEntry<Item> DARK_MATTER;
   public static final ItemRegistryEntry<Item> OBSIDIANSTEEL_INGOT;
   public static final ItemRegistryEntry<Item> SOUL;
   public static final ItemRegistryEntry<DarkSoulItem> CORRUPT_SOUL;
   public static final ItemRegistryEntry<Item> ENCHANTED_SOUL;
   public static final ItemRegistryEntry<Item> RUNE;
   public static final ItemRegistryEntry<Item> ENDER_PEARL_FRAGMENT;
   public static final ItemRegistryEntry<Item> DRAGON_SCALE;
   public static final ItemRegistryEntry<Item> SILVER_DRAGON_SCALE;
   public static final ItemRegistryEntry<Item> GOLDEN_DRAGON_SCALE;
   public static final ItemRegistryEntry<Item> AQUATIC_DRAGON_SCALE;
   public static final ItemRegistryEntry<Item> SPECTRAL_EYE_AMULET;
   public static final ItemRegistryEntry<Item> BAT_WING;
   public static final ItemRegistryEntry<Item> BAT_SOUP;
   public static final ItemRegistryEntry<Item> TENTACLE;
   public static final ItemRegistryEntry<Item> COOKED_TENTACLE;
   public static final ItemRegistryEntry<Item> EDELWOOD_STICK;
   public static final ItemRegistryEntry<Item> WAX;
   public static final ItemRegistryEntry<FerrogneticMixtureItem> FERROGNETIC_MIXTURE;
   public static final ItemRegistryEntry<Item> SOUL_BINDING_CRYSTAL;
   public static final ItemRegistryEntry<Item> AUREAL_WARDSTONE;
   public static final ItemRegistryEntry<Item> SPAWNER_SCRAP;
   public static final ItemRegistryEntry<Item> QUANTUM_CATCHER;
   public static final ItemEntrySet<QuantumCatcherItem, DyeColor> DYED_QUANTUM_CATCHERS;
   public static final ItemRegistryEntry<Item> BOSS_CATCHER;
   public static final ItemRegistryEntry<Item> ARTISAN_RELIC;
   public static final ItemRegistryEntry<Item> CRESCENT_MOON;
   public static final ItemRegistryEntry<Item> CRIMSON_STONE;
   public static final ItemRegistryEntry<Item> SOUL_CRIMSON_STONE;
   public static final ItemRegistryEntry<Item> ELEMENTARIUM;
   public static final ItemRegistryEntry<Item> DIVINE_PACT;
   public static final ItemRegistryEntry<Item> MALEDICTUS_PACT;
   public static final ItemRegistryEntry<Item> AUREAL_TANK;
   public static final ItemRegistryEntry<BlockItem> UTREM_JAR;
   public static final ItemRegistryEntry<BlockItem> ESSENCE_UTREM_JAR;
   public static final ItemRegistryEntry<AurealBottleItem> AUREAL_BOTTLE;
   public static final ItemRegistryEntry<SplashAurealBottleItem> SPLASH_AUREAL_BOTTLE;
   public static final ItemRegistryEntry<Item> ARCANE_CRYSTAL_DUST_SPECK;
   public static final ItemRegistryEntry<ArcaneBoneMealItem> ARCANE_BONE_MEAL;
   public static final ItemRegistryEntry<Item> TEST_TUBE;
   public static final ItemRegistryEntry<BloodTestTubeItem> BLOOD_TEST_TUBE;
   public static final ItemRegistryEntry<Item> BLACKSMITH_GAVEL_HEAD;
   public static final ItemRegistryEntry<PickaxeItem> WOODEN_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<PickaxeItem> STONE_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<PickaxeItem> GOLDEN_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<PickaxeItem> IRON_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<PickaxeItem> DIAMOND_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<PickaxeItem> NETHERITE_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<PickaxeItem> REINFORCED_DEORUM_BLACKSMITH_GAVEL;
   public static final ItemRegistryEntry<Item> STELLARITE_PIECE;
   public static final ItemRegistryEntry<Item> DARK_NETHER_STAR;
   public static final ItemRegistryEntry<Item> TERRASTOMP_PRISM;
   public static final ItemRegistryEntry<Item> SEA_PRISM;
   public static final ItemRegistryEntry<Item> WHIRLWIND_PRISM;
   public static final ItemRegistryEntry<SmelterPrismItem> SMELTER_PRISM;
   public static final ItemRegistryEntry<CapacityBucketItem> EDELWOOD_BUCKET;
   public static final ItemRegistryEntry<CapacityBucketItem> EDELWOOD_WATER_BUCKET;
   public static final ItemRegistryEntry<CapacityBucketItem> EDELWOOD_LAVA_BUCKET;
   public static final ItemRegistryEntry<CapacityMilkBucketItem> EDELWOOD_MILK_BUCKET;
   public static final ItemRegistryEntry<SolidCapacityBucketItem> EDELWOOD_POWDER_SNOW_BUCKET;
   public static final ItemRegistryEntry<ModArrowItem> BOOM_ARROW;
   public static final ItemRegistryEntry<ModArrowItem> DRACO_ARCANUS_ARROW;
   public static final ItemRegistryEntry<EdelwoodOilItem> EDELWOOD_OIL;
   public static final ItemRegistryEntry<Item> APPLY_MODIFIER_SMITHING_TEMPLATE;
   public static final ItemRegistryEntry<Item> OMEGA_ARCOIN;
   public static final ItemRegistryEntry<BoatItem> AURUM_BOAT;
   public static final ItemRegistryEntry<BoatItem> AURUM_CHEST_BOAT;
   public static final ItemRegistryEntry<BoatItem> EDELWOOD_BOAT;
   public static final ItemRegistryEntry<BoatItem> EDELWOOD_CHEST_BOAT;
   public static final ItemRegistryEntry<Item> SOUL_EXTRACTOR;
   public static final ItemRegistryEntry<MagicWandItem> MAGIC_WAND;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_STAFF;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_SWORD;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_SHOVEL;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_PICKAXE;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_AXE;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_HOE;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_SCEPTER;
   public static final ItemRegistryEntry<Item> REINFORCED_DEORUM_SWORD;
   public static final ItemRegistryEntry<Item> REINFORCED_DEORUM_SHOVEL;
   public static final ItemRegistryEntry<Item> REINFORCED_DEORUM_PICKAXE;
   public static final ItemRegistryEntry<Item> REINFORCED_DEORUM_AXE;
   public static final ItemRegistryEntry<Item> REINFORCED_DEORUM_HOE;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_HELMET;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_CHESTPLATE;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_LEGGINGS;
   public static final ItemRegistryEntry<Item> DRACO_ARCANUS_BOOTS;
   public static final ItemRegistryEntry<Item> TYR_HELMET;
   public static final ItemRegistryEntry<Item> TYR_CHESTPLATE;
   public static final ItemRegistryEntry<Item> TYR_LEGGINGS;
   public static final ItemRegistryEntry<Item> TYR_BOOTS;
   public static final ItemRegistryEntry<Item> MORTEM_HELMET;
   public static final ItemRegistryEntry<Item> MORTEM_CHESTPLATE;
   public static final ItemRegistryEntry<Item> MORTEM_LEGGINGS;
   public static final ItemRegistryEntry<Item> MORTEM_BOOTS;

   static {
      HELPER = ForbiddenArcanus.REGISTRY_MANAGER.getItemHelper();
      ARCANE_CRYSTAL = HELPER.register("arcane_crystal", () -> {
         return new Item(new Properties());
      });
      CORRUPTED_ARCANE_CRYSTAL = HELPER.register("corrupted_arcane_crystal", () -> {
         return new Item(new Properties());
      });
      ARCANE_CRYSTAL_DUST = HELPER.register("arcane_crystal_dust", () -> {
         return new Item(new Properties());
      });
      DEORUM_INGOT = HELPER.register("deorum_ingot", () -> {
         return new Item(new Properties());
      });
      DEORUM_NUGGET = HELPER.register("deorum_nugget", () -> {
         return new Item(new Properties());
      });
      XPETRIFIED_ORB = HELPER.register("xpetrified_orb", () -> {
         return new XpetrifiedOrbItem((new Properties()).stacksTo(16).component(ModDataComponents.ESSENCE_VALUE, EssenceValue.of(EssenceType.EXPERIENCE, 91)));
      });
      ETERNAL_STELLA = HELPER.register("eternal_stella", () -> {
         return new Item((new Properties()).stacksTo(1));
      });
      MUNDABITUR_DUST = HELPER.register("mundabitur_dust", () -> {
         return new MundabiturDustItem(new Properties());
      });
      CORRUPTI_DUST = HELPER.register("corrupti_dust", () -> {
         return new Item(new Properties());
      });
      DARK_MATTER = HELPER.register("dark_matter", () -> {
         return new DarkMatterItem(new Properties());
      });
      OBSIDIANSTEEL_INGOT = HELPER.register("obsidiansteel_ingot", () -> {
         return new Item(new Properties());
      });
      SOUL = HELPER.register("soul", () -> {
         return new Item((new Properties()).component(ModDataComponents.ESSENCE_VALUE, EssenceValue.of(EssenceType.SOULS, 1)));
      });
      CORRUPT_SOUL = HELPER.register("corrupt_soul", () -> {
         return new DarkSoulItem((new Properties()).component(ModDataComponents.ESSENCE_VALUE, EssenceValue.of(EssenceType.SOULS, 1)));
      });
      ENCHANTED_SOUL = HELPER.register("enchanted_soul", () -> {
         return new Item((new Properties()).component(ModDataComponents.ESSENCE_VALUE, EssenceValue.of(EssenceType.SOULS, 10)));
      });
      RUNE = HELPER.register("rune", () -> {
         return new Item(new Properties());
      });
      ENDER_PEARL_FRAGMENT = HELPER.register("ender_pearl_fragment", () -> {
         return new Item(new Properties());
      });
      DRAGON_SCALE = HELPER.register("dragon_scale", () -> {
         return new Item(new Properties());
      });
      SILVER_DRAGON_SCALE = HELPER.register("silver_dragon_scale", () -> {
         return new Item(new Properties());
      });
      GOLDEN_DRAGON_SCALE = HELPER.register("golden_dragon_scale", () -> {
         return new Item(new Properties());
      });
      AQUATIC_DRAGON_SCALE = HELPER.register("aquatic_dragon_scale", () -> {
         return new Item(new Properties());
      });
      SPECTRAL_EYE_AMULET = HELPER.register("spectral_eye_amulet", () -> {
         return new SpectralEyeAmuletItem((new Properties()).rarity(Rarity.RARE).stacksTo(1).component(ModDataComponents.TOGGLEABLE_STATE, ToggleableState.DEFAULT));
      });
      BAT_WING = HELPER.register("bat_wing", () -> {
         return new Item((new Properties()).food(ModFoods.BAT_WING));
      });
      BAT_SOUP = HELPER.register("bat_soup", () -> {
         return new Item((new Properties()).stacksTo(1).food(ModFoods.BAT_SOUP));
      });
      TENTACLE = HELPER.register("tentacle", () -> {
         return new Item((new Properties()).food(ModFoods.TENTACLE));
      });
      COOKED_TENTACLE = HELPER.register("cooked_tentacle", () -> {
         return new Item((new Properties()).food(ModFoods.COOKED_TENTACLE));
      });
      EDELWOOD_STICK = HELPER.register("edelwood_stick", () -> {
         return new Item(new Properties());
      });
      WAX = HELPER.register("wax", () -> {
         return new Item(new Properties());
      });
      FERROGNETIC_MIXTURE = HELPER.register("ferrognetic_mixture", () -> {
         return new FerrogneticMixtureItem(new Properties());
      });
      SOUL_BINDING_CRYSTAL = HELPER.register("soul_binding_crystal", () -> {
         return new Item(new Properties());
      });
      AUREAL_WARDSTONE = HELPER.register("aureal_wardstone", () -> {
         return new Item((new Properties()).requiredFeatures(new FeatureFlag[]{ForbiddenArcanus.PREVIEW}));
      });
      SPAWNER_SCRAP = HELPER.register("spawner_scrap", () -> {
         return new Item(new Properties());
      });
      QUANTUM_CATCHER = HELPER.register("quantum_catcher", () -> {
         return new QuantumCatcherItem(ModTags.EntityTypes.QUANTUM_CATCHER_BLACKLISTED, (new Properties()).component((DataComponentType)ModDataComponents.SHOWS_AUREAL_METER.get(), Unit.INSTANCE));
      });
      DYED_QUANTUM_CATCHERS = HELPER.registerColorEntrySet("quantum_catcher", (dyeColor) -> {
         return new QuantumCatcherItem(ModTags.EntityTypes.QUANTUM_CATCHER_BLACKLISTED, (new Properties()).component((DataComponentType)ModDataComponents.SHOWS_AUREAL_METER.get(), Unit.INSTANCE));
      });
      BOSS_CATCHER = HELPER.register("boss_catcher", () -> {
         return new QuantumCatcherItem(ModTags.EntityTypes.BOSS_CATCHER_BLACKLISTED, (new Properties()).component((DataComponentType)ModDataComponents.SHOWS_AUREAL_METER.get(), Unit.INSTANCE));
      });
      ARTISAN_RELIC = HELPER.register("artisan_relic", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.ARTISAN_RELIC));
      });
      CRESCENT_MOON = HELPER.register("crescent_moon", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.CRESCENT_MOON));
      });
      CRIMSON_STONE = HELPER.register("crimson_stone", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.CRIMSON_STONE));
      });
      SOUL_CRIMSON_STONE = HELPER.register("soul_crimson_stone", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.SOUL_CRIMSON_STONE));
      });
      ELEMENTARIUM = HELPER.register("elementarium", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.ELEMENTARIUM));
      });
      DIVINE_PACT = HELPER.register("divine_pact", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.DIVINE_PACT));
      });
      MALEDICTUS_PACT = HELPER.register("maledictus_pact", () -> {
         return new Item((new Properties()).component((DataComponentType)ModDataComponents.ENHANCER.value(), ModEnhancerDefinitions.MALEDICTUS_PACT));
      });
      AUREAL_TANK = HELPER.register("aureal_tank", () -> {
         return new AurealTankItem((new Properties()).stacksTo(1).component(ModDataComponents.ESSENCE_STORAGE, AurealTankItem.DEFAULT_DATA));
      });
      UTREM_JAR = HELPER.register("utrem_jar", () -> {
         return new BlockItem((Block)ModBlocks.UTREM_JAR.get(), new Properties());
      });
      ESSENCE_UTREM_JAR = HELPER.register("essence_utrem_jar", () -> {
         return new BlockItem((Block)ModBlocks.ESSENCE_UTREM_JAR.get(), (new Properties()).component(ModDataComponents.EMPTY_ITEM, UTREM_JAR));
      });
      AUREAL_BOTTLE = HELPER.register("aureal_bottle", () -> {
         return new AurealBottleItem((new Properties()).stacksTo(16).component(ModDataComponents.ESSENCE_VALUE, EssenceValue.of(EssenceType.AUREAL, 35)).component((DataComponentType)ModDataComponents.SHOWS_AUREAL_METER.get(), Unit.INSTANCE));
      });
      SPLASH_AUREAL_BOTTLE = HELPER.register("splash_aureal_bottle", () -> {
         return new SplashAurealBottleItem((new Properties()).stacksTo(16).component(ModDataComponents.ESSENCE_VALUE, EssenceValue.of(EssenceType.AUREAL, 30)).component((DataComponentType)ModDataComponents.SHOWS_AUREAL_METER.get(), Unit.INSTANCE));
      });
      ARCANE_CRYSTAL_DUST_SPECK = HELPER.register("arcane_crystal_dust_speck", () -> {
         return new Item(new Properties());
      });
      ARCANE_BONE_MEAL = HELPER.register("arcane_bone_meal", () -> {
         return new ArcaneBoneMealItem(new Properties());
      });
      TEST_TUBE = HELPER.register("test_tube", () -> {
         return new Item((new Properties()).stacksTo(1));
      });
      BLOOD_TEST_TUBE = HELPER.register("blood_test_tube", () -> {
         return new BloodTestTubeItem((new Properties()).stacksTo(1).component(ModDataComponents.ESSENCE_STORAGE, BloodTestTubeItem.DEFAULT_DATA).component(ModDataComponents.EMPTY_ITEM, TEST_TUBE));
      });
      BLACKSMITH_GAVEL_HEAD = HELPER.register("blacksmith_gavel_head", () -> {
         return new Item((new Properties()).stacksTo(16));
      });
      WOODEN_BLACKSMITH_GAVEL = HELPER.register("wooden_blacksmith_gavel", () -> {
         return new PickaxeItem(Tiers.WOOD, (new Properties()).stacksTo(1).component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      STONE_BLACKSMITH_GAVEL = HELPER.register("stone_blacksmith_gavel", () -> {
         return new PickaxeItem(Tiers.STONE, (new Properties()).stacksTo(1).component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      GOLDEN_BLACKSMITH_GAVEL = HELPER.register("golden_blacksmith_gavel", () -> {
         return new PickaxeItem(Tiers.GOLD, (new Properties()).stacksTo(1).component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      IRON_BLACKSMITH_GAVEL = HELPER.register("iron_blacksmith_gavel", () -> {
         return new PickaxeItem(Tiers.IRON, (new Properties()).stacksTo(1).component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      DIAMOND_BLACKSMITH_GAVEL = HELPER.register("diamond_blacksmith_gavel", () -> {
         return new PickaxeItem(Tiers.DIAMOND, (new Properties()).stacksTo(1).component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      NETHERITE_BLACKSMITH_GAVEL = HELPER.register("netherite_blacksmith_gavel", () -> {
         return new PickaxeItem(Tiers.NETHERITE, (new Properties()).stacksTo(1).fireResistant().component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      REINFORCED_DEORUM_BLACKSMITH_GAVEL = HELPER.register("reinforced_deorum_blacksmith_gavel", () -> {
         return new PickaxeItem(ModTiers.REINFORCED_DEORUM, (new Properties()).stacksTo(1).component(ModDataComponents.RITUAL_STARTER, RitualStarter.BLACKSMITH_GAVEL));
      });
      STELLARITE_PIECE = HELPER.register("stellarite_piece", () -> {
         return new Item(new Properties());
      });
      DARK_NETHER_STAR = HELPER.register("dark_nether_star", () -> {
         return new Item((new Properties()).rarity(Rarity.RARE).component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true));
      });
      TERRASTOMP_PRISM = HELPER.register("terrastomp_prism", () -> {
         return new Item(new Properties());
      });
      SEA_PRISM = HELPER.register("sea_prism", () -> {
         return new Item(new Properties());
      });
      WHIRLWIND_PRISM = HELPER.register("whirlwind_prism", () -> {
         return new WhirlwindPrismItem(new Properties());
      });
      SMELTER_PRISM = HELPER.register("smelter_prism", () -> {
         return new SmelterPrismItem((new Properties()).durability(200));
      });
      EDELWOOD_BUCKET = HELPER.register("edelwood_bucket", () -> {
         return new CapacityBucketItem(Fluids.EMPTY, BucketFamily.EDELWOOD_BUCKET, (new Properties()).stacksTo(16));
      });
      EDELWOOD_WATER_BUCKET = HELPER.register("edelwood_water_bucket", () -> {
         return new CapacityBucketItem(Fluids.WATER, BucketFamily.EDELWOOD_BUCKET, (new Properties()).stacksTo(1).component(ModDataComponents.BUCKET_CAPACITY, 4).component(ModDataComponents.STORED_FLUID_AMOUNT, 1));
      });
      EDELWOOD_LAVA_BUCKET = HELPER.register("edelwood_lava_bucket", () -> {
         return new CapacityBucketItem(Fluids.LAVA, BucketFamily.EDELWOOD_BUCKET, (new Properties()).stacksTo(1).component(ModDataComponents.BUCKET_CAPACITY, 3).component(ModDataComponents.STORED_FLUID_AMOUNT, 1));
      });
      EDELWOOD_MILK_BUCKET = HELPER.register("edelwood_milk_bucket", () -> {
         return new CapacityMilkBucketItem(BucketFamily.EDELWOOD_BUCKET, (new Properties()).stacksTo(1).component(ModDataComponents.BUCKET_CAPACITY, 4).component(ModDataComponents.STORED_FLUID_AMOUNT, 1));
      });
      EDELWOOD_POWDER_SNOW_BUCKET = HELPER.register("edelwood_powder_snow_bucket", () -> {
         return new SolidCapacityBucketItem(Blocks.POWDER_SNOW, SoundEvents.BUCKET_EMPTY_POWDER_SNOW, BucketFamily.EDELWOOD_BUCKET, (new Properties()).stacksTo(1).component(ModDataComponents.BUCKET_CAPACITY, 3).component(ModDataComponents.STORED_FLUID_AMOUNT, 1));
      });
      BOOM_ARROW = HELPER.register("boom_arrow", () -> {
         return new ModArrowItem(new Properties());
      });
      DRACO_ARCANUS_ARROW = HELPER.register("draco_arcanus_arrow", () -> {
         return new ModArrowItem(new Properties());
      });
      EDELWOOD_OIL = HELPER.register("edelwood_oil", () -> {
         return new EdelwoodOilItem((new Properties()).stacksTo(16));
      });
      APPLY_MODIFIER_SMITHING_TEMPLATE = HELPER.register("apply_modifier_smithing_template", SmithingTemplateConstants::createApplyModifierTemplate);
      OMEGA_ARCOIN = HELPER.register("omega_arcoin", () -> {
         return new Item(new Properties());
      });
      AURUM_BOAT = HELPER.register("aurum_boat", () -> {
         return new ModBoatItem(false, ModBoat.Type.AURUM, (new Properties()).stacksTo(1));
      });
      AURUM_CHEST_BOAT = HELPER.register("aurum_chest_boat", () -> {
         return new ModBoatItem(true, ModBoat.Type.AURUM, (new Properties()).stacksTo(1));
      });
      EDELWOOD_BOAT = HELPER.register("edelwood_boat", () -> {
         return new ModBoatItem(false, ModBoat.Type.EDELWOOD, (new Properties()).stacksTo(1));
      });
      EDELWOOD_CHEST_BOAT = HELPER.register("edelwood_chest_boat", () -> {
         return new ModBoatItem(true, ModBoat.Type.EDELWOOD, (new Properties()).stacksTo(1));
      });
      SOUL_EXTRACTOR = HELPER.register("soul_extractor", () -> {
         return new SoulExtractorItem((new Properties()).durability(128));
      });
      MAGIC_WAND = HELPER.register("magic_wand", () -> {
         return new MagicWandItem((new Properties()).stacksTo(1).component(ModDataComponents.SHOWS_AUREAL_METER, Unit.INSTANCE).component(ModDataComponents.AUREAL_COST, new AurealCost(5)).component(ModDataComponents.WAND_PARTS, new WandParts(new WandPart(Component.literal("Aurum Wood"), new WandStats(20, 0, 0)), new WandPart(Component.literal("Deorum"), new WandStats(0, 10, 0)), new WandPart(Component.literal("Arcane Crystal"), new WandStats(0, 0, 100)))));
      });
      DRACO_ARCANUS_STAFF = HELPER.register("draco_arcanus_staff", () -> {
         return new Item((new Properties()).stacksTo(1));
      });
      DRACO_ARCANUS_SWORD = HELPER.register("draco_arcanus_sword", () -> {
         return new SwordItem(ModTiers.DRACO_ARCANUS, new Properties());
      });
      DRACO_ARCANUS_SHOVEL = HELPER.register("draco_arcanus_shovel", () -> {
         return new ShovelItem(ModTiers.DRACO_ARCANUS, new Properties());
      });
      DRACO_ARCANUS_PICKAXE = HELPER.register("draco_arcanus_pickaxe", () -> {
         return new PickaxeItem(ModTiers.DRACO_ARCANUS, new Properties());
      });
      DRACO_ARCANUS_AXE = HELPER.register("draco_arcanus_axe", () -> {
         return new AxeItem(ModTiers.DRACO_ARCANUS, new Properties());
      });
      DRACO_ARCANUS_HOE = HELPER.register("draco_arcanus_hoe", () -> {
         return new HoeItem(ModTiers.DRACO_ARCANUS, new Properties());
      });
      DRACO_ARCANUS_SCEPTER = HELPER.register("draco_arcanus_scepter", () -> {
         return new DracoArcanusScepterItem((new Properties()).stacksTo(1));
      });
      REINFORCED_DEORUM_SWORD = HELPER.register("reinforced_deorum_sword", () -> {
         return new SwordItem(ModTiers.REINFORCED_DEORUM, new Properties());
      });
      REINFORCED_DEORUM_SHOVEL = HELPER.register("reinforced_deorum_shovel", () -> {
         return new ShovelItem(ModTiers.REINFORCED_DEORUM, new Properties());
      });
      REINFORCED_DEORUM_PICKAXE = HELPER.register("reinforced_deorum_pickaxe", () -> {
         return new PickaxeItem(ModTiers.REINFORCED_DEORUM, new Properties());
      });
      REINFORCED_DEORUM_AXE = HELPER.register("reinforced_deorum_axe", () -> {
         return new AxeItem(ModTiers.REINFORCED_DEORUM, new Properties());
      });
      REINFORCED_DEORUM_HOE = HELPER.register("reinforced_deorum_hoe", () -> {
         return new HoeItem(ModTiers.REINFORCED_DEORUM, new Properties());
      });
      DRACO_ARCANUS_HELMET = HELPER.register("draco_arcanus_helmet", () -> {
         return new ArmorItem(FAArmorMaterials.DRACO_ARCANUS, Type.HELMET, (new Properties()).durability(Type.HELMET.getDurability(40)));
      });
      DRACO_ARCANUS_CHESTPLATE = HELPER.register("draco_arcanus_chestplate", () -> {
         return new ArmorItem(FAArmorMaterials.DRACO_ARCANUS, Type.CHESTPLATE, (new Properties()).durability(Type.CHESTPLATE.getDurability(40)));
      });
      DRACO_ARCANUS_LEGGINGS = HELPER.register("draco_arcanus_leggings", () -> {
         return new ArmorItem(FAArmorMaterials.DRACO_ARCANUS, Type.LEGGINGS, (new Properties()).durability(Type.LEGGINGS.getDurability(40)));
      });
      DRACO_ARCANUS_BOOTS = HELPER.register("draco_arcanus_boots", () -> {
         return new ArmorItem(FAArmorMaterials.DRACO_ARCANUS, Type.BOOTS, (new Properties()).durability(Type.BOOTS.getDurability(40)));
      });
      TYR_HELMET = HELPER.register("tyr_helmet", () -> {
         return new ArmorItem(FAArmorMaterials.TYR, Type.HELMET, (new Properties()).durability(Type.HELMET.getDurability(42)));
      });
      TYR_CHESTPLATE = HELPER.register("tyr_chestplate", () -> {
         return new ArmorItem(FAArmorMaterials.TYR, Type.CHESTPLATE, (new Properties()).durability(Type.CHESTPLATE.getDurability(42)));
      });
      TYR_LEGGINGS = HELPER.register("tyr_leggings", () -> {
         return new ArmorItem(FAArmorMaterials.TYR, Type.LEGGINGS, (new Properties()).durability(Type.LEGGINGS.getDurability(42)));
      });
      TYR_BOOTS = HELPER.register("tyr_boots", () -> {
         return new ArmorItem(FAArmorMaterials.TYR, Type.BOOTS, (new Properties()).durability(Type.BOOTS.getDurability(42)));
      });
      MORTEM_HELMET = HELPER.register("mortem_helmet", () -> {
         return new ArmorItem(FAArmorMaterials.MORTEM, Type.HELMET, new Properties());
      });
      MORTEM_CHESTPLATE = HELPER.register("mortem_chestplate", () -> {
         return new ArmorItem(FAArmorMaterials.MORTEM, Type.CHESTPLATE, new Properties());
      });
      MORTEM_LEGGINGS = HELPER.register("mortem_leggings", () -> {
         return new ArmorItem(FAArmorMaterials.MORTEM, Type.LEGGINGS, new Properties());
      });
      MORTEM_BOOTS = HELPER.register("mortem_boots", () -> {
         return new ArmorItem(FAArmorMaterials.MORTEM, Type.BOOTS, new Properties());
      });
   }
}
