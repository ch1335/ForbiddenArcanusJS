package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.item.crafting.ClibanoRecipe;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModRecipeTypes implements RegistryClass {
   public static final MappedRegistryHelper<RecipeType<?>> HELPER;
   public static final RegistryEntry<RecipeType<?>, RecipeType<ClibanoRecipe>> CLIBANO_COMBUSTION;

   static <T extends Recipe<?>> RegistryEntry<RecipeType<?>, RecipeType<T>> registerRecipeType(String name) {
      return HELPER.register(name, () -> {
         return new RecipeType<T>() {
            public String toString() {
               return name;
            }
         };
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.RECIPE_TYPE);
      CLIBANO_COMBUSTION = registerRecipeType("clibano_combustion");
   }
}
