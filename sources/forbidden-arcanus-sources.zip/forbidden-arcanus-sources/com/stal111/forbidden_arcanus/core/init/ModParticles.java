package com.stal111.forbidden_arcanus.core.init;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.particle.EssenceDropParticleOption;
import java.util.function.Function;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;
import org.jetbrains.annotations.NotNull;

public class ModParticles implements RegistryClass {
   public static final MappedRegistryHelper<ParticleType<?>> HELPER;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> SOUL;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> AUREAL_MOTE;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> MAGIC_EXPLOSION;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> HUGE_MAGIC_EXPLOSION;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> MAGNETIC_GLOW;
   public static final RegistryEntry<ParticleType<?>, ParticleType<EssenceDropParticleOption>> AUREAL_DROP;
   public static final RegistryEntry<ParticleType<?>, ParticleType<EssenceDropParticleOption>> SOULS_DROP;
   public static final RegistryEntry<ParticleType<?>, ParticleType<EssenceDropParticleOption>> BLOOD_DROP;
   public static final RegistryEntry<ParticleType<?>, ParticleType<EssenceDropParticleOption>> EXPERIENCE_DROP;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> MAGIC_GLINT;
   public static final RegistryEntry<ParticleType<?>, SimpleParticleType> MAGIC_HIT;
   public static final RegistryEntry<ParticleType<?>, ParticleType<ColorParticleOption>> SPELL_EXPLOSION;

   private static <T extends ParticleOptions> RegistryEntry<ParticleType<?>, ParticleType<T>> register(String name, boolean overrideLimiter, Function<ParticleType<T>, MapCodec<T>> codec, Function<ParticleType<T>, StreamCodec<? super RegistryFriendlyByteBuf, T>> streamCodec) {
      return HELPER.register(name, () -> {
         return new ParticleType<T>(overrideLimiter) {
            @NotNull
            public MapCodec<T> codec() {
               return (MapCodec)codec.apply(this);
            }

            @NotNull
            public StreamCodec<? super RegistryFriendlyByteBuf, T> streamCodec() {
               return (StreamCodec)streamCodec.apply(this);
            }
         };
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.PARTICLE_TYPE);
      SOUL = HELPER.register("soul", () -> {
         return new SimpleParticleType(false);
      });
      AUREAL_MOTE = HELPER.register("aureal_mote", () -> {
         return new SimpleParticleType(false);
      });
      MAGIC_EXPLOSION = HELPER.register("magic_explosion", () -> {
         return new SimpleParticleType(true);
      });
      HUGE_MAGIC_EXPLOSION = HELPER.register("magic_explosion_emitter", () -> {
         return new SimpleParticleType(true);
      });
      MAGNETIC_GLOW = HELPER.register("magnetic_glow", () -> {
         return new SimpleParticleType(true);
      });
      AUREAL_DROP = register("aureal_drop", true, (type) -> {
         return EssenceDropParticleOption.CODEC;
      }, (type) -> {
         return EssenceDropParticleOption.STREAM_CODEC;
      });
      SOULS_DROP = register("souls_drop", true, (type) -> {
         return EssenceDropParticleOption.CODEC;
      }, (type) -> {
         return EssenceDropParticleOption.STREAM_CODEC;
      });
      BLOOD_DROP = register("blood_drop", true, (type) -> {
         return EssenceDropParticleOption.CODEC;
      }, (type) -> {
         return EssenceDropParticleOption.STREAM_CODEC;
      });
      EXPERIENCE_DROP = register("experience_drop", true, (type) -> {
         return EssenceDropParticleOption.CODEC;
      }, (type) -> {
         return EssenceDropParticleOption.STREAM_CODEC;
      });
      MAGIC_GLINT = HELPER.register("magic_glint", () -> {
         return new SimpleParticleType(false);
      });
      MAGIC_HIT = HELPER.register("magic_hit", () -> {
         return new SimpleParticleType(false);
      });
      SPELL_EXPLOSION = register("spell_explosion", true, ColorParticleOption::codec, ColorParticleOption::streamCodec);
   }
}
