package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.entity.CrimsonLightningBoltEntity;
import com.stal111.forbidden_arcanus.common.entity.ModBoat;
import com.stal111.forbidden_arcanus.common.entity.ModChestBoat;
import com.stal111.forbidden_arcanus.common.entity.darktrader.DarkTrader;
import com.stal111.forbidden_arcanus.common.entity.lostsoul.CorruptLostSoul;
import com.stal111.forbidden_arcanus.common.entity.lostsoul.EnchantedLostSoul;
import com.stal111.forbidden_arcanus.common.entity.lostsoul.LostSoul;
import com.stal111.forbidden_arcanus.common.entity.projectile.AurealMissile;
import com.stal111.forbidden_arcanus.common.entity.projectile.BoomArrow;
import com.stal111.forbidden_arcanus.common.entity.projectile.DracoArcanusArrow;
import com.stal111.forbidden_arcanus.common.entity.projectile.EnergyBall;
import com.stal111.forbidden_arcanus.common.entity.projectile.ThrownAurealBottle;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraft.world.flag.FeatureFlag;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.EntityRegistryHelper;

public class ModEntities implements RegistryClass {
   public static final EntityRegistryHelper HELPER;
   public static final RegistryEntry<EntityType<?>, EntityType<EnergyBall>> ENERGY_BALL;
   public static final RegistryEntry<EntityType<?>, EntityType<BoomArrow>> BOOM_ARROW;
   public static final RegistryEntry<EntityType<?>, EntityType<DracoArcanusArrow>> DRACO_ARCANUS_ARROW;
   public static final RegistryEntry<EntityType<?>, EntityType<CrimsonLightningBoltEntity>> CRIMSON_LIGHTNING_BOLT;
   public static final RegistryEntry<EntityType<?>, EntityType<ModBoat>> BOAT;
   public static final RegistryEntry<EntityType<?>, EntityType<ModChestBoat>> CHEST_BOAT;
   public static final RegistryEntry<EntityType<?>, EntityType<LostSoul>> LOST_SOUL;
   public static final RegistryEntry<EntityType<?>, EntityType<CorruptLostSoul>> CORRUPT_LOST_SOUL;
   public static final RegistryEntry<EntityType<?>, EntityType<EnchantedLostSoul>> ENCHANTED_LOST_SOUL;
   public static final RegistryEntry<EntityType<?>, EntityType<ThrownAurealBottle>> AUREAL_BOTTLE;
   public static final RegistryEntry<EntityType<?>, EntityType<DarkTrader>> DARK_TRADER;
   public static final RegistryEntry<EntityType<?>, EntityType<AurealMissile>> AUREAL_MISSILE;

   static {
      HELPER = (EntityRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.ENTITY_TYPE);
      ENERGY_BALL = HELPER.register("energy_ball", Builder.of(EnergyBall::new, MobCategory.MISC).sized(1.0F, 1.0F).setTrackingRange(64));
      BOOM_ARROW = HELPER.register("boom_arrow", Builder.of(BoomArrow::new, MobCategory.MISC).sized(0.5F, 0.5F).clientTrackingRange(4).updateInterval(20));
      DRACO_ARCANUS_ARROW = HELPER.register("draco_arcanus_arrow", Builder.of(DracoArcanusArrow::new, MobCategory.MISC).sized(0.5F, 0.5F).clientTrackingRange(4).updateInterval(20));
      CRIMSON_LIGHTNING_BOLT = HELPER.register("crimson_lightning_bolt", Builder.of(CrimsonLightningBoltEntity::new, MobCategory.MISC).sized(0.0F, 0.0F).setTrackingRange(16).updateInterval(Integer.MAX_VALUE));
      BOAT = HELPER.register("boat", Builder.of(ModBoat::new, MobCategory.MISC).sized(1.375F, 0.5625F).clientTrackingRange(10));
      CHEST_BOAT = HELPER.register("chest_boat", Builder.of(ModChestBoat::new, MobCategory.MISC).sized(1.375F, 0.5625F).clientTrackingRange(10));
      LOST_SOUL = HELPER.register("lost_soul", Builder.of(LostSoul::new, MobCategory.CREATURE).sized(0.35F, 0.6F).clientTrackingRange(8));
      CORRUPT_LOST_SOUL = HELPER.register("corrupt_lost_soul", Builder.of(CorruptLostSoul::new, MobCategory.CREATURE).sized(0.35F, 0.6F).clientTrackingRange(8));
      ENCHANTED_LOST_SOUL = HELPER.register("enchanted_lost_soul", Builder.of(EnchantedLostSoul::new, MobCategory.CREATURE).sized(0.35F, 0.6F).clientTrackingRange(8));
      AUREAL_BOTTLE = HELPER.register("aureal_bottle", Builder.of(ThrownAurealBottle::new, MobCategory.MISC).sized(0.25F, 0.25F).clientTrackingRange(4).updateInterval(10));
      DARK_TRADER = HELPER.register("dark_trader", Builder.of(DarkTrader::new, MobCategory.CREATURE).requiredFeatures(new FeatureFlag[0]).sized(0.35F, 0.6F).clientTrackingRange(8));
      AUREAL_MISSILE = HELPER.register("aureal_missile", Builder.of(AurealMissile::new, MobCategory.MISC).sized(0.4F, 0.4F).clientTrackingRange(4).updateInterval(10));
   }
}
