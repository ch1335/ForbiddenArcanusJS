package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.input.EssenceDataInput;
import com.stal111.forbidden_arcanus.common.block.entity.forge.input.EssenceStorageInput;
import com.stal111.forbidden_arcanus.common.block.entity.forge.input.ExtractEnchantmentsInput;
import com.stal111.forbidden_arcanus.common.block.entity.forge.input.HephaestusForgeInput;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.minecraft.core.Holder;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModForgeInputTypes implements RegistryClass {
   public static final MappedRegistryHelper<HephaestusForgeInput> HELPER;
   public static final Holder<HephaestusForgeInput> SIMPLE_ITEM;
   public static final Holder<HephaestusForgeInput> EXTRACT_ENCHANTMENTS;
   public static final Holder<HephaestusForgeInput> ESSENCE_STORAGE;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.FORGE_INPUT);
      SIMPLE_ITEM = HELPER.register("essence_data", EssenceDataInput::new);
      EXTRACT_ENCHANTMENTS = HELPER.register("extract_enchantments", ExtractEnchantmentsInput::new);
      ESSENCE_STORAGE = HELPER.register("essence_storage", EssenceStorageInput::new);
   }
}
