package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.world.level.block.state.properties.WoodType;

public class ModWoodTypes {
   public static final WoodType FUNGYSS;
   public static final WoodType AURUM;
   public static final WoodType EDELWOOD;

   public static void registerWoodTypes() {
      WoodType.register(FUNGYSS);
      WoodType.register(AURUM);
      WoodType.register(EDELWOOD);
   }

   static {
      FUNGYSS = new WoodType(ForbiddenArcanus.location("fungyss").toString(), ModBlocks.BlockSetTypes.FUNGYSS);
      AURUM = new WoodType(ForbiddenArcanus.location("aurum").toString(), ModBlocks.BlockSetTypes.AURUM);
      EDELWOOD = new WoodType(ForbiddenArcanus.location("edelwood").toString(), ModBlocks.BlockSetTypes.EDELWOOD);
   }
}
