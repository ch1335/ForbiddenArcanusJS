package com.stal111.forbidden_arcanus.core.init;

import com.mojang.datafixers.types.Type;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.ArcaneCrystalObeliskBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.BlackHoleBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.EssenceUtremJarBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.ObsidianSkullBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.PedestalBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.QuantumInjectorBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFrameBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoMainBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.desk.ResearchDeskBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.forge.HephaestusForgeBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntityType.Builder;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModBlockEntities implements RegistryClass {
   public static final MappedRegistryHelper<BlockEntityType<?>> HELPER;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<BlackHoleBlockEntity>> BLACK_HOLE;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<ObsidianSkullBlockEntity>> OBSIDIAN_SKULL;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<EssenceUtremJarBlockEntity>> ESSENCE_UTREM_JAR;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<HephaestusForgeBlockEntity>> HEPHAESTUS_FORGE;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<PedestalBlockEntity>> PEDESTAL;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<ArcaneCrystalObeliskBlockEntity>> ARCANE_CRYSTAL_OBELISK;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<ClibanoMainBlockEntity>> CLIBANO_MAIN;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<ClibanoFrameBlockEntity>> CLIBANO;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<ResearchDeskBlockEntity>> RESEARCH_DESK;
   public static final RegistryEntry<BlockEntityType<?>, BlockEntityType<QuantumInjectorBlockEntity>> QUANTUM_INJECTOR;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.BLOCK_ENTITY_TYPE);
      BLACK_HOLE = HELPER.register("black_hole", () -> {
         return Builder.of(BlackHoleBlockEntity::new, new Block[]{(Block)ModBlocks.BLACK_HOLE.get()}).build((Type)null);
      });
      OBSIDIAN_SKULL = HELPER.register("obsidian_skull", () -> {
         return Builder.of(ObsidianSkullBlockEntity::new, new Block[]{ModBlocks.OBSIDIAN_SKULL.getSkull(), ModBlocks.OBSIDIAN_SKULL.getWallSkull(), ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull(), ModBlocks.CRACKED_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull(), ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.FADING_OBSIDIAN_SKULL.getSkull(), ModBlocks.FADING_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.AUREALIC_OBSIDIAN_SKULL.getSkull(), ModBlocks.AUREALIC_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.ETERNAL_OBSIDIAN_SKULL.getSkull(), ModBlocks.ETERNAL_OBSIDIAN_SKULL.getWallSkull()}).build((Type)null);
      });
      ESSENCE_UTREM_JAR = HELPER.register("essence_utrem_jar", () -> {
         return Builder.of(EssenceUtremJarBlockEntity::new, new Block[]{(Block)ModBlocks.ESSENCE_UTREM_JAR.get()}).build((Type)null);
      });
      HEPHAESTUS_FORGE = HELPER.register("hephaestus_forge", () -> {
         return Builder.of(HephaestusForgeBlockEntity::new, new Block[]{(Block)ModBlocks.HEPHAESTUS_FORGE_TIER_1.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_2.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_3.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_4.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_5.get()}).build((Type)null);
      });
      PEDESTAL = HELPER.register("pedestal", () -> {
         return Builder.of(PedestalBlockEntity::new, new Block[]{(Block)ModBlocks.DARKSTONE_PEDESTAL.get(), (Block)ModBlocks.MAGNETIZED_DARKSTONE_PEDESTAL.get()}).build((Type)null);
      });
      ARCANE_CRYSTAL_OBELISK = HELPER.register("arcane_crystal_obelisk", () -> {
         return Builder.of(ArcaneCrystalObeliskBlockEntity::new, new Block[]{(Block)ModBlocks.ARCANE_CRYSTAL_OBELISK.get(), (Block)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_OBELISK.get()}).build((Type)null);
      });
      CLIBANO_MAIN = HELPER.register("clibano_main", () -> {
         return Builder.of(ClibanoMainBlockEntity::new, new Block[]{(Block)ModBlocks.CLIBANO_MAIN_PART.get()}).build((Type)null);
      });
      CLIBANO = HELPER.register("clibano", () -> {
         return Builder.of(ClibanoFrameBlockEntity::new, new Block[]{(Block)ModBlocks.CLIBANO_CORNER.get(), (Block)ModBlocks.CLIBANO_CENTER.get(), (Block)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get(), (Block)ModBlocks.CLIBANO_SIDE_VERTICAL.get()}).build((Type)null);
      });
      RESEARCH_DESK = HELPER.register("research_desk", () -> {
         return Builder.of(ResearchDeskBlockEntity::new, new Block[]{(Block)ModBlocks.RESEARCH_DESK.get()}).build((Type)null);
      });
      QUANTUM_INJECTOR = HELPER.register("quantum_injector", () -> {
         return Builder.of(QuantumInjectorBlockEntity::new, new Block[]{(Block)ModBlocks.QUANTUM_INJECTOR.get()}).build((Type)null);
      });
   }
}
