package com.stal111.forbidden_arcanus.core.init;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import java.util.Optional;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModMemoryModules implements RegistryClass {
   public static final MappedRegistryHelper<MemoryModuleType<?>> HELPER;
   public static final RegistryEntry<MemoryModuleType<?>, MemoryModuleType<Integer>> SCARED_TIME;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.MEMORY_MODULE_TYPE);
      SCARED_TIME = HELPER.register("scared_time", () -> {
         return new MemoryModuleType(Optional.of(Codec.INT));
      });
   }
}
