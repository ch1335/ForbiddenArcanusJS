package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.world.level.ItemLike;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.CompostableHelper;

public class CompostableRegistry {
   private static final CompostableHelper HELPER = CompostableHelper.get();

   public static void register() {
      HELPER.register03((ItemLike)ModBlocks.AURUM_LEAVES.get());
      HELPER.register03((ItemLike)ModBlocks.NUGGETY_AURUM_LEAVES.get());
      HELPER.register03((ItemLike)ModBlocks.FUNGYSS.get());
      HELPER.register03((ItemLike)ModBlocks.AURUM_SAPLING.get());
      HELPER.register065((ItemLike)ModBlocks.YELLOW_ORCHID.get());
   }
}
