package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.inventory.HephaestusForgeMenu;
import com.stal111.forbidden_arcanus.common.inventory.clibano.ClibanoMenu;
import com.stal111.forbidden_arcanus.common.inventory.research.ResearchDeskMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.network.IContainerFactory;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModMenuTypes implements RegistryClass {
   public static final MappedRegistryHelper<MenuType<?>> HELPER;
   public static final RegistryEntry<MenuType<?>, MenuType<HephaestusForgeMenu>> HEPHAESTUS_FORGE;
   public static final RegistryEntry<MenuType<?>, MenuType<ClibanoMenu>> CLIBANO;
   public static final RegistryEntry<MenuType<?>, MenuType<ResearchDeskMenu>> RESEARCH_DESK;

   private static <T extends AbstractContainerMenu> RegistryEntry<MenuType<?>, MenuType<T>> register(String name, IContainerFactory<T> factory) {
      return HELPER.register(name, () -> {
         return IMenuTypeExtension.create(factory);
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.MENU);
      HEPHAESTUS_FORGE = register("hephaestus_forge", HephaestusForgeMenu::new);
      CLIBANO = register("clibano", ClibanoMenu::new);
      RESEARCH_DESK = register("research_desk", ResearchDeskMenu::new);
   }
}
