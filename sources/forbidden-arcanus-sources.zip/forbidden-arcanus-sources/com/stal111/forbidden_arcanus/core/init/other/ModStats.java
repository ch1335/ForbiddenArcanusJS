package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.stats.StatFormatter;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModStats {
   public static final MappedRegistryHelper<ResourceLocation> HELPER;
   public static final RegistryEntry<ResourceLocation, ResourceLocation> INTERACT_WITH_PEDESTAL;

   public static RegistryEntry<ResourceLocation, ResourceLocation> register(String name, StatFormatter formatter) {
      ResourceLocation resourceLocation = ForbiddenArcanus.location(name);
      return HELPER.register(name, () -> {
         return resourceLocation;
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.CUSTOM_STAT);
      INTERACT_WITH_PEDESTAL = register("interact_with_pedestal", StatFormatter.DEFAULT);
   }
}
