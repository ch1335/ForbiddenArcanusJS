package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModSounds implements RegistryClass {
   public static final MappedRegistryHelper<SoundEvent> HELPER;
   public static final RegistryEntry<SoundEvent, SoundEvent> ENERGY_BALL_LAUNCH;
   public static final RegistryEntry<SoundEvent, SoundEvent> ENERGY_BALL_HIT;
   public static final RegistryEntry<SoundEvent, SoundEvent> QUANTUM_CATCHER_PICK_UP;
   public static final RegistryEntry<SoundEvent, SoundEvent> QUANTUM_CATCHER_RELEASE;
   public static final RegistryEntry<SoundEvent, SoundEvent> FERROGNETIC_MIXTURE_APPLY;
   public static final RegistryEntry<SoundEvent, SoundEvent> CLIBANO_FIRE_CRACKLE;
   public static final RegistryEntry<SoundEvent, SoundEvent> CLIBANO_SOUL_FIRE_CRACKLE;
   public static final RegistryEntry<SoundEvent, SoundEvent> BLACKSMITH_GAVEL_RITUAL_START;
   public static final RegistryEntry<SoundEvent, SoundEvent> FORBIDDENOMICON_OPEN;
   public static final RegistryEntry<SoundEvent, SoundEvent> FORBIDDENOMICON_CLOSE;
   public static final RegistryEntry<SoundEvent, SoundEvent> MUNDABITUR_DUST_USE;
   public static final RegistryEntry<SoundEvent, SoundEvent> PEDESTAL_INTERACT;
   public static final RegistryEntry<SoundEvent, SoundEvent> OBSIDIAN_SKULL_CRACK;
   public static final RegistryEntry<SoundEvent, SoundEvent> MAGIC_WAND_CAST;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.SOUND_EVENT);
      ENERGY_BALL_LAUNCH = HELPER.register("energy_ball_launch", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("entity.energy_ball.launch"));
      });
      ENERGY_BALL_HIT = HELPER.register("energy_ball_hit", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("entity.energy_ball.hit"));
      });
      QUANTUM_CATCHER_PICK_UP = HELPER.register("quantum_catcher_pick_up", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.quantum_catcher.pick_up"));
      });
      QUANTUM_CATCHER_RELEASE = HELPER.register("quantum_catcher_release", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.quantum_catcher.release"));
      });
      FERROGNETIC_MIXTURE_APPLY = HELPER.register("ferrognetic_mixture_apply", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.ferrognetic_mixture.apply"));
      });
      CLIBANO_FIRE_CRACKLE = HELPER.register("clibano_fire_crackle", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("block.clibano.fire_crackle"));
      });
      CLIBANO_SOUL_FIRE_CRACKLE = HELPER.register("clibano_soul_fire_crackle", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("block.clibano.soul_fire_crackle"));
      });
      BLACKSMITH_GAVEL_RITUAL_START = HELPER.register("blacksmith_gavel_ritual_start", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.blacksmith_gavel.ritual_start"));
      });
      FORBIDDENOMICON_OPEN = HELPER.register("forbiddenomicon_open", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.forbiddenomicon.open"));
      });
      FORBIDDENOMICON_CLOSE = HELPER.register("forbiddenomicon_close", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.forbiddenomicon.close"));
      });
      MUNDABITUR_DUST_USE = HELPER.register("mundabitur_dust_use", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.mundabitur_dust.use"));
      });
      PEDESTAL_INTERACT = HELPER.register("pedestal_interact", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("block.pedestal.interact"));
      });
      OBSIDIAN_SKULL_CRACK = HELPER.register("obsidian_skull_crack", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("block.obsidian_skull.crack"));
      });
      MAGIC_WAND_CAST = HELPER.register("magic_wand_cast", () -> {
         return SoundEvent.createVariableRangeEvent(ForbiddenArcanus.location("item.magic_wand.cast"));
      });
   }
}
