package com.stal111.forbidden_arcanus.core.init;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.CreateItemResult;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.RitualResult;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.RitualResultType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.TransmuteInputResult;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.UpgradeTierResult;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModRitualResultTypes implements RegistryClass {
   public static final MappedRegistryHelper<RitualResultType<?>> HELPER;
   public static final RegistryEntry<RitualResultType<?>, RitualResultType<CreateItemResult>> CREATE_ITEM;
   public static final RegistryEntry<RitualResultType<?>, RitualResultType<UpgradeTierResult>> UPGRADE_TIER;
   public static final RegistryEntry<RitualResultType<?>, RitualResultType<TransmuteInputResult>> TRANSMUTE_INPUT;

   public static <T extends RitualResult> RegistryEntry<RitualResultType<?>, RitualResultType<T>> register(String name, MapCodec<T> codec) {
      return HELPER.register(name, () -> {
         return new RitualResultType(codec);
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.RITUAL_RESULT_TYPE);
      CREATE_ITEM = register("create_item", CreateItemResult.CODEC);
      UPGRADE_TIER = register("upgrade_tier", UpgradeTierResult.CODEC);
      TRANSMUTE_INPUT = register("transmute_input", TransmuteInputResult.CODEC);
   }
}
