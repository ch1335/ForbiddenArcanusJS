package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.effect.SpectralEyeEffect;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModMobEffects {
   public static final MappedRegistryHelper<MobEffect> HELPER;
   public static final RegistryEntry<MobEffect, SpectralEyeEffect> SPECTRAL_VISION;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.MOB_EFFECT);
      SPECTRAL_VISION = HELPER.register("spectral_vision", () -> {
         return new SpectralEyeEffect(MobEffectCategory.BENEFICIAL, 745784);
      });
   }
}
