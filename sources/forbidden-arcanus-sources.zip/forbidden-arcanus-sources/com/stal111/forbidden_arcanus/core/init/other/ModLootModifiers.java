package com.stal111.forbidden_arcanus.core.init.other;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.loot.BlacksmithGavelLootModifier;
import com.stal111.forbidden_arcanus.common.loot.FieryLootModifier;
import com.stal111.forbidden_arcanus.common.loot.MagicalFarmlandLootModifier;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.registries.NeoForgeRegistries.Keys;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModLootModifiers implements RegistryClass {
   public static final MappedRegistryHelper<MapCodec<? extends IGlobalLootModifier>> HELPER;
   public static final RegistryEntry<MapCodec<? extends IGlobalLootModifier>, MapCodec<BlacksmithGavelLootModifier>> BLACKSMITH_GAVEL;
   public static final RegistryEntry<MapCodec<? extends IGlobalLootModifier>, MapCodec<FieryLootModifier>> FIERY;
   public static final RegistryEntry<MapCodec<? extends IGlobalLootModifier>, MapCodec<MagicalFarmlandLootModifier>> MAGICAL_FARMLAND;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS);
      BLACKSMITH_GAVEL = HELPER.register("blacksmith_gavel", BlacksmithGavelLootModifier.CODEC);
      FIERY = HELPER.register("fiery", FieryLootModifier.CODEC);
      MAGICAL_FARMLAND = HELPER.register("magical_farmland", MagicalFarmlandLootModifier.CODEC);
   }
}
