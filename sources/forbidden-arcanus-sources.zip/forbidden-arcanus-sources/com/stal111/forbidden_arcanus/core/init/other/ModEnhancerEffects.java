package com.stal111.forbidden_arcanus.core.init.other;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerTarget;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.ConditionalEnhancerEffect;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.EnhancerEffect;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.EnhancerEffectType;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.ModifyRequiredEssenceEffect;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.MultiplyRequiredEssenceEffect;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.MultiplySoulDurationEffect;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModEnhancerEffects implements RegistryClass {
   public static final MappedRegistryHelper<EnhancerEffectType<?>> HELPER;
   public static final RegistryEntry<EnhancerEffectType<?>, EnhancerEffectType<MultiplyRequiredEssenceEffect>> MULTIPLY_REQUIRED_ESSENCE;
   public static final RegistryEntry<EnhancerEffectType<?>, EnhancerEffectType<ModifyRequiredEssenceEffect>> MODIFY_REQUIRED_ESSENCE;
   public static final RegistryEntry<EnhancerEffectType<?>, EnhancerEffectType<MultiplySoulDurationEffect>> MULTIPLY_SOUL_DURATION;

   public static <T extends EnhancerEffect> RegistryEntry<EnhancerEffectType<?>, EnhancerEffectType<T>> register(String name, MapCodec<ConditionalEnhancerEffect<T>> codec, EnhancerTarget target) {
      return HELPER.register(name, () -> {
         return new EnhancerEffectType(codec, target);
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.ENHANCER_EFFECT);
      MULTIPLY_REQUIRED_ESSENCE = register("multiply_required_essence", ConditionalEnhancerEffect.codec(MultiplyRequiredEssenceEffect.CODEC), EnhancerTarget.HEPHAESTUS_FORGE);
      MODIFY_REQUIRED_ESSENCE = register("modify_required_essence", ConditionalEnhancerEffect.codec(ModifyRequiredEssenceEffect.CODEC), EnhancerTarget.HEPHAESTUS_FORGE);
      MULTIPLY_SOUL_DURATION = register("multiply_soul_duration", ConditionalEnhancerEffect.codec(MultiplySoulDurationEffect.CODEC), EnhancerTarget.CLIBANO);
   }
}
