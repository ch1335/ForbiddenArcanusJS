package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.common.block.dispenser.ArcaneBoneMealDispenseBehavior;
import com.stal111.forbidden_arcanus.common.block.dispenser.SoulDispenseBehavior;
import com.stal111.forbidden_arcanus.common.item.ObsidianSkullItem;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.DispenserBlock;

public class ModDispenseBehaviors {
   public static void registerDispenseBehaviors() {
      DispenserBlock.registerBehavior((ItemLike)ModItems.SOUL.get(), new SoulDispenseBehavior());
      DispenserBlock.registerBehavior(ModBlocks.OBSIDIAN_SKULL.getSkull(), ObsidianSkullItem.DISPENSE_ITEM_BEHAVIOR);
      DispenserBlock.registerBehavior(ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull(), ObsidianSkullItem.DISPENSE_ITEM_BEHAVIOR);
      DispenserBlock.registerBehavior(ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull(), ObsidianSkullItem.DISPENSE_ITEM_BEHAVIOR);
      DispenserBlock.registerBehavior(ModBlocks.FADING_OBSIDIAN_SKULL.getSkull(), ObsidianSkullItem.DISPENSE_ITEM_BEHAVIOR);
      DispenserBlock.registerBehavior(ModBlocks.AUREALIC_OBSIDIAN_SKULL.getSkull(), ObsidianSkullItem.DISPENSE_ITEM_BEHAVIOR);
      DispenserBlock.registerBehavior(ModBlocks.ETERNAL_OBSIDIAN_SKULL.getSkull(), ObsidianSkullItem.DISPENSE_ITEM_BEHAVIOR);
      DispenserBlock.registerProjectileBehavior((ItemLike)ModItems.BOOM_ARROW.get());
      DispenserBlock.registerProjectileBehavior((ItemLike)ModItems.DRACO_ARCANUS_ARROW.get());
      DispenserBlock.registerBehavior((ItemLike)ModItems.ARCANE_BONE_MEAL.get(), new ArcaneBoneMealDispenseBehavior());
   }
}
