package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.ArcaneCrystalObeliskBlock;
import com.stal111.forbidden_arcanus.common.block.ArcaneDragonEggBlock;
import com.stal111.forbidden_arcanus.common.block.BlackHoleBlock;
import com.stal111.forbidden_arcanus.common.block.CarvedEdelwoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.DeskBlock;
import com.stal111.forbidden_arcanus.common.block.EdelwoodBranchBlock;
import com.stal111.forbidden_arcanus.common.block.EdelwoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.EssenceUtremJarBlock;
import com.stal111.forbidden_arcanus.common.block.ForbiddenomiconBlock;
import com.stal111.forbidden_arcanus.common.block.FungyssBlock;
import com.stal111.forbidden_arcanus.common.block.GrowingEdelwoodBlock;
import com.stal111.forbidden_arcanus.common.block.HephaestusForgeBlock;
import com.stal111.forbidden_arcanus.common.block.MagicalFarmlandBlock;
import com.stal111.forbidden_arcanus.common.block.MortarBlock;
import com.stal111.forbidden_arcanus.common.block.MysterywoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.PillarBlock;
import com.stal111.forbidden_arcanus.common.block.QuantumInjectorBlock;
import com.stal111.forbidden_arcanus.common.block.ResearchDeskBlock;
import com.stal111.forbidden_arcanus.common.block.SoullessSandBlock;
import com.stal111.forbidden_arcanus.common.block.StellaArcanumBlock;
import com.stal111.forbidden_arcanus.common.block.UpwindBlock;
import com.stal111.forbidden_arcanus.common.block.UtremJarBlock;
import com.stal111.forbidden_arcanus.common.block.WhirlwindBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoCenterBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoCoreBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoCornerBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoMainPartBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoSideBlock;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFireType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.HephaestusForgeLevel;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.block.grower.FATreeGrower;
import com.stal111.forbidden_arcanus.common.block.pedestal.MagnetizedPedestalBlock;
import com.stal111.forbidden_arcanus.common.block.pedestal.PedestalBlock;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.clibano.ClibanoCenterType;
import com.stal111.forbidden_arcanus.common.block.skull.ObsidianSkullBlock;
import com.stal111.forbidden_arcanus.common.block.skull.ObsidianSkullType;
import com.stal111.forbidden_arcanus.common.block.skull.ObsidianWallSkullBlock;
import com.stal111.forbidden_arcanus.common.item.ObsidianSkullItem;
import com.stal111.forbidden_arcanus.common.item.component.EffectGrantingRule;
import com.stal111.forbidden_arcanus.core.init.other.ModWoodTypes;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.ChainBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.HeavyCoreBlock;
import net.minecraft.world.level.block.HugeMushroomBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.TransparentBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.valhelsia.valhelsia_core.api.client.ValhelsiaRenderType;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.BlockRegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.BlockRegistryHelper;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.SkullRegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.ToolTier;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.ToolType;
import net.valhelsia.valhelsia_core.api.common.registry.helper.block.SkullRegistryEntry.SkullItemFactory;

public class ModBlocks implements RegistryClass {
   public static final BlockRegistryHelper HELPER;
   public static final BlockRegistryEntry<ForbiddenomiconBlock> FORBIDDENOMICON;
   public static final BlockRegistryEntry<Block> DARKSTONE;
   public static final BlockRegistryEntry<SlabBlock> DARKSTONE_SLAB;
   public static final BlockRegistryEntry<StairBlock> DARKSTONE_STAIRS;
   public static final BlockRegistryEntry<WallBlock> DARKSTONE_WALL;
   public static final BlockRegistryEntry<Block> POLISHED_DARKSTONE;
   public static final BlockRegistryEntry<SlabBlock> POLISHED_DARKSTONE_SLAB;
   public static final BlockRegistryEntry<StairBlock> POLISHED_DARKSTONE_STAIRS;
   public static final BlockRegistryEntry<WallBlock> POLISHED_DARKSTONE_WALL;
   public static final BlockRegistryEntry<PressurePlateBlock> POLISHED_DARKSTONE_PRESSURE_PLATE;
   public static final BlockRegistryEntry<ButtonBlock> POLISHED_DARKSTONE_BUTTON;
   public static final BlockRegistryEntry<Block> CHISELED_POLISHED_DARKSTONE;
   public static final BlockRegistryEntry<Block> GILDED_CHISELED_POLISHED_DARKSTONE;
   public static final BlockRegistryEntry<Block> POLISHED_DARKSTONE_BRICKS;
   public static final BlockRegistryEntry<SlabBlock> POLISHED_DARKSTONE_BRICK_SLAB;
   public static final BlockRegistryEntry<StairBlock> POLISHED_DARKSTONE_BRICK_STAIRS;
   public static final BlockRegistryEntry<WallBlock> POLISHED_DARKSTONE_BRICK_WALL;
   public static final BlockRegistryEntry<Block> CRACKED_POLISHED_DARKSTONE_BRICKS;
   public static final BlockRegistryEntry<Block> TILED_POLISHED_DARKSTONE_BRICKS;
   public static final BlockRegistryEntry<Block> ARCANE_POLISHED_DARKSTONE;
   public static final BlockRegistryEntry<SlabBlock> ARCANE_POLISHED_DARKSTONE_SLAB;
   public static final BlockRegistryEntry<StairBlock> ARCANE_POLISHED_DARKSTONE_STAIRS;
   public static final BlockRegistryEntry<WallBlock> ARCANE_POLISHED_DARKSTONE_WALL;
   public static final BlockRegistryEntry<Block> CHISELED_ARCANE_POLISHED_DARKSTONE;
   public static final BlockRegistryEntry<PillarBlock> ARCANE_POLISHED_DARKSTONE_PILLAR;
   public static final BlockRegistryEntry<PedestalBlock> DARKSTONE_PEDESTAL;
   public static final BlockRegistryEntry<MagnetizedPedestalBlock> MAGNETIZED_DARKSTONE_PEDESTAL;
   public static final BlockRegistryEntry<MortarBlock> MORTAR;
   public static final BlockRegistryEntry<ClibanoCoreBlock> CLIBANO_CORE;
   public static final BlockRegistryEntry<ClibanoSideBlock> CLIBANO_SIDE_HORIZONTAL;
   public static final BlockRegistryEntry<ClibanoSideBlock> CLIBANO_SIDE_VERTICAL;
   public static final BlockRegistryEntry<ClibanoMainPartBlock> CLIBANO_MAIN_PART;
   public static final BlockRegistryEntry<ClibanoCornerBlock> CLIBANO_CORNER;
   public static final BlockRegistryEntry<ClibanoCenterBlock> CLIBANO_CENTER;
   public static final BlockRegistryEntry<StellaArcanumBlock> STELLA_ARCANUM;
   public static final BlockRegistryEntry<DropExperienceBlock> ARCANE_CRYSTAL_ORE;
   public static final BlockRegistryEntry<DropExperienceBlock> DEEPSLATE_ARCANE_CRYSTAL_ORE;
   public static final BlockRegistryEntry<DropExperienceBlock> RUNIC_STONE;
   public static final BlockRegistryEntry<DropExperienceBlock> RUNIC_DEEPSLATE;
   public static final BlockRegistryEntry<DropExperienceBlock> RUNIC_DARKSTONE;
   public static final BlockRegistryEntry<Block> OBSIDIANSTEEL_BLOCK;
   public static final BlockRegistryEntry<Block> DEORUM_BLOCK;
   public static final BlockRegistryEntry<Block> STELLARITE_BLOCK;
   public static final BlockRegistryEntry<Block> ARCANE_CRYSTAL_BLOCK;
   public static final BlockRegistryEntry<Block> CORRUPTED_ARCANE_CRYSTAL_BLOCK;
   public static final BlockRegistryEntry<Block> RUNE_BLOCK;
   public static final BlockRegistryEntry<TransparentBlock> DEORUM_GLASS;
   public static final BlockRegistryEntry<TransparentBlock> RUNIC_GLASS;
   public static final BlockRegistryEntry<IronBarsBlock> DEORUM_GLASS_PANE;
   public static final BlockRegistryEntry<IronBarsBlock> RUNIC_GLASS_PANE;
   public static final BlockRegistryEntry<LanternBlock> DEORUM_LANTERN;
   public static final BlockRegistryEntry<LanternBlock> DEORUM_SOUL_LANTERN;
   public static final BlockRegistryEntry<SoullessSandBlock> SOULLESS_SAND;
   public static final BlockRegistryEntry<Block> SOULLESS_SANDSTONE;
   public static final BlockRegistryEntry<Block> CUT_SOULLESS_SANDSTONE;
   public static final BlockRegistryEntry<Block> POLISHED_SOULLESS_SANDSTONE;
   public static final BlockRegistryEntry<SlabBlock> SOULLESS_SANDSTONE_SLAB;
   public static final BlockRegistryEntry<SlabBlock> CUT_SOULLESS_SANDSTONE_SLAB;
   public static final BlockRegistryEntry<SlabBlock> POLISHED_SOULLESS_SANDSTONE_SLAB;
   public static final BlockRegistryEntry<StairBlock> SOULLESS_SANDSTONE_STAIRS;
   public static final BlockRegistryEntry<StairBlock> POLISHED_SOULLESS_SANDSTONE_STAIRS;
   public static final BlockRegistryEntry<WallBlock> SOULLESS_SANDSTONE_WALL;
   public static final BlockRegistryEntry<FungyssBlock> FUNGYSS;
   public static final BlockRegistryEntry<SaplingBlock> AURUM_SAPLING;
   public static final BlockRegistryEntry<GrowingEdelwoodBlock> GROWING_EDELWOOD;
   public static final BlockRegistryEntry<HugeMushroomBlock> FUNGYSS_BLOCK;
   public static final BlockRegistryEntry<LeavesBlock> AURUM_LEAVES;
   public static final BlockRegistryEntry<LeavesBlock> NUGGETY_AURUM_LEAVES;
   public static final BlockRegistryEntry<RotatedPillarBlock> FUNGYSS_STEM;
   public static final BlockRegistryEntry<MysterywoodLogBlock> AURUM_LOG;
   public static final BlockRegistryEntry<EdelwoodLogBlock> EDELWOOD_LOG;
   public static final BlockRegistryEntry<CarvedEdelwoodLogBlock> CARVED_EDELWOOD_LOG;
   public static final BlockRegistryEntry<EdelwoodBranchBlock> EDELWOOD_BRANCH;
   public static final BlockRegistryEntry<MysterywoodLogBlock> STRIPPED_AURUM_LOG;
   public static final BlockRegistryEntry<RotatedPillarBlock> FUNGYSS_HYPHAE;
   public static final BlockRegistryEntry<MysterywoodLogBlock> AURUM_WOOD;
   public static final BlockRegistryEntry<MysterywoodLogBlock> STRIPPED_AURUM_WOOD;
   public static final BlockRegistryEntry<Block> FUNGYSS_PLANKS;
   public static final BlockRegistryEntry<Block> AURUM_PLANKS;
   public static final BlockRegistryEntry<Block> EDELWOOD_PLANKS;
   public static final BlockRegistryEntry<Block> ARCANE_EDELWOOD_PLANKS;
   public static final BlockRegistryEntry<SlabBlock> FUNGYSS_SLAB;
   public static final BlockRegistryEntry<SlabBlock> AURUM_SLAB;
   public static final BlockRegistryEntry<SlabBlock> EDELWOOD_SLAB;
   public static final BlockRegistryEntry<StairBlock> FUNGYSS_STAIRS;
   public static final BlockRegistryEntry<StairBlock> AURUM_STAIRS;
   public static final BlockRegistryEntry<StairBlock> EDELWOOD_STAIRS;
   public static final BlockRegistryEntry<DoorBlock> DEORUM_DOOR;
   public static final BlockRegistryEntry<DoorBlock> FUNGYSS_DOOR;
   public static final BlockRegistryEntry<DoorBlock> AURUM_DOOR;
   public static final BlockRegistryEntry<DoorBlock> EDELWOOD_DOOR;
   public static final BlockRegistryEntry<DoorBlock> ARCANE_EDELWOOD_DOOR;
   public static final BlockRegistryEntry<TrapDoorBlock> DEORUM_TRAPDOOR;
   public static final BlockRegistryEntry<TrapDoorBlock> FUNGYSS_TRAPDOOR;
   public static final BlockRegistryEntry<TrapDoorBlock> AURUM_TRAPDOOR;
   public static final BlockRegistryEntry<TrapDoorBlock> EDELWOOD_TRAPDOOR;
   public static final BlockRegistryEntry<TrapDoorBlock> ARCANE_EDELWOOD_TRAPDOOR;
   public static final BlockRegistryEntry<FenceBlock> FUNGYSS_FENCE;
   public static final BlockRegistryEntry<FenceBlock> AURUM_FENCE;
   public static final BlockRegistryEntry<FenceBlock> EDELWOOD_FENCE;
   public static final BlockRegistryEntry<FenceGateBlock> FUNGYSS_FENCE_GATE;
   public static final BlockRegistryEntry<FenceGateBlock> AURUM_FENCE_GATE;
   public static final BlockRegistryEntry<FenceGateBlock> EDELWOOD_FENCE_GATE;
   public static final BlockRegistryEntry<LadderBlock> EDELWOOD_LADDER;
   public static final BlockRegistryEntry<ButtonBlock> FUNGYSS_BUTTON;
   public static final BlockRegistryEntry<ButtonBlock> AURUM_BUTTON;
   public static final BlockRegistryEntry<ButtonBlock> EDELWOOD_BUTTON;
   public static final BlockRegistryEntry<PressurePlateBlock> FUNGYSS_PRESSURE_PLATE;
   public static final BlockRegistryEntry<PressurePlateBlock> AURUM_PRESSURE_PLATE;
   public static final BlockRegistryEntry<PressurePlateBlock> EDELWOOD_PRESSURE_PLATE;
   public static final BlockRegistryEntry<HephaestusForgeBlock> HEPHAESTUS_FORGE_TIER_1;
   public static final BlockRegistryEntry<HephaestusForgeBlock> HEPHAESTUS_FORGE_TIER_2;
   public static final BlockRegistryEntry<HephaestusForgeBlock> HEPHAESTUS_FORGE_TIER_3;
   public static final BlockRegistryEntry<HephaestusForgeBlock> HEPHAESTUS_FORGE_TIER_4;
   public static final BlockRegistryEntry<HephaestusForgeBlock> HEPHAESTUS_FORGE_TIER_5;
   public static final BlockRegistryEntry<ArcaneDragonEggBlock> ARCANE_DRAGON_EGG;
   public static final BlockRegistryEntry<ArcaneCrystalObeliskBlock> ARCANE_CRYSTAL_OBELISK;
   public static final BlockRegistryEntry<ArcaneCrystalObeliskBlock> CORRUPTED_ARCANE_CRYSTAL_OBELISK;
   public static final SkullRegistryEntry<ObsidianSkullBlock, ObsidianWallSkullBlock> OBSIDIAN_SKULL;
   public static final SkullRegistryEntry<ObsidianSkullBlock, ObsidianWallSkullBlock> CRACKED_OBSIDIAN_SKULL;
   public static final SkullRegistryEntry<ObsidianSkullBlock, ObsidianWallSkullBlock> FRAGMENTED_OBSIDIAN_SKULL;
   public static final SkullRegistryEntry<ObsidianSkullBlock, ObsidianWallSkullBlock> FADING_OBSIDIAN_SKULL;
   public static final SkullRegistryEntry<ObsidianSkullBlock, ObsidianWallSkullBlock> AUREALIC_OBSIDIAN_SKULL;
   public static final SkullRegistryEntry<ObsidianSkullBlock, ObsidianWallSkullBlock> ETERNAL_OBSIDIAN_SKULL;
   public static final BlockRegistryEntry<UtremJarBlock> UTREM_JAR;
   public static final BlockRegistryEntry<EssenceUtremJarBlock> ESSENCE_UTREM_JAR;
   public static final BlockRegistryEntry<Block> BLACK_HOLE;
   public static final BlockRegistryEntry<ChainBlock> DEORUM_CHAIN;
   public static final BlockRegistryEntry<FlowerBlock> YELLOW_ORCHID;
   public static final BlockRegistryEntry<MagicalFarmlandBlock> MAGICAL_FARMLAND;
   public static final BlockRegistryEntry<WhirlwindBlock> WHIRLWIND;
   public static final BlockRegistryEntry<UpwindBlock> UPWIND;
   public static final BlockRegistryEntry<DeskBlock> DESK;
   public static final BlockRegistryEntry<ResearchDeskBlock> RESEARCH_DESK;
   public static final BlockRegistryEntry<HeavyCoreBlock> QUANTUM_CORE;
   public static final BlockRegistryEntry<QuantumInjectorBlock> QUANTUM_INJECTOR;
   public static final BlockRegistryEntry<FlowerPotBlock> POTTED_FUNGYSS;
   public static final BlockRegistryEntry<FlowerPotBlock> POTTED_AURUM_SAPLING;
   public static final BlockRegistryEntry<FlowerPotBlock> POTTED_GROWING_EDELWOOD;
   public static final BlockRegistryEntry<FlowerPotBlock> POTTED_YELLOW_ORCHID;

   private static boolean never(BlockState state, BlockGetter level, BlockPos pos, EntityType<?> entityType) {
      return false;
   }

   static {
      HELPER = ForbiddenArcanus.REGISTRY_MANAGER.getBlockHelper();
      FORBIDDENOMICON = HELPER.register("forbiddenomicon", () -> {
         return new ForbiddenomiconBlock(Properties.of());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      DARKSTONE = HELPER.register("darkstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      DARKSTONE_SLAB = HELPER.register("darkstone_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      DARKSTONE_STAIRS = HELPER.register("darkstone_stairs", () -> {
         return new StairBlock(((Block)DARKSTONE.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      DARKSTONE_WALL = HELPER.register("darkstone_wall", () -> {
         return new WallBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE = HELPER.register("polished_darkstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_SLAB = HELPER.register("polished_darkstone_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.STONE_SLAB).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_STAIRS = HELPER.register("polished_darkstone_stairs", () -> {
         return new StairBlock(((Block)POLISHED_DARKSTONE.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.STONE_STAIRS).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_WALL = HELPER.register("polished_darkstone_wall", () -> {
         return new WallBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_PRESSURE_PLATE = HELPER.register("polished_darkstone_pressure_plate", () -> {
         return new PressurePlateBlock(BlockSetType.STONE, Properties.ofLegacyCopy(Blocks.STONE_PRESSURE_PLATE).strength(0.5F));
      }).withItem();
      POLISHED_DARKSTONE_BUTTON = HELPER.register("polished_darkstone_button", () -> {
         return new ButtonBlock(BlockSetType.STONE, 20, Properties.ofLegacyCopy(Blocks.STONE_BUTTON).strength(0.5F));
      }).withItem();
      CHISELED_POLISHED_DARKSTONE = HELPER.register("chiseled_polished_darkstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      GILDED_CHISELED_POLISHED_DARKSTONE = HELPER.register("gilded_chiseled_polished_darkstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_BRICKS = HELPER.register("polished_darkstone_bricks", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_BRICK_SLAB = HELPER.register("polished_darkstone_brick_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.STONE_SLAB).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_BRICK_STAIRS = HELPER.register("polished_darkstone_brick_stairs", () -> {
         return new StairBlock(((Block)POLISHED_DARKSTONE_BRICKS.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.STONE_STAIRS).strength(4.5F, 8.0F));
      }).withItem();
      POLISHED_DARKSTONE_BRICK_WALL = HELPER.register("polished_darkstone_brick_wall", () -> {
         return new WallBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      CRACKED_POLISHED_DARKSTONE_BRICKS = HELPER.register("cracked_polished_darkstone_bricks", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      TILED_POLISHED_DARKSTONE_BRICKS = HELPER.register("tiled_polished_darkstone_bricks", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      ARCANE_POLISHED_DARKSTONE = HELPER.register("arcane_polished_darkstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      ARCANE_POLISHED_DARKSTONE_SLAB = HELPER.register("arcane_polished_darkstone_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.STONE_SLAB).strength(4.5F, 8.0F));
      }).withItem();
      ARCANE_POLISHED_DARKSTONE_STAIRS = HELPER.register("arcane_polished_darkstone_stairs", () -> {
         return new StairBlock(((Block)ARCANE_POLISHED_DARKSTONE.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.STONE_STAIRS).strength(4.5F, 8.0F));
      }).withItem();
      ARCANE_POLISHED_DARKSTONE_WALL = HELPER.register("arcane_polished_darkstone_wall", () -> {
         return new WallBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      CHISELED_ARCANE_POLISHED_DARKSTONE = HELPER.register("chiseled_arcane_polished_darkstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      ARCANE_POLISHED_DARKSTONE_PILLAR = HELPER.register("arcane_polished_darkstone_pillar", () -> {
         return new PillarBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      DARKSTONE_PEDESTAL = HELPER.register("darkstone_pedestal", () -> {
         return new PedestalBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F).noOcclusion());
      }).withItem();
      MAGNETIZED_DARKSTONE_PEDESTAL = HELPER.register("magnetized_darkstone_pedestal", () -> {
         return new MagnetizedPedestalBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F).noOcclusion());
      }).withItem();
      MORTAR = HELPER.register("mortar", () -> {
         return new MortarBlock(Properties.ofLegacyCopy(Blocks.STONE).requiredFeatures(new FeatureFlag[]{ForbiddenArcanus.PREVIEW}).strength(4.5F, 8.0F).noOcclusion());
      }).withItem();
      CLIBANO_CORE = HELPER.register("clibano_core", () -> {
         return new ClibanoCoreBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      }).withItem();
      CLIBANO_SIDE_HORIZONTAL = HELPER.register("clibano_side_horizontal", () -> {
         return new ClibanoSideBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      });
      CLIBANO_SIDE_VERTICAL = HELPER.register("clibano_side_vertical", () -> {
         return new ClibanoSideBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      });
      CLIBANO_MAIN_PART = HELPER.register("clibano_main_part", () -> {
         return new ClibanoMainPartBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      });
      CLIBANO_CORNER = HELPER.register("clibano_corner", () -> {
         return new ClibanoCornerBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F));
      });
      CLIBANO_CENTER = HELPER.register("clibano_center", () -> {
         return new ClibanoCenterBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(4.5F, 8.0F).lightLevel((state) -> {
            return (Integer)Optional.ofNullable(((ClibanoCenterType)state.getValue(ModBlockStateProperties.CLIBANO_CENTER_TYPE)).getFireType()).map(ClibanoFireType::getLightLevel).orElse(0);
         }));
      });
      STELLA_ARCANUM = HELPER.register("stella_arcanum", () -> {
         return new StellaArcanumBlock(Properties.ofLegacyCopy(Blocks.OBSIDIAN).strength(38.0F, 1200.0F));
      }).withItem();
      ARCANE_CRYSTAL_ORE = HELPER.register("arcane_crystal_ore", () -> {
         return new DropExperienceBlock(UniformInt.of(2, 5), Properties.of().mapColor(MapColor.STONE).instrument(NoteBlockInstrument.BASEDRUM).requiresCorrectToolForDrops().strength(3.0F));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      DEEPSLATE_ARCANE_CRYSTAL_ORE = HELPER.register("deepslate_arcane_crystal_ore", () -> {
         return new DropExperienceBlock(UniformInt.of(2, 5), Properties.of().mapColor(MapColor.DEEPSLATE).instrument(NoteBlockInstrument.BASEDRUM).requiresCorrectToolForDrops().strength(4.5F, 3.0F).sound(SoundType.DEEPSLATE));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      RUNIC_STONE = HELPER.register("runic_stone", () -> {
         return new DropExperienceBlock(UniformInt.of(4, 8), Properties.of().mapColor(MapColor.STONE).instrument(NoteBlockInstrument.BASEDRUM).requiresCorrectToolForDrops().strength(3.0F));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      RUNIC_DEEPSLATE = HELPER.register("runic_deepslate", () -> {
         return new DropExperienceBlock(UniformInt.of(4, 8), Properties.of().mapColor(MapColor.STONE).instrument(NoteBlockInstrument.BASEDRUM).requiresCorrectToolForDrops().strength(4.5F, 3.0F).sound(SoundType.DEEPSLATE));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      RUNIC_DARKSTONE = HELPER.register("runic_darkstone", () -> {
         return new DropExperienceBlock(UniformInt.of(4, 8), Properties.of().mapColor(MapColor.COLOR_BLACK).instrument(NoteBlockInstrument.BASEDRUM).requiresCorrectToolForDrops().strength(6.0F, 4.0F));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      OBSIDIANSTEEL_BLOCK = HELPER.register("obsidiansteel_block", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.OBSIDIAN));
      }).withItem();
      DEORUM_BLOCK = HELPER.register("deorum_block", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.GOLD_BLOCK));
      }).withItem();
      STELLARITE_BLOCK = HELPER.register("stellarite_block", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.OBSIDIAN));
      }).withItem();
      ARCANE_CRYSTAL_BLOCK = HELPER.register("arcane_crystal_block", () -> {
         return new Block(Properties.of().requiresCorrectToolForDrops().strength(1.0F, 3.0F).noOcclusion());
      }).withItem().toolType(ToolType.PICKAXE).toolTier(ToolTier.IRON).renderType(ValhelsiaRenderType.CUTOUT);
      CORRUPTED_ARCANE_CRYSTAL_BLOCK = HELPER.register("corrupted_arcane_crystal_block", () -> {
         return new Block(Properties.of().requiresCorrectToolForDrops().strength(1.0F, 3.0F));
      }).withItem().toolType(ToolType.PICKAXE).toolTier(ToolTier.IRON);
      RUNE_BLOCK = HELPER.register("rune_block", () -> {
         return new Block(Properties.of().mapColor(MapColor.COLOR_MAGENTA).requiresCorrectToolForDrops().strength(5.0F, 6.0F));
      }).withItem();
      DEORUM_GLASS = HELPER.register("deorum_glass", () -> {
         return new TransparentBlock(Properties.ofLegacyCopy(Blocks.GLASS));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      RUNIC_GLASS = HELPER.register("runic_glass", () -> {
         return new TransparentBlock(Properties.ofLegacyCopy(Blocks.GLASS));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      DEORUM_GLASS_PANE = HELPER.register("deorum_glass_pane", () -> {
         return new IronBarsBlock(Properties.ofLegacyCopy(Blocks.GLASS_PANE));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      RUNIC_GLASS_PANE = HELPER.register("runic_glass_pane", () -> {
         return new IronBarsBlock(Properties.ofLegacyCopy(Blocks.GLASS_PANE));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      DEORUM_LANTERN = HELPER.register("deorum_lantern", () -> {
         return new LanternBlock(Properties.ofLegacyCopy(Blocks.LANTERN));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      DEORUM_SOUL_LANTERN = HELPER.register("deorum_soul_lantern", () -> {
         return new LanternBlock(Properties.ofLegacyCopy(Blocks.SOUL_LANTERN));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      SOULLESS_SAND = HELPER.register("soulless_sand", () -> {
         return new SoullessSandBlock(Properties.ofLegacyCopy(Blocks.SOUL_SAND).speedFactor(1.0F));
      }).withItem();
      SOULLESS_SANDSTONE = HELPER.register("soulless_sandstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.SANDSTONE));
      }).withItem();
      CUT_SOULLESS_SANDSTONE = HELPER.register("cut_soulless_sandstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.SANDSTONE));
      }).withItem();
      POLISHED_SOULLESS_SANDSTONE = HELPER.register("polished_soulless_sandstone", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.SANDSTONE));
      }).withItem();
      SOULLESS_SANDSTONE_SLAB = HELPER.register("soulless_sandstone_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.SANDSTONE_SLAB));
      }).withItem();
      CUT_SOULLESS_SANDSTONE_SLAB = HELPER.register("cut_soulless_sandstone_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.SANDSTONE_SLAB));
      }).withItem();
      POLISHED_SOULLESS_SANDSTONE_SLAB = HELPER.register("polished_soulless_sandstone_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.SANDSTONE_SLAB));
      }).withItem();
      SOULLESS_SANDSTONE_STAIRS = HELPER.register("soulless_sandstone_stairs", () -> {
         return new StairBlock(((Block)SOULLESS_SANDSTONE.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.SANDSTONE_STAIRS));
      }).withItem();
      POLISHED_SOULLESS_SANDSTONE_STAIRS = HELPER.register("polished_soulless_sandstone_stairs", () -> {
         return new StairBlock(((Block)POLISHED_SOULLESS_SANDSTONE.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.SANDSTONE_STAIRS));
      }).withItem();
      SOULLESS_SANDSTONE_WALL = HELPER.register("soulless_sandstone_wall", () -> {
         return new WallBlock(Properties.ofLegacyCopy(Blocks.SANDSTONE_WALL));
      }).withItem();
      FUNGYSS = HELPER.register("fungyss", () -> {
         return new FungyssBlock(Properties.ofLegacyCopy(Blocks.WARPED_FUNGUS).sound(SoundType.GRASS));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      AURUM_SAPLING = HELPER.register("aurum_sapling", () -> {
         return new SaplingBlock(FATreeGrower.AURUM, Properties.ofLegacyCopy(Blocks.OAK_SAPLING));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      GROWING_EDELWOOD = HELPER.register("growing_edelwood", () -> {
         return new GrowingEdelwoodBlock(Properties.ofLegacyCopy(Blocks.OAK_SAPLING));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      FUNGYSS_BLOCK = HELPER.register("fungyss_block", () -> {
         return new HugeMushroomBlock(Properties.of().mapColor(MapColor.COLOR_BLUE).strength(0.2F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_LEAVES = HELPER.register("aurum_leaves", () -> {
         return new LeavesBlock(Properties.ofLegacyCopy(Blocks.OAK_LEAVES));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT_MIPPED);
      NUGGETY_AURUM_LEAVES = HELPER.register("nuggety_aurum_leaves", () -> {
         return new LeavesBlock(Properties.ofLegacyCopy(Blocks.OAK_LEAVES));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT_MIPPED);
      FUNGYSS_STEM = HELPER.register("fungyss_stem", () -> {
         return new RotatedPillarBlock(Properties.of().mapColor(MapColor.WOOL).strength(2.0F).sound(SoundType.STEM));
      }).withItem();
      AURUM_LOG = HELPER.register("aurum_log", () -> {
         return new MysterywoodLogBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG));
      }).withItem();
      EDELWOOD_LOG = HELPER.register("edelwood_log", () -> {
         return new EdelwoodLogBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG).mapColor(MapColor.COLOR_BROWN).randomTicks());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      CARVED_EDELWOOD_LOG = HELPER.register("carved_edelwood_log", () -> {
         return new CarvedEdelwoodLogBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG).mapColor(MapColor.COLOR_BROWN).randomTicks());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      EDELWOOD_BRANCH = HELPER.register("edelwood_branch", () -> {
         return new EdelwoodBranchBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG).mapColor(MapColor.COLOR_BROWN));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      STRIPPED_AURUM_LOG = HELPER.register("stripped_aurum_log", () -> {
         return new MysterywoodLogBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG));
      }).withItem();
      FUNGYSS_HYPHAE = HELPER.register("fungyss_hyphae", () -> {
         return new RotatedPillarBlock(Properties.of().mapColor(MapColor.WOOL).strength(2.0F).sound(SoundType.STEM));
      }).withItem();
      AURUM_WOOD = HELPER.register("aurum_wood", () -> {
         return new MysterywoodLogBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG));
      }).withItem();
      STRIPPED_AURUM_WOOD = HELPER.register("stripped_aurum_wood", () -> {
         return new MysterywoodLogBlock(Properties.ofLegacyCopy(Blocks.OAK_LOG));
      }).withItem();
      FUNGYSS_PLANKS = HELPER.register("fungyss_planks", () -> {
         return new Block(Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_PLANKS = HELPER.register("aurum_planks", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.OAK_PLANKS));
      }).withItem();
      EDELWOOD_PLANKS = HELPER.register("edelwood_planks", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.OAK_PLANKS));
      }).withItem();
      ARCANE_EDELWOOD_PLANKS = HELPER.register("arcane_edelwood_planks", () -> {
         return new Block(Properties.ofLegacyCopy(Blocks.OAK_PLANKS));
      }).withItem();
      FUNGYSS_SLAB = HELPER.register("fungyss_slab", () -> {
         return new SlabBlock(Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_SLAB = HELPER.register("aurum_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.OAK_SLAB));
      }).withItem();
      EDELWOOD_SLAB = HELPER.register("edelwood_slab", () -> {
         return new SlabBlock(Properties.ofLegacyCopy(Blocks.OAK_SLAB));
      }).withItem();
      FUNGYSS_STAIRS = HELPER.register("fungyss_stairs", () -> {
         return new StairBlock(((Block)FUNGYSS_PLANKS.get()).defaultBlockState(), Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_STAIRS = HELPER.register("aurum_stairs", () -> {
         return new StairBlock(((Block)AURUM_PLANKS.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.OAK_STAIRS));
      }).withItem();
      EDELWOOD_STAIRS = HELPER.register("edelwood_stairs", () -> {
         return new StairBlock(((Block)EDELWOOD_PLANKS.get()).defaultBlockState(), Properties.ofLegacyCopy(Blocks.OAK_STAIRS));
      }).withItem();
      DEORUM_DOOR = HELPER.register("deorum_door", () -> {
         return new DoorBlock(BlockSetType.GOLD, Properties.of().mapColor(MapColor.GOLD).requiresCorrectToolForDrops().strength(3.0F).sound(SoundType.METAL).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      FUNGYSS_DOOR = HELPER.register("fungyss_door", () -> {
         return new DoorBlock(ModBlocks.BlockSetTypes.FUNGYSS, Properties.of().mapColor(MapColor.WOOL).strength(3.0F).sound(SoundType.WOOD).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      AURUM_DOOR = HELPER.register("aurum_door", () -> {
         return new DoorBlock(ModBlocks.BlockSetTypes.AURUM, Properties.of().strength(3.0F).sound(SoundType.WOOD).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      EDELWOOD_DOOR = HELPER.register("edelwood_door", () -> {
         return new DoorBlock(ModBlocks.BlockSetTypes.EDELWOOD, Properties.of().strength(3.0F).sound(SoundType.WOOD).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      ARCANE_EDELWOOD_DOOR = HELPER.register("arcane_edelwood_door", () -> {
         return new DoorBlock(ModBlocks.BlockSetTypes.EDELWOOD, Properties.of().strength(3.0F).sound(SoundType.WOOD).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      DEORUM_TRAPDOOR = HELPER.register("deorum_trapdoor", () -> {
         return new TrapDoorBlock(BlockSetType.GOLD, Properties.of().mapColor(MapColor.GOLD).requiresCorrectToolForDrops().strength(3.0F).sound(SoundType.METAL).noOcclusion().isValidSpawn(ModBlocks::never));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      FUNGYSS_TRAPDOOR = HELPER.register("fungyss_trapdoor", () -> {
         return new TrapDoorBlock(ModBlocks.BlockSetTypes.FUNGYSS, Properties.of().mapColor(MapColor.WOOL).strength(3.0F).sound(SoundType.WOOD).noOcclusion().isValidSpawn(ModBlocks::never));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      AURUM_TRAPDOOR = HELPER.register("aurum_trapdoor", () -> {
         return new TrapDoorBlock(ModBlocks.BlockSetTypes.AURUM, Properties.of().strength(3.0F).sound(SoundType.WOOD).noOcclusion().isValidSpawn(ModBlocks::never));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      EDELWOOD_TRAPDOOR = HELPER.register("edelwood_trapdoor", () -> {
         return new TrapDoorBlock(ModBlocks.BlockSetTypes.EDELWOOD, Properties.of().strength(3.0F).sound(SoundType.WOOD).noOcclusion().isValidSpawn(ModBlocks::never));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      ARCANE_EDELWOOD_TRAPDOOR = HELPER.register("arcane_edelwood_trapdoor", () -> {
         return new TrapDoorBlock(ModBlocks.BlockSetTypes.EDELWOOD, Properties.of().strength(3.0F).sound(SoundType.WOOD).noOcclusion().isValidSpawn(ModBlocks::never));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      FUNGYSS_FENCE = HELPER.register("fungyss_fence", () -> {
         return new FenceBlock(Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_FENCE = HELPER.register("aurum_fence", () -> {
         return new FenceBlock(Properties.ofLegacyCopy(Blocks.OAK_FENCE));
      }).withItem();
      EDELWOOD_FENCE = HELPER.register("edelwood_fence", () -> {
         return new FenceBlock(Properties.ofLegacyCopy(Blocks.OAK_FENCE));
      }).withItem();
      FUNGYSS_FENCE_GATE = HELPER.register("fungyss_fence_gate", () -> {
         return new FenceGateBlock(ModWoodTypes.FUNGYSS, Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_FENCE_GATE = HELPER.register("aurum_fence_gate", () -> {
         return new FenceGateBlock(ModWoodTypes.AURUM, Properties.ofLegacyCopy(Blocks.OAK_FENCE_GATE));
      }).withItem();
      EDELWOOD_FENCE_GATE = HELPER.register("edelwood_fence_gate", () -> {
         return new FenceGateBlock(ModWoodTypes.EDELWOOD, Properties.ofLegacyCopy(Blocks.OAK_FENCE_GATE));
      }).withItem();
      EDELWOOD_LADDER = HELPER.register("edelwood_ladder", () -> {
         return new LadderBlock(Properties.ofLegacyCopy(Blocks.LADDER));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      FUNGYSS_BUTTON = HELPER.register("fungyss_button", () -> {
         return new ButtonBlock(ModBlocks.BlockSetTypes.FUNGYSS, 30, Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_BUTTON = HELPER.register("aurum_button", () -> {
         return new ButtonBlock(ModBlocks.BlockSetTypes.AURUM, 30, Properties.ofLegacyCopy(Blocks.OAK_BUTTON));
      }).withItem();
      EDELWOOD_BUTTON = HELPER.register("edelwood_button", () -> {
         return new ButtonBlock(ModBlocks.BlockSetTypes.EDELWOOD, 30, Properties.ofLegacyCopy(Blocks.OAK_BUTTON));
      }).withItem();
      FUNGYSS_PRESSURE_PLATE = HELPER.register("fungyss_pressure_plate", () -> {
         return new PressurePlateBlock(ModBlocks.BlockSetTypes.FUNGYSS, Properties.of().mapColor(MapColor.WOOL).strength(2.0F, 3.0F).sound(SoundType.WOOD));
      }).withItem();
      AURUM_PRESSURE_PLATE = HELPER.register("aurum_pressure_plate", () -> {
         return new PressurePlateBlock(ModBlocks.BlockSetTypes.AURUM, Properties.ofLegacyCopy(Blocks.OAK_PRESSURE_PLATE));
      }).withItem();
      EDELWOOD_PRESSURE_PLATE = HELPER.register("edelwood_pressure_plate", () -> {
         return new PressurePlateBlock(ModBlocks.BlockSetTypes.EDELWOOD, Properties.ofLegacyCopy(Blocks.OAK_PRESSURE_PLATE));
      }).withItem();
      HEPHAESTUS_FORGE_TIER_1 = HELPER.register("hephaestus_forge_tier_1", () -> {
         return new HephaestusForgeBlock(HephaestusForgeLevel.ONE, Properties.ofLegacyCopy(Blocks.OBSIDIAN).strength(38.0F, 1200.0F).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      HEPHAESTUS_FORGE_TIER_2 = HELPER.register("hephaestus_forge_tier_2", () -> {
         return new HephaestusForgeBlock(HephaestusForgeLevel.TWO, Properties.ofLegacyCopy(Blocks.OBSIDIAN).strength(38.0F, 1200.0F).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      HEPHAESTUS_FORGE_TIER_3 = HELPER.register("hephaestus_forge_tier_3", () -> {
         return new HephaestusForgeBlock(HephaestusForgeLevel.THREE, Properties.ofLegacyCopy(Blocks.OBSIDIAN).strength(38.0F, 1200.0F).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      HEPHAESTUS_FORGE_TIER_4 = HELPER.register("hephaestus_forge_tier_4", () -> {
         return new HephaestusForgeBlock(HephaestusForgeLevel.FOUR, Properties.ofLegacyCopy(Blocks.OBSIDIAN).strength(38.0F, 1200.0F).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      HEPHAESTUS_FORGE_TIER_5 = HELPER.register("hephaestus_forge_tier_5", () -> {
         return new HephaestusForgeBlock(HephaestusForgeLevel.FIVE, Properties.ofLegacyCopy(Blocks.OBSIDIAN).strength(38.0F, 1200.0F).noOcclusion());
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      ARCANE_DRAGON_EGG = HELPER.register("arcane_dragon_egg", () -> {
         return new ArcaneDragonEggBlock(Properties.ofLegacyCopy(Blocks.DRAGON_EGG).lightLevel((value) -> {
            return 5;
         }));
      }).withItem();
      ARCANE_CRYSTAL_OBELISK = HELPER.register("arcane_crystal_obelisk", () -> {
         return new ArcaneCrystalObeliskBlock(Properties.of().strength(1.0F, 10.0F).pushReaction(PushReaction.BLOCK));
      }).withItem();
      CORRUPTED_ARCANE_CRYSTAL_OBELISK = HELPER.register("corrupted_arcane_crystal_obelisk", () -> {
         return new ArcaneCrystalObeliskBlock(Properties.of().strength(1.0F, 10.0F).pushReaction(PushReaction.BLOCK));
      }).withItem();
      OBSIDIAN_SKULL = HELPER.registerSkull("obsidian", ObsidianSkullType.DEFAULT, ObsidianSkullBlock::new, ObsidianWallSkullBlock::new, Properties.ofLegacyCopy(Blocks.SKELETON_SKULL), ModBlocks.BlockItems.OBSIDIAN_SKULL_ITEM);
      CRACKED_OBSIDIAN_SKULL = HELPER.registerSkull("cracked_obsidian", ObsidianSkullType.CRACKED, ObsidianSkullBlock::new, ObsidianWallSkullBlock::new, Properties.ofLegacyCopy(Blocks.SKELETON_SKULL), ModBlocks.BlockItems.CRACKED_OBSIDIAN_SKULL_ITEM);
      FRAGMENTED_OBSIDIAN_SKULL = HELPER.registerSkull("fragmented_obsidian", ObsidianSkullType.FRAGMENTED, ObsidianSkullBlock::new, ObsidianWallSkullBlock::new, Properties.ofLegacyCopy(Blocks.SKELETON_SKULL), ModBlocks.BlockItems.FRAGMENTED_OBSIDIAN_SKULL_ITEM);
      FADING_OBSIDIAN_SKULL = HELPER.registerSkull("fading_obsidian", ObsidianSkullType.FADING, ObsidianSkullBlock::new, ObsidianWallSkullBlock::new, Properties.ofLegacyCopy(Blocks.SKELETON_SKULL), ModBlocks.BlockItems.FADING_OBSIDIAN_SKULL_ITEM);
      AUREALIC_OBSIDIAN_SKULL = HELPER.registerSkull("aurealic_obsidian", ObsidianSkullType.AUREALIC, ObsidianSkullBlock::new, ObsidianWallSkullBlock::new, Properties.ofLegacyCopy(Blocks.SKELETON_SKULL), ModBlocks.BlockItems.AUREALIC_OBSIDIAN_SKULL_ITEM);
      ETERNAL_OBSIDIAN_SKULL = HELPER.registerSkull("eternal_obsidian", ObsidianSkullType.ETERNAL, ObsidianSkullBlock::new, ObsidianWallSkullBlock::new, Properties.ofLegacyCopy(Blocks.SKELETON_SKULL), ModBlocks.BlockItems.ETERNAL_OBSIDIAN_SKULL_ITEM);
      UTREM_JAR = HELPER.register("utrem_jar", () -> {
         return new UtremJarBlock(Properties.ofLegacyCopy(Blocks.GLASS));
      }).renderType(ValhelsiaRenderType.CUTOUT);
      ESSENCE_UTREM_JAR = HELPER.register("essence_utrem_jar", () -> {
         return new EssenceUtremJarBlock(Properties.ofLegacyCopy(Blocks.GLASS).lightLevel((state) -> {
            return ((EssenceType)state.getValue(ModBlockStateProperties.ESSENCE_TYPE)).getLightEmission();
         }));
      }).renderType(ValhelsiaRenderType.CUTOUT);
      BLACK_HOLE = HELPER.register("black_hole", () -> {
         return new BlackHoleBlock(Properties.ofLegacyCopy(Blocks.STONE).strength(2.0F, 8.0F).noOcclusion());
      });
      DEORUM_CHAIN = HELPER.register("deorum_chain", () -> {
         return new ChainBlock(Properties.ofLegacyCopy(Blocks.CHAIN));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT_MIPPED);
      YELLOW_ORCHID = HELPER.register("yellow_orchid", () -> {
         return new FlowerBlock(MobEffects.GLOWING, 10.0F, Properties.ofLegacyCopy(Blocks.BLUE_ORCHID));
      }).withItem().renderType(ValhelsiaRenderType.CUTOUT);
      MAGICAL_FARMLAND = HELPER.register("magical_farmland", () -> {
         return new MagicalFarmlandBlock(Properties.ofLegacyCopy(Blocks.FARMLAND).randomTicks());
      }).withItem();
      WHIRLWIND = HELPER.register("whirlwind", () -> {
         return new WhirlwindBlock(Properties.ofLegacyCopy(Blocks.WHEAT));
      }).renderType(ValhelsiaRenderType.CUTOUT);
      UPWIND = HELPER.register("upwind", () -> {
         return new UpwindBlock(Properties.ofLegacyCopy(Blocks.WHEAT));
      });
      DESK = HELPER.register("desk", () -> {
         return new DeskBlock(Properties.of());
      }).withItem();
      RESEARCH_DESK = HELPER.register("research_desk", () -> {
         return new ResearchDeskBlock(Properties.of());
      }).withItem();
      QUANTUM_CORE = HELPER.register("quantum_core", () -> {
         return new HeavyCoreBlock(Properties.of().explosionResistance(1200.0F));
      }).withItem();
      QUANTUM_INJECTOR = HELPER.register("quantum_injector", () -> {
         return new QuantumInjectorBlock(Properties.of().explosionResistance(1200.0F));
      }).withItem();
      POTTED_FUNGYSS = HELPER.register("potted_fungyss", () -> {
         return new FlowerPotBlock(() -> {
            return (FlowerPotBlock)Blocks.FLOWER_POT;
         }, FUNGYSS, Properties.ofLegacyCopy(Blocks.POTTED_OAK_SAPLING));
      }).renderType(ValhelsiaRenderType.CUTOUT);
      POTTED_AURUM_SAPLING = HELPER.register("potted_aurum_sapling", () -> {
         return new FlowerPotBlock(() -> {
            return (FlowerPotBlock)Blocks.FLOWER_POT;
         }, AURUM_SAPLING, Properties.ofLegacyCopy(Blocks.POTTED_OAK_SAPLING));
      }).renderType(ValhelsiaRenderType.CUTOUT);
      POTTED_GROWING_EDELWOOD = HELPER.register("potted_growing_edelwood", () -> {
         return new FlowerPotBlock(() -> {
            return (FlowerPotBlock)Blocks.FLOWER_POT;
         }, GROWING_EDELWOOD, Properties.ofLegacyCopy(Blocks.POTTED_OAK_SAPLING));
      }).renderType(ValhelsiaRenderType.CUTOUT);
      POTTED_YELLOW_ORCHID = HELPER.register("potted_yellow_orchid", () -> {
         return new FlowerPotBlock(() -> {
            return (FlowerPotBlock)Blocks.FLOWER_POT;
         }, YELLOW_ORCHID, Properties.ofLegacyCopy(Blocks.POTTED_OAK_SAPLING));
      }).renderType(ValhelsiaRenderType.CUTOUT);
   }

   public static class BlockSetTypes {
      public static final BlockSetType FUNGYSS = BlockSetType.register(new BlockSetType("fungyss"));
      public static final BlockSetType AURUM = BlockSetType.register(new BlockSetType("aurum"));
      public static final BlockSetType EDELWOOD = BlockSetType.register(new BlockSetType("edelwood"));
   }

   private static class BlockItems {
      public static final SkullItemFactory OBSIDIAN_SKULL_ITEM = (skull, wallSkull) -> {
         return new ObsidianSkullItem(skull, wallSkull, (new net.minecraft.world.item.Item.Properties()).stacksTo(1).fireResistant().component(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.DEFAULT).component(ModDataComponents.GRANTS_EFFECTS, List.of(EffectGrantingRule.GRANT_FIRE_RESISTANCE)));
      };
      public static final SkullItemFactory CRACKED_OBSIDIAN_SKULL_ITEM = (skull, wallSkull) -> {
         return new ObsidianSkullItem(skull, wallSkull, (new net.minecraft.world.item.Item.Properties()).stacksTo(1).fireResistant().component(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.CRACKED).component(ModDataComponents.GRANTS_EFFECTS, List.of(EffectGrantingRule.GRANT_FIRE_RESISTANCE)));
      };
      public static final SkullItemFactory FRAGMENTED_OBSIDIAN_SKULL_ITEM = (skull, wallSkull) -> {
         return new ObsidianSkullItem(skull, wallSkull, (new net.minecraft.world.item.Item.Properties()).stacksTo(1).fireResistant().component(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.FRAGMENTED).component(ModDataComponents.GRANTS_EFFECTS, List.of(EffectGrantingRule.GRANT_FIRE_RESISTANCE)));
      };
      public static final SkullItemFactory FADING_OBSIDIAN_SKULL_ITEM = (skull, wallSkull) -> {
         return new ObsidianSkullItem(skull, wallSkull, (new net.minecraft.world.item.Item.Properties()).stacksTo(1).fireResistant().component(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.FADING).component(ModDataComponents.GRANTS_EFFECTS, List.of(EffectGrantingRule.GRANT_FIRE_RESISTANCE)));
      };
      public static final SkullItemFactory AUREALIC_OBSIDIAN_SKULL_ITEM = (skull, wallSkull) -> {
         return new ObsidianSkullItem(skull, wallSkull, (new net.minecraft.world.item.Item.Properties()).stacksTo(1).rarity(Rarity.UNCOMMON).fireResistant().component(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.AUREALIC).component(ModDataComponents.GRANTS_EFFECTS, List.of(EffectGrantingRule.GRANT_FIRE_RESISTANCE_IF_HAS_AUREAL)));
      };
      public static final SkullItemFactory ETERNAL_OBSIDIAN_SKULL_ITEM = (skull, wallSkull) -> {
         return new ObsidianSkullItem(skull, wallSkull, (new net.minecraft.world.item.Item.Properties()).stacksTo(1).rarity(Rarity.RARE).fireResistant().component(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.ETERNAL).component(ModDataComponents.GRANTS_EFFECTS, List.of(EffectGrantingRule.GRANT_FIRE_RESISTANCE)));
      };
   }
}
