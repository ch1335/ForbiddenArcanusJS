package com.stal111.forbidden_arcanus.core.init.other;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceStorage;
import com.stal111.forbidden_arcanus.common.item.modifier.SoulboundInventory;
import java.util.function.Supplier;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.NeoForgeRegistries.Keys;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModAttachmentTypes {
   public static final MappedRegistryHelper<AttachmentType<?>> HELPER;
   public static final Supplier<AttachmentType<EssenceStorage>> AUREAL;
   public static final Supplier<AttachmentType<EssenceStorage>> SOULS;
   public static final Supplier<AttachmentType<EssenceStorage>> BLOOD;
   public static final Supplier<AttachmentType<EssenceStorage>> EXPERIENCE;
   public static final Supplier<AttachmentType<SoulboundInventory>> SOULBOUND_INVENTORY;

   private static Supplier<AttachmentType<EssenceStorage>> createEssenceStorage(EssenceType type) {
      return HELPER.register(type.getSerializedName(), () -> {
         return AttachmentType.builder(() -> {
            return EssenceStorage.createEmpty(type, 100);
         }).serialize(EssenceStorage.codec(type)).build();
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Keys.ATTACHMENT_TYPES);
      AUREAL = createEssenceStorage(EssenceType.AUREAL);
      SOULS = createEssenceStorage(EssenceType.SOULS);
      BLOOD = createEssenceStorage(EssenceType.BLOOD);
      EXPERIENCE = createEssenceStorage(EssenceType.EXPERIENCE);
      SOULBOUND_INVENTORY = HELPER.register("soulbound_inventory", () -> {
         return AttachmentType.builder(SoulboundInventory::create).serialize(SoulboundInventory.CODEC, (inventory) -> {
            return !inventory.isEmpty();
         }).copyOnDeath().build();
      });
   }
}
