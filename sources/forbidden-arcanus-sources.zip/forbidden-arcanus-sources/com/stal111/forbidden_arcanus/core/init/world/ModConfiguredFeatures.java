package com.stal111.forbidden_arcanus.core.init.world;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.EdelwoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.MysterywoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.StellaArcanumBlock;
import com.stal111.forbidden_arcanus.common.world.feature.config.BigFungyssFeatureConfig;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import java.util.List;
import java.util.OptionalInt;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.random.SimpleWeightedRandomList;
import net.minecraft.util.random.SimpleWeightedRandomList.Builder;
import net.minecraft.util.valueproviders.ConstantInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.HugeMushroomBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.RandomPatchConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.SimpleBlockConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration.TargetBlockState;
import net.minecraft.world.level.levelgen.feature.configurations.TreeConfiguration.TreeConfigurationBuilder;
import net.minecraft.world.level.levelgen.feature.featuresize.TwoLayersFeatureSize;
import net.minecraft.world.level.levelgen.feature.foliageplacers.FancyFoliagePlacer;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import net.minecraft.world.level.levelgen.feature.stateproviders.SimpleStateProvider;
import net.minecraft.world.level.levelgen.feature.stateproviders.WeightedStateProvider;
import net.minecraft.world.level.levelgen.feature.trunkplacers.FancyTrunkPlacer;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockMatchTest;
import net.minecraft.world.level.levelgen.structure.templatesystem.RuleTest;
import net.minecraft.world.level.levelgen.structure.templatesystem.TagMatchTest;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModConfiguredFeatures extends DatapackRegistryClass<ConfiguredFeature<?, ?>> {
   public static final DatapackRegistryHelper<ConfiguredFeature<?, ?>> HELPER;
   public static final ResourceKey<ConfiguredFeature<?, ?>> ARCANE_CRYSTAL_ORE;
   public static final ResourceKey<ConfiguredFeature<?, ?>> RUNIC_STONE;
   public static final ResourceKey<ConfiguredFeature<?, ?>> RUNIC_STONE_LOWER;
   public static final ResourceKey<ConfiguredFeature<?, ?>> DARKSTONE;
   public static final ResourceKey<ConfiguredFeature<?, ?>> STELLA_ARCANUM;
   public static final ResourceKey<ConfiguredFeature<?, ?>> AURUM;
   public static final ResourceKey<ConfiguredFeature<?, ?>> YELLOW_ORCHID;
   public static final ResourceKey<ConfiguredFeature<?, ?>> EDELWOOD;
   public static final ResourceKey<ConfiguredFeature<?, ?>> BIG_FUNGYSS_0;
   public static final ResourceKey<ConfiguredFeature<?, ?>> BIG_FUNGYSS_1;
   public static final ResourceKey<ConfiguredFeature<?, ?>> MEGA_FUNGYSS_0;
   public static final ResourceKey<ConfiguredFeature<?, ?>> MEGA_FUNGYSS_1;

   public ModConfiguredFeatures(BootstrapContext<ConfiguredFeature<?, ?>> context) {
      super(context);
   }

   private static Builder<BlockState> weightedBlockStateBuilder() {
      return SimpleWeightedRandomList.builder();
   }

   public void bootstrap(BootstrapContext<ConfiguredFeature<?, ?>> context) {
      RuleTest stoneOreReplaceables = new TagMatchTest(BlockTags.STONE_ORE_REPLACEABLES);
      RuleTest deepslateOreReplaceables = new TagMatchTest(BlockTags.DEEPSLATE_ORE_REPLACEABLES);
      List<TargetBlockState> arcaneCrystalTargetList = List.of(OreConfiguration.target(stoneOreReplaceables, (BlockState)ModConfiguredFeatures.States.ARCANE_CRYSTAL_ORE.get()), OreConfiguration.target(deepslateOreReplaceables, (BlockState)ModConfiguredFeatures.States.DEEPSLATE_ARCANE_CRYSTAL_ORE.get()));
      List<TargetBlockState> runicStoneTargetList = List.of(OreConfiguration.target(stoneOreReplaceables, (BlockState)ModConfiguredFeatures.States.RUNIC_STONE.get()), OreConfiguration.target(deepslateOreReplaceables, (BlockState)ModConfiguredFeatures.States.RUNIC_DEEPSLATE.get()), OreConfiguration.target(new BlockMatchTest((Block)ModBlocks.DARKSTONE.get()), (BlockState)ModConfiguredFeatures.States.RUNIC_DARKSTONE.get()));
      List<TargetBlockState> darkstoneTargetList = List.of(OreConfiguration.target(stoneOreReplaceables, (BlockState)ModConfiguredFeatures.States.DARKSTONE.get()), OreConfiguration.target(deepslateOreReplaceables, (BlockState)ModConfiguredFeatures.States.DARKSTONE.get()));
      List<TargetBlockState> stellaArcanumTargetList = List.of(OreConfiguration.target(stoneOreReplaceables, (BlockState)ModConfiguredFeatures.States.STELLA_ARCANUM.get()), OreConfiguration.target(deepslateOreReplaceables, (BlockState)ModConfiguredFeatures.States.STELLA_ARCANUM.get()));
      context.register(ARCANE_CRYSTAL_ORE, new ConfiguredFeature(Feature.ORE, new OreConfiguration(arcaneCrystalTargetList, 5)));
      context.register(RUNIC_STONE, new ConfiguredFeature(Feature.ORE, new OreConfiguration(runicStoneTargetList, 5, 0.5F)));
      context.register(RUNIC_STONE_LOWER, new ConfiguredFeature(Feature.ORE, new OreConfiguration(runicStoneTargetList, 7, 0.3F)));
      context.register(DARKSTONE, new ConfiguredFeature(Feature.ORE, new OreConfiguration(darkstoneTargetList, 20)));
      context.register(STELLA_ARCANUM, new ConfiguredFeature(Feature.ORE, new OreConfiguration(stellaArcanumTargetList, 3)));
      context.register(AURUM, new ConfiguredFeature(Feature.TREE, (new TreeConfigurationBuilder(BlockStateProvider.simple((Block)ModBlocks.AURUM_LOG.get()), new FancyTrunkPlacer(3, 11, 0), new WeightedStateProvider(weightedBlockStateBuilder().add((BlockState)ModConfiguredFeatures.States.MYSTERYWOOD_LEAVES.get(), 4).add((BlockState)ModConfiguredFeatures.States.NUGGETY_MYSTERYWOOD_LEAVES.get(), 1)), new FancyFoliagePlacer(ConstantInt.of(2), ConstantInt.of(4), 4), new TwoLayersFeatureSize(0, 0, 0, OptionalInt.of(4)))).ignoreVines().build()));
      context.register(YELLOW_ORCHID, new ConfiguredFeature(Feature.FLOWER, new RandomPatchConfiguration(64, 6, 2, PlacementUtils.onlyWhenEmpty(Feature.SIMPLE_BLOCK, new SimpleBlockConfiguration(BlockStateProvider.simple((Block)ModBlocks.YELLOW_ORCHID.get()))))));
      context.register(EDELWOOD, new ConfiguredFeature((Feature)ModFeatures.EDELWOOD.get(), NoneFeatureConfiguration.INSTANCE));
      context.register(BIG_FUNGYSS_0, new ConfiguredFeature((Feature)ModFeatures.BIG_FUNGYSS.get(), new BigFungyssFeatureConfig(SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_BLOCK.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_STEM.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_HYPHAE.get()), 0)));
      context.register(BIG_FUNGYSS_1, new ConfiguredFeature((Feature)ModFeatures.BIG_FUNGYSS.get(), new BigFungyssFeatureConfig(SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_BLOCK.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_STEM.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_HYPHAE.get()), 1)));
      context.register(MEGA_FUNGYSS_0, new ConfiguredFeature((Feature)ModFeatures.MEGA_FUNGYSS.get(), new BigFungyssFeatureConfig(SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_BLOCK.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_STEM.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_HYPHAE.get()), 0)));
      context.register(MEGA_FUNGYSS_1, new ConfiguredFeature((Feature)ModFeatures.MEGA_FUNGYSS.get(), new BigFungyssFeatureConfig(SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_BLOCK.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_STEM.get()), SimpleStateProvider.simple((BlockState)ModConfiguredFeatures.States.FUNGYSS_HYPHAE.get()), 1)));
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.CONFIGURED_FEATURE);
      ARCANE_CRYSTAL_ORE = HELPER.createKey("ore_arcane_crystal");
      RUNIC_STONE = HELPER.createKey("ore_rune");
      RUNIC_STONE_LOWER = HELPER.createKey("ore_rune_lower");
      DARKSTONE = HELPER.createKey("ore_darkstone");
      STELLA_ARCANUM = HELPER.createKey("ore_stella_arcanum");
      AURUM = HELPER.createKey("aurum");
      YELLOW_ORCHID = HELPER.createKey("flower_yellow_orchid");
      EDELWOOD = HELPER.createKey("edelwood");
      BIG_FUNGYSS_0 = HELPER.createKey("big_fungyss_0");
      BIG_FUNGYSS_1 = HELPER.createKey("big_fungyss_1");
      MEGA_FUNGYSS_0 = HELPER.createKey("mega_fungyss_0");
      MEGA_FUNGYSS_1 = HELPER.createKey("mega_fungyss_1");
   }

   public static final class States {
      private static final BlockState GRASS_BLOCK;
      private static final BlockState STONE;
      private static final Supplier<BlockState> ARCANE_CRYSTAL_ORE;
      private static final Supplier<BlockState> DEEPSLATE_ARCANE_CRYSTAL_ORE;
      private static final Supplier<BlockState> RUNIC_STONE;
      private static final Supplier<BlockState> RUNIC_DEEPSLATE;
      private static final Supplier<BlockState> RUNIC_DARKSTONE;
      private static final Supplier<BlockState> DARKSTONE;
      private static final Supplier<BlockState> STELLA_ARCANUM;
      private static final Supplier<BlockState> MYSTERYWOOD_LOG;
      private static final Supplier<BlockState> MYSTERYWOOD_LEAVES;
      private static final Supplier<BlockState> NUGGETY_MYSTERYWOOD_LEAVES;
      private static final Supplier<BlockState> MYSTERYWOOD_SAPLING;
      private static final Supplier<BlockState> YELLOW_ORCHID;
      private static final Supplier<BlockState> EDELWOOD_LOG;
      private static final Supplier<BlockState> FUNGYSS_BLOCK;
      private static final Supplier<BlockState> FUNGYSS_STEM;
      private static final Supplier<BlockState> FUNGYSS_HYPHAE;

      static {
         GRASS_BLOCK = Blocks.GRASS_BLOCK.defaultBlockState();
         STONE = Blocks.STONE.defaultBlockState();
         ARCANE_CRYSTAL_ORE = () -> {
            return ((DropExperienceBlock)ModBlocks.ARCANE_CRYSTAL_ORE.get()).defaultBlockState();
         };
         DEEPSLATE_ARCANE_CRYSTAL_ORE = () -> {
            return ((DropExperienceBlock)ModBlocks.DEEPSLATE_ARCANE_CRYSTAL_ORE.get()).defaultBlockState();
         };
         RUNIC_STONE = () -> {
            return ((DropExperienceBlock)ModBlocks.RUNIC_STONE.get()).defaultBlockState();
         };
         RUNIC_DEEPSLATE = () -> {
            return ((DropExperienceBlock)ModBlocks.RUNIC_DEEPSLATE.get()).defaultBlockState();
         };
         RUNIC_DARKSTONE = () -> {
            return ((DropExperienceBlock)ModBlocks.RUNIC_DARKSTONE.get()).defaultBlockState();
         };
         DARKSTONE = () -> {
            return ((Block)ModBlocks.DARKSTONE.get()).defaultBlockState();
         };
         STELLA_ARCANUM = () -> {
            return ((StellaArcanumBlock)ModBlocks.STELLA_ARCANUM.get()).defaultBlockState();
         };
         MYSTERYWOOD_LOG = () -> {
            return ((MysterywoodLogBlock)ModBlocks.AURUM_LOG.get()).defaultBlockState();
         };
         MYSTERYWOOD_LEAVES = () -> {
            return ((LeavesBlock)ModBlocks.AURUM_LEAVES.get()).defaultBlockState();
         };
         NUGGETY_MYSTERYWOOD_LEAVES = () -> {
            return ((LeavesBlock)ModBlocks.NUGGETY_AURUM_LEAVES.get()).defaultBlockState();
         };
         MYSTERYWOOD_SAPLING = () -> {
            return ((SaplingBlock)ModBlocks.AURUM_SAPLING.get()).defaultBlockState();
         };
         YELLOW_ORCHID = () -> {
            return ((FlowerBlock)ModBlocks.YELLOW_ORCHID.get()).defaultBlockState();
         };
         EDELWOOD_LOG = () -> {
            return ((EdelwoodLogBlock)ModBlocks.EDELWOOD_LOG.get()).defaultBlockState();
         };
         FUNGYSS_BLOCK = () -> {
            return (BlockState)((HugeMushroomBlock)ModBlocks.FUNGYSS_BLOCK.get()).defaultBlockState().setValue(HugeMushroomBlock.DOWN, false);
         };
         FUNGYSS_STEM = () -> {
            return ((RotatedPillarBlock)ModBlocks.FUNGYSS_STEM.get()).defaultBlockState();
         };
         FUNGYSS_HYPHAE = () -> {
            return ((RotatedPillarBlock)ModBlocks.FUNGYSS_HYPHAE.get()).defaultBlockState();
         };
      }
   }

   public static final class FillerBlockTypes {
      private static final RuleTest DARKSTONE;

      static {
         DARKSTONE = new BlockMatchTest((Block)ModBlocks.DARKSTONE.get());
      }
   }
}
