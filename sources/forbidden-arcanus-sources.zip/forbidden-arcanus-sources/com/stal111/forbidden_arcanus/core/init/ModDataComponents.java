package com.stal111.forbidden_arcanus.core.init;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.skull.ObsidianSkullType;
import com.stal111.forbidden_arcanus.common.essence.EssenceStorage;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import com.stal111.forbidden_arcanus.common.item.component.AurealCost;
import com.stal111.forbidden_arcanus.common.item.component.EffectGrantingRule;
import com.stal111.forbidden_arcanus.common.item.component.RitualStarter;
import com.stal111.forbidden_arcanus.common.item.component.StoredEntity;
import com.stal111.forbidden_arcanus.common.item.component.ToggleableState;
import com.stal111.forbidden_arcanus.common.item.component.WandParts;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import com.stal111.forbidden_arcanus.common.item.modifier.ItemModifier;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Unit;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class ModDataComponents {
   public static final MappedRegistryHelper<DataComponentType<?>> HELPER;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<Holder<ItemModifier>>> ITEM_MODIFIER;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<EssenceValue>> ESSENCE_VALUE;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<EssenceStorage>> ESSENCE_STORAGE;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<Holder<Item>>> EMPTY_ITEM;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<StoredEntity>> STORED_ENTITY;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<Integer>> BUCKET_CAPACITY;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<Integer>> STORED_FLUID_AMOUNT;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<Integer>> TICKS_TILL_NEXT_STAGE;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<ResourceKey<EnhancerDefinition>>> ENHANCER;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<ToggleableState>> TOGGLEABLE_STATE;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<Unit>> SHOWS_AUREAL_METER;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<RitualStarter>> RITUAL_STARTER;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<ObsidianSkullType>> OBSIDIAN_SKULL_TYPE;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<List<EffectGrantingRule>>> GRANTS_EFFECTS;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<WandParts>> WAND_PARTS;
   public static final RegistryEntry<DataComponentType<?>, DataComponentType<AurealCost>> AUREAL_COST;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.DATA_COMPONENT_TYPE);
      ITEM_MODIFIER = HELPER.register("modifier", () -> {
         return DataComponentType.builder().persistent(ItemModifier.CODEC).networkSynchronized(ItemModifier.STREAM_CODEC).build();
      });
      ESSENCE_VALUE = HELPER.register("essence_data", () -> {
         return DataComponentType.builder().persistent(EssenceValue.CODEC).networkSynchronized(EssenceValue.STREAM_CODEC).build();
      });
      ESSENCE_STORAGE = HELPER.register("essence_storage", () -> {
         return DataComponentType.builder().persistent(EssenceStorage.CODEC).networkSynchronized(EssenceStorage.STREAM_CODEC).build();
      });
      EMPTY_ITEM = HELPER.register("empty_item", () -> {
         return DataComponentType.builder().persistent(ItemStack.ITEM_NON_AIR_CODEC).networkSynchronized(ByteBufCodecs.holderRegistry(Registries.ITEM)).build();
      });
      STORED_ENTITY = HELPER.register("stored_entity", () -> {
         return DataComponentType.builder().persistent(StoredEntity.CODEC).networkSynchronized(StoredEntity.STREAM_CODEC).build();
      });
      BUCKET_CAPACITY = HELPER.register("bucket_capacity", () -> {
         return DataComponentType.builder().persistent(ExtraCodecs.POSITIVE_INT).networkSynchronized(ByteBufCodecs.VAR_INT).build();
      });
      STORED_FLUID_AMOUNT = HELPER.register("stored_fluid_amount", () -> {
         return DataComponentType.builder().persistent(ExtraCodecs.POSITIVE_INT).networkSynchronized(ByteBufCodecs.VAR_INT).build();
      });
      TICKS_TILL_NEXT_STAGE = HELPER.register("ticks_till_next_stage", () -> {
         return DataComponentType.builder().persistent(ExtraCodecs.POSITIVE_INT).build();
      });
      ENHANCER = HELPER.register("enhancer", () -> {
         return DataComponentType.builder().persistent(ResourceKey.codec(FARegistries.ENHANCER_DEFINITION)).networkSynchronized(ResourceKey.streamCodec(FARegistries.ENHANCER_DEFINITION)).build();
      });
      TOGGLEABLE_STATE = HELPER.register("toggleable_state", () -> {
         return DataComponentType.builder().persistent(ToggleableState.CODEC).networkSynchronized(ToggleableState.STREAM_CODEC).build();
      });
      SHOWS_AUREAL_METER = HELPER.register("shows_aureal_meter", () -> {
         return DataComponentType.builder().persistent(Unit.CODEC).networkSynchronized(StreamCodec.unit(Unit.INSTANCE)).build();
      });
      RITUAL_STARTER = HELPER.register("ritual_starter", () -> {
         return DataComponentType.builder().persistent(RitualStarter.CODEC).build();
      });
      OBSIDIAN_SKULL_TYPE = HELPER.register("obsidian_skull_type", () -> {
         return DataComponentType.builder().persistent(ObsidianSkullType.CODEC).build();
      });
      GRANTS_EFFECTS = HELPER.register("grants_effects", () -> {
         return DataComponentType.builder().persistent(EffectGrantingRule.CODEC.listOf()).build();
      });
      WAND_PARTS = HELPER.register("wand_parts", () -> {
         return DataComponentType.builder().persistent(WandParts.CODEC).build();
      });
      AUREAL_COST = HELPER.register("aureal_cost", () -> {
         return DataComponentType.builder().persistent(AurealCost.CODEC).networkSynchronized(AurealCost.STREAM_CODEC).build();
      });
   }
}
