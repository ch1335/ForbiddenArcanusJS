package com.stal111.forbidden_arcanus.core.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import javax.annotation.Nullable;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Gui.class})
public abstract class GuiMixin {
   @Shadow
   @Nullable
   protected abstract Player getCameraPlayer();

   @Inject(
      method = {"renderCrosshair"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/player/LocalPlayer;getAttackStrengthScale(F)F"
)},
      cancellable = true
   )
   private void forbiddenArcanus_renderCrosshair$hideAttackIndicator(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
      Player player = this.getCameraPlayer();
      if (player != null && player.getMainHandItem().is(ModItems.MAGIC_WAND)) {
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableBlend();
         ci.cancel();
      }

   }
}
