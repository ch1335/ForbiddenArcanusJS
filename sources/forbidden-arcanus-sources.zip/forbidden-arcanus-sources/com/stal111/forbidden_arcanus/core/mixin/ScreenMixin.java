package com.stal111.forbidden_arcanus.core.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.stal111.forbidden_arcanus.common.item.modifier.ModifierHelper;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipPositioner;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.event.RenderTooltipEvent.Pre;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin({GuiGraphics.class})
public abstract class ScreenMixin {
   @Shadow(
      remap = false
   )
   private ItemStack tooltipStack;

   @Shadow
   public abstract int guiWidth();

   @Shadow
   public abstract int guiHeight();

   @Shadow
   public abstract void blit(ResourceLocation var1, int var2, int var3, float var4, float var5, int var6, int var7, int var8, int var9);

   @Inject(
      at = {@At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"
)},
      method = {"renderTooltipInternal"},
      locals = LocalCapture.CAPTURE_FAILEXCEPTION
   )
   private void forbiddenArcanus_renderTooltipInternal(Font font, List<ClientTooltipComponent> components, int x, int y, ClientTooltipPositioner positioner, CallbackInfo ci, Pre event) {
      ModifierHelper.getModifier(this.tooltipStack).ifPresent((modifier) -> {
         int width = 0;
         int height = components.size() == 1 ? -2 : 0;

         ClientTooltipComponent clienttooltipcomponent;
         for(Iterator var6 = components.iterator(); var6.hasNext(); height += clienttooltipcomponent.getHeight()) {
            clienttooltipcomponent = (ClientTooltipComponent)var6.next();
            int k = clienttooltipcomponent.getWidth(event.getFont());
            if (k > width) {
               width = k;
            }
         }

         int j2 = event.getX() + 12;
         int k2 = event.getY() - 12;
         if (j2 + width > this.guiWidth()) {
            j2 -= 28 + width;
         }

         if (k2 + height + 6 > this.guiHeight()) {
            k2 = this.guiHeight() - height - 6;
         }

         RenderSystem.enableBlend();
         ResourceLocation texture = modifier.displaySettings().texture();
         this.blit(texture, j2 - 8, k2 - 8, 9.0F, 9.0F, 7, 7, 128, 32);
         this.blit(texture, j2 + width + 1, k2 - 8, 98.0F, 9.0F, 7, 7, 128, 32);
         this.blit(texture, j2 - 8, k2 + height + 1, 9.0F, 17.0F, 7, 7, 128, 32);
         this.blit(texture, j2 + width + 1, k2 + height + 1, 98.0F, 17.0F, 7, 7, 128, 32);
         if (width >= 94) {
            this.blit(texture, j2 + width / 2 - 31, k2 - 16, 26.0F, 0.0F, 62, 15, 128, 32);
            this.blit(texture, j2 + width / 2 - 31, k2 + height + 1, 26.0F, 17.0F, 62, 15, 128, 32);
         }

         RenderSystem.disableBlend();
      });
   }
}
