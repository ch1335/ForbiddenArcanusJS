package com.stal111.forbidden_arcanus.core.mixin;

import com.stal111.forbidden_arcanus.common.item.component.EffectGrantingRule;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({LivingEntity.class})
public abstract class LivingEntityMixin extends Entity {
   public LivingEntityMixin(EntityType<?> entityType, Level level) {
      super(entityType, level);
   }

   @Shadow
   public abstract ItemStack getItemBySlot(EquipmentSlot var1);

   @Inject(
      at = {@At("HEAD")},
      method = {"hasEffect"},
      cancellable = true
   )
   public void forbiddenArcanus_hasEffect$preventEffect(Holder<MobEffect> effect, CallbackInfoReturnable<Boolean> cir) {
      Level var4 = this.level();
      if (var4 instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)var4;
         EquipmentSlot[] var12 = EquipmentSlot.values();
         int var5 = var12.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            EquipmentSlot slot = var12[var6];
            ItemStack stack = this.getItemBySlot(slot);
            List<EffectGrantingRule> rules = (List)stack.getOrDefault(ModDataComponents.GRANTS_EFFECTS, List.of());
            Iterator var10 = rules.iterator();

            while(var10.hasNext()) {
               EffectGrantingRule rule = (EffectGrantingRule)var10.next();
               if (rule.shouldGrantEffect(serverLevel, slot, effect, (LivingEntity)this)) {
                  cir.setReturnValue(true);
                  return;
               }
            }
         }
      }

   }
}
