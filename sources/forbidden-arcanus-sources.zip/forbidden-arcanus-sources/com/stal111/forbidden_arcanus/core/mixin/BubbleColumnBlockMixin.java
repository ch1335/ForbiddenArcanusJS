package com.stal111.forbidden_arcanus.core.mixin;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BubbleColumnBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({BubbleColumnBlock.class})
public class BubbleColumnBlockMixin {
   @Inject(
      at = {@At("HEAD")},
      method = {"getColumnState"},
      cancellable = true
   )
   private static void forbiddenArcanus_getColumnState(BlockState state, CallbackInfoReturnable<BlockState> cir) {
      if (state.is((Block)ModBlocks.SOULLESS_SAND.get())) {
         cir.setReturnValue((BlockState)Blocks.BUBBLE_COLUMN.defaultBlockState().setValue(BubbleColumnBlock.DRAG_DOWN, false));
      }

   }
}
