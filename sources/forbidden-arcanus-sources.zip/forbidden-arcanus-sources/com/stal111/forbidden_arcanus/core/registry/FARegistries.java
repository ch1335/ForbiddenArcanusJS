package com.stal111.forbidden_arcanus.core.registry;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.residue.ResidueType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.circle.MagicCircleType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.input.HephaestusForgeInput;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.Ritual;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.RitualResultType;
import com.stal111.forbidden_arcanus.common.block.pedestal.effect.PedestalEffect;
import com.stal111.forbidden_arcanus.common.entity.darktrader.DarkTraderVariant;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import com.stal111.forbidden_arcanus.common.item.enhancer.condition.EffectConditionType;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.EnhancerEffect;
import com.stal111.forbidden_arcanus.common.item.enhancer.effect.EnhancerEffectType;
import com.stal111.forbidden_arcanus.common.item.modifier.ItemModifier;
import com.stal111.forbidden_arcanus.common.item.mundabitur.MundabiturInteraction;
import com.stal111.forbidden_arcanus.common.research.Constellation;
import com.stal111.forbidden_arcanus.common.research.Knowledge;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.neoforged.neoforge.registries.RegistryBuilder;

public class FARegistries {
   public static final ResourceKey<Registry<Ritual>> RITUAL = createRegistryKey("hephaestus_forge/ritual");
   public static final ResourceKey<Registry<RitualResultType<?>>> RITUAL_RESULT_TYPE = createRegistryKey("ritual_result");
   public static final ResourceKey<Registry<HephaestusForgeInput>> FORGE_INPUT = createRegistryKey("hephaestus_forge/input");
   public static final ResourceKey<Registry<ItemModifier>> ITEM_MODIFIER = createRegistryKey("item_modifier");
   public static final ResourceKey<Registry<EnhancerEffectType<?>>> ENHANCER_EFFECT = createRegistryKey("enhancer/effect");
   public static final ResourceKey<Registry<EffectConditionType<?>>> ENHANCER_EFFECT_CONDITION = createRegistryKey("enhancer/effect_condition");
   public static final ResourceKey<Registry<EnhancerDefinition>> ENHANCER_DEFINITION = createRegistryKey("enhancer/definition");
   public static final ResourceKey<Registry<DarkTraderVariant>> DARK_TRADER_VARIANT = createRegistryKey("dark_trader_variant");
   public static final ResourceKey<Registry<MundabiturInteraction<?>>> MUNDABITUR_INTERACTION = createRegistryKey("mundabitur_interaction");
   public static final ResourceKey<Registry<Knowledge>> KNOWLEDGE = createRegistryKey("research/knowledge");
   public static final ResourceKey<Registry<Constellation>> CONSTELLATION = createRegistryKey("research/constellation");
   public static final ResourceKey<Registry<ResidueType>> RESIDUE_TYPE = createRegistryKey("residue_type");
   public static final ResourceKey<Registry<PedestalEffect>> PEDESTAL_EFFECT = createRegistryKey("pedestal_effect");
   public static final ResourceKey<Registry<MagicCircleType>> MAGIC_CIRCLE = createRegistryKey("magic_circle");
   public static final Registry<RitualResultType<?>> RITUAL_RESULT_TYPE_REGISTRY;
   public static final Registry<HephaestusForgeInput> FORGE_INPUT_REGISTRY;
   public static final Registry<EnhancerEffectType<? extends EnhancerEffect>> ENHANCER_EFFECT_REGISTRY;
   public static final Registry<EffectConditionType<?>> ENHANCER_EFFECT_CONDITION_REGISTRY;
   public static final Registry<DarkTraderVariant> DARK_TRADER_VARIANT_REGISTRY;
   public static final Registry<MundabiturInteraction<?>> MUNDABITUR_INTERACTION_REGISTRY;
   public static final Registry<PedestalEffect> PEDESTAL_EFFECT_REGISTRY;

   private static <T> ResourceKey<Registry<T>> createRegistryKey(String name) {
      return ResourceKey.createRegistryKey(ForbiddenArcanus.location(name));
   }

   private static <T> Registry<T> makeSyncedRegistry(ResourceKey<Registry<T>> registryKey) {
      return (new RegistryBuilder(registryKey)).sync(true).create();
   }

   private static <T> Registry<T> makeRegistry(ResourceKey<Registry<T>> registryKey) {
      return (new RegistryBuilder(registryKey)).create();
   }

   static {
      RITUAL_RESULT_TYPE_REGISTRY = makeSyncedRegistry(RITUAL_RESULT_TYPE);
      FORGE_INPUT_REGISTRY = makeSyncedRegistry(FORGE_INPUT);
      ENHANCER_EFFECT_REGISTRY = makeRegistry(ENHANCER_EFFECT);
      ENHANCER_EFFECT_CONDITION_REGISTRY = makeRegistry(ENHANCER_EFFECT_CONDITION);
      DARK_TRADER_VARIANT_REGISTRY = makeSyncedRegistry(DARK_TRADER_VARIANT);
      MUNDABITUR_INTERACTION_REGISTRY = makeSyncedRegistry(MUNDABITUR_INTERACTION);
      PEDESTAL_EFFECT_REGISTRY = makeRegistry(PEDESTAL_EFFECT);
   }
}
