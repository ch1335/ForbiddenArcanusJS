package com.stal111.forbidden_arcanus.core.config;

import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.DoubleValue;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class BlockConfig {
   public static BooleanValue STELLA_ARCANUM_EXPLODE;
   public static BooleanValue STELLA_ARCANUM_BLOCK_DAMAGE;
   public static IntValue STELLA_ARCANUM_EXPLOSION_RADIUS;
   public static DoubleValue EDELWOOD_LADDER_SPEED;

   public static void init(Builder builder) {
      builder.push("blocks");
      STELLA_ARCANUM_EXPLODE = builder.comment("Should Stella Arcanum explode when mined [default: true]").define("stella_arcanum.explode", true);
      STELLA_ARCANUM_BLOCK_DAMAGE = builder.comment("Should Stella Arcanum explosions deal Block Damage (if explosions enabled) [default: true]").define("stella_arcanum.block_damage", true);
      STELLA_ARCANUM_EXPLOSION_RADIUS = builder.comment("Radius of Stella Arcanum explosions (if explosions enabled) [default: 3]").defineInRange("stella_arcanum.explosion_radius", 3, 1, 10);
      EDELWOOD_LADDER_SPEED = builder.comment("The speed multiplier that gets added to the players y movement when on the ladder [default: 2.0").defineInRange("edelwood_ladder.speed", 2.0D, 0.0D, 10.0D);
      builder.pop();
   }
}
