package com.stal111.forbidden_arcanus.core.config;

import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;

public class Config {
   private static final Builder COMMON_BUILDER = new Builder();
   private static final Builder CLIENT_BUILDER = new Builder();
   public static final ModConfigSpec COMMON_CONFIG;
   public static final ModConfigSpec CLIENT_CONFIG;

   static {
      ItemConfig.init(COMMON_BUILDER);
      BlockConfig.init(COMMON_BUILDER);
      COMMON_CONFIG = COMMON_BUILDER.build();
      CLIENT_CONFIG = CLIENT_BUILDER.build();
   }
}
