package com.stal111.forbidden_arcanus.data;

import com.mojang.datafixers.util.Pair;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.item.modifier.ItemModifier;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import com.stal111.forbidden_arcanus.util.ModTags;
import java.util.List;
import java.util.Map;
import net.minecraft.Util;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.advancements.critereon.ItemPredicate.Builder;
import net.minecraft.advancements.critereon.ItemSubPredicate.Type;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.enchantment.Enchantment;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.advancements.critereon.ItemAbilityPredicate;
import net.valhelsia.valhelsia_core.api.common.item.predicate.ItemAllOfPredicate;
import net.valhelsia.valhelsia_core.api.common.item.predicate.ItemAnyOfPredicate;
import net.valhelsia.valhelsia_core.api.common.item.predicate.ItemHasComponentPredicate;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;
import net.valhelsia.valhelsia_core.core.registry.ValhelsiaItemSubPredicates;

public class ModItemModifiers extends DatapackRegistryClass<ItemModifier> {
   public static final DatapackRegistryHelper<ItemModifier> HELPER;
   public static final ResourceKey<ItemModifier> ETERNAL;
   public static final ResourceKey<ItemModifier> FIERY;
   public static final ResourceKey<ItemModifier> MAGNETIZED;
   public static final ResourceKey<ItemModifier> DEMOLISHING;
   public static final ResourceKey<ItemModifier> AQUATIC;
   public static final ResourceKey<ItemModifier> SOULBOUND;
   private HolderGetter<Enchantment> enchantmentGetter;

   public ModItemModifiers(BootstrapContext<ItemModifier> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<ItemModifier> context) {
      this.enchantmentGetter = context.lookup(Registries.ENCHANTMENT);
      ItemPredicate eternalPredicate = Builder.item().withSubPredicate((Type)ValhelsiaItemSubPredicates.ALL_OF.get(), new ItemAllOfPredicate(Map.of((Type)ValhelsiaItemSubPredicates.HAS_COMPONENT.get(), List.of(new ItemHasComponentPredicate(DataComponents.MAX_DAMAGE), new ItemHasComponentPredicate(DataComponents.DAMAGE))))).build();
      ItemPredicate isToolPredicate = Builder.item().withSubPredicate((Type)ValhelsiaItemSubPredicates.ANY_OF.get(), new ItemAnyOfPredicate(Map.of(ItemAbilityPredicate.TYPE, List.of(new ItemAbilityPredicate(ItemAbilities.PICKAXE_DIG), new ItemAbilityPredicate(ItemAbilities.AXE_DIG), new ItemAbilityPredicate(ItemAbilities.SHOVEL_DIG), new ItemAbilityPredicate(ItemAbilities.HOE_DIG))))).build();
      ItemPredicate magnetizedPredicate = Builder.item().of(ItemTags.FOOT_ARMOR).build();
      ItemPredicate aquaticPredicate = Builder.item().of(ItemTags.HEAD_ARMOR).build();
      ItemPredicate soulBoundPredicate = Builder.item().of(ModTags.Items.SOULBOUND_APPLICABLE).build();
      this.register(ETERNAL, eternalPredicate, ModTags.Items.ETERNAL_INCOMPATIBLE, ModTags.Enchantments.ETERNAL_INCOMPATIBLE, HolderSet.direct(new Holder[]{BuiltInRegistries.DATA_COMPONENT_TYPE.wrapAsHolder(DataComponents.DAMAGE), BuiltInRegistries.DATA_COMPONENT_TYPE.wrapAsHolder(DataComponents.MAX_DAMAGE)}), createDisplay(ETERNAL, ARGB32.color(255, 170, 181, 159), ARGB32.color(255, 49, 57, 56)));
      this.register(FIERY, isToolPredicate, ModTags.Items.FIERY_INCOMPATIBLE, ModTags.Enchantments.FIERY_INCOMPATIBLE, createDisplay(FIERY, ARGB32.color(255, 255, 143, 0), ARGB32.color(255, 88, 6, 6)));
      this.register(MAGNETIZED, magnetizedPredicate, ModTags.Items.MAGNETIZED_INCOMPATIBLE, ModTags.Enchantments.MAGNETIZED_INCOMPATIBLE, createDisplay(MAGNETIZED, ARGB32.color(255, 200, 201, 215), ARGB32.color(255, 87, 105, 99)));
      this.register(DEMOLISHING, isToolPredicate, ModTags.Items.DEMOLISHING_INCOMPATIBLE, ModTags.Enchantments.DEMOLISHING_INCOMPATIBLE, createDisplay(DEMOLISHING, ARGB32.color(255, 111, 84, 80), ARGB32.color(255, 78, 58, 39)));
      this.register(AQUATIC, aquaticPredicate, ModTags.Items.AQUATIC_INCOMPATIBLE, ModTags.Enchantments.AQUATIC_INCOMPATIBLE, createDisplay(AQUATIC, ARGB32.color(255, 90, 130, 243), ARGB32.color(255, 35, 79, 204)));
      this.register(SOULBOUND, soulBoundPredicate, ModTags.Items.SOULBOUND_INCOMPATIBLE, ModTags.Enchantments.SOULBOUND_INCOMPATIBLE, createDisplay(SOULBOUND, ARGB32.color(255, 166, 185, 246), ARGB32.color(255, 247, 184, 217)));
   }

   private void register(ResourceKey<ItemModifier> key, ItemPredicate predicate, TagKey<Item> incompatibleItems, TagKey<Enchantment> incompatibleEnchantments, ItemModifier.DisplaySettings displaySettings) {
      this.getContext().register(key, new ItemModifier(predicate, BuiltInRegistries.ITEM.getOrCreateTag(incompatibleItems), this.enchantmentGetter.getOrThrow(incompatibleEnchantments), HolderSet.empty(), displaySettings));
   }

   private void register(ResourceKey<ItemModifier> key, ItemPredicate predicate, TagKey<Item> incompatibleItems, TagKey<Enchantment> incompatibleEnchantments, HolderSet<DataComponentType<?>> componentsToRemove, ItemModifier.DisplaySettings displaySettings) {
      this.getContext().register(key, new ItemModifier(predicate, BuiltInRegistries.ITEM.getOrCreateTag(incompatibleItems), this.enchantmentGetter.getOrThrow(incompatibleEnchantments), componentsToRemove, displaySettings));
   }

   private static ItemModifier.DisplaySettings createDisplay(ResourceKey<ItemModifier> key, int startColor, int endColor) {
      return new ItemModifier.DisplaySettings(Component.translatable(Util.makeDescriptionId("modifier", key.location())), key.location().withPrefix("textures/gui/tooltip/").withSuffix(".png"), Pair.of(startColor, endColor));
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.ITEM_MODIFIER);
      ETERNAL = HELPER.createKey("eternal");
      FIERY = HELPER.createKey("fiery");
      MAGNETIZED = HELPER.createKey("magnetized");
      DEMOLISHING = HELPER.createKey("demolishing");
      AQUATIC = HELPER.createKey("aquatic");
      SOULBOUND = HELPER.createKey("soulbound");
   }
}
