package com.stal111.forbidden_arcanus.data.research;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.ForbiddenomiconBlock;
import com.stal111.forbidden_arcanus.common.block.ResearchDeskBlock;
import com.stal111.forbidden_arcanus.common.research.DisplayInfo;
import com.stal111.forbidden_arcanus.common.research.FrameType;
import com.stal111.forbidden_arcanus.common.research.Knowledge;
import com.stal111.forbidden_arcanus.common.research.icon.ItemIcon;
import com.stal111.forbidden_arcanus.common.research.icon.TextureIcon;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.List;
import net.minecraft.core.Holder.Reference;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModKnowledge extends DatapackRegistryClass<Knowledge> {
   public static final DatapackRegistryHelper<Knowledge> HELPER;
   public static final ResourceKey<Knowledge> WELCOME;
   public static final ResourceKey<Knowledge> FORBIDDENOMICON;
   public static final ResourceKey<Knowledge> RESEARCH_DESK;

   public ModKnowledge(BootstrapContext<Knowledge> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<Knowledge> context) {
      Reference<Knowledge> welcome = context.register(WELCOME, new Knowledge(new DisplayInfo(Component.literal("Welcome!"), Component.literal("The start of an adventure."), FrameType.DEFAULT, new TextureIcon(ForbiddenArcanus.location("textures/gui/research/icon/feather.png")), 0, 0), List.of()));
      context.register(FORBIDDENOMICON, new Knowledge(new DisplayInfo(Component.literal("Forbiddenomicon"), Component.literal("The forbidden grimoire."), FrameType.ADVANCED, new ItemIcon(((ForbiddenomiconBlock)ModBlocks.FORBIDDENOMICON.get()).asItem()), 2, 0), List.of(welcome)));
      context.register(RESEARCH_DESK, new Knowledge(new DisplayInfo(Component.literal("Desk"), Component.literal("More than elegant furniture."), FrameType.MASTER, new ItemIcon(((ResearchDeskBlock)ModBlocks.RESEARCH_DESK.get()).asItem()), 0, 2), List.of(welcome)));
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.KNOWLEDGE);
      WELCOME = HELPER.createKey("welcome");
      FORBIDDENOMICON = HELPER.createKey("forbiddenomicon");
      RESEARCH_DESK = HELPER.createKey("research_desk");
   }
}
