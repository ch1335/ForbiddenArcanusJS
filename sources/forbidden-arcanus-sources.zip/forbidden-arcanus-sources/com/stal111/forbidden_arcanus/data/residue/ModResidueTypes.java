package com.stal111.forbidden_arcanus.data.residue;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.residue.ResidueType;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModResidueTypes extends DatapackRegistryClass<ResidueType> {
   public static final DatapackRegistryHelper<ResidueType> HELPER;
   public static final ResourceKey<ResidueType> ARCANE_CRYSTAL;
   public static final ResourceKey<ResidueType> RUNE;
   public static final ResourceKey<ResidueType> COAL;
   public static final ResourceKey<ResidueType> IRON;
   public static final ResourceKey<ResidueType> GOLD;
   public static final ResourceKey<ResidueType> COPPER;
   public static final ResourceKey<ResidueType> LAPIS_LAZULI;
   public static final ResourceKey<ResidueType> DIAMOND;
   public static final ResourceKey<ResidueType> EMERALD;
   public static final ResourceKey<ResidueType> NETHERITE;
   public static final ResourceKey<ResidueType> DEORUM;

   public ModResidueTypes(BootstrapContext<ResidueType> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<ResidueType> context) {
      context.register(ARCANE_CRYSTAL, ResidueType.withDefaultKey("arcane_crystal", 9, new ItemStack((ItemLike)ModBlocks.ARCANE_CRYSTAL_BLOCK.get())));
      context.register(RUNE, ResidueType.withDefaultKey("rune", 9, new ItemStack((ItemLike)ModBlocks.RUNE_BLOCK.get())));
      context.register(COAL, ResidueType.withDefaultKey("coal", 9, Items.COAL_BLOCK.getDefaultInstance()));
      context.register(IRON, ResidueType.withDefaultKey("iron", 9, Items.IRON_BLOCK.getDefaultInstance()));
      context.register(GOLD, ResidueType.withDefaultKey("gold", 9, Items.GOLD_BLOCK.getDefaultInstance()));
      context.register(COPPER, ResidueType.withDefaultKey("copper", 9, Items.COPPER_BLOCK.getDefaultInstance()));
      context.register(LAPIS_LAZULI, ResidueType.withDefaultKey("lapis_lazuli", 9, Items.LAPIS_BLOCK.getDefaultInstance()));
      context.register(DIAMOND, ResidueType.withDefaultKey("diamond", 9, Items.DIAMOND_BLOCK.getDefaultInstance()));
      context.register(EMERALD, ResidueType.withDefaultKey("emerald", 9, Items.EMERALD_BLOCK.getDefaultInstance()));
      context.register(NETHERITE, ResidueType.withDefaultKey("netherite", 9, Items.NETHERITE_BLOCK.getDefaultInstance()));
      context.register(DEORUM, ResidueType.withDefaultKey("deorum", 1, new ItemStack((ItemLike)ModItems.DEORUM_NUGGET.get(), 2)));
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.RESIDUE_TYPE);
      ARCANE_CRYSTAL = HELPER.createKey("arcane_crystal");
      RUNE = HELPER.createKey("rune");
      COAL = HELPER.createKey("coal");
      IRON = HELPER.createKey("iron");
      GOLD = HELPER.createKey("gold");
      COPPER = HELPER.createKey("copper");
      LAPIS_LAZULI = HELPER.createKey("lapis_lazuli");
      DIAMOND = HELPER.createKey("diamond");
      EMERALD = HELPER.createKey("emerald");
      NETHERITE = HELPER.createKey("netherite");
      DEORUM = HELPER.createKey("deorum");
   }
}
