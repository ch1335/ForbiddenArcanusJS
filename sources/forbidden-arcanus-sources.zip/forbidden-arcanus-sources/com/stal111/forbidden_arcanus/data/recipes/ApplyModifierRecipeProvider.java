package com.stal111.forbidden_arcanus.data.recipes;

import com.stal111.forbidden_arcanus.common.item.modifier.ItemModifier;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.data.ModItemModifiers;
import com.stal111.forbidden_arcanus.data.recipes.builder.ApplyModifierRecipeBuilder;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.world.level.ItemLike;
import net.valhelsia.valhelsia_core.datagen.recipes.RecipeSubProvider;
import net.valhelsia.valhelsia_core.datagen.recipes.ValhelsiaRecipeProvider;

public class ApplyModifierRecipeProvider extends RecipeSubProvider {
   public ApplyModifierRecipeProvider(ValhelsiaRecipeProvider provider) {
      super(provider);
   }

   protected void registerRecipes(Provider lookupProvider) {
      this.modifier((ItemLike)ModItems.ETERNAL_STELLA.get(), lookupProvider.holderOrThrow(ModItemModifiers.ETERNAL));
      this.modifier((ItemLike)ModItems.SMELTER_PRISM.get(), lookupProvider.holderOrThrow(ModItemModifiers.FIERY));
      this.modifier((ItemLike)ModItems.FERROGNETIC_MIXTURE.get(), lookupProvider.holderOrThrow(ModItemModifiers.MAGNETIZED));
      this.modifier((ItemLike)ModItems.TERRASTOMP_PRISM.get(), lookupProvider.holderOrThrow(ModItemModifiers.DEMOLISHING));
      this.modifier((ItemLike)ModItems.SEA_PRISM.get(), lookupProvider.holderOrThrow(ModItemModifiers.AQUATIC));
      this.modifier((ItemLike)ModItems.SOUL_BINDING_CRYSTAL.get(), lookupProvider.holderOrThrow(ModItemModifiers.SOULBOUND));
   }

   private void modifier(ItemLike addition, Holder<ItemModifier> modifier) {
      this.add(ApplyModifierRecipeBuilder.of((ItemLike)ModItems.APPLY_MODIFIER_SMITHING_TEMPLATE.get(), addition, modifier));
   }
}
