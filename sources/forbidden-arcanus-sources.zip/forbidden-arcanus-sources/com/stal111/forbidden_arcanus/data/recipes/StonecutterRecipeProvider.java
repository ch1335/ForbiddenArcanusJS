package com.stal111.forbidden_arcanus.data.recipes;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.SingleItemRecipeBuilder;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.valhelsia.valhelsia_core.datagen.recipes.RecipeSubProvider;
import net.valhelsia.valhelsia_core.datagen.recipes.ValhelsiaRecipeProvider;

public class StonecutterRecipeProvider extends RecipeSubProvider {
   public StonecutterRecipeProvider(ValhelsiaRecipeProvider provider) {
      super(provider);
   }

   protected void registerRecipes(Provider provider) {
      this.add((ItemLike)ModBlocks.SOULLESS_SANDSTONE_STAIRS.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get());
      this.add((ItemLike)ModBlocks.SOULLESS_SANDSTONE_SLAB.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get(), 2);
      this.add((ItemLike)ModBlocks.SOULLESS_SANDSTONE_WALL.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get());
      this.add((ItemLike)ModBlocks.CUT_SOULLESS_SANDSTONE.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get());
      this.add((ItemLike)ModBlocks.CUT_SOULLESS_SANDSTONE_SLAB.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get(), 2);
      this.add((ItemLike)ModBlocks.CUT_SOULLESS_SANDSTONE_SLAB.get(), (ItemLike)ModBlocks.CUT_SOULLESS_SANDSTONE.get(), 2);
      this.add((ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get());
      this.add((ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE_STAIRS.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get());
      this.add((ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE_SLAB.get(), (ItemLike)ModBlocks.SOULLESS_SANDSTONE.get(), 2);
      this.add((ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE_STAIRS.get(), (ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get());
      this.add((ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE_SLAB.get(), (ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get(), 2);
   }

   private void add(ItemLike result, ItemLike material) {
      this.add(result, material, 1);
   }

   private void add(ItemLike result, ItemLike material, int count) {
      SingleItemRecipeBuilder var10001 = SingleItemRecipeBuilder.stonecutting(Ingredient.of(new ItemLike[]{material}), RecipeCategory.BUILDING_BLOCKS, result, count).unlockedBy("has_" + getName(material), has(new ItemLike[]{material}));
      String var10002 = getName(result);
      this.add(var10001, var10002 + "_from_" + getName(material) + "_stonecutting");
   }
}
