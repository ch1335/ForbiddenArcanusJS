package com.stal111.forbidden_arcanus.data.recipes;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.data.FABlockFamilies;
import com.stal111.forbidden_arcanus.util.ModTags;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.component.DataComponentPredicate;
import net.minecraft.core.component.DataComponents;
import net.minecraft.data.BlockFamily;
import net.minecraft.data.recipes.RecipeCategory;
import net.minecraft.data.recipes.RecipeProvider;
import net.minecraft.data.recipes.SimpleCookingRecipeBuilder;
import net.minecraft.data.recipes.SingleItemRecipeBuilder;
import net.minecraft.data.recipes.SmithingTransformRecipeBuilder;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.common.Tags.Items;
import net.neoforged.neoforge.common.crafting.DataComponentIngredient;
import net.valhelsia.valhelsia_core.datagen.recipes.RecipePart;
import net.valhelsia.valhelsia_core.datagen.recipes.RecipeSubProvider;
import net.valhelsia.valhelsia_core.datagen.recipes.ValhelsiaRecipeProvider;

public class CraftingRecipeProvider extends RecipeSubProvider {
   private final ValhelsiaRecipeProvider provider;

   public CraftingRecipeProvider(ValhelsiaRecipeProvider provider) {
      super(provider);
      this.provider = provider;
   }

   protected void registerRecipes(Provider lookupProvider) {
      FABlockFamilies.getAllFamilies().filter(BlockFamily::shouldGenerateRecipe).forEach((family) -> {
         RecipeProvider.generateRecipes(this.provider.getRecipeOutput(), family, FeatureFlagSet.of(FeatureFlags.VANILLA));
      });
      this.shaped(RecipeCategory.DECORATIONS, (ItemLike)ModBlocks.UTREM_JAR.get(), (builder) -> {
         return builder.pattern("#X#").pattern("# #").pattern("###").define('#', Items.GLASS_BLOCKS_COLORLESS).define('X', (ItemLike)ModBlocks.EDELWOOD_PLANKS.get()).unlockedBy(this, RecipePart.of(Items.GLASS_BLOCKS_COLORLESS));
      });
      this.shaped(RecipeCategory.MISC, ModItems.ARCANE_CRYSTAL_DUST, (builder) -> {
         return builder.pattern("###").pattern("###").pattern("###").define('#', ModItems.ARCANE_CRYSTAL_DUST_SPECK).unlockedBy(this, ModItems.ARCANE_CRYSTAL_DUST_SPECK);
      });
      this.shaped(RecipeCategory.TOOLS, ModItems.SOUL_EXTRACTOR, (builder) -> {
         return builder.pattern("U  ").pattern("##X").pattern("Q  ").define('U', (ItemLike)ModBlocks.UTREM_JAR.get()).define('#', Blocks.NETHER_BRICKS).define('X', Blocks.QUARTZ_BLOCK).define('Q', net.minecraft.world.item.Items.QUARTZ).unlockedBy(this, (ItemLike)ModBlocks.UTREM_JAR.get());
      });
      this.shaped(RecipeCategory.MISC, ModItems.ARCANE_BONE_MEAL, 4, (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern(" # ").define('#', net.minecraft.world.item.Items.BONE_MEAL).define('X', ModItems.ARCANE_CRYSTAL_DUST).unlockedBy(this, ModItems.ARCANE_CRYSTAL_DUST);
      });
      this.shaped(RecipeCategory.MISC, ModItems.AUREAL_BOTTLE, (builder) -> {
         return builder.pattern("###").pattern("#X#").pattern("###").define('#', ModItems.ARCANE_CRYSTAL_DUST).define('X', DataComponentIngredient.of(true, DataComponentPredicate.builder().expect(DataComponents.POTION_CONTENTS, new PotionContents(Potions.STRONG_REGENERATION)).build(), new ItemLike[]{net.minecraft.world.item.Items.POTION})).unlockedBy(this, ModItems.ARCANE_CRYSTAL_DUST);
      });
      this.shaped(RecipeCategory.TOOLS, ModItems.MAGIC_WAND, (builder) -> {
         return builder.pattern("  E").pattern(" D ").pattern("A  ").define('E', ModItems.EDELWOOD_STICK).define('D', ModItems.DEORUM_INGOT).define('A', ModItems.ARCANE_CRYSTAL).unlockedBy(this, RecipePart.of(ModItems.EDELWOOD_STICK)).unlockedBy(this, RecipePart.of(ModItems.DEORUM_INGOT)).unlockedBy(this, RecipePart.of(ModItems.ARCANE_CRYSTAL));
      });
      this.shaped(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.DARKSTONE_PEDESTAL.get(), (builder) -> {
         return builder.pattern("###").pattern(" * ").pattern("XXX").define('#', (ItemLike)ModBlocks.ARCANE_POLISHED_DARKSTONE_SLAB.get()).define('*', (ItemLike)ModBlocks.ARCANE_POLISHED_DARKSTONE_PILLAR.get()).define('X', (ItemLike)ModBlocks.POLISHED_DARKSTONE.get()).unlockedBy(this, (ItemLike)ModBlocks.POLISHED_DARKSTONE.get());
      });
      this.shaped(RecipeCategory.MISC, ModItems.DARK_NETHER_STAR, (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern(" # ").define('#', ModItems.OBSIDIANSTEEL_INGOT).define('X', net.minecraft.world.item.Items.NETHER_STAR).unlockedBy(this, ModItems.OBSIDIANSTEEL_INGOT).unlockedBy(this, net.minecraft.world.item.Items.NETHER_STAR);
      });
      this.shaped(RecipeCategory.MISC, ModItems.DEORUM_INGOT, (builder) -> {
         return builder.pattern("#*#").pattern("MXM").pattern("#*#").define('#', net.minecraft.world.item.Items.CHARCOAL).define('X', net.minecraft.world.item.Items.GOLD_INGOT).define('M', ModItems.MUNDABITUR_DUST).define('*', ModItems.ARCANE_CRYSTAL_DUST).unlockedBy(this, net.minecraft.world.item.Items.GOLD_INGOT).unlockedBy(this, ModItems.ARCANE_CRYSTAL_DUST).unlockedBy(this, ModItems.MUNDABITUR_DUST);
      });
      this.shaped(RecipeCategory.DECORATIONS, (ItemLike)ModBlocks.DEORUM_CHAIN.get(), (builder) -> {
         return builder.pattern("#").pattern("X").pattern("#").define('#', ModTags.Items.DEORUM_NUGGETS).define('X', ModTags.Items.DEORUM_INGOTS).unlockedBy(this, RecipePart.of(ModTags.Items.DEORUM_INGOTS)).unlockedBy(this, RecipePart.of(ModTags.Items.DEORUM_NUGGETS));
      });
      DyeColor[] var2 = DyeColor.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         DyeColor color = var2[var4];
         this.shaped(RecipeCategory.TOOLS, (ItemLike)ModItems.DYED_QUANTUM_CATCHERS.get(color), (builder) -> {
            return builder.pattern(" # ").pattern("#X#").pattern(" # ").define('X', ModItems.QUANTUM_CATCHER).define('#', color.getTag()).unlockedBy(this, ModItems.QUANTUM_CATCHER).unlockedBy(this, RecipePart.of(color.getTag()));
         });
      }

      this.shaped(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.EDELWOOD_LADDER.get(), 3, (builder) -> {
         return builder.pattern("# #").pattern("#X#").pattern("# #").define('#', Items.RODS_WOODEN).define('X', (ItemLike)ModBlocks.EDELWOOD_PLANKS.get()).unlockedBy(this, RecipePart.of(Items.RODS_WOODEN)).unlockedBy(this, (ItemLike)ModBlocks.EDELWOOD_PLANKS.get());
      });
      this.shaped(RecipeCategory.MISC, ModItems.EDELWOOD_BUCKET, (builder) -> {
         return builder.pattern("# #").pattern("# #").pattern(" # ").define('#', (ItemLike)ModBlocks.EDELWOOD_PLANKS.get()).unlockedBy("has_planks", has(new ItemLike[]{(ItemLike)ModBlocks.EDELWOOD_PLANKS.get()}));
      });
      this.shaped(RecipeCategory.MISC, ModItems.BOOM_ARROW, 4, (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern(" # ").define('X', Blocks.TNT).define('#', net.minecraft.world.item.Items.ARROW).unlockedBy(this, Blocks.TNT).unlockedBy(this, net.minecraft.world.item.Items.ARROW);
      });
      this.surroundingItem(RecipeCategory.MISC, (ItemLike)ModBlocks.ARCANE_POLISHED_DARKSTONE.get(), this.item(ModItems.DEORUM_INGOT), this.item((ItemLike)ModBlocks.POLISHED_DARKSTONE.get()), 8);
      this.surroundingItem(RecipeCategory.MISC, ModBlocks.OBSIDIAN_SKULL.getSkull(), this.item(net.minecraft.world.item.Items.SKELETON_SKULL), this.item(ModItems.OBSIDIANSTEEL_INGOT), 1);
      this.surroundingItem(RecipeCategory.MISC, ModItems.APPLY_MODIFIER_SMITHING_TEMPLATE, this.item(net.minecraft.world.item.Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE), this.item((ItemLike)ModBlocks.DARKSTONE.get()), 1);
      this.shaped(RecipeCategory.MISC, (ItemLike)ModBlocks.ARCANE_DRAGON_EGG.get(), (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern("###").define('#', ModItems.GOLDEN_DRAGON_SCALE).define('X', Blocks.DRAGON_EGG).unlockedBy(this, Blocks.DRAGON_EGG).unlockedBy(this, ModItems.GOLDEN_DRAGON_SCALE);
      });
      this.shaped(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.ARCANE_POLISHED_DARKSTONE_PILLAR.get(), (builder) -> {
         return builder.pattern("#").pattern("#").define('#', (ItemLike)ModBlocks.ARCANE_POLISHED_DARKSTONE.get()).unlockedBy(this, (ItemLike)ModBlocks.ARCANE_POLISHED_DARKSTONE.get());
      });
      this.shaped(RecipeCategory.MISC, ModItems.DRACO_ARCANUS_ARROW, (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern(" # ").define('#', net.minecraft.world.item.Items.ARROW).define('X', net.minecraft.world.item.Items.DRAGON_BREATH).unlockedBy(this, net.minecraft.world.item.Items.ARROW).unlockedBy(this, net.minecraft.world.item.Items.DRAGON_BREATH);
      });
      this.shaped(RecipeCategory.MISC, ModItems.SILVER_DRAGON_SCALE, (builder) -> {
         return builder.pattern("#X#").pattern("XDX").pattern("#X#").define('#', ModItems.ARCANE_CRYSTAL_DUST).define('X', net.minecraft.world.item.Items.IRON_INGOT).define('D', ModItems.DRAGON_SCALE).unlockedBy(this, ModItems.ARCANE_CRYSTAL_DUST).unlockedBy(this, ModItems.DRAGON_SCALE);
      });
      this.shaped(RecipeCategory.MISC, ModItems.GOLDEN_DRAGON_SCALE, (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern(" # ").define('#', ModItems.DEORUM_INGOT).define('X', ModItems.DRAGON_SCALE).unlockedBy(this, ModItems.DEORUM_INGOT).unlockedBy(this, ModItems.DRAGON_SCALE);
      });
      this.shaped(RecipeCategory.MISC, ModItems.SPECTRAL_EYE_AMULET, (builder) -> {
         return builder.pattern(" # ").pattern("#X#").pattern("DED").define('#', net.minecraft.world.item.Items.STRING).define('X', net.minecraft.world.item.Items.NETHER_STAR).define('D', ModItems.DEORUM_INGOT).define('E', net.minecraft.world.item.Items.ENDER_EYE).unlockedBy(this, ModItems.DEORUM_INGOT).unlockedBy(this, net.minecraft.world.item.Items.NETHER_STAR);
      });
      this.shaped(RecipeCategory.MISC, net.minecraft.world.item.Items.ENDER_PEARL, (builder) -> {
         return builder.pattern(" # ").pattern("# #").pattern(" # ").define('#', ModItems.ENDER_PEARL_FRAGMENT).unlockedBy(this, ModItems.ENDER_PEARL_FRAGMENT);
      });
      this.shapeless(RecipeCategory.MISC, ModItems.TEST_TUBE, (builder) -> {
         return builder.requires(net.minecraft.world.item.Items.GLASS_BOTTLE).requires(ModItems.RUNE).unlockedBy("has_item", has(new ItemLike[]{ModItems.RUNE}));
      });
      this.shapeless(RecipeCategory.MISC, ModItems.MUNDABITUR_DUST, 4, (builder) -> {
         return builder.requires(ModItems.ARCANE_CRYSTAL_DUST).requires(net.minecraft.world.item.Items.REDSTONE).requires(net.minecraft.world.item.Items.BLAZE_POWDER).requires(net.minecraft.world.item.Items.BONE_MEAL).requires(net.minecraft.world.item.Items.PHANTOM_MEMBRANE).requires(net.minecraft.world.item.Items.GUNPOWDER).unlockedBy("has_arcane_crystal_dust", has(new ItemLike[]{ModItems.ARCANE_CRYSTAL_DUST})).unlockedBy("has_redstone", has(new ItemLike[]{net.minecraft.world.item.Items.REDSTONE})).unlockedBy("has_blaze_powder", has(new ItemLike[]{net.minecraft.world.item.Items.BLAZE_POWDER})).unlockedBy("has_bone_meal", has(new ItemLike[]{net.minecraft.world.item.Items.BONE_MEAL})).unlockedBy("has_phantom_membrane", has(new ItemLike[]{net.minecraft.world.item.Items.PHANTOM_MEMBRANE})).unlockedBy("has_gunpowder", has(new ItemLike[]{net.minecraft.world.item.Items.GUNPOWDER}));
      });
      this.shapeless(RecipeCategory.MISC, ModItems.WAX, 2, (builder) -> {
         return builder.requires(net.minecraft.world.item.Items.HONEY_BOTTLE).requires(net.minecraft.world.item.Items.SLIME_BALL).unlockedBy("has_honey_bottle", has(new ItemLike[]{net.minecraft.world.item.Items.HONEY_BOTTLE})).unlockedBy("has_slime_ball", has(new ItemLike[]{net.minecraft.world.item.Items.SLIME_BALL}));
      });
      this.shapeless(RecipeCategory.MISC, ModItems.CORRUPTI_DUST, 4, (builder) -> {
         return builder.requires(ModItems.OBSIDIANSTEEL_INGOT).requires(net.minecraft.world.item.Items.BLAZE_POWDER).requires(net.minecraft.world.item.Items.NETHER_WART).requires(ModItems.ARCANE_CRYSTAL_DUST).requires(ModItems.ENDER_PEARL_FRAGMENT).unlockedBy("has_obsidiansteel_ingot", has(new ItemLike[]{ModItems.OBSIDIANSTEEL_INGOT})).unlockedBy("has_blaze_powder", has(new ItemLike[]{net.minecraft.world.item.Items.BLAZE_POWDER})).unlockedBy("has_nether_wart", has(new ItemLike[]{net.minecraft.world.item.Items.NETHER_WART})).unlockedBy("has_arcane_crystal_dust", has(new ItemLike[]{ModItems.ARCANE_CRYSTAL_DUST})).unlockedBy("has_ender_pearl_fragment", has(new ItemLike[]{ModItems.ENDER_PEARL_FRAGMENT}));
      });
      this.shapeless(RecipeCategory.MISC, ModBlocks.OBSIDIAN_SKULL.getSkull(), (builder) -> {
         return builder.requires(ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull()).requires(ModItems.OBSIDIANSTEEL_INGOT, 2).unlockedBy("has_cracked_obsidian_skull", has(new ItemLike[]{ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull()})).unlockedBy("has_obsidiansteel_ingot", has(new ItemLike[]{ModItems.OBSIDIANSTEEL_INGOT}));
      }, "obsidian_skull_from_cracked_obsidian_skull");
      this.shapeless(RecipeCategory.MISC, ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull(), (builder) -> {
         return builder.requires(ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull()).requires(ModItems.OBSIDIANSTEEL_INGOT, 2).unlockedBy("has_fragmented_obsidian_skull", has(new ItemLike[]{ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull()})).unlockedBy("has_obsidiansteel_ingot", has(new ItemLike[]{ModItems.OBSIDIANSTEEL_INGOT}));
      });
      this.shapeless(RecipeCategory.MISC, ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull(), (builder) -> {
         return builder.requires(ModBlocks.FADING_OBSIDIAN_SKULL.getSkull()).requires(ModItems.OBSIDIANSTEEL_INGOT, 2).unlockedBy("has_fading_obsidian_skull", has(new ItemLike[]{ModBlocks.FADING_OBSIDIAN_SKULL.getSkull()})).unlockedBy("has_obsidiansteel_ingot", has(new ItemLike[]{ModItems.OBSIDIANSTEEL_INGOT}));
      });
      this.shapeless(RecipeCategory.MISC, (ItemLike)ModBlocks.QUANTUM_CORE.get(), (builder) -> {
         return builder.requires(ModItems.RUNE).requires(net.minecraft.world.item.Items.FLINT).requires(ModItems.MUNDABITUR_DUST).unlockedBy("has_rune", has(new ItemLike[]{ModItems.RUNE})).unlockedBy("has_flint", has(new ItemLike[]{net.minecraft.world.item.Items.FLINT})).unlockedBy("has_mundabitur_dust", has(new ItemLike[]{ModItems.MUNDABITUR_DUST}));
      });
      this.shapeless(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get(), (builder) -> {
         return builder.requires((ItemLike)ModBlocks.CHISELED_POLISHED_DARKSTONE.get()).requires(ModItems.DEORUM_NUGGET).unlockedBy("has_chiseled_polished_darkstone", has(new ItemLike[]{(ItemLike)ModBlocks.CHISELED_POLISHED_DARKSTONE.get()})).unlockedBy("has_deorum_nugget", has(new ItemLike[]{ModItems.DEORUM_NUGGET}));
      });
      this.shapeless(RecipeCategory.MISC, (ItemLike)ModItems.AQUATIC_DRAGON_SCALE.get(), (builder) -> {
         return builder.requires(ModItems.DRAGON_SCALE).requires(net.minecraft.world.item.Items.PRISMARINE_SHARD).requires(net.minecraft.world.item.Items.PRISMARINE_CRYSTALS).requires(ModItems.ARCANE_CRYSTAL_DUST).unlockedBy("has_dragon_scale", has(new ItemLike[]{ModItems.DRAGON_SCALE}));
      });
      this.shapeless(RecipeCategory.FOOD, ModItems.BAT_SOUP, (builder) -> {
         return builder.requires(Items.MUSHROOMS).requires(net.minecraft.world.item.Items.NETHER_WART).requires(net.minecraft.world.item.Items.BOWL).requires(ModItems.BAT_WING).unlockedBy("has_bat_wing", has(new ItemLike[]{ModItems.BAT_WING}));
      });
      this.shapeless(RecipeCategory.MISC, net.minecraft.world.item.Items.BLACK_DYE, 2, (builder) -> {
         return builder.requires(ModItems.EDELWOOD_OIL).unlockedBy("has_edelwood_oil", has(new ItemLike[]{ModItems.EDELWOOD_OIL}));
      }, "black_dye");
      this.shapeless(RecipeCategory.MISC, ModItems.ENDER_PEARL_FRAGMENT, 4, (builder) -> {
         return builder.requires(net.minecraft.world.item.Items.ENDER_PEARL).unlockedBy("has_ender_pearl", has(new ItemLike[]{net.minecraft.world.item.Items.ENDER_PEARL}));
      });
      this.add(SimpleCookingRecipeBuilder.smelting(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.ARCANE_CRYSTAL.get()}), RecipeCategory.MISC, (ItemLike)ModItems.ARCANE_CRYSTAL_DUST.get(), 0.4F, 150).unlockedBy("has_item", has(new ItemLike[]{(ItemLike)ModItems.ARCANE_CRYSTAL.get()})), "smelting/arcane_crystal_dust_from_smelting");
      this.add(SimpleCookingRecipeBuilder.smelting(Ingredient.of(ModTags.Items.RUNIC_STONES), RecipeCategory.MISC, (ItemLike)ModItems.RUNE.get(), 1.0F, 200).unlockedBy("has_item", has(ModTags.Items.RUNIC_STONES)), "smelting/rune_from_smelting");
      this.add(SimpleCookingRecipeBuilder.smelting(Ingredient.of(ModTags.Items.ARCANE_CRYSTAL_ORES), RecipeCategory.MISC, (ItemLike)ModItems.ARCANE_CRYSTAL.get(), 1.0F, 200).unlockedBy("has_item", has(ModTags.Items.ARCANE_CRYSTAL_ORES)), "smelting/arcane_crystal_from_smelting");
      this.add(SimpleCookingRecipeBuilder.smelting(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.TENTACLE.get()}), RecipeCategory.FOOD, (ItemLike)ModItems.COOKED_TENTACLE.get(), 0.35F, 200).unlockedBy("has_item", has(new ItemLike[]{(ItemLike)ModItems.TENTACLE.get()})), "smelting/cooked_tentacle");
      this.add(SimpleCookingRecipeBuilder.smelting(Ingredient.of(new ItemLike[]{(ItemLike)ModBlocks.EDELWOOD_LOG.get()}), RecipeCategory.MISC, (ItemLike)ModItems.DARK_MATTER.get(), 0.4F, 400).unlockedBy("has_item", has(new ItemLike[]{(ItemLike)ModBlocks.EDELWOOD_LOG.get()})), "smelting/dark_matter");
      this.add(SimpleCookingRecipeBuilder.blasting(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.ARCANE_CRYSTAL.get()}), RecipeCategory.MISC, (ItemLike)ModItems.ARCANE_CRYSTAL_DUST.get(), 0.4F, 75).unlockedBy("has_item", has(new ItemLike[]{(ItemLike)ModItems.ARCANE_CRYSTAL.get()})), "blasting/arcane_crystal_dust_from_blasting");
      this.add(SimpleCookingRecipeBuilder.blasting(Ingredient.of(ModTags.Items.RUNIC_STONES), RecipeCategory.MISC, (ItemLike)ModItems.RUNE.get(), 1.0F, 100).unlockedBy("has_item", has(ModTags.Items.RUNIC_STONES)), "blasting/rune_from_blasting");
      this.add(SimpleCookingRecipeBuilder.blasting(Ingredient.of(ModTags.Items.ARCANE_CRYSTAL_ORES), RecipeCategory.MISC, (ItemLike)ModItems.ARCANE_CRYSTAL.get(), 1.0F, 100).unlockedBy("has_item", has(ModTags.Items.ARCANE_CRYSTAL_ORES)), "blasting/arcane_crystal_from_blasting");
      SmithingTransformRecipeBuilder.smithing(Ingredient.of(new ItemLike[]{net.minecraft.world.item.Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE}), Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DIAMOND_BLACKSMITH_GAVEL.get()}), Ingredient.of(new ItemLike[]{net.minecraft.world.item.Items.NETHERITE_INGOT}), RecipeCategory.MISC, (Item)ModItems.NETHERITE_BLACKSMITH_GAVEL.get()).unlocks("has_item", has(new ItemLike[]{net.minecraft.world.item.Items.NETHERITE_INGOT})).save(this.getRecipeOutput(), ForbiddenArcanus.location("smithing/netherite_blacksmith_gavel"));
      this.addStonecutterRecipe((ItemLike)ModBlocks.TILED_POLISHED_DARKSTONE_BRICKS.get(), (ItemLike)ModBlocks.DARKSTONE.get());
      this.addStonecutterRecipe((ItemLike)ModBlocks.TILED_POLISHED_DARKSTONE_BRICKS.get(), (ItemLike)ModBlocks.POLISHED_DARKSTONE.get());
      this.addStonecutterRecipe((ItemLike)ModBlocks.TILED_POLISHED_DARKSTONE_BRICKS.get(), (ItemLike)ModBlocks.POLISHED_DARKSTONE_BRICKS.get());
      this.storageRecipe((ItemLike)ModItems.OBSIDIANSTEEL_INGOT.get(), (ItemLike)ModBlocks.OBSIDIANSTEEL_BLOCK.get(), "obsidian_ingot", (String)null);
      this.storageRecipe((ItemLike)ModItems.DEORUM_INGOT.get(), (ItemLike)ModBlocks.DEORUM_BLOCK.get(), "deorum_ingot", (String)null);
      this.storageRecipe((ItemLike)ModItems.DEORUM_NUGGET.get(), (ItemLike)ModItems.DEORUM_INGOT.get(), (String)null, "deorum_ingot");
      this.storageRecipe((ItemLike)ModItems.STELLARITE_PIECE.get(), (ItemLike)ModBlocks.STELLARITE_BLOCK.get());
      this.storageRecipe((ItemLike)ModItems.ARCANE_CRYSTAL.get(), (ItemLike)ModBlocks.ARCANE_CRYSTAL_BLOCK.get());
      this.storageRecipe((ItemLike)ModItems.CORRUPTED_ARCANE_CRYSTAL.get(), (ItemLike)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_BLOCK.get());
      this.storageRecipe((ItemLike)ModItems.RUNE.get(), (ItemLike)ModBlocks.RUNE_BLOCK.get());
      this.surroundingItem(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.DEORUM_GLASS.get(), this.tag(ModTags.Items.DEORUM_INGOTS), RecipePart.of(Blocks.GLASS), 8);
      this.glassPane((ItemLike)ModBlocks.DEORUM_GLASS_PANE.get(), this.item((ItemLike)ModBlocks.DEORUM_GLASS.get()));
      this.surroundingItem(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.RUNIC_GLASS.get(), RecipePart.of((Item)ModItems.RUNE.get()), RecipePart.of(Blocks.GLASS), 8);
      this.glassPane((ItemLike)ModBlocks.RUNIC_GLASS_PANE.get(), this.item((ItemLike)ModBlocks.RUNIC_GLASS.get()));
      this.combine2x2((ItemLike)ModBlocks.SOULLESS_SANDSTONE.get(), this.item((ItemLike)ModBlocks.SOULLESS_SAND.get()));
      this.slab((ItemLike)ModBlocks.SOULLESS_SANDSTONE_SLAB.get(), this.item((ItemLike)ModBlocks.SOULLESS_SANDSTONE.get()));
      this.stairs((ItemLike)ModBlocks.SOULLESS_SANDSTONE_STAIRS.get(), this.item((ItemLike)ModBlocks.SOULLESS_SANDSTONE.get()));
      this.wall((ItemLike)ModBlocks.SOULLESS_SANDSTONE_WALL.get(), this.item((ItemLike)ModBlocks.SOULLESS_SANDSTONE.get()));
      this.combine2x2((ItemLike)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get(), this.item((ItemLike)ModBlocks.SOULLESS_SANDSTONE.get()), 4);
      this.wood((ItemLike)ModBlocks.FUNGYSS_HYPHAE.get(), this.item((ItemLike)ModBlocks.FUNGYSS_STEM.get()));
      this.wood((ItemLike)ModBlocks.AURUM_WOOD.get(), this.item((ItemLike)ModBlocks.AURUM_LOG.get()));
      this.wood((ItemLike)ModBlocks.STRIPPED_AURUM_WOOD.get(), this.item((ItemLike)ModBlocks.STRIPPED_AURUM_LOG.get()));
      this.planks((ItemLike)ModBlocks.FUNGYSS_PLANKS.get(), ModTags.Items.FUNGYSS_STEMS, 4);
      this.planks((ItemLike)ModBlocks.AURUM_PLANKS.get(), ModTags.Items.MYSTERYWOOD_LOGS, 4);
      this.planks((ItemLike)ModBlocks.EDELWOOD_PLANKS.get(), ModTags.Items.EDELWOOD_LOGS, 2);
      this.surroundingItem(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.ARCANE_EDELWOOD_PLANKS.get(), this.tag(ModTags.Items.DEORUM_INGOTS), this.item((ItemLike)ModBlocks.EDELWOOD_PLANKS.get()), 8);
      this.door((ItemLike)ModBlocks.DEORUM_DOOR.get(), this.tag(ModTags.Items.DEORUM_INGOTS));
      this.trapdoor((ItemLike)ModBlocks.DEORUM_TRAPDOOR.get(), this.tag(ModTags.Items.DEORUM_INGOTS));
      this.boat((ItemLike)ModItems.AURUM_BOAT.get(), this.item((ItemLike)ModBlocks.AURUM_PLANKS.get()));
      this.boat((ItemLike)ModItems.EDELWOOD_BOAT.get(), this.item((ItemLike)ModBlocks.EDELWOOD_PLANKS.get()));
      this.chestBoat((ItemLike)ModItems.AURUM_CHEST_BOAT.get(), (ItemLike)ModItems.AURUM_BOAT.get());
      this.chestBoat((ItemLike)ModItems.EDELWOOD_CHEST_BOAT.get(), (ItemLike)ModItems.EDELWOOD_BOAT.get());
      this.surroundingItem(RecipeCategory.BUILDING_BLOCKS, (ItemLike)ModBlocks.CLIBANO_CORE.get(), RecipePart.of(Blocks.BLAST_FURNACE), RecipePart.of((Block)ModBlocks.DARKSTONE.get()), 1);
      this.lantern((ItemLike)ModBlocks.DEORUM_LANTERN.get(), Blocks.TORCH, RecipePart.of(ModTags.Items.DEORUM_NUGGETS));
      this.lantern((ItemLike)ModBlocks.DEORUM_SOUL_LANTERN.get(), Blocks.SOUL_TORCH, RecipePart.of(ModTags.Items.DEORUM_NUGGETS));
      this.shaped(RecipeCategory.MISC, (ItemLike)ModItems.BLACKSMITH_GAVEL_HEAD.get(), (builder) -> {
         return builder.pattern("###").pattern("# #").pattern(" # ").define('#', net.minecraft.world.item.Items.CLAY_BALL).unlockedBy(this, net.minecraft.world.item.Items.CLAY_BALL);
      });
      this.blacksmithGavel((ItemLike)ModItems.WOODEN_BLACKSMITH_GAVEL.get(), ItemTags.PLANKS);
      this.blacksmithGavel((ItemLike)ModItems.STONE_BLACKSMITH_GAVEL.get(), ItemTags.STONE_TOOL_MATERIALS);
      this.blacksmithGavel((ItemLike)ModItems.GOLDEN_BLACKSMITH_GAVEL.get(), Items.INGOTS_GOLD);
      this.blacksmithGavel((ItemLike)ModItems.IRON_BLACKSMITH_GAVEL.get(), Items.INGOTS_IRON);
      this.blacksmithGavel((ItemLike)ModItems.DIAMOND_BLACKSMITH_GAVEL.get(), Items.GEMS_DIAMOND);
   }

   public void slab(ItemLike result, RecipePart<?> material) {
      this.shaped(RecipeCategory.BUILDING_BLOCKS, result, 6, (builder) -> {
         return builder.pattern("###").define('#', material).unlockedBy(this, material);
      });
   }

   public void stairs(ItemLike result, RecipePart<?> material) {
      this.shaped(RecipeCategory.BUILDING_BLOCKS, result, 4, (builder) -> {
         return builder.pattern("#  ").pattern("## ").pattern("###").define('#', material).unlockedBy(this, material);
      });
   }

   public void wall(ItemLike result, RecipePart<?> material) {
      this.shaped(RecipeCategory.BUILDING_BLOCKS, result, 6, (builder) -> {
         return builder.pattern("###").pattern("###").define('#', material).unlockedBy(this, material);
      });
   }

   public void combine2x2(ItemLike result, RecipePart<?> material) {
      this.combine2x2(result, material, 1);
   }

   public void combine2x2(ItemLike result, RecipePart<?> material, int count) {
      this.shaped(RecipeCategory.BUILDING_BLOCKS, result, count, (builder) -> {
         return builder.pattern("##").pattern("##").define('#', material).unlockedBy(this, material);
      });
   }

   private void lantern(ItemLike result, ItemLike torch, RecipePart<?> material) {
      this.shaped(RecipeCategory.DECORATIONS, result, (builder) -> {
         return builder.pattern("XXX").pattern("X#X").pattern("XXX").define('X', material).define('#', torch).unlockedBy(this, material).unlockedBy(this, torch);
      });
   }

   private void blacksmithGavel(ItemLike gavel, TagKey<Item> material) {
      this.shaped(RecipeCategory.TOOLS, gavel, (builder) -> {
         return builder.pattern("#X#").pattern("#S#").pattern(" S ").define('#', material).define('X', (ItemLike)ModItems.BLACKSMITH_GAVEL_HEAD.get()).define('S', Items.RODS_WOODEN).unlockedBy(this, RecipePart.of(material));
      });
   }

   private void addStonecutterRecipe(ItemLike result, ItemLike material) {
      this.addStonecutterRecipe(result, material, 1);
   }

   private void addStonecutterRecipe(ItemLike result, ItemLike material, int count) {
      SingleItemRecipeBuilder var10001 = SingleItemRecipeBuilder.stonecutting(Ingredient.of(new ItemLike[]{material}), RecipeCategory.BUILDING_BLOCKS, result, count).unlockedBy("has_" + getName(material), has(new ItemLike[]{material}));
      String var10002 = getName(result);
      this.add(var10001, var10002 + "_from_" + getName(material) + "_stonecutting");
   }
}
