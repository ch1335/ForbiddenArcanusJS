package com.stal111.forbidden_arcanus.data.recipes.builder;

import com.stal111.forbidden_arcanus.common.item.crafting.ApplyModifierRecipe;
import com.stal111.forbidden_arcanus.common.item.modifier.ItemModifier;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.advancements.Criterion;
import net.minecraft.advancements.Advancement.Builder;
import net.minecraft.advancements.AdvancementRequirements.Strategy;
import net.minecraft.advancements.critereon.RecipeUnlockedTrigger;
import net.minecraft.core.Holder;
import net.minecraft.data.recipes.RecipeBuilder;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;

public record ApplyModifierRecipeBuilder(Ingredient template, Ingredient addition, Holder<ItemModifier> modifier) implements RecipeBuilder {
   public ApplyModifierRecipeBuilder(Ingredient template, Ingredient addition, Holder<ItemModifier> modifier) {
      this.template = template;
      this.addition = addition;
      this.modifier = modifier;
   }

   public static ApplyModifierRecipeBuilder of(ItemLike template, ItemLike addition, Holder<ItemModifier> modifier) {
      return new ApplyModifierRecipeBuilder(Ingredient.of(new ItemLike[]{template}), Ingredient.of(new ItemLike[]{addition}), modifier);
   }

   public static ApplyModifierRecipeBuilder of(ItemLike template, Ingredient addition, Holder<ItemModifier> modifier) {
      return new ApplyModifierRecipeBuilder(Ingredient.of(new ItemLike[]{template}), addition, modifier);
   }

   @Nonnull
   public RecipeBuilder unlockedBy(@Nonnull String criterionName, @Nonnull Criterion<?> criterion) {
      return this;
   }

   @Nonnull
   public RecipeBuilder group(@Nullable String groupName) {
      return this;
   }

   public Item getResult() {
      return null;
   }

   public void save(@Nonnull RecipeOutput recipeOutput) {
      ResourceLocation key = this.modifier.getKey().location();
      this.save(recipeOutput, ResourceLocation.fromNamespaceAndPath(key.getNamespace(), "smithing/apply_" + key.getPath() + "_modifier"));
   }

   public void save(@Nonnull RecipeOutput recipeOutput, @Nonnull ResourceLocation recipeId) {
      ApplyModifierRecipe recipe = new ApplyModifierRecipe(this.template, this.addition, this.modifier);
      Builder builder = recipeOutput.advancement().addCriterion("has_the_recipe", RecipeUnlockedTrigger.unlocked(recipeId)).rewards(net.minecraft.advancements.AdvancementRewards.Builder.recipe(recipeId)).requirements(Strategy.OR);
      recipeOutput.accept(recipeId, recipe, builder.build(recipeId.withPrefix("recipes/apply_modifier/")));
   }

   public Ingredient template() {
      return this.template;
   }

   public Ingredient addition() {
      return this.addition;
   }

   public Holder<ItemModifier> modifier() {
      return this.modifier;
   }
}
