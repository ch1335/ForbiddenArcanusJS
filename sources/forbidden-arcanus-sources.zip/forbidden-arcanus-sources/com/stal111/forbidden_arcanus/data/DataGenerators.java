package com.stal111.forbidden_arcanus.data;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.data.client.ModSoundsProvider;
import com.stal111.forbidden_arcanus.data.model.ModBlockModels;
import com.stal111.forbidden_arcanus.data.model.ModItemModels;
import com.stal111.forbidden_arcanus.data.particle.ParticleDataProvider;
import com.stal111.forbidden_arcanus.data.recipes.ApplyModifierRecipeProvider;
import com.stal111.forbidden_arcanus.data.recipes.ClibanoRecipeProvider;
import com.stal111.forbidden_arcanus.data.recipes.CraftingRecipeProvider;
import com.stal111.forbidden_arcanus.data.recipes.SpecialRecipesProvider;
import com.stal111.forbidden_arcanus.data.recipes.StonecutterRecipeProvider;
import com.stal111.forbidden_arcanus.data.server.loot.ModBlockLootAdditions;
import com.stal111.forbidden_arcanus.data.server.loot.ModBlockLootTables;
import com.stal111.forbidden_arcanus.data.server.loot.ModChestLootAdditions;
import com.stal111.forbidden_arcanus.data.server.loot.ModEntityLootAdditions;
import com.stal111.forbidden_arcanus.data.server.loot.ModEntityLootTables;
import com.stal111.forbidden_arcanus.data.server.loot.ModLootModifierProvider;
import com.stal111.forbidden_arcanus.data.server.tags.ModBlockTagsProvider;
import com.stal111.forbidden_arcanus.data.server.tags.ModEnchantmentTagsProvider;
import com.stal111.forbidden_arcanus.data.server.tags.ModEntityTypeTagsProvider;
import com.stal111.forbidden_arcanus.data.server.tags.ModItemTagsProvider;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.PackOutput;
import net.minecraft.data.DataGenerator.PackGenerator;
import net.minecraft.data.loot.LootTableProvider;
import net.minecraft.data.loot.LootTableProvider.SubProviderEntry;
import net.minecraft.data.metadata.PackMetadataGenerator;
import net.minecraft.network.chat.Component;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.common.data.DatapackBuiltinEntriesProvider;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.neoforged.neoforge.data.event.GatherDataEvent;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;
import net.valhelsia.valhelsia_core.datagen.model.ValhelsiaModelProvider;
import net.valhelsia.valhelsia_core.datagen.recipes.ValhelsiaRecipeProvider;

@EventBusSubscriber(
   modid = "forbidden_arcanus",
   bus = Bus.MOD
)
public class DataGenerators {
   @SubscribeEvent
   public static void gatherData(GatherDataEvent event) {
      DataGenerator generator = event.getGenerator();
      PackOutput output = generator.getPackOutput();
      CompletableFuture<Provider> lookupProvider = event.getLookupProvider();
      ExistingFileHelper fileHelper = event.getExistingFileHelper();
      DataProviderContext context = new DataProviderContext(event.getGenerator().getPackOutput(), event.getLookupProvider(), ForbiddenArcanus.REGISTRY_MANAGER, event.getExistingFileHelper());
      generator.addProvider(event.includeClient(), new ValhelsiaModelProvider(context, ModBlockModels::new, ModItemModels::new));
      generator.addProvider(event.includeClient(), new LangProvider(context.output()));
      generator.addProvider(event.includeClient(), new ModSoundsProvider(context, fileHelper));
      generator.addProvider(event.includeServer(), new ParticleDataProvider(context));
      DatapackBuiltinEntriesProvider datapackBuiltinEntriesProvider = new DatapackBuiltinEntriesProvider(output, lookupProvider, ForbiddenArcanus.REGISTRY_MANAGER.buildRegistrySet(), Set.of("forbidden_arcanus"));
      generator.addProvider(event.includeServer(), datapackBuiltinEntriesProvider);
      lookupProvider = datapackBuiltinEntriesProvider.getRegistryProvider();
      context = new DataProviderContext(event.getGenerator().getPackOutput(), lookupProvider, ForbiddenArcanus.REGISTRY_MANAGER, event.getExistingFileHelper());
      ModBlockTagsProvider blockTagsProvider = new ModBlockTagsProvider(context);
      generator.addProvider(event.includeServer(), blockTagsProvider);
      generator.addProvider(event.includeServer(), new ModItemTagsProvider(context, blockTagsProvider.contentsGetter()));
      generator.addProvider(event.includeServer(), new ModEnchantmentTagsProvider(context, fileHelper));
      generator.addProvider(event.includeServer(), new ModEntityTypeTagsProvider(context, fileHelper));
      generator.addProvider(event.includeServer(), new LootTableProvider(output, Set.of(), List.of(new SubProviderEntry(ModBlockLootTables::new, LootContextParamSets.BLOCK), new SubProviderEntry(ModEntityLootTables::new, LootContextParamSets.ENTITY), new SubProviderEntry(ModChestLootAdditions::new, LootContextParamSets.CHEST), new SubProviderEntry(ModBlockLootAdditions::new, LootContextParamSets.BLOCK), new SubProviderEntry(ModEntityLootAdditions::new, LootContextParamSets.ENTITY)), context.lookupProvider()));
      generator.addProvider(event.includeServer(), new ValhelsiaRecipeProvider(context, new Function[]{CraftingRecipeProvider::new, ClibanoRecipeProvider::new, ApplyModifierRecipeProvider::new, SpecialRecipesProvider::new, StonecutterRecipeProvider::new}));
      generator.addProvider(event.includeServer(), new ModLootModifierProvider(context));
      PackGenerator featurePack = generator.getBuiltinDatapack(true, "forbidden_arcanus", "preview");
      featurePack.addProvider((output1) -> {
         return PackMetadataGenerator.forFeaturePack(output1, Component.literal("Enable experimental features for Forbidden Arcanus"), FeatureFlagSet.of(ForbiddenArcanus.PREVIEW));
      });
   }
}
