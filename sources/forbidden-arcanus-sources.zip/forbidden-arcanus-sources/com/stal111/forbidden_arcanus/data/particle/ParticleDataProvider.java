package com.stal111.forbidden_arcanus.data.particle;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.init.ModParticles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput.PathProvider;
import net.minecraft.data.PackOutput.Target;
import net.minecraft.resources.ResourceLocation;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryManager;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ParticleDataProvider implements DataProvider {
   private final PathProvider particlePathProvider;
   private final RegistryManager registryManager;
   private final Map<ResourceLocation, ParticleDataProvider.ParticleDefinition> builders = new HashMap();

   public ParticleDataProvider(DataProviderContext context) {
      this.particlePathProvider = context.output().createPathProvider(Target.RESOURCE_PACK, "particles");
      this.registryManager = context.registryManager();
   }

   protected void registerParticles() {
      this.register((ParticleType)ModParticles.SOUL.get(), this.modLoc("soul_0"), this.modLoc("soul_1"), this.modLoc("soul_2"), this.modLoc("soul_3"), this.modLoc("soul_4"), this.modLoc("soul_5"), this.modLoc("soul_6"), this.modLoc("soul_7"), this.modLoc("soul_8"), this.modLoc("soul_9"), this.modLoc("soul_10"), this.modLoc("soul_11"), this.modLoc("soul_12"), this.modLoc("soul_13"), this.modLoc("soul_14"), this.modLoc("soul_15"));
      this.register((ParticleType)ModParticles.AUREAL_MOTE.get(), this.modLoc("aureal_mote"));
      this.register((ParticleType)ModParticles.MAGIC_EXPLOSION.get(), this.modLoc("magic_explosion_0"), this.modLoc("magic_explosion_1"), this.modLoc("magic_explosion_2"), this.modLoc("magic_explosion_3"), this.modLoc("magic_explosion_4"));
      this.register((ParticleType)ModParticles.HUGE_MAGIC_EXPLOSION.get());
      this.register((ParticleType)ModParticles.MAGNETIC_GLOW.get(), this.modLoc("magnetic_glow"));
      this.register((ParticleType)ModParticles.AUREAL_DROP.get(), this.modLoc("drop/aureal_0"), this.modLoc("drop/aureal_1"), this.modLoc("drop/aureal_2"), this.modLoc("drop/aureal_3"), this.modLoc("drop/aureal_4"), this.modLoc("drop/aureal_5"), this.modLoc("drop/aureal_6"));
      this.register((ParticleType)ModParticles.SOULS_DROP.get(), this.modLoc("drop/souls_0"), this.modLoc("drop/souls_1"), this.modLoc("drop/souls_2"), this.modLoc("drop/souls_3"), this.modLoc("drop/souls_4"), this.modLoc("drop/souls_5"), this.modLoc("drop/souls_6"));
      this.register((ParticleType)ModParticles.BLOOD_DROP.get(), this.modLoc("drop/blood_0"), this.modLoc("drop/blood_1"), this.modLoc("drop/blood_2"), this.modLoc("drop/blood_3"), this.modLoc("drop/blood_4"), this.modLoc("drop/blood_5"), this.modLoc("drop/blood_6"));
      this.register((ParticleType)ModParticles.EXPERIENCE_DROP.get(), this.modLoc("drop/experience_0"), this.modLoc("drop/experience_1"), this.modLoc("drop/experience_2"), this.modLoc("drop/experience_3"), this.modLoc("drop/experience_4"), this.modLoc("drop/experience_5"), this.modLoc("drop/experience_6"));
      this.register((ParticleType)ModParticles.MAGIC_GLINT.get(), this.modLoc("magic_glint_0"), this.modLoc("magic_glint_1"), this.modLoc("magic_glint_2"), this.modLoc("magic_glint_3"), this.modLoc("magic_glint_4"));
      this.register((ParticleType)ModParticles.MAGIC_HIT.get(), this.modLoc("magic_hit_0"), this.modLoc("magic_hit_1"), this.modLoc("magic_hit_2"));
      this.register((ParticleType)ModParticles.SPELL_EXPLOSION.get(), this.modLoc("spell_explosion_0"), this.modLoc("spell_explosion_1"), this.modLoc("spell_explosion_2"), this.modLoc("spell_explosion_3"), this.modLoc("spell_explosion_4"), this.modLoc("spell_explosion_5"), this.modLoc("spell_explosion_6"), this.modLoc("spell_explosion_7"));
   }

   private void register(ParticleType<?> particleType, ResourceLocation... textures) {
      this.builders.put(BuiltInRegistries.PARTICLE_TYPE.getKey(particleType), new ParticleDataProvider.ParticleDefinition(List.of(textures)));
   }

   private void register(ParticleType<?> particleType) {
      this.builders.put(BuiltInRegistries.PARTICLE_TYPE.getKey(particleType), new ParticleDataProvider.ParticleDefinition((List)null));
   }

   @NotNull
   public CompletableFuture<?> run(@NotNull CachedOutput output) {
      this.registerParticles();
      return CompletableFuture.allOf((CompletableFuture[])this.builders.entrySet().stream().map((entry) -> {
         JsonElement element = (JsonElement)ParticleDataProvider.ParticleDefinition.CODEC.encodeStart(JsonOps.INSTANCE, (ParticleDataProvider.ParticleDefinition)entry.getValue()).getOrThrow();
         return DataProvider.saveStable(output, element, this.particlePathProvider.json((ResourceLocation)entry.getKey()));
      }).toArray((x$0) -> {
         return new CompletableFuture[x$0];
      }));
   }

   private ResourceLocation modLoc(String path) {
      return ResourceLocation.fromNamespaceAndPath(this.getModId(), path);
   }

   @NotNull
   public String getName() {
      return "forbidden_arcanus - Particles";
   }

   public String getModId() {
      return this.registryManager.modId();
   }

   public static record ParticleDefinition(@Nullable List<ResourceLocation> textures) {
      public static final Codec<ParticleDataProvider.ParticleDefinition> CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(ResourceLocation.CODEC.listOf().optionalFieldOf("textures").forGetter((particleDefinition) -> {
            return Optional.ofNullable(particleDefinition.textures);
         })).apply(instance, (resourceLocations) -> {
            return new ParticleDataProvider.ParticleDefinition((List)resourceLocations.orElse((Object)null));
         });
      });

      public ParticleDefinition(@Nullable List<ResourceLocation> textures) {
         this.textures = textures;
      }

      @Nullable
      public List<ResourceLocation> textures() {
         return this.textures;
      }
   }
}
