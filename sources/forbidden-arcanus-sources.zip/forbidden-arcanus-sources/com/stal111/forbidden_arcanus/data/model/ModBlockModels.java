package com.stal111.forbidden_arcanus.data.model;

import com.google.common.collect.ImmutableMap;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.ArcaneDragonEggBlock;
import com.stal111.forbidden_arcanus.common.block.DeskBlock;
import com.stal111.forbidden_arcanus.common.block.EssenceUtremJarBlock;
import com.stal111.forbidden_arcanus.common.block.HephaestusForgeBlock;
import com.stal111.forbidden_arcanus.common.block.pedestal.PedestalBlock;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.PillarType;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.data.FABlockFamilies;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.data.BlockFamily;
import net.minecraft.data.models.BlockModelGenerators;
import net.minecraft.data.models.BlockModelGenerators.BlockEntityModelGenerator;
import net.minecraft.data.models.BlockModelGenerators.BlockFamilyProvider;
import net.minecraft.data.models.BlockModelGenerators.TintState;
import net.minecraft.data.models.blockstates.MultiVariantGenerator;
import net.minecraft.data.models.blockstates.PropertyDispatch;
import net.minecraft.data.models.blockstates.Variant;
import net.minecraft.data.models.blockstates.VariantProperties;
import net.minecraft.data.models.blockstates.VariantProperty;
import net.minecraft.data.models.blockstates.VariantProperties.Rotation;
import net.minecraft.data.models.model.DelegatedModel;
import net.minecraft.data.models.model.ModelLocationUtils;
import net.minecraft.data.models.model.ModelTemplate;
import net.minecraft.data.models.model.ModelTemplates;
import net.minecraft.data.models.model.TextureMapping;
import net.minecraft.data.models.model.TextureSlot;
import net.minecraft.data.models.model.TexturedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChainBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.valhelsia.valhelsia_core.datagen.model.BlockModelGenerator;

public class ModBlockModels extends BlockModelGenerator {
   private final Map<Block, TexturedModel> texturedModels;

   public ModBlockModels(BlockModelGenerators defaultGenerators) {
      super(defaultGenerators);
      this.texturedModels = ImmutableMap.builder().put((Block)ModBlocks.CUT_SOULLESS_SANDSTONE.get(), TexturedModel.COLUMN.get((Block)ModBlocks.CUT_SOULLESS_SANDSTONE.get())).build();
   }

   protected void generate() {
      BlockModelGenerators generators = this.getDefaultGenerators();
      FABlockFamilies.getAllFamilies().filter(BlockFamily::shouldGenerateModel).forEach((blockFamily) -> {
         this.family(blockFamily.getBaseBlock()).generateFor(blockFamily);
      });
      this.createSimpleFlatItemModel(((ChainBlock)ModBlocks.DEORUM_CHAIN.get()).asItem());
      this.createSimpleFlatItemModel(((ArcaneDragonEggBlock)ModBlocks.ARCANE_DRAGON_EGG.get()).asItem());
      this.createSimpleFlatItemModel((Block)ModBlocks.EDELWOOD_LADDER.get());
      generators.createTrivialCube((Block)ModBlocks.SOULLESS_SAND.get());
      generators.createTrivialCube((Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get());
      generators.createTrivialCube((Block)ModBlocks.TILED_POLISHED_DARKSTONE_BRICKS.get());
      generators.createTrivialCube((Block)ModBlocks.QUANTUM_INJECTOR.get());
      this.createEmissiveLayerCube((Block)ModBlocks.ARCANE_CRYSTAL_ORE.get(), "arcane_crystal_ore");
      this.createEmissiveLayerCube((Block)ModBlocks.DEEPSLATE_ARCANE_CRYSTAL_ORE.get(), "arcane_crystal_ore");
      this.createEmissiveLayerCube((Block)ModBlocks.RUNIC_STONE.get(), "runic_stone");
      this.createEmissiveLayerCube((Block)ModBlocks.RUNIC_DEEPSLATE.get(), "runic_stone");
      this.createEmissiveLayerCube((Block)ModBlocks.RUNIC_DARKSTONE.get(), "runic_stone");
      generators.createTrivialCube((Block)ModBlocks.STELLA_ARCANUM.get());
      this.createEmissiveCube((Block)ModBlocks.ARCANE_CRYSTAL_BLOCK.get());
      generators.createTrivialCube((Block)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_BLOCK.get());
      generators.createTrivialCube((Block)ModBlocks.RUNE_BLOCK.get());
      generators.createTrivialCube((Block)ModBlocks.STELLARITE_BLOCK.get());
      generators.createTrivialCube((Block)ModBlocks.DEORUM_BLOCK.get());
      generators.createTrivialCube((Block)ModBlocks.OBSIDIANSTEEL_BLOCK.get());
      generators.createTrivialCube((Block)ModBlocks.AURUM_LEAVES.get());
      generators.createTrivialCube((Block)ModBlocks.NUGGETY_AURUM_LEAVES.get());
      generators.createTrivialCube((Block)ModBlocks.FUNGYSS_BLOCK.get());
      this.createForbiddenomicon((Block)ModBlocks.FORBIDDENOMICON.get());
      this.createDesk((DeskBlock)ModBlocks.DESK.get(), false);
      this.createDesk((DeskBlock)ModBlocks.RESEARCH_DESK.get(), true);
      this.createPedestal((PedestalBlock)ModBlocks.DARKSTONE_PEDESTAL.get());
      this.createPedestal((PedestalBlock)ModBlocks.MAGNETIZED_DARKSTONE_PEDESTAL.get());
      this.createClibanoCore((Block)ModBlocks.CLIBANO_CORE.get());
      this.createClibanoCenter((Block)ModBlocks.CLIBANO_CENTER.get());
      this.createClibanoCorner((Block)ModBlocks.CLIBANO_CORNER.get());
      this.createClibanoSideHorizontal((Block)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get());
      this.createClibanoSideVertical((Block)ModBlocks.CLIBANO_SIDE_VERTICAL.get());
      this.createHephaestusForge((HephaestusForgeBlock)ModBlocks.HEPHAESTUS_FORGE_TIER_1.get());
      this.createHephaestusForge((HephaestusForgeBlock)ModBlocks.HEPHAESTUS_FORGE_TIER_2.get());
      this.createHephaestusForge((HephaestusForgeBlock)ModBlocks.HEPHAESTUS_FORGE_TIER_3.get());
      this.createHephaestusForge((HephaestusForgeBlock)ModBlocks.HEPHAESTUS_FORGE_TIER_4.get());
      this.createHephaestusForge((HephaestusForgeBlock)ModBlocks.HEPHAESTUS_FORGE_TIER_5.get());
      this.createObelisk((Block)ModBlocks.ARCANE_CRYSTAL_OBELISK.get());
      this.createObelisk((Block)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_OBELISK.get());
      this.createUtremJar((Block)ModBlocks.UTREM_JAR.get());
      this.blockStateOutput.accept(createSimpleBlock((Block)ModBlocks.ESSENCE_UTREM_JAR.get(), ModelLocationUtils.getModelLocation((Block)ModBlocks.UTREM_JAR.get())));
      ModModelTemplates.UTREM_JAR_ITEM.create(ModelLocationUtils.getModelLocation(((EssenceUtremJarBlock)ModBlocks.ESSENCE_UTREM_JAR.get()).asItem()), TextureMapping.particle((Block)ModBlocks.UTREM_JAR.get()), this.modelOutput);
      this.createPillar((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_PILLAR.get());
      this.createNonTemplateModelBlock((Block)ModBlocks.QUANTUM_CORE.get());
      generators.createDoor((Block)ModBlocks.DEORUM_DOOR.get());
      generators.createTrapdoor((Block)ModBlocks.DEORUM_TRAPDOOR.get());
      generators.createAxisAlignedPillarBlockCustomModel((Block)ModBlocks.DEORUM_CHAIN.get(), ModelLocationUtils.getModelLocation((Block)ModBlocks.DEORUM_CHAIN.get()));
      generators.createGlassBlocks((Block)ModBlocks.DEORUM_GLASS.get(), (Block)ModBlocks.DEORUM_GLASS_PANE.get());
      generators.createGlassBlocks((Block)ModBlocks.RUNIC_GLASS.get(), (Block)ModBlocks.RUNIC_GLASS_PANE.get());
      generators.createLantern((Block)ModBlocks.DEORUM_LANTERN.get());
      generators.createLantern((Block)ModBlocks.DEORUM_SOUL_LANTERN.get());
      generators.createPlant((Block)ModBlocks.FUNGYSS.get(), (Block)ModBlocks.POTTED_FUNGYSS.get(), TintState.NOT_TINTED);
      generators.createPlant((Block)ModBlocks.AURUM_SAPLING.get(), (Block)ModBlocks.POTTED_AURUM_SAPLING.get(), TintState.NOT_TINTED);
      generators.createPlant((Block)ModBlocks.GROWING_EDELWOOD.get(), (Block)ModBlocks.POTTED_GROWING_EDELWOOD.get(), TintState.NOT_TINTED);
      generators.createPlant((Block)ModBlocks.YELLOW_ORCHID.get(), (Block)ModBlocks.POTTED_YELLOW_ORCHID.get(), TintState.NOT_TINTED);
      generators.woodProvider((Block)ModBlocks.FUNGYSS_STEM.get()).log((Block)ModBlocks.FUNGYSS_STEM.get()).wood((Block)ModBlocks.FUNGYSS_HYPHAE.get());
      generators.woodProvider((Block)ModBlocks.AURUM_LOG.get()).logWithHorizontal((Block)ModBlocks.AURUM_LOG.get()).wood((Block)ModBlocks.AURUM_WOOD.get());
      generators.woodProvider((Block)ModBlocks.STRIPPED_AURUM_LOG.get()).logWithHorizontal((Block)ModBlocks.STRIPPED_AURUM_LOG.get()).wood((Block)ModBlocks.STRIPPED_AURUM_WOOD.get());
      this.createHollowLog((Block)ModBlocks.EDELWOOD_LOG.get());
      this.createHollowLogWithFace((Block)ModBlocks.CARVED_EDELWOOD_LOG.get());
      this.createEdelwoodBranch();
      this.createMagicalFarmland();
      this.createNonTemplateHorizontalBlock((Block)ModBlocks.EDELWOOD_LADDER.get());
      this.createMortar((Block)ModBlocks.MORTAR.get());
      this.blockEntityModels(ModelLocationUtils.getModelLocation(ModBlocks.OBSIDIAN_SKULL.getSkull()), Blocks.SOUL_SAND).createWithCustomBlockItemModel(ModelTemplates.SKULL_INVENTORY, new Block[]{ModBlocks.OBSIDIAN_SKULL.getSkull(), ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull(), ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull(), ModBlocks.FADING_OBSIDIAN_SKULL.getSkull(), ModBlocks.AUREALIC_OBSIDIAN_SKULL.getSkull(), ModBlocks.ETERNAL_OBSIDIAN_SKULL.getSkull()}).createWithoutBlockItem(new Block[]{ModBlocks.OBSIDIAN_SKULL.getWallSkull(), ModBlocks.CRACKED_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.FADING_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.AUREALIC_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.ETERNAL_OBSIDIAN_SKULL.getWallSkull()});
   }

   public BlockFamilyProvider family(Block block) {
      TexturedModel texturedmodel = (TexturedModel)this.texturedModels.getOrDefault(block, TexturedModel.CUBE.get(block));
      BlockModelGenerators var10002 = this.getDefaultGenerators();
      Objects.requireNonNull(var10002);
      return (new BlockFamilyProvider(var10002, texturedmodel.getMapping())).fullBlock(block, texturedmodel.getTemplate());
   }

   private BlockEntityModelGenerator blockEntityModels(ResourceLocation modelLocation, Block block) {
      BlockModelGenerators var10002 = this.getDefaultGenerators();
      Objects.requireNonNull(var10002);
      return new BlockEntityModelGenerator(var10002, modelLocation, block);
   }

   private void createEmissiveCube(Block block) {
      this.blockStateOutput.accept(createSimpleBlock(block, ModModelTemplates.CUBE_ALL_EMISSIVE.create(block, ModTextureMapping.emissiveCube(block), this.modelOutput)));
   }

   private void createEmissiveLayerCube(Block block, String folder) {
      this.blockStateOutput.accept(createSimpleBlock(block, ModModelTemplates.CUBE_ALL_EMISSIVE_LAYER.create(block, ModTextureMapping.emissiveLayerCube(block, folder), this.modelOutput)));
   }

   private void createForbiddenomicon(Block block) {
      TextureMapping textureMapping = ModTextureMapping.forbiddenomicon(block);
      ResourceLocation model = ModModelTemplates.FORBIDDENOMICON.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model).with(BlockModelGenerators.createHorizontalFacingDispatch()));
   }

   private void createDesk(DeskBlock block, boolean research) {
      TextureMapping textureMapping = ModTextureMapping.desk(research);
      ResourceLocation model = ModModelTemplates.DESK.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model).with(BlockModelGenerators.createHorizontalFacingDispatch()));
   }

   private void createPedestal(PedestalBlock block) {
      TextureMapping textureMapping = ModTextureMapping.pedestal(block);
      ResourceLocation model = ModModelTemplates.PEDESTAL.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model));
   }

   private void createClibanoCore(Block block) {
      TextureMapping textureMapping = ModTextureMapping.clibanoCore();
      ResourceLocation model = ModelTemplates.CUBE_ORIENTABLE.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model).with(BlockModelGenerators.createHorizontalFacingDispatch()));
   }

   private void createClibanoCenter(Block block) {
      PropertyDispatch dispatch = PropertyDispatch.property(ModBlockStateProperties.CLIBANO_CENTER_TYPE).generate((type) -> {
         ResourceLocation model = ModModelTemplates.CLIBANO_CENTER.createWithSuffix(block, "_" + type.getSerializedName(), ModTextureMapping.clibanoCenter(type), this.modelOutput);
         return Variant.variant().with(VariantProperties.MODEL, model);
      });
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(dispatch).with(BlockModelGenerators.createFacingDispatch()));
   }

   private void createClibanoCorner(Block block) {
      ResourceLocation model = ForbiddenArcanus.location("block/clibano_corner");
      PropertyDispatch dispatch = PropertyDispatch.property(BlockStateProperties.BOTTOM).generate((bottom) -> {
         return Variant.variant().with(VariantProperties.X_ROT, bottom ? Rotation.R90 : Rotation.R0);
      });
      this.blockStateOutput.accept(createSimpleBlock(block, model).with(dispatch).with(BlockModelGenerators.createHorizontalFacingDispatch()));
   }

   private void createClibanoSideHorizontal(Block block) {
      PropertyDispatch typeDispatch = PropertyDispatch.property(ModBlockStateProperties.CLIBANO_SIDE_TYPE).generate((type) -> {
         TextureMapping textureMapping = ModTextureMapping.clibanoSide(type);
         ResourceLocation model = ModModelTemplates.CLIBANO_SIDE_HORIZONTAL.createWithSuffix(block, "_" + type.getSerializedName(), textureMapping, this.modelOutput);
         return Variant.variant().with(VariantProperties.MODEL, model);
      });
      PropertyDispatch facingDispatch = PropertyDispatch.properties(BlockStateProperties.HORIZONTAL_FACING, ModBlockStateProperties.MIRRORED).select(Direction.EAST, false, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R90)).select(Direction.EAST, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R0).with(VariantProperties.X_ROT, Rotation.R180)).select(Direction.SOUTH, false, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R180)).select(Direction.SOUTH, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R90).with(VariantProperties.X_ROT, Rotation.R180)).select(Direction.WEST, false, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R270)).select(Direction.WEST, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R180).with(VariantProperties.X_ROT, Rotation.R180)).select(Direction.NORTH, false, Variant.variant()).select(Direction.NORTH, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R270).with(VariantProperties.X_ROT, Rotation.R180));
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(typeDispatch).with(facingDispatch));
   }

   private void createClibanoSideVertical(Block block) {
      PropertyDispatch typeDispatch = PropertyDispatch.property(ModBlockStateProperties.CLIBANO_SIDE_TYPE).generate((type) -> {
         TextureMapping textureMapping = ModTextureMapping.clibanoSide(type);
         ResourceLocation model = ModModelTemplates.CLIBANO_SIDE_VERTICAL.createWithSuffix(block, "_" + type.getSerializedName(), textureMapping, this.modelOutput);
         return Variant.variant().with(VariantProperties.MODEL, model);
      });
      PropertyDispatch facingDispatch = PropertyDispatch.properties(BlockStateProperties.HORIZONTAL_FACING, ModBlockStateProperties.MIRRORED).select(Direction.EAST, false, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R90)).select(Direction.EAST, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R270).with(VariantProperties.X_ROT, Rotation.R180)).select(Direction.SOUTH, false, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R180)).select(Direction.SOUTH, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R0).with(VariantProperties.X_ROT, Rotation.R180)).select(Direction.WEST, false, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R270)).select(Direction.WEST, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R90).with(VariantProperties.X_ROT, Rotation.R180)).select(Direction.NORTH, false, Variant.variant()).select(Direction.NORTH, true, Variant.variant().with(VariantProperties.Y_ROT, Rotation.R180).with(VariantProperties.X_ROT, Rotation.R180));
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(typeDispatch).with(facingDispatch));
   }

   private void createHephaestusForge(HephaestusForgeBlock block) {
      TextureMapping textureMapping = ModTextureMapping.hephaestusForge(block.getLevel().getAsInt());
      ResourceLocation model = ModModelTemplates.HEPHAESTUS_FORGE.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model));
   }

   private void createObelisk(Block block) {
      PropertyDispatch dispatch = PropertyDispatch.property(ModBlockStateProperties.OBELISK_PART).generate((part) -> {
         TextureMapping textureMapping = ModTextureMapping.obelisk(block, part);
         ResourceLocation model = ((ModelTemplate)ModModelTemplates.OBELISK.get(part)).createWithSuffix(block, "_" + part.getSerializedName(), textureMapping, this.modelOutput);
         return Variant.variant().with(VariantProperties.MODEL, model);
      });
      this.createSimpleFlatItemModel(block.asItem());
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(dispatch));
   }

   private void createMortar(Block block) {
      this.blockStateOutput.accept(createSimpleBlock(block, ForbiddenArcanus.location("block/mortar")));
   }

   private void createUtremJar(Block block) {
      TextureMapping textureMapping = ModTextureMapping.utremJar(block);
      ResourceLocation model = ModModelTemplates.UTREM_JAR.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model));
   }

   private void createPillar(Block block) {
      PropertyDispatch dispatch = PropertyDispatch.properties(ModBlockStateProperties.PILLAR_TYPE, RotatedPillarBlock.AXIS).generate((part, axis) -> {
         Variant var10000 = Variant.variant();
         VariantProperty var10001 = VariantProperties.MODEL;
         String var10002;
         if (part == PillarType.SINGLE) {
            var10002 = "";
         } else {
            PillarType var2 = axis == Axis.Z ? part.getOpposite() : part;
            var10002 = "_" + var2.getSerializedName();
         }

         return var10000.with(var10001, ForbiddenArcanus.location("block/arcane_polished_darkstone_pillar" + var10002)).with(VariantProperties.Y_ROT, axis == Axis.X ? Rotation.R90 : Rotation.R0).with(VariantProperties.X_ROT, axis == Axis.Y ? Rotation.R0 : Rotation.R90);
      });
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant(block).with(dispatch));
   }

   private void createHollowLog(Block block) {
      TextureMapping textureMapping = ModTextureMapping.edelwoodLog();
      ResourceLocation model = ModModelTemplates.HOLLOW_LOG.create(block, textureMapping, this.modelOutput);
      this.blockStateOutput.accept(createSimpleBlock(block, model));
   }

   private void createHollowLogWithFace(Block block) {
      TextureMapping textureMapping = ModTextureMapping.edelwoodLogWithFace(false);
      TextureMapping textureMappingWithLeaves = ModTextureMapping.edelwoodLogWithFace(true);
      ResourceLocation model = ModModelTemplates.HOLLOW_LOG_FACE.create(block, textureMapping, this.modelOutput);
      ResourceLocation modelWithLaves = ModModelTemplates.HOLLOW_LOG_FACE_AND_LEAVES.createWithSuffix(block, "_leaves", textureMappingWithLeaves, this.modelOutput);
      PropertyDispatch dispatch = PropertyDispatch.property(ModBlockStateProperties.LEAVES).generate((hasLeaves) -> {
         return Variant.variant().with(VariantProperties.MODEL, hasLeaves ? modelWithLaves : model);
      });
      this.blockStateOutput.accept(createSimpleBlock(block, model).with(BlockModelGenerators.createHorizontalFacingDispatch()).with(dispatch));
   }

   private void createEdelwoodBranch() {
      this.blockStateOutput.accept(createSimpleBlock((Block)ModBlocks.EDELWOOD_BRANCH.get(), ModelLocationUtils.getModelLocation((Block)ModBlocks.EDELWOOD_BRANCH.get())).with(BlockModelGenerators.createHorizontalFacingDispatch()));
   }

   private void createMagicalFarmland() {
      TextureMapping textureMapping = (new TextureMapping()).put(TextureSlot.DIRT, ForbiddenArcanus.location("block/magical_dirt")).put(TextureSlot.TOP, TextureMapping.getBlockTexture((Block)ModBlocks.MAGICAL_FARMLAND.get()));
      TextureMapping moistTextureMapping = (new TextureMapping()).put(TextureSlot.DIRT, ForbiddenArcanus.location("block/magical_dirt")).put(TextureSlot.TOP, TextureMapping.getBlockTexture((Block)ModBlocks.MAGICAL_FARMLAND.get(), "_moist"));
      ResourceLocation model = ModelTemplates.FARMLAND.create((Block)ModBlocks.MAGICAL_FARMLAND.get(), textureMapping, this.modelOutput);
      ResourceLocation moistModel = ModelTemplates.FARMLAND.create(TextureMapping.getBlockTexture((Block)ModBlocks.MAGICAL_FARMLAND.get(), "_moist"), moistTextureMapping, this.modelOutput);
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant((Block)ModBlocks.MAGICAL_FARMLAND.get()).with(BlockModelGenerators.createEmptyOrFullDispatch(BlockStateProperties.MOISTURE, 7, moistModel, model)));
   }

   private void createNonTemplateModelBlock(Block pBlock) {
      this.createNonTemplateModelBlock(pBlock, pBlock);
   }

   private void createNonTemplateModelBlock(Block pBlock, Block pModelBlock) {
      this.blockStateOutput.accept(createSimpleBlock(pBlock, ModelLocationUtils.getModelLocation(pModelBlock)));
   }

   private void createNonTemplateHorizontalBlock(Block horizontalBlock) {
      this.blockStateOutput.accept(MultiVariantGenerator.multiVariant(horizontalBlock, Variant.variant().with(VariantProperties.MODEL, ModelLocationUtils.getModelLocation(horizontalBlock))).with(BlockModelGenerators.createHorizontalFacingDispatch()));
   }

   static MultiVariantGenerator createSimpleBlock(Block block, ResourceLocation resourceLocation) {
      return MultiVariantGenerator.multiVariant(block, Variant.variant().with(VariantProperties.MODEL, resourceLocation));
   }

   void createSimpleFlatItemModel(Item item) {
      ModelTemplates.FLAT_ITEM.create(ModelLocationUtils.getModelLocation(item.asItem()), TextureMapping.layer0(item.asItem()), this.modelOutput);
   }

   void createSimpleFlatItemModel(Block block) {
      ModelTemplates.FLAT_ITEM.create(ModelLocationUtils.getModelLocation(block.asItem()), TextureMapping.layer0(block), this.modelOutput);
   }

   void delegateItemModel(Block block, ResourceLocation resourceLocation) {
      this.modelOutput.accept(ModelLocationUtils.getModelLocation(block.asItem()), new DelegatedModel(resourceLocation));
   }
}
