package com.stal111.forbidden_arcanus.data.model;

import net.minecraft.data.models.model.TextureSlot;

public class ModTextureSlots {
   public static final TextureSlot TOP_LAYER = TextureSlot.create("top_layer");
   public static final TextureSlot SIDE_LAYER = TextureSlot.create("side_layer");
   public static final TextureSlot CLOTH_SIDE = TextureSlot.create("cloth_side");
   public static final TextureSlot BLOCK = TextureSlot.create("block");
   public static final TextureSlot INNER = TextureSlot.create("inner");
   public static final TextureSlot LAYER = TextureSlot.create("layer");
   public static final TextureSlot LOG = TextureSlot.create("log");
   public static final TextureSlot LEAVES = TextureSlot.create("leaves");
}
