package com.stal111.forbidden_arcanus.data.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.models.ItemModelGenerators;
import net.minecraft.data.models.model.ModelLocationUtils;
import net.minecraft.data.models.model.ModelTemplate;
import net.minecraft.data.models.model.ModelTemplates;
import net.minecraft.data.models.model.TextureMapping;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.valhelsia.valhelsia_core.api.common.registry.helper.item.ItemRegistryEntry;
import net.valhelsia.valhelsia_core.datagen.model.ItemModelGenerator;

public class ModItemModels extends ItemModelGenerator {
   private static final String ARMOR = "armor";
   private static final String TOOL = "tool";

   public ModItemModels(ItemModelGenerators defaultGenerators) {
      super(defaultGenerators);
   }

   public void generate() {
      this.generateFlatItem(ModItems.EDELWOOD_BUCKET);
      this.generateFlatItem(ModItems.EDELWOOD_WATER_BUCKET);
      this.generateFlatItem(ModItems.EDELWOOD_LAVA_BUCKET);
      this.generateFlatItem(ModItems.EDELWOOD_MILK_BUCKET);
      this.generateFlatItem(ModItems.EDELWOOD_POWDER_SNOW_BUCKET);
      this.generateFlatItem(ModItems.OBSIDIANSTEEL_INGOT);
      this.generateFlatItem(ModItems.MUNDABITUR_DUST);
      this.generateFlatItem(ModItems.CORRUPTI_DUST);
      this.generateFlatItem(ModItems.FERROGNETIC_MIXTURE);
      this.generateFlatItem(ModItems.SOUL);
      this.generateFlatItem(ModItems.CORRUPT_SOUL);
      this.generateFlatItem(ModItems.ENCHANTED_SOUL);
      this.generateFlatItem(ModItems.AUREAL_BOTTLE);
      this.generateFlatItem(ModItems.SPLASH_AUREAL_BOTTLE);
      this.generateFlatItem(ModItems.ARCANE_CRYSTAL);
      this.generateFlatItem(ModItems.CORRUPTED_ARCANE_CRYSTAL);
      this.generateFlatItem(ModItems.RUNE);
      this.generateFlatItem(ModItems.STELLARITE_PIECE);
      this.generateFlatItem(ModItems.XPETRIFIED_ORB);
      this.generateFlatItem(ModItems.DARK_NETHER_STAR);
      this.generateFlatItem(ModItems.DEORUM_NUGGET);
      this.generateFlatItem(ModItems.DEORUM_INGOT);
      this.generateFlatItem(ModItems.ARCANE_CRYSTAL_DUST);
      this.generateFlatItem(ModItems.ARCANE_CRYSTAL_DUST_SPECK);
      this.generateFlatItem(ModItems.ARCANE_BONE_MEAL);
      this.generateFlatItem(ModItems.DARK_MATTER);
      this.generateFlatItem(ModItems.ENDER_PEARL_FRAGMENT);
      this.generateFlatItem(ModItems.DRAGON_SCALE);
      this.generateFlatItem(ModItems.SILVER_DRAGON_SCALE);
      this.generateFlatItem(ModItems.GOLDEN_DRAGON_SCALE);
      this.generateFlatItem(ModItems.AQUATIC_DRAGON_SCALE);
      this.generateFlatItem(ModItems.BAT_WING);
      this.generateFlatItem(ModItems.BAT_SOUP);
      this.generateFlatItem(ModItems.TENTACLE);
      this.generateFlatItem(ModItems.COOKED_TENTACLE);
      this.generateFlatItem(ModItems.EDELWOOD_STICK, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem(ModItems.WAX);
      this.generateFlatItem(ModItems.SPAWNER_SCRAP);
      this.generateFlatItem(ModItems.BOOM_ARROW);
      this.generateFlatItem(ModItems.DRACO_ARCANUS_ARROW);
      this.generateFlatItem(ModItems.EDELWOOD_OIL);
      this.generateFlatItem(ModItems.AURUM_BOAT);
      this.generateFlatItem(ModItems.AURUM_CHEST_BOAT);
      this.generateFlatItem(ModItems.EDELWOOD_BOAT);
      this.generateFlatItem(ModItems.EDELWOOD_CHEST_BOAT);
      this.generateFlatItem(ModItems.APPLY_MODIFIER_SMITHING_TEMPLATE);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_STAFF, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_SWORD, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_SHOVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_PICKAXE, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_AXE, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_HOE, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DRACO_ARCANUS_SCEPTER, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("armor", ModItems.DRACO_ARCANUS_HELMET, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.DRACO_ARCANUS_CHESTPLATE, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.DRACO_ARCANUS_LEGGINGS, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.DRACO_ARCANUS_BOOTS, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.TYR_HELMET, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.TYR_CHESTPLATE, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.TYR_LEGGINGS, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.TYR_BOOTS, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.MORTEM_HELMET, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.MORTEM_CHESTPLATE, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.MORTEM_LEGGINGS, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("armor", ModItems.MORTEM_BOOTS, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.ARTISAN_RELIC, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.CRESCENT_MOON, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.CRIMSON_STONE, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.SOUL_CRIMSON_STONE, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.ELEMENTARIUM, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.DIVINE_PACT, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem("enhancer", ModItems.MALEDICTUS_PACT, ModelTemplates.FLAT_ITEM);
      this.generateFlatItem(ModItems.BLACKSMITH_GAVEL_HEAD);
      this.generateFlatItem("tool", ModItems.WOODEN_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.STONE_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.GOLDEN_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.IRON_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.DIAMOND_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.NETHERITE_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem("tool", ModItems.REINFORCED_DEORUM_BLACKSMITH_GAVEL, ModelTemplates.FLAT_HANDHELD_ITEM);
      this.generateFlatItem(ModItems.ETERNAL_STELLA);
      this.generateFlatItem(ModItems.TERRASTOMP_PRISM);
      this.generateFlatItem(ModItems.SEA_PRISM);
      this.generateFlatItem(ModItems.WHIRLWIND_PRISM);
      this.generateFlatItem(ModItems.SMELTER_PRISM);
      this.generateFlatItem(ModItems.SOUL_BINDING_CRYSTAL);
      this.generateFlatItem(ModItems.AUREAL_WARDSTONE);
      this.generateWandItem(ModItems.MAGIC_WAND, "wooden_magic_wand", "arcane_crystal");
      ModModelTemplates.QUANTUM_CATCHER.create(ModelLocationUtils.getModelLocation((Item)ModItems.QUANTUM_CATCHER.get()), ModTextureMapping.quantumCatcher(""), this.output);
      ModItems.DYED_QUANTUM_CATCHERS.forEach((color, registryEntry) -> {
         ModModelTemplates.QUANTUM_CATCHER.create(ModelLocationUtils.getModelLocation((Item)registryEntry.get()), ModTextureMapping.quantumCatcher("/" + String.valueOf(color)), this.output);
      });
      ModModelTemplates.QUANTUM_CATCHER.create(ModelLocationUtils.getModelLocation((Item)ModItems.BOSS_CATCHER.get()), ModTextureMapping.quantumCatcher("/boss_catcher"), this.output);
      ResourceLocation aurealTank0 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_0", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTank1 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_1", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTank2 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_2", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTank3 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_3", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTankMax = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_max", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTankMax0 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_max_0", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTankMax1 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_max_1", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTankMax2 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_max_2", ModelTemplates.FLAT_ITEM);
      ResourceLocation aurealTankMax3 = this.generateFlatItem("aureal_tank", ModItems.AUREAL_TANK, "_max_3", ModelTemplates.FLAT_ITEM);
      this.generateWithOverrides("aureal_tank", ModItems.AUREAL_TANK, new ModItemModels.ModelPredicate(aurealTank0, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.25F), ModItemModels.ModelProperty.of("max", 0.0F)}), new ModItemModels.ModelPredicate(aurealTank1, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.5F), ModItemModels.ModelProperty.of("max", 0.0F)}), new ModItemModels.ModelPredicate(aurealTank2, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.75F), ModItemModels.ModelProperty.of("max", 0.0F)}), new ModItemModels.ModelPredicate(aurealTank3, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 1.0F), ModItemModels.ModelProperty.of("max", 0.0F)}), new ModItemModels.ModelPredicate(aurealTankMax, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.0F), ModItemModels.ModelProperty.of("max", 1.0F)}), new ModItemModels.ModelPredicate(aurealTankMax0, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.25F), ModItemModels.ModelProperty.of("max", 1.0F)}), new ModItemModels.ModelPredicate(aurealTankMax1, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.5F), ModItemModels.ModelProperty.of("max", 1.0F)}), new ModItemModels.ModelPredicate(aurealTankMax2, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.75F), ModItemModels.ModelProperty.of("max", 1.0F)}), new ModItemModels.ModelPredicate(aurealTankMax3, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 1.0F), ModItemModels.ModelProperty.of("max", 1.0F)}));
      this.generateFlatItem(ModItems.TEST_TUBE);
      ResourceLocation bloodTestTube0 = this.generateFlatItem("blood_test_tube", ModItems.BLOOD_TEST_TUBE, "_0", ModelTemplates.FLAT_ITEM);
      ResourceLocation bloodTestTube1 = this.generateFlatItem("blood_test_tube", ModItems.BLOOD_TEST_TUBE, "_1", ModelTemplates.FLAT_ITEM);
      ResourceLocation bloodTestTube2 = this.generateFlatItem("blood_test_tube", ModItems.BLOOD_TEST_TUBE, "_2", ModelTemplates.FLAT_ITEM);
      ResourceLocation bloodTestTube3 = this.generateFlatItem("blood_test_tube", ModItems.BLOOD_TEST_TUBE, "_3", ModelTemplates.FLAT_ITEM);
      ResourceLocation bloodTestTube4 = this.generateFlatItem("blood_test_tube", ModItems.BLOOD_TEST_TUBE, "_4", ModelTemplates.FLAT_ITEM);
      ResourceLocation bloodTestTube5 = this.generateFlatItem("blood_test_tube", ModItems.BLOOD_TEST_TUBE, "_5", ModelTemplates.FLAT_ITEM);
      this.generateWithOverrides("blood_test_tube", ModItems.BLOOD_TEST_TUBE, new ModItemModels.ModelPredicate(bloodTestTube0, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.1F)}), new ModItemModels.ModelPredicate(bloodTestTube1, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.25F)}), new ModItemModels.ModelPredicate(bloodTestTube2, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.5F)}), new ModItemModels.ModelPredicate(bloodTestTube3, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.75F)}), new ModItemModels.ModelPredicate(bloodTestTube4, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 0.9F)}), new ModItemModels.ModelPredicate(bloodTestTube5, new ModItemModels.ModelProperty[]{ModItemModels.ModelProperty.of("amount", 1.0F)}));
   }

   private ResourceLocation generateFlatItem(ItemRegistryEntry<? extends Item> item) {
      return this.generateFlatItem(item, ModelTemplates.FLAT_ITEM);
   }

   private ResourceLocation generateFlatItem(String folder, ItemRegistryEntry<? extends Item> item, ModelTemplate template) {
      return template.create(ModelLocationUtils.getModelLocation((Item)item.get()), TextureMapping.layer0(getItemTexture((Item)item.get(), folder, "")), this.output);
   }

   private ResourceLocation generateFlatItem(ItemRegistryEntry<? extends Item> item, ModelTemplate template) {
      return template.create(ModelLocationUtils.getModelLocation((Item)item.get()), TextureMapping.layer0((Item)item.get()), this.output);
   }

   private ResourceLocation generateFlatItem(String folder, ItemRegistryEntry<? extends Item> item, String modelSuffix, ModelTemplate template) {
      return template.create(ModLocationUtils.getItem(folder, item, modelSuffix), TextureMapping.layer0(getItemTexture((Item)item.get(), folder, modelSuffix)), this.output);
   }

   private ResourceLocation generateFlatItem(ItemRegistryEntry<Item> item, String modelSuffix, ModelTemplate template) {
      return template.create(ModelLocationUtils.getModelLocation((Item)item.get(), modelSuffix), TextureMapping.layer0(TextureMapping.getItemTexture((Item)item.get(), modelSuffix)), this.output);
   }

   private ResourceLocation generateWandItem(ItemRegistryEntry<? extends Item> item, String wand, String pommel) {
      return ModModelTemplates.FLAT_HANDHELD_WAND.create(ModelLocationUtils.getModelLocation((Item)item.get()), TextureMapping.layered(ForbiddenArcanus.location("item/wand/" + wand), ForbiddenArcanus.location("item/wand/pommel/" + pommel)), this.output);
   }

   public static ResourceLocation getItemTexture(Item item, String folder, String suffix) {
      ResourceLocation resourcelocation = BuiltInRegistries.ITEM.getKey(item);
      return resourcelocation.withPath((path) -> {
         return "item/" + folder + "/" + path + suffix;
      });
   }

   private void generateWithOverrides(String folder, Holder<Item> item, ModItemModels.ModelPredicate... predicates) {
      ModelTemplates.FLAT_ITEM.create(ModLocationUtils.getItem(item), TextureMapping.layer0(getItemTexture((Item)item.value(), folder, "")), this.output, (modelLocation, map) -> {
         JsonObject jsonObject = ModelTemplates.TWO_LAYERED_ITEM.createBaseTemplate(modelLocation, map);
         JsonArray jsonArray = new JsonArray();
         ModItemModels.ModelPredicate[] var5 = predicates;
         int var6 = predicates.length;

         for(int var7 = 0; var7 < var6; ++var7) {
            ModItemModels.ModelPredicate predicate = var5[var7];
            predicate.serialize(jsonArray);
         }

         jsonObject.add("overrides", jsonArray);
         return jsonObject;
      });
   }

   public static record ModelPredicate(ResourceLocation modelLocation, ModItemModels.ModelProperty... properties) {
      public ModelPredicate(ResourceLocation modelLocation, ModItemModels.ModelProperty... properties) {
         this.modelLocation = modelLocation;
         this.properties = properties;
      }

      public void serialize(JsonArray jsonArray) {
         JsonObject entry = new JsonObject();
         JsonObject predicate = new JsonObject();
         ModItemModels.ModelProperty[] var4 = this.properties;
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            ModItemModels.ModelProperty property = var4[var6];
            property.serialize(predicate);
         }

         entry.add("predicate", predicate);
         entry.addProperty("model", this.modelLocation.toString());
         jsonArray.add(entry);
      }

      public ResourceLocation modelLocation() {
         return this.modelLocation;
      }

      public ModItemModels.ModelProperty[] properties() {
         return this.properties;
      }
   }

   public static record ModelProperty(ResourceLocation name, float value) {
      public ModelProperty(ResourceLocation name, float value) {
         this.name = name;
         this.value = value;
      }

      public static ModItemModels.ModelProperty of(String name, float value) {
         return new ModItemModels.ModelProperty(ForbiddenArcanus.location(name), value);
      }

      public void serialize(JsonObject jsonObject) {
         jsonObject.addProperty(this.name.toString(), this.value);
      }

      public ResourceLocation name() {
         return this.name;
      }

      public float value() {
         return this.value;
      }
   }
}
