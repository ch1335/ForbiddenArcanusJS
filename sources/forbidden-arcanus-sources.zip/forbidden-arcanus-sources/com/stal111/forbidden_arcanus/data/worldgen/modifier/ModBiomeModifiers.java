package com.stal111.forbidden_arcanus.data.worldgen.modifier;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.data.worldgen.placement.ModOrePlacements;
import com.stal111.forbidden_arcanus.data.worldgen.placement.ModTreePlacements;
import com.stal111.forbidden_arcanus.data.worldgen.placement.ModVegetationPlacements;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.MobSpawnSettings.SpawnerData;
import net.minecraft.world.level.levelgen.GenerationStep.Decoration;
import net.neoforged.neoforge.common.world.BiomeModifier;
import net.neoforged.neoforge.registries.NeoForgeRegistries.Keys;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;
import net.valhelsia.valhelsia_core.api.datagen.worldgen.ValhelsiaBiomeModifierProvider;

public class ModBiomeModifiers extends ValhelsiaBiomeModifierProvider {
   public static final DatapackRegistryHelper<BiomeModifier> HELPER;
   public static final ResourceKey<BiomeModifier> ADD_ARCANE_CRYSTAL_ORE;
   public static final ResourceKey<BiomeModifier> ADD_RUNIC_STONE;
   public static final ResourceKey<BiomeModifier> ADD_DARKSTONE;
   public static final ResourceKey<BiomeModifier> ADD_STELLA_ARCANUM;
   public static final ResourceKey<BiomeModifier> ADD_AURUM_TREES;
   public static final ResourceKey<BiomeModifier> ADD_YELLOW_ORCHIDS;
   public static final ResourceKey<BiomeModifier> ADD_LOST_SOUL_OVERWORLD;

   public ModBiomeModifiers(BootstrapContext<BiomeModifier> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<BiomeModifier> context) {
      this.addFeature(ADD_ARCANE_CRYSTAL_ORE, this.isOverworld, this.directFeature(new ResourceKey[]{ModOrePlacements.ARCANE_CRYSTAL_ORE}), Decoration.UNDERGROUND_ORES);
      this.addFeature(ADD_RUNIC_STONE, this.isOverworld, this.directFeature(new ResourceKey[]{ModOrePlacements.RUNIC_STONE}), Decoration.UNDERGROUND_ORES);
      this.addFeature(ADD_DARKSTONE, this.isOverworld, this.directFeature(new ResourceKey[]{ModOrePlacements.DARKSTONE}), Decoration.UNDERGROUND_ORES);
      this.addFeature(ADD_STELLA_ARCANUM, this.isOverworld, this.directFeature(new ResourceKey[]{ModOrePlacements.STELLA_ARCANUM}), Decoration.UNDERGROUND_ORES);
      this.addFeature(ADD_AURUM_TREES, this.directBiome(new ResourceKey[]{Biomes.FLOWER_FOREST}), this.directFeature(new ResourceKey[]{ModTreePlacements.AURUM_TREES}), Decoration.VEGETAL_DECORATION);
      this.addFeature(ADD_YELLOW_ORCHIDS, this.directBiome(new ResourceKey[]{Biomes.FLOWER_FOREST}), this.directFeature(new ResourceKey[]{ModVegetationPlacements.YELLOW_ORCHID}), Decoration.VEGETAL_DECORATION);
      this.addSpawn(ADD_LOST_SOUL_OVERWORLD, this.isOverworld, new SpawnerData[]{new SpawnerData((EntityType)ModEntities.LOST_SOUL.get(), 35, 1, 3)});
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Keys.BIOME_MODIFIERS);
      ADD_ARCANE_CRYSTAL_ORE = HELPER.createKey("add_arcane_crystal_ore");
      ADD_RUNIC_STONE = HELPER.createKey("add_runic_stone");
      ADD_DARKSTONE = HELPER.createKey("add_darkstone");
      ADD_STELLA_ARCANUM = HELPER.createKey("add_stella_arcanum");
      ADD_AURUM_TREES = HELPER.createKey("add_aurum_trees");
      ADD_YELLOW_ORCHIDS = HELPER.createKey("add_yellow_orchids");
      ADD_LOST_SOUL_OVERWORLD = HELPER.createKey("add_lost_soul_overworld");
   }
}
