package com.stal111.forbidden_arcanus.data.worldgen.placement;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModCavePlacements extends DatapackRegistryClass<PlacedFeature> {
   public static final DatapackRegistryHelper<PlacedFeature> HELPER;

   public ModCavePlacements(BootstrapContext<PlacedFeature> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<PlacedFeature> context) {
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.PLACED_FEATURE);
   }
}
