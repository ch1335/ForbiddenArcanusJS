package com.stal111.forbidden_arcanus.data.worldgen.placement;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.world.ModConfiguredFeatures;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.placement.BiomeFilter;
import net.minecraft.world.level.levelgen.placement.InSquarePlacement;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.placement.PlacementModifier;
import net.minecraft.world.level.levelgen.placement.SurfaceWaterDepthFilter;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModTreePlacements extends DatapackRegistryClass<PlacedFeature> {
   public static final DatapackRegistryHelper<PlacedFeature> HELPER;
   public static final PlacementModifier TREE_THRESHOLD;
   public static final ResourceKey<PlacedFeature> EDELWOOD_TREES;
   public static final ResourceKey<PlacedFeature> AURUM_TREES;

   public ModTreePlacements(BootstrapContext<PlacedFeature> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<PlacedFeature> context) {
      HolderGetter<ConfiguredFeature<?, ?>> configuredFeatureRegistry = context.lookup(Registries.CONFIGURED_FEATURE);
      PlacementUtils.register(context, EDELWOOD_TREES, configuredFeatureRegistry.getOrThrow(ModConfiguredFeatures.EDELWOOD), new PlacementModifier[]{InSquarePlacement.spread(), TREE_THRESHOLD, PlacementUtils.HEIGHTMAP_WORLD_SURFACE, PlacementUtils.countExtra(18, 0.25F, 3), BiomeFilter.biome()});
      PlacementUtils.register(context, AURUM_TREES, configuredFeatureRegistry.getOrThrow(ModConfiguredFeatures.AURUM), new PlacementModifier[]{InSquarePlacement.spread(), TREE_THRESHOLD, PlacementUtils.HEIGHTMAP_WORLD_SURFACE, PlacementUtils.countExtra(1, 0.2F, 1), BiomeFilter.biome()});
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.PLACED_FEATURE);
      TREE_THRESHOLD = SurfaceWaterDepthFilter.forMaxDepth(0);
      EDELWOOD_TREES = HELPER.createKey("edelwood_trees");
      AURUM_TREES = HELPER.createKey("aurum_trees");
   }
}
