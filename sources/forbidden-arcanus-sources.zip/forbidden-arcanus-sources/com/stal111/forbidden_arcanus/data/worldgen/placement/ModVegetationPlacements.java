package com.stal111.forbidden_arcanus.data.worldgen.placement;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.world.ModConfiguredFeatures;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.placement.BiomeFilter;
import net.minecraft.world.level.levelgen.placement.InSquarePlacement;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.placement.PlacementModifier;
import net.minecraft.world.level.levelgen.placement.RarityFilter;
import net.minecraft.world.level.levelgen.placement.SurfaceWaterDepthFilter;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModVegetationPlacements extends DatapackRegistryClass<PlacedFeature> {
   public static final DatapackRegistryHelper<PlacedFeature> HELPER;
   public static final PlacementModifier TREE_THRESHOLD;
   public static final ResourceKey<PlacedFeature> YELLOW_ORCHID;

   public ModVegetationPlacements(BootstrapContext<PlacedFeature> context) {
      super(context);
   }

   public void bootstrap(BootstrapContext<PlacedFeature> context) {
      HolderGetter<ConfiguredFeature<?, ?>> configuredFeatureRegistry = context.lookup(Registries.CONFIGURED_FEATURE);
      PlacementUtils.register(context, YELLOW_ORCHID, configuredFeatureRegistry.getOrThrow(ModConfiguredFeatures.YELLOW_ORCHID), new PlacementModifier[]{RarityFilter.onAverageOnceEvery(12), PlacementUtils.HEIGHTMAP, InSquarePlacement.spread(), BiomeFilter.biome()});
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.PLACED_FEATURE);
      TREE_THRESHOLD = SurfaceWaterDepthFilter.forMaxDepth(0);
      YELLOW_ORCHID = HELPER.createKey("yellow_orchid");
   }
}
