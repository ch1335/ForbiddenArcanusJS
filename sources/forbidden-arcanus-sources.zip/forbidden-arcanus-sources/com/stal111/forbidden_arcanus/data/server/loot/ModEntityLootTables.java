package com.stal111.forbidden_arcanus.data.server.loot;

import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.stream.Stream;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.loot.EntityLootSubProvider;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

public class ModEntityLootTables extends EntityLootSubProvider {
   public ModEntityLootTables(Provider registries) {
      super(FeatureFlags.DEFAULT_FLAGS, registries);
   }

   public void generate() {
      this.add((EntityType)ModEntities.LOST_SOUL.get(), LootTable.lootTable().withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).add(LootItem.lootTableItem(ModItems.SOUL))));
      this.add((EntityType)ModEntities.CORRUPT_LOST_SOUL.get(), LootTable.lootTable().withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).add(LootItem.lootTableItem(ModItems.CORRUPT_SOUL))));
      this.add((EntityType)ModEntities.ENCHANTED_LOST_SOUL.get(), LootTable.lootTable().withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).add(LootItem.lootTableItem(ModItems.ENCHANTED_SOUL))));
   }

   protected Stream<EntityType<?>> getKnownEntityTypes() {
      return Stream.of((EntityType)ModEntities.LOST_SOUL.get(), (EntityType)ModEntities.CORRUPT_LOST_SOUL.get(), (EntityType)ModEntities.ENCHANTED_LOST_SOUL.get());
   }
}
