package com.stal111.forbidden_arcanus.data.server.tags;

import com.stal111.forbidden_arcanus.data.ModEnchantments;
import com.stal111.forbidden_arcanus.util.ModTags;
import javax.annotation.Nonnull;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.tags.EnchantmentTagsProvider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.world.item.enchantment.Enchantments;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;
import org.jetbrains.annotations.NotNull;

public class ModEnchantmentTagsProvider extends EnchantmentTagsProvider {
   public ModEnchantmentTagsProvider(DataProviderContext context, ExistingFileHelper fileHelper) {
      super(context.output(), context.lookupProvider(), "forbidden_arcanus", fileHelper);
   }

   protected void addTags(@NotNull Provider provider) {
      this.tag(ModTags.Enchantments.ETERNAL_INCOMPATIBLE).add(new ResourceKey[]{Enchantments.UNBREAKING, Enchantments.MENDING});
      this.tag(ModTags.Enchantments.FIERY_INCOMPATIBLE).add(Enchantments.SILK_TOUCH);
      this.tag(ModTags.Enchantments.MAGNETIZED_INCOMPATIBLE);
      this.tag(ModTags.Enchantments.DEMOLISHING_INCOMPATIBLE);
      this.tag(ModTags.Enchantments.AQUATIC_INCOMPATIBLE);
      this.tag(EnchantmentTags.NON_TREASURE).add(ModEnchantments.SOUL_LOOTING);
   }

   @Nonnull
   public String getName() {
      return "forbidden_arcanus: Enchantment Tags";
   }
}
