package com.stal111.forbidden_arcanus.data.server.loot;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.clibano.AbstractClibanoFrameBlock;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.ObeliskPart;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.Set;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.HolderLookup.RegistryLookup;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.DynamicLoot;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.CopyComponentsFunction;
import net.minecraft.world.level.storage.loot.functions.CopyComponentsFunction.Source;
import net.minecraft.world.level.storage.loot.predicates.BonusLevelTableCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition.Builder;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.valhelsia.valhelsia_core.datagen.ValhelsiaBlockLootTables;

public class ModBlockLootTables extends ValhelsiaBlockLootTables {
   public ModBlockLootTables(Provider lookupProvider) {
      super(Set.of(), FeatureFlags.DEFAULT_FLAGS, lookupProvider, ForbiddenArcanus.REGISTRY_MANAGER);
   }

   protected void generate() {
      this.dropSelf((Block)ModBlocks.DARKSTONE.get());
      this.dropSelf((Block)ModBlocks.DARKSTONE_STAIRS.get());
      this.dropSelf((Block)ModBlocks.DARKSTONE_WALL.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_STAIRS.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_WALL.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_PRESSURE_PLATE.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_BUTTON.get());
      this.dropSelf((Block)ModBlocks.CHISELED_POLISHED_DARKSTONE.get());
      this.dropSelf((Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_BRICKS.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_BRICK_STAIRS.get());
      this.dropSelf((Block)ModBlocks.POLISHED_DARKSTONE_BRICK_WALL.get());
      this.dropSelf((Block)ModBlocks.CRACKED_POLISHED_DARKSTONE_BRICKS.get());
      this.dropSelf((Block)ModBlocks.TILED_POLISHED_DARKSTONE_BRICKS.get());
      this.dropSelf((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE.get());
      this.dropSelf((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_STAIRS.get());
      this.dropSelf((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_WALL.get());
      this.dropSelf((Block)ModBlocks.CHISELED_ARCANE_POLISHED_DARKSTONE.get());
      this.dropSelf((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_PILLAR.get());
      this.dropSelf((Block)ModBlocks.DARKSTONE_PEDESTAL.get());
      this.dropSelf((Block)ModBlocks.MAGNETIZED_DARKSTONE_PEDESTAL.get());
      this.dropSelf((Block)ModBlocks.CLIBANO_CORE.get());
      this.dropSelf((Block)ModBlocks.HEPHAESTUS_FORGE_TIER_1.get());
      this.dropSelf((Block)ModBlocks.HEPHAESTUS_FORGE_TIER_2.get());
      this.dropSelf((Block)ModBlocks.HEPHAESTUS_FORGE_TIER_3.get());
      this.dropSelf((Block)ModBlocks.HEPHAESTUS_FORGE_TIER_4.get());
      this.dropSelf((Block)ModBlocks.HEPHAESTUS_FORGE_TIER_5.get());
      this.dropSelf((Block)ModBlocks.QUANTUM_CORE.get());
      this.dropSelf((Block)ModBlocks.QUANTUM_INJECTOR.get());
      this.dropSelf((Block)ModBlocks.ARCANE_CRYSTAL_BLOCK.get());
      this.dropSelf((Block)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_BLOCK.get());
      this.dropSelf((Block)ModBlocks.RUNE_BLOCK.get());
      this.dropSelf((Block)ModBlocks.STELLARITE_BLOCK.get());
      this.dropSelf((Block)ModBlocks.DEORUM_BLOCK.get());
      this.dropSelf((Block)ModBlocks.OBSIDIANSTEEL_BLOCK.get());
      this.dropSelf((Block)ModBlocks.DEORUM_LANTERN.get());
      this.dropSelf((Block)ModBlocks.DEORUM_SOUL_LANTERN.get());
      this.dropSelf((Block)ModBlocks.SOULLESS_SAND.get());
      this.dropSelf((Block)ModBlocks.SOULLESS_SANDSTONE.get());
      this.dropSelf((Block)ModBlocks.SOULLESS_SANDSTONE_STAIRS.get());
      this.dropSelf((Block)ModBlocks.SOULLESS_SANDSTONE_WALL.get());
      this.dropSelf((Block)ModBlocks.CUT_SOULLESS_SANDSTONE.get());
      this.dropSelf((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get());
      this.dropSelf((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE_STAIRS.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS.get());
      this.dropSelf((Block)ModBlocks.GROWING_EDELWOOD.get());
      this.dropSelf((Block)ModBlocks.AURUM_SAPLING.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_STEM.get());
      this.dropSelf((Block)ModBlocks.AURUM_LOG.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_LOG.get());
      this.dropSelf((Block)ModBlocks.CARVED_EDELWOOD_LOG.get());
      this.dropSelf((Block)ModBlocks.STRIPPED_AURUM_LOG.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_HYPHAE.get());
      this.dropSelf((Block)ModBlocks.AURUM_WOOD.get());
      this.dropSelf((Block)ModBlocks.STRIPPED_AURUM_WOOD.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_PLANKS.get());
      this.dropSelf((Block)ModBlocks.AURUM_PLANKS.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_PLANKS.get());
      this.dropSelf((Block)ModBlocks.ARCANE_EDELWOOD_PLANKS.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_STAIRS.get());
      this.dropSelf((Block)ModBlocks.AURUM_STAIRS.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_STAIRS.get());
      this.add((Block)ModBlocks.DEORUM_DOOR.get(), (block) -> {
         return this.createSinglePropConditionTable(block, BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER);
      });
      this.add((Block)ModBlocks.FUNGYSS_DOOR.get(), (block) -> {
         return this.createSinglePropConditionTable(block, BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER);
      });
      this.add((Block)ModBlocks.AURUM_DOOR.get(), (block) -> {
         return this.createSinglePropConditionTable(block, BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER);
      });
      this.add((Block)ModBlocks.EDELWOOD_DOOR.get(), (block) -> {
         return this.createSinglePropConditionTable(block, BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER);
      });
      this.add((Block)ModBlocks.ARCANE_EDELWOOD_DOOR.get(), (block) -> {
         return this.createSinglePropConditionTable(block, BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER);
      });
      this.dropSelf((Block)ModBlocks.DEORUM_TRAPDOOR.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_TRAPDOOR.get());
      this.dropSelf((Block)ModBlocks.AURUM_TRAPDOOR.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_TRAPDOOR.get());
      this.dropSelf((Block)ModBlocks.ARCANE_EDELWOOD_TRAPDOOR.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_FENCE.get());
      this.dropSelf((Block)ModBlocks.AURUM_FENCE.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_FENCE.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_FENCE_GATE.get());
      this.dropSelf((Block)ModBlocks.AURUM_FENCE_GATE.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_FENCE_GATE.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_LADDER.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_BUTTON.get());
      this.dropSelf((Block)ModBlocks.AURUM_BUTTON.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_BUTTON.get());
      this.dropSelf((Block)ModBlocks.FUNGYSS_PRESSURE_PLATE.get());
      this.dropSelf((Block)ModBlocks.AURUM_PRESSURE_PLATE.get());
      this.dropSelf((Block)ModBlocks.EDELWOOD_PRESSURE_PLATE.get());
      this.dropSelf((Block)ModBlocks.ARCANE_DRAGON_EGG.get());
      this.dropSelf((Block)ModBlocks.DEORUM_CHAIN.get());
      this.dropSelf((Block)ModBlocks.YELLOW_ORCHID.get());
      this.dropSelf((Block)ModBlocks.UTREM_JAR.get());
      this.dropSelf(ModBlocks.OBSIDIAN_SKULL.getSkull());
      this.dropOther(ModBlocks.OBSIDIAN_SKULL.getWallSkull(), ModBlocks.OBSIDIAN_SKULL.getSkull());
      this.dropSelf(ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull());
      this.dropOther(ModBlocks.CRACKED_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull());
      this.dropSelf(ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull());
      this.dropOther(ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull());
      this.dropSelf(ModBlocks.FADING_OBSIDIAN_SKULL.getSkull());
      this.dropOther(ModBlocks.FADING_OBSIDIAN_SKULL.getWallSkull(), ModBlocks.FADING_OBSIDIAN_SKULL.getSkull());
      this.dropOther((Block)ModBlocks.MAGICAL_FARMLAND.get(), Blocks.DIRT);
      this.add((Block)ModBlocks.DARKSTONE_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.POLISHED_DARKSTONE_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.POLISHED_DARKSTONE_BRICK_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.SOULLESS_SANDSTONE_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.CUT_SOULLESS_SANDSTONE_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.FUNGYSS_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.AURUM_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.add((Block)ModBlocks.EDELWOOD_SLAB.get(), (x$0) -> {
         return this.createSlabItemTable(x$0);
      });
      this.dropWhenSilkTouch((Block)ModBlocks.DEORUM_GLASS.get());
      this.dropWhenSilkTouch((Block)ModBlocks.DEORUM_GLASS_PANE.get());
      this.dropWhenSilkTouch((Block)ModBlocks.RUNIC_GLASS.get());
      this.dropWhenSilkTouch((Block)ModBlocks.RUNIC_GLASS_PANE.get());
      this.add((Block)ModBlocks.ARCANE_CRYSTAL_ORE.get(), (block) -> {
         return this.createOreDrop(block, (Item)ModItems.ARCANE_CRYSTAL.get());
      });
      this.add((Block)ModBlocks.DEEPSLATE_ARCANE_CRYSTAL_ORE.get(), (block) -> {
         return this.createOreDrop(block, (Item)ModItems.ARCANE_CRYSTAL.get());
      });
      this.add((Block)ModBlocks.RUNIC_STONE.get(), (block) -> {
         return this.createOreDrop(block, (Item)ModItems.RUNE.get());
      });
      this.add((Block)ModBlocks.RUNIC_DEEPSLATE.get(), (block) -> {
         return this.createOreDrop(block, (Item)ModItems.RUNE.get());
      });
      this.add((Block)ModBlocks.RUNIC_DARKSTONE.get(), (block) -> {
         return this.createOreDrop(block, (Item)ModItems.RUNE.get());
      });
      this.add((Block)ModBlocks.STELLA_ARCANUM.get(), (block) -> {
         return this.createSingleItemTableWithSilkTouch(block, (ItemLike)ModItems.STELLARITE_PIECE.get());
      });
      this.add((Block)ModBlocks.FUNGYSS_BLOCK.get(), (block) -> {
         return this.createMushroomBlockDrop(block, (ItemLike)ModBlocks.FUNGYSS.get());
      });
      this.add((Block)ModBlocks.ARCANE_CRYSTAL_OBELISK.get(), (block) -> {
         return this.createSinglePropConditionTable(block, ModBlockStateProperties.OBELISK_PART, ObeliskPart.LOWER);
      });
      this.add((Block)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_OBELISK.get(), (block) -> {
         return this.createSinglePropConditionTable(block, ModBlockStateProperties.OBELISK_PART, ObeliskPart.LOWER);
      });
      this.add((Block)ModBlocks.AURUM_LEAVES.get(), (block) -> {
         return this.createLeavesDrops(block, (Block)ModBlocks.AURUM_SAPLING.get(), NORMAL_LEAVES_SAPLING_CHANCES);
      });
      this.add((Block)ModBlocks.NUGGETY_AURUM_LEAVES.get(), (block) -> {
         return this.createNuggetyAurumLeavesDrops(block, (Block)ModBlocks.AURUM_SAPLING.get(), NORMAL_LEAVES_SAPLING_CHANCES);
      });
      this.add((Block)ModBlocks.ESSENCE_UTREM_JAR.get(), this::createUtremJarDrops);
      this.add((Block)ModBlocks.CLIBANO_CENTER.get(), this::createClibanoFrameTable);
      this.add((Block)ModBlocks.CLIBANO_CORNER.get(), this::createClibanoFrameTable);
      this.add((Block)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get(), this::createClibanoFrameTable);
      this.add((Block)ModBlocks.CLIBANO_SIDE_VERTICAL.get(), this::createClibanoFrameTable);
      this.add((Block)ModBlocks.CLIBANO_MAIN_PART.get(), (block) -> {
         return LootTable.lootTable();
      });
      this.add((Block)ModBlocks.EDELWOOD_BRANCH.get(), (block) -> {
         return this.createSingleItemTableWithSilkTouch(block, (ItemLike)ModItems.EDELWOOD_STICK.get());
      });
      this.add((Block)ModBlocks.BLACK_HOLE.get(), (block) -> {
         return LootTable.lootTable();
      });
      this.add((Block)ModBlocks.WHIRLWIND.get(), (block) -> {
         return LootTable.lootTable();
      });
      this.add((Block)ModBlocks.UPWIND.get(), (block) -> {
         return LootTable.lootTable();
      });
      this.dropPottedContents((Block)ModBlocks.POTTED_FUNGYSS.get());
      this.dropPottedContents((Block)ModBlocks.POTTED_AURUM_SAPLING.get());
      this.dropPottedContents((Block)ModBlocks.POTTED_GROWING_EDELWOOD.get());
      this.dropPottedContents((Block)ModBlocks.POTTED_YELLOW_ORCHID.get());
   }

   private Builder hasShearsOrSilkTouch() {
      return HAS_SHEARS.or(this.hasSilkTouch());
   }

   private Builder doesNotHaveShearsOrSilkTouch() {
      return this.hasShearsOrSilkTouch().invert();
   }

   private net.minecraft.world.level.storage.loot.LootTable.Builder createNuggetyAurumLeavesDrops(Block leaves, Block sapling, float... chances) {
      RegistryLookup<Enchantment> registryLookup = this.registries.lookupOrThrow(Registries.ENCHANTMENT);
      return this.createLeavesDrops(leaves, sapling, chances).withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).when(this.doesNotHaveShearsOrSilkTouch()).add((net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer.Builder)this.applyExplosionCondition(leaves, LootItem.lootTableItem(Items.GOLD_NUGGET).when(BonusLevelTableCondition.bonusLevelFlatChance(registryLookup.getOrThrow(Enchantments.FORTUNE), new float[]{0.005F, 0.0055555557F, 0.00625F, 0.008333334F, 0.025F})))));
   }

   private net.minecraft.world.level.storage.loot.LootTable.Builder createUtremJarDrops(Block block) {
      return LootTable.lootTable().withPool((net.minecraft.world.level.storage.loot.LootPool.Builder)this.applyExplosionCondition(block, LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).add(LootItem.lootTableItem(block).apply(CopyComponentsFunction.copyComponents(Source.BLOCK_ENTITY).include((DataComponentType)ModDataComponents.ESSENCE_STORAGE.get())))));
   }

   private net.minecraft.world.level.storage.loot.LootTable.Builder createClibanoFrameTable(Block block) {
      return LootTable.lootTable().withPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1.0F)).add(DynamicLoot.dynamicEntry(AbstractClibanoFrameBlock.DYNAMIC_DROP_ID)));
   }
}
