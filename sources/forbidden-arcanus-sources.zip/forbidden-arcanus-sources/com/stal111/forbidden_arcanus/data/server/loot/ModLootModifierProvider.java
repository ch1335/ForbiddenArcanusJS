package com.stal111.forbidden_arcanus.data.server.loot;

import com.stal111.forbidden_arcanus.common.advancements.critereon.FAItemSubPredicates;
import com.stal111.forbidden_arcanus.common.advancements.critereon.ItemModifierPredicate;
import com.stal111.forbidden_arcanus.common.loot.BlacksmithGavelLootModifier;
import com.stal111.forbidden_arcanus.common.loot.FieryLootModifier;
import com.stal111.forbidden_arcanus.common.loot.MagicalFarmlandLootModifier;
import com.stal111.forbidden_arcanus.data.ModItemModifiers;
import java.util.List;
import net.minecraft.advancements.critereon.EnchantmentPredicate;
import net.minecraft.advancements.critereon.ItemEnchantmentsPredicate;
import net.minecraft.advancements.critereon.ItemSubPredicates;
import net.minecraft.advancements.critereon.ItemPredicate.Builder;
import net.minecraft.advancements.critereon.ItemSubPredicate.Type;
import net.minecraft.advancements.critereon.MinMaxBounds.Ints;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.predicates.AnyOfCondition;
import net.minecraft.world.level.storage.loot.predicates.InvertedLootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.predicates.MatchTool;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.data.GlobalLootModifierProvider;
import net.neoforged.neoforge.common.loot.AddTableLootModifier;
import net.neoforged.neoforge.common.loot.LootTableIdCondition;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;

public class ModLootModifierProvider extends GlobalLootModifierProvider {
   public ModLootModifierProvider(DataProviderContext context) {
      super(context.output(), context.lookupProvider(), "forbidden_arcanus");
   }

   protected void start() {
      this.add("spawner_additions", new AddTableLootModifier(new LootItemCondition[]{InvertedLootItemCondition.invert(MatchTool.toolMatches(Builder.item().withSubPredicate(ItemSubPredicates.ENCHANTMENTS, ItemEnchantmentsPredicate.enchantments(List.of(new EnchantmentPredicate(this.registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.SILK_TOUCH), Ints.atLeast(1))))))).build(), LootTableIdCondition.builder(Blocks.SPAWNER.getLootTable().location()).build()}, ModBlockLootAdditions.SPAWNER_SCRAP_ADDITION), new ICondition[0]);
      this.add("enderman_additions", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(EntityType.ENDERMAN.getDefaultLootTable().location()).build()}, ModEntityLootAdditions.ENDER_PEARL_FRAGMENT_ADDITION), new ICondition[0]);
      this.add("bat_additions", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(EntityType.BAT.getDefaultLootTable().location()).build()}, ModEntityLootAdditions.BAT_WING_ADDITION), new ICondition[0]);
      this.add("squid_additions", new AddTableLootModifier(new LootItemCondition[]{LootItemRandomChanceCondition.randomChance(0.7F).build(), LootTableIdCondition.builder(EntityType.SQUID.getDefaultLootTable().location()).build()}, ModEntityLootAdditions.TENTACLE_ADDITION), new ICondition[0]);
      this.add("ender_dragon_additions", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(EntityType.ENDER_DRAGON.getDefaultLootTable().location()).build()}, ModEntityLootAdditions.DRAGON_SCALE_ADDITION), new ICondition[0]);
      this.add("simple_dungeon_additions", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(BuiltInLootTables.SIMPLE_DUNGEON.location()).build()}, ModChestLootAdditions.AUREAL_BOTTLE_ADDITION), new ICondition[0]);
      this.add("end_city_treasure_additions", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(BuiltInLootTables.END_CITY_TREASURE.location()).build()}, ModChestLootAdditions.DRAGON_SCALE_ADDITION), new ICondition[0]);
      this.add("artisan_relic_addition", new AddTableLootModifier(new LootItemCondition[]{AnyOfCondition.anyOf(new net.minecraft.world.level.storage.loot.predicates.LootItemCondition.Builder[]{LootTableIdCondition.builder(BuiltInLootTables.VILLAGE_ARMORER.location()), LootTableIdCondition.builder(BuiltInLootTables.VILLAGE_TOOLSMITH.location()), LootTableIdCondition.builder(BuiltInLootTables.VILLAGE_WEAPONSMITH.location())}).build()}, ModChestLootAdditions.ARTISAN_RELIC_ADDITION), new ICondition[0]);
      this.add("crimson_stone_addition", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(BuiltInLootTables.PILLAGER_OUTPOST.location()).build()}, ModChestLootAdditions.CRIMSON_STONE_ADDITION), new ICondition[0]);
      this.add("elementarium_addition", new AddTableLootModifier(new LootItemCondition[]{AnyOfCondition.anyOf(new net.minecraft.world.level.storage.loot.predicates.LootItemCondition.Builder[]{LootTableIdCondition.builder(BuiltInLootTables.JUNGLE_TEMPLE.location()), LootTableIdCondition.builder(BuiltInLootTables.DESERT_PYRAMID.location()), LootTableIdCondition.builder(BuiltInLootTables.UNDERWATER_RUIN_SMALL.location()), LootTableIdCondition.builder(BuiltInLootTables.UNDERWATER_RUIN_BIG.location())}).build()}, ModChestLootAdditions.ELEMENTARIUM_ADDITION), new ICondition[0]);
      this.add("maledictus_pact", new AddTableLootModifier(new LootItemCondition[]{LootTableIdCondition.builder(BuiltInLootTables.BASTION_TREASURE.location()).build()}, ModChestLootAdditions.MALEDICTUS_PACT_ADDITION), new ICondition[0]);
      this.add("fiery_modifier", new FieryLootModifier(new LootItemCondition[]{MatchTool.toolMatches(Builder.item().withSubPredicate((Type)FAItemSubPredicates.MODIFIER.get(), ItemModifierPredicate.modifier(this.registries.holderOrThrow(ModItemModifiers.FIERY)))).build()}), new ICondition[0]);
      this.add("blacksmith_gavel_ore_doubling", new BlacksmithGavelLootModifier(new LootItemCondition[]{LootItemRandomChanceCondition.randomChance(0.3F).build()}), new ICondition[0]);
      this.add("magical_farmland_crop_doubling", new MagicalFarmlandLootModifier(new LootItemCondition[0]), new ICondition[0]);
   }
}
