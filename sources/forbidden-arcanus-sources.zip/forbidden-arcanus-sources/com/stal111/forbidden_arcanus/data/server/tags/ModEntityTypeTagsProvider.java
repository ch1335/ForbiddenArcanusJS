package com.stal111.forbidden_arcanus.data.server.tags;

import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.util.ModTags;
import javax.annotation.Nonnull;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.data.tags.EntityTypeTagsProvider;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.EntityType;
import net.neoforged.neoforge.common.Tags.EntityTypes;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;

public class ModEntityTypeTagsProvider extends EntityTypeTagsProvider {
   public ModEntityTypeTagsProvider(DataProviderContext context, ExistingFileHelper fileHelper) {
      super(context.output(), context.lookupProvider(), "forbidden_arcanus", fileHelper);
   }

   protected void addTags(@Nonnull Provider provider) {
      this.tag(ModTags.EntityTypes.BLACK_HOLE_AFFECTED).add(new EntityType[]{EntityType.ITEM, EntityType.EXPERIENCE_ORB, EntityType.ARROW, EntityType.SPECTRAL_ARROW, (EntityType)ModEntities.BOOM_ARROW.get(), (EntityType)ModEntities.DRACO_ARCANUS_ARROW.get()});
      this.tag(ModTags.EntityTypes.QUANTUM_CATCHER_BLACKLISTED).addTag(ModTags.EntityTypes.BOSS_CATCHER_BLACKLISTED).addTag(EntityTypes.BOSSES);
      this.tag(ModTags.EntityTypes.BOSS_CATCHER_BLACKLISTED).add(EntityType.PLAYER);
      this.tag(ModTags.EntityTypes.SPAWNS_LOST_SOUL_CHANCE).add(new EntityType[]{EntityType.PLAYER, EntityType.VILLAGER, EntityType.WANDERING_TRADER});
      this.tag(ModTags.EntityTypes.SPAWNS_CORRUPT_LOST_SOUL_CHANCE).addTag(EntityTypeTags.SKELETONS).add(new EntityType[]{EntityType.ZOMBIE, EntityType.ZOMBIE_VILLAGER, EntityType.WITCH, EntityType.DROWNED, EntityType.PILLAGER, EntityType.ILLUSIONER, EntityType.VINDICATOR, EntityType.HUSK, EntityType.PIGLIN, EntityType.PIGLIN_BRUTE, EntityType.EVOKER});
      this.tag(ModTags.EntityTypes.TEST_TUBE_BLACKLISTED);
      this.tag(ModTags.EntityTypes.SPECTRAL_VISION_UNAFFECTED);
   }

   @Nonnull
   public String getName() {
      return "forbidden_arcanus: Entity Type Tags";
   }
}
