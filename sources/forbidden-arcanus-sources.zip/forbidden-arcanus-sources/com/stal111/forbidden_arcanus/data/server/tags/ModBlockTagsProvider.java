package com.stal111.forbidden_arcanus.data.server.tags;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.util.ModTags;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.common.Tags.Blocks;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;
import net.valhelsia.valhelsia_core.datagen.tags.ValhelsiaBlockTagsProvider;
import org.jetbrains.annotations.NotNull;

public class ModBlockTagsProvider extends ValhelsiaBlockTagsProvider {
   public ModBlockTagsProvider(DataProviderContext context) {
      super(context);
   }

   protected void addTags(@NotNull Provider provider) {
      this.tag(ModTags.Blocks.FUNGYSS_STEMS).add(new Block[]{(Block)ModBlocks.FUNGYSS_STEM.get(), (Block)ModBlocks.FUNGYSS_HYPHAE.get()});
      this.tag(ModTags.Blocks.MYSTERYWOOD_LOGS).add(new Block[]{(Block)ModBlocks.AURUM_LOG.get(), (Block)ModBlocks.AURUM_WOOD.get(), (Block)ModBlocks.STRIPPED_AURUM_LOG.get(), (Block)ModBlocks.STRIPPED_AURUM_WOOD.get()});
      this.tag(ModTags.Blocks.EDELWOOD_LOGS).add(new Block[]{(Block)ModBlocks.EDELWOOD_LOG.get(), (Block)ModBlocks.CARVED_EDELWOOD_LOG.get()});
      this.tag(BlockTags.LOGS).addTags(new TagKey[]{ModTags.Blocks.FUNGYSS_STEMS, ModTags.Blocks.MYSTERYWOOD_LOGS, ModTags.Blocks.EDELWOOD_LOGS});
      this.tag(BlockTags.LOGS_THAT_BURN).addTag(ModTags.Blocks.MYSTERYWOOD_LOGS);
      this.tag(BlockTags.PLANKS).add(new Block[]{(Block)ModBlocks.FUNGYSS_PLANKS.get(), (Block)ModBlocks.AURUM_PLANKS.get(), (Block)ModBlocks.EDELWOOD_PLANKS.get(), (Block)ModBlocks.ARCANE_EDELWOOD_PLANKS.get()});
      this.tag(BlockTags.WOODEN_SLABS).add(new Block[]{(Block)ModBlocks.FUNGYSS_SLAB.get(), (Block)ModBlocks.AURUM_SLAB.get(), (Block)ModBlocks.EDELWOOD_SLAB.get()});
      this.tag(BlockTags.WOODEN_STAIRS).add(new Block[]{(Block)ModBlocks.FUNGYSS_STAIRS.get(), (Block)ModBlocks.AURUM_STAIRS.get(), (Block)ModBlocks.EDELWOOD_STAIRS.get()});
      this.tag(BlockTags.WOODEN_PRESSURE_PLATES).add(new Block[]{(Block)ModBlocks.FUNGYSS_PRESSURE_PLATE.get(), (Block)ModBlocks.AURUM_PRESSURE_PLATE.get(), (Block)ModBlocks.EDELWOOD_PRESSURE_PLATE.get()});
      this.tag(BlockTags.BUTTONS).add((Block)ModBlocks.POLISHED_DARKSTONE_BUTTON.get());
      this.tag(BlockTags.WOODEN_BUTTONS).add(new Block[]{(Block)ModBlocks.FUNGYSS_BUTTON.get(), (Block)ModBlocks.AURUM_BUTTON.get(), (Block)ModBlocks.EDELWOOD_BUTTON.get()});
      this.tag(BlockTags.WOODEN_FENCES).add(new Block[]{(Block)ModBlocks.FUNGYSS_FENCE.get(), (Block)ModBlocks.AURUM_FENCE.get(), (Block)ModBlocks.EDELWOOD_FENCE.get()});
      this.tag(Blocks.FENCES_WOODEN).add(new Block[]{(Block)ModBlocks.FUNGYSS_FENCE.get(), (Block)ModBlocks.AURUM_FENCE.get(), (Block)ModBlocks.EDELWOOD_FENCE.get()});
      this.tag(BlockTags.FENCE_GATES).add(new Block[]{(Block)ModBlocks.FUNGYSS_FENCE_GATE.get(), (Block)ModBlocks.AURUM_FENCE_GATE.get(), (Block)ModBlocks.EDELWOOD_FENCE_GATE.get()});
      this.tag(Blocks.FENCE_GATES_WOODEN).add(new Block[]{(Block)ModBlocks.FUNGYSS_FENCE_GATE.get(), (Block)ModBlocks.AURUM_FENCE_GATE.get(), (Block)ModBlocks.EDELWOOD_FENCE_GATE.get()});
      this.tag(BlockTags.WOODEN_DOORS).add(new Block[]{(Block)ModBlocks.FUNGYSS_DOOR.get(), (Block)ModBlocks.AURUM_DOOR.get(), (Block)ModBlocks.EDELWOOD_DOOR.get(), (Block)ModBlocks.ARCANE_EDELWOOD_DOOR.get()});
      this.tag(BlockTags.DOORS).add((Block)ModBlocks.DEORUM_DOOR.get());
      this.tag(BlockTags.WOODEN_TRAPDOORS).add(new Block[]{(Block)ModBlocks.FUNGYSS_TRAPDOOR.get(), (Block)ModBlocks.AURUM_TRAPDOOR.get(), (Block)ModBlocks.EDELWOOD_TRAPDOOR.get(), (Block)ModBlocks.ARCANE_EDELWOOD_TRAPDOOR.get()});
      this.tag(BlockTags.TRAPDOORS).add((Block)ModBlocks.DEORUM_TRAPDOOR.get());
      this.tag(BlockTags.FLOWER_POTS).add(new Block[]{(Block)ModBlocks.POTTED_FUNGYSS.get(), (Block)ModBlocks.POTTED_AURUM_SAPLING.get(), (Block)ModBlocks.POTTED_GROWING_EDELWOOD.get(), (Block)ModBlocks.POTTED_YELLOW_ORCHID.get()});
      this.tag(ModTags.Blocks.BLACKSMITH_GAVEL_UNAFFECTED);
      this.tag(ModTags.Blocks.MAGICAL_FARMLAND_BLACKLISTED);
      this.tag(ModTags.Blocks.RUNIC_STONES).add(new Block[]{(Block)ModBlocks.RUNIC_STONE.get(), (Block)ModBlocks.RUNIC_DEEPSLATE.get(), (Block)ModBlocks.RUNIC_DARKSTONE.get()});
      this.tag(ModTags.Blocks.RUNE_BLOCKS).add((Block)ModBlocks.RUNE_BLOCK.get());
      this.tag(ModTags.Blocks.ARCANE_CRYSTAL_ORES).add(new Block[]{(Block)ModBlocks.ARCANE_CRYSTAL_ORE.get(), (Block)ModBlocks.DEEPSLATE_ARCANE_CRYSTAL_ORE.get()});
      this.tag(BlockTags.IMPERMEABLE).add(new Block[]{(Block)ModBlocks.DEORUM_GLASS.get(), (Block)ModBlocks.RUNIC_GLASS.get()});
      this.tag(BlockTags.SAPLINGS).add(new Block[]{(Block)ModBlocks.AURUM_SAPLING.get(), (Block)ModBlocks.GROWING_EDELWOOD.get()});
      this.tag(BlockTags.LEAVES).add(new Block[]{(Block)ModBlocks.AURUM_LEAVES.get(), (Block)ModBlocks.NUGGETY_AURUM_LEAVES.get()});
      this.tag(BlockTags.SMALL_FLOWERS).add((Block)ModBlocks.YELLOW_ORCHID.get());
      this.tag(ModTags.Blocks.DARKSTONE_ORE_REPLACEABLES).add((Block)ModBlocks.DARKSTONE.get());
      this.tag(ModTags.Blocks.HEPHAESTUS_FORGES).add(new Block[]{(Block)ModBlocks.HEPHAESTUS_FORGE_TIER_1.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_2.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_3.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_4.get(), (Block)ModBlocks.HEPHAESTUS_FORGE_TIER_5.get()});
      this.tag(ModTags.Blocks.PEDESTALS).add(new Block[]{(Block)ModBlocks.DARKSTONE_PEDESTAL.get(), (Block)ModBlocks.MAGNETIZED_DARKSTONE_PEDESTAL.get()});
      this.tag(ModTags.Blocks.STORAGE_BLOCKS_DEORUM).add((Block)ModBlocks.DEORUM_BLOCK.get());
      this.tag(ModTags.Blocks.STORAGE_BLOCKS_ARCANE_CRYSTAL).add((Block)ModBlocks.ARCANE_CRYSTAL_BLOCK.get());
      this.tag(ModTags.Blocks.STORAGE_BLOCKS_CORRUPTED_ARCANE_CRYSTAL).add((Block)ModBlocks.CORRUPTED_ARCANE_CRYSTAL_BLOCK.get());
      this.tag(ModTags.Blocks.STORAGE_BLOCKS_STELLARITE).add((Block)ModBlocks.STELLARITE_BLOCK.get());
      this.tag(ModTags.Blocks.STORAGE_BLOCKS_OBSIDIANSTEEL).add((Block)ModBlocks.OBSIDIANSTEEL_BLOCK.get());
      this.tag(Blocks.STORAGE_BLOCKS).addTags(new TagKey[]{ModTags.Blocks.STORAGE_BLOCKS_DEORUM, ModTags.Blocks.STORAGE_BLOCKS_ARCANE_CRYSTAL, ModTags.Blocks.STORAGE_BLOCKS_CORRUPTED_ARCANE_CRYSTAL, ModTags.Blocks.STORAGE_BLOCKS_STELLARITE, ModTags.Blocks.STORAGE_BLOCKS_OBSIDIANSTEEL});
      this.tag(ModTags.Blocks.ORES_ARCANE_CRYSTAL).add(new Block[]{(Block)ModBlocks.ARCANE_CRYSTAL_ORE.get(), (Block)ModBlocks.DEEPSLATE_ARCANE_CRYSTAL_ORE.get()});
      this.tag(ModTags.Blocks.ORES_RUNIC).add(new Block[]{(Block)ModBlocks.RUNIC_STONE.get(), (Block)ModBlocks.RUNIC_DEEPSLATE.get(), (Block)ModBlocks.RUNIC_DARKSTONE.get()});
      this.tag(ModTags.Blocks.ORES_STELLARITE).add((Block)ModBlocks.STELLA_ARCANUM.get());
      this.tag(Blocks.ORES).addTag(ModTags.Blocks.ORES_ARCANE_CRYSTAL).addTag(ModTags.Blocks.ORES_RUNIC).addTag(ModTags.Blocks.ORES_STELLARITE);
      this.tag(Blocks.ORES_IN_GROUND_STONE).add(new Block[]{(Block)ModBlocks.ARCANE_CRYSTAL_ORE.get(), (Block)ModBlocks.RUNIC_STONE.get(), (Block)ModBlocks.STELLA_ARCANUM.get()});
      this.tag(Blocks.ORES_IN_GROUND_DEEPSLATE).add(new Block[]{(Block)ModBlocks.DEEPSLATE_ARCANE_CRYSTAL_ORE.get(), (Block)ModBlocks.RUNIC_DEEPSLATE.get(), (Block)ModBlocks.STELLA_ARCANUM.get()});
      this.tag(BlockTags.BASE_STONE_OVERWORLD).add((Block)ModBlocks.DARKSTONE.get());
      this.tag(Blocks.GLASS_BLOCKS).add(new Block[]{(Block)ModBlocks.DEORUM_GLASS.get(), (Block)ModBlocks.RUNIC_GLASS.get()});
      this.tag(Blocks.GLASS_BLOCKS_COLORLESS).add(new Block[]{(Block)ModBlocks.DEORUM_GLASS.get(), (Block)ModBlocks.RUNIC_GLASS.get()});
      this.tag(Blocks.GLASS_PANES).add(new Block[]{(Block)ModBlocks.DEORUM_GLASS_PANE.get(), (Block)ModBlocks.RUNIC_GLASS_PANE.get()});
      this.tag(Blocks.GLASS_PANES_COLORLESS).add(new Block[]{(Block)ModBlocks.DEORUM_GLASS_PANE.get(), (Block)ModBlocks.RUNIC_GLASS_PANE.get()});
      this.tag(BlockTags.CLIMBABLE).add((Block)ModBlocks.EDELWOOD_LADDER.get());
      this.tag(BlockTags.FALL_DAMAGE_RESETTING).add((Block)ModBlocks.EDELWOOD_LADDER.get());
      this.tag(BlockTags.MINEABLE_WITH_PICKAXE).add(new Block[]{(Block)ModBlocks.DEORUM_CHAIN.get(), (Block)ModBlocks.STELLA_ARCANUM.get(), (Block)ModBlocks.OBSIDIANSTEEL_BLOCK.get(), (Block)ModBlocks.DEORUM_BLOCK.get(), (Block)ModBlocks.STELLARITE_BLOCK.get(), (Block)ModBlocks.SOULLESS_SANDSTONE.get(), (Block)ModBlocks.CUT_SOULLESS_SANDSTONE.get(), (Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get(), (Block)ModBlocks.SOULLESS_SANDSTONE_SLAB.get(), (Block)ModBlocks.CUT_SOULLESS_SANDSTONE_SLAB.get(), (Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE_SLAB.get(), (Block)ModBlocks.SOULLESS_SANDSTONE_STAIRS.get(), (Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE_STAIRS.get(), (Block)ModBlocks.DEORUM_DOOR.get(), (Block)ModBlocks.DEORUM_TRAPDOOR.get(), (Block)ModBlocks.DARKSTONE.get(), (Block)ModBlocks.DARKSTONE_SLAB.get(), (Block)ModBlocks.DARKSTONE_STAIRS.get(), (Block)ModBlocks.POLISHED_DARKSTONE.get(), (Block)ModBlocks.POLISHED_DARKSTONE_SLAB.get(), (Block)ModBlocks.POLISHED_DARKSTONE_STAIRS.get(), (Block)ModBlocks.POLISHED_DARKSTONE_WALL.get(), (Block)ModBlocks.POLISHED_DARKSTONE_PRESSURE_PLATE.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BUTTON.get(), (Block)ModBlocks.CHISELED_POLISHED_DARKSTONE.get(), (Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICKS.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICK_SLAB.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICK_STAIRS.get(), (Block)ModBlocks.CRACKED_POLISHED_DARKSTONE_BRICKS.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_SLAB.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_STAIRS.get(), (Block)ModBlocks.CHISELED_ARCANE_POLISHED_DARKSTONE.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_PILLAR.get(), (Block)ModBlocks.TILED_POLISHED_DARKSTONE_BRICKS.get(), (Block)ModBlocks.CLIBANO_CORE.get(), (Block)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get(), (Block)ModBlocks.CLIBANO_SIDE_VERTICAL.get(), (Block)ModBlocks.CLIBANO_CORNER.get(), (Block)ModBlocks.CLIBANO_CENTER.get(), (Block)ModBlocks.CLIBANO_MAIN_PART.get(), (Block)ModBlocks.DEORUM_LANTERN.get(), (Block)ModBlocks.DEORUM_SOUL_LANTERN.get()}).addTag(ModTags.Blocks.RUNIC_STONES).addTag(ModTags.Blocks.RUNE_BLOCKS).addTag(ModTags.Blocks.ARCANE_CRYSTAL_ORES).addTag(ModTags.Blocks.HEPHAESTUS_FORGES).addTag(ModTags.Blocks.PEDESTALS);
      this.tag(BlockTags.MINEABLE_WITH_SHOVEL).add((Block)ModBlocks.SOULLESS_SAND.get());
      this.tag(BlockTags.MINEABLE_WITH_HOE).add(new Block[]{(Block)ModBlocks.AURUM_LEAVES.get(), (Block)ModBlocks.NUGGETY_AURUM_LEAVES.get()});
      this.tag(BlockTags.MINEABLE_WITH_AXE).add(new Block[]{(Block)ModBlocks.EDELWOOD_LADDER.get(), (Block)ModBlocks.EDELWOOD_BRANCH.get()});
      this.tag(BlockTags.NEEDS_DIAMOND_TOOL).add(new Block[]{(Block)ModBlocks.OBSIDIANSTEEL_BLOCK.get(), (Block)ModBlocks.STELLA_ARCANUM.get(), (Block)ModBlocks.STELLARITE_BLOCK.get()}).addTag(ModTags.Blocks.HEPHAESTUS_FORGES).addTag(ModTags.Blocks.RUNIC_STONES).addTag(ModTags.Blocks.RUNE_BLOCKS);
      this.tag(BlockTags.NEEDS_IRON_TOOL).add((Block)ModBlocks.DEORUM_BLOCK.get()).addTag(ModTags.Blocks.ARCANE_CRYSTAL_ORES);
      this.tag(BlockTags.NEEDS_STONE_TOOL).addTag(ModTags.Blocks.PEDESTALS).add(new Block[]{(Block)ModBlocks.DARKSTONE.get(), (Block)ModBlocks.DARKSTONE_SLAB.get(), (Block)ModBlocks.DARKSTONE_STAIRS.get(), (Block)ModBlocks.DARKSTONE_WALL.get(), (Block)ModBlocks.POLISHED_DARKSTONE.get(), (Block)ModBlocks.POLISHED_DARKSTONE_SLAB.get(), (Block)ModBlocks.POLISHED_DARKSTONE_STAIRS.get(), (Block)ModBlocks.POLISHED_DARKSTONE_WALL.get(), (Block)ModBlocks.POLISHED_DARKSTONE_PRESSURE_PLATE.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BUTTON.get(), (Block)ModBlocks.CHISELED_POLISHED_DARKSTONE.get(), (Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICKS.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICK_SLAB.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICK_STAIRS.get(), (Block)ModBlocks.POLISHED_DARKSTONE_BRICK_WALL.get(), (Block)ModBlocks.CRACKED_POLISHED_DARKSTONE_BRICKS.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_SLAB.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_STAIRS.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_WALL.get(), (Block)ModBlocks.CHISELED_ARCANE_POLISHED_DARKSTONE.get(), (Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_PILLAR.get(), (Block)ModBlocks.CLIBANO_CORE.get(), (Block)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get(), (Block)ModBlocks.CLIBANO_SIDE_VERTICAL.get(), (Block)ModBlocks.CLIBANO_CORNER.get(), (Block)ModBlocks.CLIBANO_CENTER.get(), (Block)ModBlocks.CLIBANO_MAIN_PART.get()});
   }
}
