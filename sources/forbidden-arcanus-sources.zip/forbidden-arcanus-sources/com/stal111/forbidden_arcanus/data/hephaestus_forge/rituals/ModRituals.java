package com.stal111.forbidden_arcanus.data.hephaestus_forge.rituals;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.TierPredicate;
import com.stal111.forbidden_arcanus.common.block.entity.forge.circle.MagicCircleType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssencesDefinition;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.Ritual;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.RitualRequirements;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.CreateItemResult;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.RitualResult;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.TransmuteInputResult;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.UpgradeTierResult;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import com.stal111.forbidden_arcanus.data.enhancer.ModEnhancerDefinitions;
import com.stal111.forbidden_arcanus.data.hephaestus_forge.ModMagicCircles;
import java.util.function.UnaryOperator;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.helper.datapack.DatapackRegistryHelper;

public class ModRituals extends DatapackRegistryClass<Ritual> {
   public static final DatapackRegistryHelper<Ritual> HELPER;
   public static final ResourceKey<Ritual> ETERNAL_STELLA;
   public static final ResourceKey<Ritual> TERRASTOMP_PRISM;
   public static final ResourceKey<Ritual> SEA_PRISM;
   public static final ResourceKey<Ritual> WHIRLWIND_PRISM;
   public static final ResourceKey<Ritual> SMELTER_PRISM;
   public static final ResourceKey<Ritual> FERROGNETIC_MIXTURE;
   public static final ResourceKey<Ritual> QUANTUM_CATCHER;
   public static final ResourceKey<Ritual> BOSS_CATCHER;
   public static final ResourceKey<Ritual> QUANTUM_INJECTOR;
   public static final ResourceKey<Ritual> SOUL_BINDING_CRYSTAL;
   public static final ResourceKey<Ritual> DRACO_ARCANUS_HELMET;
   public static final ResourceKey<Ritual> DRACO_ARCANUS_CHESTPLATE;
   public static final ResourceKey<Ritual> DRACO_ARCANUS_LEGGINGS;
   public static final ResourceKey<Ritual> DRACO_ARCANUS_BOOTS;
   public static final ResourceKey<Ritual> TYR_HELMET;
   public static final ResourceKey<Ritual> TYR_CHESTPLATE;
   public static final ResourceKey<Ritual> TYR_LEGGINGS;
   public static final ResourceKey<Ritual> TYR_BOOTS;
   public static final ResourceKey<Ritual> UPGRADE_TIER_2;
   public static final ResourceKey<Ritual> UPGRADE_TIER_3;
   public static final ResourceKey<Ritual> UPGRADE_TIER_4;
   public static final ResourceKey<Ritual> UPGRADE_TIER_5;
   private HolderGetter<MagicCircleType> magicCircleLookup;

   public ModRituals(BootstrapContext<Ritual> context) {
      super(context);
   }

   public void init(BootstrapContext<Ritual> context) {
      this.magicCircleLookup = context.lookup(FARegistries.MAGIC_CIRCLE);
   }

   public void bootstrap(BootstrapContext<Ritual> context) {
      HolderGetter<EnhancerDefinition> enhancerLookup = context.lookup(FARegistries.ENHANCER_DEFINITION);
      Holder<EnhancerDefinition> elementarium = enhancerLookup.getOrThrow(ModEnhancerDefinitions.ELEMENTARIUM);
      Holder<EnhancerDefinition> divinePact = enhancerLookup.getOrThrow(ModEnhancerDefinitions.DIVINE_PACT);
      RitualRequirements eternalStella = this.requirements(EssencesDefinition.of(82, 1, 1000, 0), (builder) -> {
         return builder.tier(TierPredicate.min(3));
      });
      RitualRequirements terrastompPrism = this.requirements(EssencesDefinition.of(300, 9, 1500, 0), (builder) -> {
         return builder.tier(TierPredicate.min(2)).enhancer(elementarium);
      });
      RitualRequirements seaPrism = this.requirements(EssencesDefinition.of(1000, 8, 2000, 0), (builder) -> {
         return builder.tier(TierPredicate.min(3)).enhancer(elementarium);
      });
      RitualRequirements whirlwindPrism = this.requirements(EssencesDefinition.of(1000, 3, 2250, 0), (builder) -> {
         return builder.tier(TierPredicate.min(3)).enhancer(elementarium);
      });
      RitualRequirements smelterPrism = this.requirements(EssencesDefinition.of(200, 4, 1250, 0), (builder) -> {
         return builder.enhancer(elementarium);
      });
      RitualRequirements ferrogneticMixture = this.requirements(EssencesDefinition.of(100, 2, 1250, 0), UnaryOperator.identity());
      RitualRequirements quantumCatcher = this.requirements(EssencesDefinition.of(200, 5, 1200, 155), UnaryOperator.identity());
      RitualRequirements bossCatcher = this.requirements(EssencesDefinition.of(500, 10, 7500, 1200), (builder) -> {
         return builder.tier(TierPredicate.min(4));
      });
      RitualRequirements quantumInjector = this.requirements(EssencesDefinition.of(5000, 50, 3000, 1060), (builder) -> {
         return builder.tier(TierPredicate.min(3));
      });
      RitualRequirements soulBindingCrystal = this.requirements(EssencesDefinition.of(1500, 20, 375, 220), (builder) -> {
         return builder.tier(TierPredicate.min(4)).enhancer(divinePact);
      });
      RitualRequirements dracoArcanusHelmet = this.requirements(EssencesDefinition.of(820, 6, 475, 420), (builder) -> {
         return builder.tier(TierPredicate.min(2));
      });
      RitualRequirements dracoArcanusChestplate = this.requirements(EssencesDefinition.of(1300, 9, 625, 760), (builder) -> {
         return builder.tier(TierPredicate.min(2));
      });
      RitualRequirements dracoArcanusLeggings = this.requirements(EssencesDefinition.of(1000, 7, 565, 540), (builder) -> {
         return builder.tier(TierPredicate.min(2));
      });
      RitualRequirements dracoArcanusBoots = this.requirements(EssencesDefinition.of(700, 5, 405, 370), (builder) -> {
         return builder.tier(TierPredicate.min(2));
      });
      RitualRequirements tyrHelmet = this.requirements(EssencesDefinition.of(4820, 40, 5930, 2450), (builder) -> {
         return builder.tier(TierPredicate.min(4));
      });
      RitualRequirements tyrChestplate = this.requirements(EssencesDefinition.of(6300, 60, 8080, 3420), (builder) -> {
         return builder.tier(TierPredicate.min(4));
      });
      RitualRequirements tyrLeggings = this.requirements(EssencesDefinition.of(5080, 50, 7620, 3010), (builder) -> {
         return builder.tier(TierPredicate.min(4));
      });
      RitualRequirements tyrBoots = this.requirements(EssencesDefinition.of(4460, 40, 5620, 2170), (builder) -> {
         return builder.tier(TierPredicate.min(4));
      });
      RitualRequirements tier2 = this.requirements(EssencesDefinition.of(500, 10, 6000, 0), (builder) -> {
         return builder.tier(TierPredicate.exact(1));
      });
      RitualRequirements tier3 = this.requirements(EssencesDefinition.of(1000, 50, 9000, 0), (builder) -> {
         return builder.tier(TierPredicate.exact(2));
      });
      RitualRequirements tier4 = this.requirements(EssencesDefinition.of(2000, 100, 12000, 0), (builder) -> {
         return builder.tier(TierPredicate.exact(3));
      });
      RitualRequirements tier5 = this.requirements(EssencesDefinition.of(5000, 500, 20000, 0), (builder) -> {
         return builder.tier(TierPredicate.exact(4));
      });
      this.register(ETERNAL_STELLA, (ItemLike)((ItemLike)ModItems.ETERNAL_STELLA.get()), (ItemLike)Items.DIAMOND, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{ModItems.XPETRIFIED_ORB}), 3).input(Ingredient.of(new ItemLike[]{ModItems.STELLARITE_PIECE})).requirements(eternalStella);
      });
      this.register(TERRASTOMP_PRISM, (ItemLike)((ItemLike)ModItems.TERRASTOMP_PRISM.get()), (ItemLike)Blocks.DIAMOND_BLOCK, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{Items.FLINT}), 2).input(Ingredient.of(new ItemLike[]{Blocks.DRIPSTONE_BLOCK}), 2).input(Ingredient.of(new ItemLike[]{Blocks.POINTED_DRIPSTONE}), 2).requirements(terrastompPrism);
      });
      this.register(SEA_PRISM, (ItemLike)((ItemLike)ModItems.SEA_PRISM.get()), (ItemLike)Items.HEART_OF_THE_SEA, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{Items.PRISMARINE_SHARD}), 2).input(Ingredient.of(new ItemLike[]{Items.TURTLE_SCUTE}), 2).input(Ingredient.of(new ItemLike[]{Items.LAPIS_LAZULI}), 2).requirements(seaPrism);
      });
      this.register(WHIRLWIND_PRISM, (ItemLike)((ItemLike)ModItems.WHIRLWIND_PRISM.get()), (ItemLike)Blocks.WHITE_WOOL, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{ModItems.BAT_WING})).input(Ingredient.of(new ItemLike[]{Items.FEATHER}), 2).input(Ingredient.of(new ItemLike[]{Items.PHANTOM_MEMBRANE}), 3).requirements(whirlwindPrism);
      });
      this.register(SMELTER_PRISM, (ItemLike)ModItems.SMELTER_PRISM.get(), (ItemLike)ModBlocks.ARCANE_CRYSTAL_BLOCK.get(), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{Items.COAL}), 2).input(Ingredient.of(new ItemLike[]{Items.BLAZE_POWDER}), 4).requirements(smelterPrism);
      });
      this.register(FERROGNETIC_MIXTURE, (ItemLike)((ItemLike)ModItems.FERROGNETIC_MIXTURE.get()), (ItemLike)Blocks.LODESTONE, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{Items.CLAY_BALL}), 2).input(Ingredient.of(new ItemLike[]{ModItems.WAX}), 2).input(Ingredient.of(new ItemLike[]{Items.SLIME_BALL}), 2).input(Ingredient.of(new ItemLike[]{Items.IRON_INGOT})).requirements(ferrogneticMixture);
      });
      this.register(QUANTUM_CATCHER, (ItemLike)ModItems.QUANTUM_CATCHER.get(), (ItemLike)ModBlocks.QUANTUM_CORE.get(), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{ModItems.SPAWNER_SCRAP}), 4).requirements(quantumCatcher);
      });
      this.register(BOSS_CATCHER, (ItemLike)ModItems.BOSS_CATCHER.get(), (ItemLike)ModItems.QUANTUM_CATCHER.get(), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{Items.NETHER_STAR})).input(Ingredient.of(new ItemLike[]{ModItems.STELLARITE_PIECE}), 3).requirements(bossCatcher);
      });
      this.register(QUANTUM_INJECTOR, (ItemLike)ModBlocks.QUANTUM_INJECTOR.get(), (ItemLike)ModItems.MUNDABITUR_DUST.get(), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModBlocks.QUANTUM_CORE.get()}), 4).requirements(quantumInjector);
      });
      this.register(SOUL_BINDING_CRYSTAL, (ItemLike)((ItemLike)ModItems.SOUL_BINDING_CRYSTAL.get()), (ItemLike)Items.QUARTZ, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{ModItems.SOUL})).input(Ingredient.of(new ItemLike[]{ModItems.CORRUPT_SOUL})).input(Ingredient.of(new ItemLike[]{ModItems.ENCHANTED_SOUL})).input(Ingredient.of(new ItemLike[]{Items.AMETHYST_SHARD}), 2).input(Ingredient.of(new ItemLike[]{ModItems.ENDER_PEARL_FRAGMENT}), 3).requirements(soulBindingCrystal);
      });
      this.register(DRACO_ARCANUS_HELMET, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.DRACO_ARCANUS_HELMET.getKey()))), (ItemLike)Items.NETHERITE_HELMET, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()}), 2).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.OBSIDIANSTEEL_INGOT.get()}), 3).requirements(dracoArcanusHelmet);
      });
      this.register(DRACO_ARCANUS_CHESTPLATE, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.DRACO_ARCANUS_CHESTPLATE.getKey()))), (ItemLike)Items.NETHERITE_CHESTPLATE, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.OBSIDIANSTEEL_INGOT.get()}), 3).requirements(dracoArcanusChestplate);
      });
      this.register(DRACO_ARCANUS_LEGGINGS, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.DRACO_ARCANUS_LEGGINGS.getKey()))), (ItemLike)Items.NETHERITE_LEGGINGS, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()}), 3).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.OBSIDIANSTEEL_INGOT.get()}), 3).requirements(dracoArcanusLeggings);
      });
      this.register(DRACO_ARCANUS_BOOTS, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.DRACO_ARCANUS_BOOTS.getKey()))), (ItemLike)Items.NETHERITE_BOOTS, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()}), 2).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.OBSIDIANSTEEL_INGOT.get()}), 2).requirements(dracoArcanusBoots);
      });
      this.register(TYR_HELMET, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.TYR_HELMET.getKey()))), (ItemLike)ModItems.DRACO_ARCANUS_HELMET, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.AQUATIC_DRAGON_SCALE.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.GOLDEN_DRAGON_SCALE.get()}), 1).requirements(tyrHelmet);
      });
      this.register(TYR_CHESTPLATE, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.TYR_CHESTPLATE.getKey()))), (ItemLike)ModItems.DRACO_ARCANUS_CHESTPLATE, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.AQUATIC_DRAGON_SCALE.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.GOLDEN_DRAGON_SCALE.get()}), 4).requirements(tyrChestplate);
      });
      this.register(TYR_LEGGINGS, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.TYR_LEGGINGS.getKey()))), (ItemLike)ModItems.DRACO_ARCANUS_LEGGINGS, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.AQUATIC_DRAGON_SCALE.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.GOLDEN_DRAGON_SCALE.get()}), 3).requirements(tyrLeggings);
      });
      this.register(TYR_BOOTS, (RitualResult)(new TransmuteInputResult(context.lookup(Registries.ITEM).getOrThrow(ModItems.TYR_BOOTS.getKey()))), (ItemLike)ModItems.DRACO_ARCANUS_BOOTS, (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.AQUATIC_DRAGON_SCALE.get()}), 3).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.GOLDEN_DRAGON_SCALE.get()}), 2).requirements(tyrBoots);
      });
      this.register(UPGRADE_TIER_2, (RitualResult)(new UpgradeTierResult(2)), (ItemStack)(new ItemStack((ItemLike)ModBlocks.EDELWOOD_PLANKS.get())), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.ARCANE_CRYSTAL.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.SPAWNER_SCRAP.get()}), 4).requirements(tier2).magicCircle(ModMagicCircles.UPGRADE_TIER);
      });
      this.register(UPGRADE_TIER_3, (RitualResult)(new UpgradeTierResult(3)), (ItemStack)(new ItemStack((ItemLike)ModBlocks.CHISELED_POLISHED_DARKSTONE.get())), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.ARCANE_CRYSTAL.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DEORUM_INGOT.get()}), 4).requirements(tier3).magicCircle(ModMagicCircles.UPGRADE_TIER);
      });
      this.register(UPGRADE_TIER_4, (RitualResult)(new UpgradeTierResult(4)), (ItemStack)(new ItemStack((ItemLike)ModBlocks.CHISELED_POLISHED_DARKSTONE.get())), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.STELLARITE_PIECE.get()}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.RUNE.get()}), 4).requirements(tier4).magicCircle(ModMagicCircles.UPGRADE_TIER);
      });
      this.register(UPGRADE_TIER_5, (RitualResult)(new UpgradeTierResult(5)), (ItemStack)(new ItemStack((ItemLike)ModBlocks.STELLARITE_BLOCK.get())), (builder) -> {
         return builder.input(Ingredient.of(new ItemLike[]{Blocks.SCULK_CATALYST}), 4).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DARK_NETHER_STAR.get()}), 2).input(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()}), 2).requirements(tier5).magicCircle(ModMagicCircles.UPGRADE_FINAL_TIER);
      });
   }

   private RitualRequirements requirements(EssencesDefinition essences, UnaryOperator<RitualRequirements.Builder> builder) {
      return ((RitualRequirements.Builder)builder.apply(RitualRequirements.builder(essences))).build();
   }

   private void register(ResourceKey<Ritual> key, ItemLike result, ItemLike mainIngredient, UnaryOperator<RitualBuilder> builder) {
      this.getContext().register(key, ((RitualBuilder)builder.apply(new RitualBuilder(new ItemStack(mainIngredient), new CreateItemResult(new ItemStack(result)), this.magicCircleLookup))).build());
   }

   private void register(ResourceKey<Ritual> key, ItemStack result, ItemStack mainIngredient, UnaryOperator<RitualBuilder> builder) {
      this.getContext().register(key, ((RitualBuilder)builder.apply(new RitualBuilder(mainIngredient, new CreateItemResult(result), this.magicCircleLookup))).build());
   }

   private void register(ResourceKey<Ritual> key, RitualResult result, ItemLike mainIngredient, UnaryOperator<RitualBuilder> builder) {
      this.getContext().register(key, ((RitualBuilder)builder.apply(new RitualBuilder(new ItemStack(mainIngredient), result, this.magicCircleLookup))).build());
   }

   private void register(ResourceKey<Ritual> key, RitualResult result, ItemStack mainIngredient, UnaryOperator<RitualBuilder> builder) {
      this.getContext().register(key, ((RitualBuilder)builder.apply(new RitualBuilder(mainIngredient, result, this.magicCircleLookup))).build());
   }

   static {
      HELPER = (DatapackRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.RITUAL);
      ETERNAL_STELLA = HELPER.createKey("eternal_stella");
      TERRASTOMP_PRISM = HELPER.createKey("terrastomp_prism");
      SEA_PRISM = HELPER.createKey("sea_prism");
      WHIRLWIND_PRISM = HELPER.createKey("whirlwind_prism");
      SMELTER_PRISM = HELPER.createKey("smelter_prism");
      FERROGNETIC_MIXTURE = HELPER.createKey("ferrognetic_mixture");
      QUANTUM_CATCHER = HELPER.createKey("quantum_catcher");
      BOSS_CATCHER = HELPER.createKey("boss_catcher");
      QUANTUM_INJECTOR = HELPER.createKey("quantum_injector");
      SOUL_BINDING_CRYSTAL = HELPER.createKey("soul_binding_crystal");
      DRACO_ARCANUS_HELMET = HELPER.createKey("draco_arcanus_helmet");
      DRACO_ARCANUS_CHESTPLATE = HELPER.createKey("draco_arcanus_chestplate");
      DRACO_ARCANUS_LEGGINGS = HELPER.createKey("draco_arcanus_leggings");
      DRACO_ARCANUS_BOOTS = HELPER.createKey("draco_arcanus_boots");
      TYR_HELMET = HELPER.createKey("tyr_helmet");
      TYR_CHESTPLATE = HELPER.createKey("tyr_chestplate");
      TYR_LEGGINGS = HELPER.createKey("tyr_leggings");
      TYR_BOOTS = HELPER.createKey("tyr_boots");
      UPGRADE_TIER_2 = HELPER.createKey("upgrade_tier_2");
      UPGRADE_TIER_3 = HELPER.createKey("upgrade_tier_3");
      UPGRADE_TIER_4 = HELPER.createKey("upgrade_tier_4");
      UPGRADE_TIER_5 = HELPER.createKey("upgrade_tier_5");
   }
}
