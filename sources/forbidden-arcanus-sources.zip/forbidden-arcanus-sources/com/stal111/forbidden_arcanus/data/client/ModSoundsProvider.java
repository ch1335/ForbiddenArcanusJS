package com.stal111.forbidden_arcanus.data.client;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModSounds;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.neoforged.neoforge.common.data.SoundDefinition;
import net.neoforged.neoforge.common.data.SoundDefinitionsProvider;
import net.neoforged.neoforge.common.data.SoundDefinition.Sound;
import net.neoforged.neoforge.common.data.SoundDefinition.SoundType;
import net.valhelsia.valhelsia_core.datagen.DataProviderContext;

public class ModSoundsProvider extends SoundDefinitionsProvider {
   public ModSoundsProvider(DataProviderContext context, ExistingFileHelper fileHelper) {
      super(context.output(), "forbidden_arcanus", fileHelper);
   }

   public void registerSounds() {
      this.add(ModSounds.ENERGY_BALL_LAUNCH, SoundDefinition.definition().with(this.simpleSound("energy_ball_launch")));
      this.add(ModSounds.ENERGY_BALL_HIT, SoundDefinition.definition().with(this.simpleSound("energy_ball_hit")));
      this.add(ModSounds.QUANTUM_CATCHER_PICK_UP, SoundDefinition.definition().with(this.simpleSound("quantum_catcher_pick_up")));
      this.add(ModSounds.QUANTUM_CATCHER_RELEASE, SoundDefinition.definition().with(this.simpleSound("quantum_catcher_release")));
      this.add(ModSounds.FERROGNETIC_MIXTURE_APPLY, SoundDefinition.definition().with(this.simpleSound("ferrognetic_mixture_apply_1")).with(this.simpleSound("ferrognetic_mixture_apply_2")));
      this.add(ModSounds.CLIBANO_FIRE_CRACKLE, SoundDefinition.definition().with(this.simpleSound("clibano_fire_crackle_1")).with(this.simpleSound("clibano_fire_crackle_2")).with(this.simpleSound("clibano_fire_crackle_3")).with(this.simpleSound("clibano_fire_crackle_4")).with(this.simpleSound("clibano_fire_crackle_5")));
      this.add(ModSounds.CLIBANO_SOUL_FIRE_CRACKLE, SoundDefinition.definition().with(this.simpleSound("clibano_soul_fire_crackle_1")).with(this.simpleSound("clibano_soul_fire_crackle_2")).with(this.simpleSound("clibano_soul_fire_crackle_3")).with(this.simpleSound("clibano_soul_fire_crackle_4")).with(this.simpleSound("clibano_soul_fire_crackle_5")));
      this.add(ModSounds.BLACKSMITH_GAVEL_RITUAL_START, SoundDefinition.definition().with(this.simpleSound("blacksmith_gavel_ritual_start")));
      this.add(ModSounds.FORBIDDENOMICON_OPEN, SoundDefinition.definition().with(this.simpleSound("forbiddenomicon_open")));
      this.add(ModSounds.FORBIDDENOMICON_CLOSE, SoundDefinition.definition().with(this.simpleSound("forbiddenomicon_close")));
      this.add(ModSounds.MUNDABITUR_DUST_USE, SoundDefinition.definition().with(this.simpleSound("mundabitur_dust_use")));
      this.add(ModSounds.PEDESTAL_INTERACT, SoundDefinition.definition().with(this.simpleSound("pedestal_interact")));
      this.add(ModSounds.OBSIDIAN_SKULL_CRACK, SoundDefinition.definition().with(this.simpleSound("obsidian_skull_crack_1")).with(this.simpleSound("obsidian_skull_crack_2")));
      this.add(ModSounds.MAGIC_WAND_CAST, SoundDefinition.definition().with(this.simpleSound("magic_wand_cast_1")).with(this.simpleSound("magic_wand_cast_2")).with(this.simpleSound("magic_wand_cast_3")).with(this.simpleSound("magic_wand_cast_4")));
   }

   private Sound simpleSound(String name) {
      return Sound.sound(ForbiddenArcanus.location(name), SoundType.SOUND);
   }
}
