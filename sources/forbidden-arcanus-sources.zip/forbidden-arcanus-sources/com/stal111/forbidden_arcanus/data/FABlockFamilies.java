package com.stal111.forbidden_arcanus.data;

import com.google.common.collect.Maps;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.BlockFamily;
import net.minecraft.data.BlockFamily.Builder;
import net.minecraft.world.level.block.Block;

public class FABlockFamilies {
   private static final Map<Block, BlockFamily> MAP = Maps.newHashMap();
   public static final BlockFamily DARKSTONE;
   public static final BlockFamily POLISHED_DARKSTONE;
   public static final BlockFamily POLISHED_DARKSTONE_BRICKS;
   public static final BlockFamily ARCANE_POLISHED_DARKSTONE;
   public static final BlockFamily SOULLESS_SANDSTONE;
   public static final BlockFamily CUT_SOULLESS_SANDSTONE;
   public static final BlockFamily POLISHED_SOULLESS_SANDSTONE;
   public static final BlockFamily FUNGYSS_PLANKS;
   public static final BlockFamily AURUM_PLANKS;
   public static final BlockFamily EDELWOOD_PLANKS;
   public static final BlockFamily ARCANE_EDELWOOD_PLANKS;

   private static Builder familyBuilder(Block baseBlock) {
      Builder builder = new Builder(baseBlock);
      BlockFamily family = (BlockFamily)MAP.put(baseBlock, builder.getFamily());
      if (family != null) {
         throw new IllegalStateException("Duplicate family definition for " + String.valueOf(BuiltInRegistries.BLOCK.getKey(baseBlock)));
      } else {
         return builder;
      }
   }

   public static Stream<BlockFamily> getAllFamilies() {
      return MAP.values().stream();
   }

   static {
      DARKSTONE = familyBuilder((Block)ModBlocks.DARKSTONE.get()).wall((Block)ModBlocks.DARKSTONE_WALL.get()).stairs((Block)ModBlocks.DARKSTONE_STAIRS.get()).slab((Block)ModBlocks.DARKSTONE_SLAB.get()).polished((Block)ModBlocks.POLISHED_DARKSTONE.get()).getFamily();
      POLISHED_DARKSTONE = familyBuilder((Block)ModBlocks.POLISHED_DARKSTONE.get()).wall((Block)ModBlocks.POLISHED_DARKSTONE_WALL.get()).stairs((Block)ModBlocks.POLISHED_DARKSTONE_STAIRS.get()).slab((Block)ModBlocks.POLISHED_DARKSTONE_SLAB.get()).pressurePlate((Block)ModBlocks.POLISHED_DARKSTONE_PRESSURE_PLATE.get()).button((Block)ModBlocks.POLISHED_DARKSTONE_BUTTON.get()).polished((Block)ModBlocks.POLISHED_DARKSTONE_BRICKS.get()).chiseled((Block)ModBlocks.CHISELED_POLISHED_DARKSTONE.get()).getFamily();
      POLISHED_DARKSTONE_BRICKS = familyBuilder((Block)ModBlocks.POLISHED_DARKSTONE_BRICKS.get()).wall((Block)ModBlocks.POLISHED_DARKSTONE_BRICK_WALL.get()).stairs((Block)ModBlocks.POLISHED_DARKSTONE_BRICK_STAIRS.get()).slab((Block)ModBlocks.POLISHED_DARKSTONE_BRICK_SLAB.get()).cracked((Block)ModBlocks.CRACKED_POLISHED_DARKSTONE_BRICKS.get()).getFamily();
      ARCANE_POLISHED_DARKSTONE = familyBuilder((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE.get()).wall((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_WALL.get()).stairs((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_STAIRS.get()).slab((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE_SLAB.get()).chiseled((Block)ModBlocks.CHISELED_ARCANE_POLISHED_DARKSTONE.get()).getFamily();
      SOULLESS_SANDSTONE = familyBuilder((Block)ModBlocks.SOULLESS_SANDSTONE.get()).wall((Block)ModBlocks.SOULLESS_SANDSTONE_WALL.get()).stairs((Block)ModBlocks.SOULLESS_SANDSTONE_STAIRS.get()).slab((Block)ModBlocks.SOULLESS_SANDSTONE_SLAB.get()).cut((Block)ModBlocks.CUT_SOULLESS_SANDSTONE.get()).polished((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get()).dontGenerateRecipe().getFamily();
      CUT_SOULLESS_SANDSTONE = familyBuilder((Block)ModBlocks.CUT_SOULLESS_SANDSTONE.get()).slab((Block)ModBlocks.CUT_SOULLESS_SANDSTONE_SLAB.get()).getFamily();
      POLISHED_SOULLESS_SANDSTONE = familyBuilder((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE.get()).stairs((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE_STAIRS.get()).slab((Block)ModBlocks.POLISHED_SOULLESS_SANDSTONE_SLAB.get()).getFamily();
      FUNGYSS_PLANKS = familyBuilder((Block)ModBlocks.FUNGYSS_PLANKS.get()).button((Block)ModBlocks.FUNGYSS_BUTTON.get()).fence((Block)ModBlocks.FUNGYSS_FENCE.get()).fenceGate((Block)ModBlocks.FUNGYSS_FENCE_GATE.get()).pressurePlate((Block)ModBlocks.FUNGYSS_PRESSURE_PLATE.get()).slab((Block)ModBlocks.FUNGYSS_SLAB.get()).stairs((Block)ModBlocks.FUNGYSS_STAIRS.get()).door((Block)ModBlocks.FUNGYSS_DOOR.get()).trapdoor((Block)ModBlocks.FUNGYSS_TRAPDOOR.get()).recipeGroupPrefix("wooden").recipeUnlockedBy("has_planks").getFamily();
      AURUM_PLANKS = familyBuilder((Block)ModBlocks.AURUM_PLANKS.get()).button((Block)ModBlocks.AURUM_BUTTON.get()).fence((Block)ModBlocks.AURUM_FENCE.get()).fenceGate((Block)ModBlocks.AURUM_FENCE_GATE.get()).pressurePlate((Block)ModBlocks.AURUM_PRESSURE_PLATE.get()).slab((Block)ModBlocks.AURUM_SLAB.get()).stairs((Block)ModBlocks.AURUM_STAIRS.get()).door((Block)ModBlocks.AURUM_DOOR.get()).trapdoor((Block)ModBlocks.AURUM_TRAPDOOR.get()).recipeGroupPrefix("wooden").recipeUnlockedBy("has_planks").getFamily();
      EDELWOOD_PLANKS = familyBuilder((Block)ModBlocks.EDELWOOD_PLANKS.get()).button((Block)ModBlocks.EDELWOOD_BUTTON.get()).fence((Block)ModBlocks.EDELWOOD_FENCE.get()).fenceGate((Block)ModBlocks.EDELWOOD_FENCE_GATE.get()).pressurePlate((Block)ModBlocks.EDELWOOD_PRESSURE_PLATE.get()).slab((Block)ModBlocks.EDELWOOD_SLAB.get()).stairs((Block)ModBlocks.EDELWOOD_STAIRS.get()).door((Block)ModBlocks.EDELWOOD_DOOR.get()).trapdoor((Block)ModBlocks.EDELWOOD_TRAPDOOR.get()).recipeGroupPrefix("wooden").recipeUnlockedBy("has_planks").getFamily();
      ARCANE_EDELWOOD_PLANKS = familyBuilder((Block)ModBlocks.ARCANE_EDELWOOD_PLANKS.get()).door((Block)ModBlocks.ARCANE_EDELWOOD_DOOR.get()).trapdoor((Block)ModBlocks.ARCANE_EDELWOOD_TRAPDOOR.get()).getFamily();
   }
}
