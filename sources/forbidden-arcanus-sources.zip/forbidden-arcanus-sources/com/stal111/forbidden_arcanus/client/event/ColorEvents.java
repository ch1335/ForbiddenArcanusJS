package com.stal111.forbidden_arcanus.client.event;

import com.stal111.forbidden_arcanus.core.init.ModItems;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.world.level.ItemLike;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent.Item;

@EventBusSubscriber({Dist.CLIENT})
public class ColorEvents {
   @SubscribeEvent
   public static void onRenderTooltipColor(Item event) {
      event.register((stack, tintIndex) -> {
         return tintIndex > 0 ? -1 : DyedItemColor.getOrDefault(stack, -6265536);
      }, new ItemLike[]{(ItemLike)ModItems.MORTEM_HELMET.get(), (ItemLike)ModItems.MORTEM_CHESTPLATE.get(), (ItemLike)ModItems.MORTEM_LEGGINGS.get(), (ItemLike)ModItems.MORTEM_BOOTS.get()});
   }
}
