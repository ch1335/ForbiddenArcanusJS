package com.stal111.forbidden_arcanus.client.event;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.model.AbstractForbiddenomiconModel;
import com.stal111.forbidden_arcanus.client.model.DarkTraderModel;
import com.stal111.forbidden_arcanus.client.model.FAModelLayers;
import com.stal111.forbidden_arcanus.client.model.LostSoulModel;
import com.stal111.forbidden_arcanus.client.model.MagicCircleModel;
import com.stal111.forbidden_arcanus.client.model.QuantumInjectorModel;
import com.stal111.forbidden_arcanus.client.model.QuantumLightDoorModel;
import com.stal111.forbidden_arcanus.client.model.UtremJarSoulsModel;
import com.stal111.forbidden_arcanus.client.renderer.block.BlackHoleRenderer;
import com.stal111.forbidden_arcanus.client.renderer.block.ObsidianSkullRenderer;
import com.stal111.forbidden_arcanus.common.entity.ModBoat;
import net.minecraft.client.model.BoatModel;
import net.minecraft.client.model.ChestBoatModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.EntityRenderersEvent.RegisterLayerDefinitions;

@EventBusSubscriber(
   value = {Dist.CLIENT},
   bus = Bus.MOD
)
public class EntityRendererEvents {
   @SubscribeEvent
   public static void onRegisterLayers(RegisterLayerDefinitions event) {
      event.registerLayerDefinition(BlackHoleRenderer.BLACK_HOLE_LAYER, BlackHoleRenderer::createHoleLayer);
      event.registerLayerDefinition(BlackHoleRenderer.BLACK_HOLE_AURA_LAYER, BlackHoleRenderer::createAuraLayer);
      event.registerLayerDefinition(MagicCircleModel.OUTER_RING_LAYER, MagicCircleModel::createLayer);
      event.registerLayerDefinition(MagicCircleModel.INNER_RING_LAYER, MagicCircleModel::createLayer);
      event.registerLayerDefinition(MagicCircleModel.VALID_RITUAL_INDICATOR, MagicCircleModel::createLayer);
      event.registerLayerDefinition(LostSoulModel.LAYER_LOCATION, LostSoulModel::createBodyLayer);
      event.registerLayerDefinition(DarkTraderModel.LAYER_LOCATION, DarkTraderModel::createBodyLayer);
      event.registerLayerDefinition(QuantumLightDoorModel.LAYER_LOCATION, QuantumLightDoorModel::createLayer);
      event.registerLayerDefinition(UtremJarSoulsModel.LAYER_LOCATION, UtremJarSoulsModel::createBodyLayer);
      event.registerLayerDefinition(QuantumInjectorModel.LAYER_LOCATION, QuantumInjectorModel::createBodyLayer);
      event.registerLayerDefinition(FAModelLayers.OBSIDIAN_SKULL_LAYER, ObsidianSkullRenderer::createObsidianSkullLayer);
      event.registerLayerDefinition(FAModelLayers.DETAILED_OBSIDIAN_SKULL_LAYER, ObsidianSkullRenderer::createDetailedObsidianSkullLayer);
      event.registerLayerDefinition(AbstractForbiddenomiconModel.LAYER_LOCATION, AbstractForbiddenomiconModel::createBodyLayer);
      ModBoat.Type[] var1 = ModBoat.Type.values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         ModBoat.Type type = var1[var3];
         event.registerLayerDefinition(new ModelLayerLocation(ForbiddenArcanus.location(type.getModelLocation()), "main"), BoatModel::createBodyModel);
         event.registerLayerDefinition(new ModelLayerLocation(ForbiddenArcanus.location(type.getChestModelLocation()), "main"), ChestBoatModel::createBodyModel);
      }

   }
}
