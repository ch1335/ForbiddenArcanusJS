package com.stal111.forbidden_arcanus.client.event;

import com.mojang.datafixers.util.Either;
import com.stal111.forbidden_arcanus.client.tooltip.CapacityBucketTooltip;
import com.stal111.forbidden_arcanus.common.item.bucket.CapacityBucket;
import com.stal111.forbidden_arcanus.common.item.modifier.ModifierHelper;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderTooltipEvent.Color;
import net.neoforged.neoforge.client.event.RenderTooltipEvent.GatherComponents;

@EventBusSubscriber({Dist.CLIENT})
public class TooltipEvents {
   @SubscribeEvent
   public static void onRenderTooltipColor(Color event) {
      ItemStack stack = event.getItemStack();
      ModifierHelper.getModifier(stack).map((modifier) -> {
         return modifier.displaySettings().tooltipColor();
      }).ifPresent((color) -> {
         event.setBorderStart((Integer)color.getFirst());
         event.setBorderEnd((Integer)color.getSecond());
      });
   }

   @SubscribeEvent
   public static void onGatherComponents(GatherComponents event) {
      ItemStack stack = event.getItemStack();
      Item var3 = stack.getItem();
      if (var3 instanceof CapacityBucket) {
         CapacityBucket capacityBucket = (CapacityBucket)var3;
         if (capacityBucket.getCapacity(stack) != 0) {
            event.getTooltipElements().add(1, Either.right(new CapacityBucketTooltip(stack, capacityBucket.getFullness(stack), capacityBucket.getCapacity(stack))));
         }
      }

   }
}
