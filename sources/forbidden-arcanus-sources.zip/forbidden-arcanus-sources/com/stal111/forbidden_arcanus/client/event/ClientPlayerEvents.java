package com.stal111.forbidden_arcanus.client.event;

import com.stal111.forbidden_arcanus.client.animation.DracoAurumWingsAnimation;
import net.minecraft.world.entity.player.Player;

public class ClientPlayerEvents {
   private static void startAnimation(Player player, DracoAurumWingsAnimation animation) {
      DracoAurumWingsAnimation[] var2 = DracoAurumWingsAnimation.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         DracoAurumWingsAnimation otherAnimation = var2[var4];
         if (otherAnimation != animation) {
            otherAnimation.getAnimationState(player.getUUID()).stop();
         }
      }

      animation.getAnimationState(player.getUUID()).startIfStopped(player.tickCount);
   }
}
