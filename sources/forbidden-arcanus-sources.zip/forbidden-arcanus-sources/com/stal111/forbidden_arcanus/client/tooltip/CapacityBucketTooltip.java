package com.stal111.forbidden_arcanus.client.tooltip;

import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;

public record CapacityBucketTooltip(ItemStack filledBucket, int fullness, int capacity) implements TooltipComponent {
   public CapacityBucketTooltip(ItemStack filledBucket, int fullness, int capacity) {
      this.filledBucket = filledBucket;
      this.fullness = fullness;
      this.capacity = capacity;
   }

   public ItemStack filledBucket() {
      return this.filledBucket;
   }

   public int fullness() {
      return this.fullness;
   }

   public int capacity() {
      return this.capacity;
   }
}
