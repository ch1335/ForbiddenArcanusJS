package com.stal111.forbidden_arcanus.client.tooltip;

import com.stal111.forbidden_arcanus.core.init.ModItems;
import javax.annotation.Nonnull;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import org.jetbrains.annotations.NotNull;

public class ClientCapacityBucketTooltip implements ClientTooltipComponent {
   private final ItemStack emptyBucket;
   private final ItemStack filledBucket;
   private final int fullness;
   private final int capacity;

   public ClientCapacityBucketTooltip(CapacityBucketTooltip tooltip) {
      this.emptyBucket = new ItemStack((ItemLike)ModItems.EDELWOOD_BUCKET.get());
      this.filledBucket = tooltip.filledBucket();
      this.fullness = tooltip.fullness();
      this.capacity = tooltip.capacity();
   }

   public int getHeight() {
      return 19;
   }

   public int getWidth(@Nonnull Font font) {
      return 2 + 18 * this.capacity;
   }

   public void renderImage(@Nonnull Font font, int mouseX, int mouseY, @NotNull GuiGraphics guiGraphics) {
      for(int i = 1; i <= this.capacity; ++i) {
         guiGraphics.renderFakeItem(i <= this.fullness ? this.filledBucket : this.emptyBucket, (i - 1) * 15 + mouseX, mouseY);
      }

   }
}
