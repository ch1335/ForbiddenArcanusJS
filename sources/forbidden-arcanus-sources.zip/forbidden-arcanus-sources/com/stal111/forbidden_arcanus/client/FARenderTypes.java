package com.stal111.forbidden_arcanus.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import java.util.function.Function;
import net.minecraft.Util;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderStateShard.ShaderStateShard;
import net.minecraft.client.renderer.RenderStateShard.TextureStateShard;
import net.minecraft.client.renderer.RenderType.CompositeState;
import net.minecraft.resources.ResourceLocation;

public class FARenderTypes extends RenderType {
   public static final ShaderStateShard RENDERTYPE_ENTITY_FULLBRIGHT_CUTOUT_SHADER = new ShaderStateShard(FAShaders::getRendertypeEntityFullbrightCutout);
   public static final ShaderStateShard RENDERTYPE_ENTITY_FULLBRIGHT_TRANSLUCENT_SHADER = new ShaderStateShard(FAShaders::getRendertypeEntityFullbrightCutout);
   private static final Function<ResourceLocation, RenderType> ENTITY_FULLBRIGHT_CUTOUT = Util.memoize((resourceLocation) -> {
      TextureStateShard textureStateShard = new TextureStateShard(resourceLocation, false, false);
      CompositeState builder = CompositeState.builder().setShaderState(RENDERTYPE_ENTITY_FULLBRIGHT_CUTOUT_SHADER).setTextureState(textureStateShard).setTransparencyState(NO_TRANSPARENCY).setLightmapState(LIGHTMAP).setOverlayState(OVERLAY).createCompositeState(false);
      return create("forbidden_arcanus:entity_fullbright_cutout", DefaultVertexFormat.NEW_ENTITY, Mode.QUADS, 256, true, true, builder);
   });
   private static final Function<ResourceLocation, RenderType> ENTITY_FULLBRIGHT_TRANSLUCENT = Util.memoize((resourceLocation) -> {
      TextureStateShard textureStateShard = new TextureStateShard(resourceLocation, false, false);
      CompositeState builder = CompositeState.builder().setShaderState(RENDERTYPE_ENTITY_FULLBRIGHT_TRANSLUCENT_SHADER).setTextureState(textureStateShard).setTransparencyState(TRANSLUCENT_TRANSPARENCY).setCullState(NO_CULL).setLightmapState(LIGHTMAP).setOverlayState(OVERLAY).createCompositeState(false);
      return create("forbidden_arcanus:entity_fullbright_translucent", DefaultVertexFormat.NEW_ENTITY, Mode.QUADS, 256, true, true, builder);
   });

   public FARenderTypes(String p_173178_, VertexFormat p_173179_, Mode p_173180_, int p_173181_, boolean p_173182_, boolean p_173183_, Runnable p_173184_, Runnable p_173185_) {
      super(p_173178_, p_173179_, p_173180_, p_173181_, p_173182_, p_173183_, p_173184_, p_173185_);
   }

   public static RenderType entityFullbrightCutout(ResourceLocation resourceLocation) {
      return (RenderType)ENTITY_FULLBRIGHT_CUTOUT.apply(resourceLocation);
   }

   public static RenderType entityFullbrightTranslucent(ResourceLocation resourceLocation) {
      return (RenderType)ENTITY_FULLBRIGHT_TRANSLUCENT.apply(resourceLocation);
   }
}
