package com.stal111.forbidden_arcanus.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import org.jetbrains.annotations.NotNull;

public class FullbrightAnimatedParticle extends TextureSheetParticle {
   private final SpriteSet sprites;

   protected FullbrightAnimatedParticle(ClientLevel level, double x, double y, double z, SpriteSet spriteSet) {
      super(level, x, y, z);
      this.sprites = spriteSet;
      this.setSpriteFromAge(this.sprites);
   }

   public void tick() {
      super.tick();
      this.setSpriteFromAge(this.sprites);
   }

   @NotNull
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_OPAQUE;
   }

   protected int getLightColor(float partialTick) {
      return 240;
   }

   public static record Factory(SpriteSet spriteSet, int lifetime) implements ParticleProvider<SimpleParticleType> {
      public Factory(SpriteSet spriteSet, int lifetime) {
         this.spriteSet = spriteSet;
         this.lifetime = lifetime;
      }

      public Particle createParticle(@NotNull SimpleParticleType type, @NotNull ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
         FullbrightAnimatedParticle particle = new FullbrightAnimatedParticle(level, x, y, z, this.spriteSet);
         particle.setLifetime(this.lifetime);
         return particle;
      }

      public SpriteSet spriteSet() {
         return this.spriteSet;
      }

      public int lifetime() {
         return this.lifetime;
      }
   }
}
