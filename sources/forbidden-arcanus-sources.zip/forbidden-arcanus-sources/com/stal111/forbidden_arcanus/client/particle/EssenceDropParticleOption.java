package com.stal111.forbidden_arcanus.client.particle;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import java.util.List;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ExtraCodecs;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

public record EssenceDropParticleOption(EssenceType type, List<Vector3f> path) implements ParticleOptions {
   public static final MapCodec<EssenceDropParticleOption> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(EssenceType.CODEC.fieldOf("type").forGetter(EssenceDropParticleOption::type), ExtraCodecs.VECTOR3F.listOf().fieldOf("path").forGetter(EssenceDropParticleOption::path)).apply(instance, EssenceDropParticleOption::new);
   });
   public static final StreamCodec<FriendlyByteBuf, EssenceDropParticleOption> STREAM_CODEC;

   public EssenceDropParticleOption(EssenceType type, List<Vector3f> path) {
      this.type = type;
      this.path = path;
   }

   @NotNull
   public ParticleType<?> getType() {
      return this.type.getParticleType();
   }

   public EssenceType type() {
      return this.type;
   }

   public List<Vector3f> path() {
      return this.path;
   }

   static {
      STREAM_CODEC = StreamCodec.composite(EssenceType.STREAM_CODEC, EssenceDropParticleOption::type, ByteBufCodecs.VECTOR3F.apply(ByteBufCodecs.list()), EssenceDropParticleOption::path, EssenceDropParticleOption::new);
   }
}
