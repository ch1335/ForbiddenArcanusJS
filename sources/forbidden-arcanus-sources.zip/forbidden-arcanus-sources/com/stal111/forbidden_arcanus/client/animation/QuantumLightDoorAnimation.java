package com.stal111.forbidden_arcanus.client.animation;

import net.minecraft.client.animation.AnimationChannel;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.animation.AnimationChannel.Interpolations;
import net.minecraft.client.animation.AnimationChannel.Targets;
import net.minecraft.client.animation.AnimationDefinition.Builder;

public class QuantumLightDoorAnimation {
   public static final AnimationDefinition SPAWN;
   public static final AnimationDefinition MODEL_MEDIUM;
   public static final AnimationDefinition MODEL_BIG;

   static {
      SPAWN = Builder.withLength(1.0F).addAnimation("light_door", new AnimationChannel(Targets.SCALE, new Keyframe[]{new Keyframe(0.0F, KeyframeAnimations.scaleVec(0.0D, 0.0D, 0.0D), Interpolations.LINEAR), new Keyframe(0.6F, KeyframeAnimations.scaleVec(1.0D, 1.0D, 1.0D), Interpolations.LINEAR)})).addAnimation("top", new AnimationChannel(Targets.POSITION, new Keyframe[]{new Keyframe(0.32F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), Interpolations.LINEAR), new Keyframe(0.72F, KeyframeAnimations.posVec(0.0F, 20.0F, 0.0F), Interpolations.LINEAR)})).addAnimation("top", new AnimationChannel(Targets.SCALE, new Keyframe[]{new Keyframe(0.2F, KeyframeAnimations.scaleVec(0.0D, 1.0D, 0.0D), Interpolations.LINEAR), new Keyframe(0.52F, KeyframeAnimations.scaleVec(1.0D, 1.0D, 1.0D), Interpolations.LINEAR), new Keyframe(1.0F, KeyframeAnimations.scaleVec(0.0D, 0.0D, 0.0D), Interpolations.LINEAR)})).addAnimation("down", new AnimationChannel(Targets.POSITION, new Keyframe[]{new Keyframe(0.32F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), Interpolations.LINEAR), new Keyframe(0.72F, KeyframeAnimations.posVec(0.0F, -16.0F, 0.0F), Interpolations.LINEAR)})).addAnimation("down", new AnimationChannel(Targets.SCALE, new Keyframe[]{new Keyframe(0.2F, KeyframeAnimations.scaleVec(0.0D, 1.0D, 0.0D), Interpolations.LINEAR), new Keyframe(0.52F, KeyframeAnimations.scaleVec(1.0D, 1.0D, 1.0D), Interpolations.LINEAR), new Keyframe(1.0F, KeyframeAnimations.scaleVec(0.0D, 0.0D, 0.0D), Interpolations.LINEAR)})).addAnimation("inner", new AnimationChannel(Targets.POSITION, new Keyframe[]{new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 2.0F, 0.0F), Interpolations.LINEAR)})).addAnimation("inner", new AnimationChannel(Targets.SCALE, new Keyframe[]{new Keyframe(0.32F, KeyframeAnimations.scaleVec(0.0D, 1.0D, 0.0D), Interpolations.LINEAR), new Keyframe(0.6F, KeyframeAnimations.scaleVec(1.0D, 1.100000023841858D, 1.0D), Interpolations.LINEAR), new Keyframe(0.8F, KeyframeAnimations.scaleVec(0.0D, 1.600000023841858D, 0.0D), Interpolations.LINEAR), new Keyframe(0.88F, KeyframeAnimations.scaleVec(0.0D, 0.0D, 0.0D), Interpolations.LINEAR)})).build();
      MODEL_MEDIUM = Builder.withLength(0.0F).addAnimation("light_door", new AnimationChannel(Targets.POSITION, new Keyframe[]{new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 10.0F, 0.0F), Interpolations.LINEAR)})).addAnimation("light_door", new AnimationChannel(Targets.SCALE, new Keyframe[]{new Keyframe(0.0F, KeyframeAnimations.scaleVec(1.600000023841858D, 1.600000023841858D, 1.600000023841858D), Interpolations.LINEAR)})).build();
      MODEL_BIG = Builder.withLength(0.0F).addAnimation("light_door", new AnimationChannel(Targets.POSITION, new Keyframe[]{new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 16.0F, 0.0F), Interpolations.LINEAR)})).addAnimation("light_door", new AnimationChannel(Targets.SCALE, new Keyframe[]{new Keyframe(0.0F, KeyframeAnimations.scaleVec(2.0D, 2.0D, 2.0D), Interpolations.LINEAR)})).build();
   }
}
