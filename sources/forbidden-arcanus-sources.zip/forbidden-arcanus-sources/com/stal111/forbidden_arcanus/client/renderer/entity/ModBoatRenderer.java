package com.stal111.forbidden_arcanus.client.renderer.entity;

import com.mojang.datafixers.util.Pair;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.entity.CustomBoat;
import com.stal111.forbidden_arcanus.common.entity.ModBoat;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nonnull;
import net.minecraft.client.model.BoatModel;
import net.minecraft.client.model.ChestBoatModel;
import net.minecraft.client.model.ListModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.BoatRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.vehicle.Boat;

public class ModBoatRenderer extends BoatRenderer {
   private final Map<ModBoat.Type, Pair<ResourceLocation, ListModel<Boat>>> boatResources = new HashMap();

   public ModBoatRenderer(Context context, boolean hasChest) {
      super(context, hasChest);
      ModBoat.Type[] var3 = ModBoat.Type.values();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         ModBoat.Type type = var3[var5];
         this.boatResources.put(type, Pair.of(type.getTexture(hasChest), this.createBoatModel(context, type, hasChest)));
      }

   }

   private ListModel<Boat> createBoatModel(Context context, ModBoat.Type type, boolean hasChest) {
      ModelLayerLocation layerLocation = new ModelLayerLocation(ForbiddenArcanus.location(hasChest ? type.getChestModelLocation() : type.getModelLocation()), "main");
      ModelPart part = context.bakeLayer(layerLocation);
      return (ListModel)(hasChest ? new ChestBoatModel(part) : new BoatModel(part));
   }

   @Nonnull
   public Pair<ResourceLocation, ListModel<Boat>> getModelWithLocation(@Nonnull Boat boat) {
      if (boat instanceof CustomBoat) {
         CustomBoat customBoat = (CustomBoat)boat;
         return (Pair)this.boatResources.get(customBoat.getWoodType());
      } else {
         return super.getModelWithLocation(boat);
      }
   }
}
