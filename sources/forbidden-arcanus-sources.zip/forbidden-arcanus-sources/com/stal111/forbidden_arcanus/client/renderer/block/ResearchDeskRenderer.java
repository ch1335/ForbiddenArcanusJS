package com.stal111.forbidden_arcanus.client.renderer.block;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.model.DeskForbiddenomiconModel;
import com.stal111.forbidden_arcanus.common.block.entity.desk.ResearchDeskBlockEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public class ResearchDeskRenderer implements BlockEntityRenderer<ResearchDeskBlockEntity> {
   private static final ResourceLocation TEXTURE = ForbiddenArcanus.location("textures/entity/forbiddenomicon.png");
   private final DeskForbiddenomiconModel<?> model;

   public ResearchDeskRenderer(Context context) {
      this.model = new DeskForbiddenomiconModel(context);
   }

   public void render(@NotNull ResearchDeskBlockEntity blockEntity, float partialTick, @NotNull PoseStack poseStack, @NotNull MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
      poseStack.pushPose();
      poseStack.translate(0.5F, 2.25F, 0.5F);
      poseStack.mulPose(Axis.ZP.rotationDegrees(180.0F));

      float f1;
      for(f1 = blockEntity.rot - blockEntity.oRot; f1 >= 3.1415927F; f1 -= 6.2831855F) {
      }

      while((double)f1 < -3.141592653589793D) {
         f1 += 6.2831855F;
      }

      float rotation = blockEntity.oRot + f1 * partialTick;
      poseStack.mulPose(Axis.YP.rotation(rotation));
      this.model.setupAnim(blockEntity, 0.0F, 0.0F, (float)blockEntity.getTickCount() + partialTick, 0.0F, 0.0F);
      this.model.renderToBuffer(poseStack, bufferSource.getBuffer(this.model.renderType(TEXTURE)), packedLight, packedOverlay);
      poseStack.popPose();
   }
}
