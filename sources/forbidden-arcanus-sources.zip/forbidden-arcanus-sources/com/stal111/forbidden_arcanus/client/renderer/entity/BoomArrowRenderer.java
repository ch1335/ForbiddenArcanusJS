package com.stal111.forbidden_arcanus.client.renderer.entity;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.entity.projectile.BoomArrow;
import javax.annotation.Nonnull;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;

public class BoomArrowRenderer extends ArrowRenderer<BoomArrow> {
   private static final ResourceLocation LOCATION = ForbiddenArcanus.location("textures/entity/projectiles/boom_arrow.png");

   public BoomArrowRenderer(Context context) {
      super(context);
   }

   @Nonnull
   public ResourceLocation getTextureLocation(@Nonnull BoomArrow entity) {
      return LOCATION;
   }
}
