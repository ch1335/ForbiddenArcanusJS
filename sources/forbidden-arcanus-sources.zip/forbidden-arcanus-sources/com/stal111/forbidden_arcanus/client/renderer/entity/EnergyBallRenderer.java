package com.stal111.forbidden_arcanus.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.entity.projectile.EnergyBall;
import javax.annotation.Nonnull;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

public class EnergyBallRenderer extends EntityRenderer<EnergyBall> {
   private static final ResourceLocation LOCATION = ForbiddenArcanus.location("textures/effect/energy_ball.png");

   public EnergyBallRenderer(Context context) {
      super(context);
   }

   public void render(@Nonnull EnergyBall entity, float entityYaw, float partialTicks, @Nonnull PoseStack poseStack, @Nonnull MultiBufferSource buffer, int packedLight) {
      poseStack.pushPose();
      VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityTranslucent(this.getTextureLocation(entity)));
      Matrix4f matrix4f = poseStack.last().pose();
      long t = System.currentTimeMillis() % 6L;
      poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
      vertexConsumer.addVertex(matrix4f, -1.0F, -1.0F, 0.0F).setColor(255, 255, 255, 255).setUv(0.0F, 0.0F + (float)t * 0.25F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight).setNormal(0.0F, 1.0F, 0.0F);
      vertexConsumer.addVertex(matrix4f, -1.0F, 1.0F, 0.0F).setColor(255, 255, 255, 255).setUv(0.0F, 0.0F + (float)t * 0.25F + 0.25F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight).setNormal(0.0F, 1.0F, 0.0F);
      vertexConsumer.addVertex(matrix4f, 1.0F, 1.0F, 0.0F).setColor(255, 255, 255, 255).setUv(1.0F, 0.0F + (float)t * 0.25F + 0.25F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight).setNormal(0.0F, 1.0F, 0.0F);
      vertexConsumer.addVertex(matrix4f, 1.0F, -1.0F, 0.0F).setColor(255, 255, 255, 255).setUv(1.0F, 0.0F + (float)t * 0.25F).setOverlay(OverlayTexture.NO_OVERLAY).setLight(packedLight).setNormal(0.0F, 1.0F, 0.0F);
      poseStack.popPose();
      super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
   }

   @Nonnull
   public ResourceLocation getTextureLocation(@Nonnull EnergyBall entity) {
      return LOCATION;
   }
}
