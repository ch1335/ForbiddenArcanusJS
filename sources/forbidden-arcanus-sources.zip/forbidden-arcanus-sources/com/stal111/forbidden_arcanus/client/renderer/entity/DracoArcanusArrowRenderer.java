package com.stal111.forbidden_arcanus.client.renderer.entity;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.entity.projectile.DracoArcanusArrow;
import javax.annotation.Nonnull;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;

public class DracoArcanusArrowRenderer extends ArrowRenderer<DracoArcanusArrow> {
   private static final ResourceLocation LOCATION = ForbiddenArcanus.location("textures/entity/projectiles/draco_arcanus_arrow.png");

   public DracoArcanusArrowRenderer(Context context) {
      super(context);
   }

   @Nonnull
   public ResourceLocation getTextureLocation(@Nonnull DracoArcanusArrow entity) {
      return LOCATION;
   }
}
