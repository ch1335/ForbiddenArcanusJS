package com.stal111.forbidden_arcanus.client.renderer.entity;

import com.stal111.forbidden_arcanus.client.model.LostSoulModel;
import com.stal111.forbidden_arcanus.common.entity.lostsoul.AbstractLostSoul;
import javax.annotation.Nonnull;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;

public class LostSoulRenderer extends MobRenderer<AbstractLostSoul, LostSoulModel> {
   private final ResourceLocation texture;

   public LostSoulRenderer(Context context, ResourceLocation texture) {
      super(context, new LostSoulModel(context.bakeLayer(LostSoulModel.LAYER_LOCATION)), 0.0F);
      this.texture = texture;
   }

   @Nonnull
   public ResourceLocation getTextureLocation(@Nonnull AbstractLostSoul entity) {
      return this.texture;
   }
}
