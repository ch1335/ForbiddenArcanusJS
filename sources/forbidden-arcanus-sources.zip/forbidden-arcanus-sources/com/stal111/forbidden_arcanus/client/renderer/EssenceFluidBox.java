package com.stal111.forbidden_arcanus.client.renderer;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.AABB;

public class EssenceFluidBox extends FluidBox {
   private final EssenceFluidBox.Type type;

   public EssenceFluidBox(EssenceFluidBox.Type type, AABB boundingBox) {
      super(type.stillTexture, type.flowingTexture, new int[]{255, 255, 255, 255}, boundingBox);
      this.type = type;
   }

   public static EssenceFluidBox create(EssenceFluidBox.Type type, AABB boundingBox) {
      return new EssenceFluidBox(type, boundingBox);
   }

   public EssenceFluidBox.Type getType() {
      return this.type;
   }

   public static enum Type {
      AUREAL(EssenceType.AUREAL, "aureal_still", "aureal_flow"),
      BLOOD(EssenceType.BLOOD, "blood_still", "blood_flow"),
      EXPERIENCE(EssenceType.EXPERIENCE, "experience_still", "experience_flow");

      private final EssenceType essenceType;
      private final ResourceLocation stillTexture;
      private final ResourceLocation flowingTexture;

      private Type(EssenceType param3, String param4, String param5) {
         this.essenceType = type;
         this.stillTexture = ForbiddenArcanus.location("block/liquid/" + still);
         this.flowingTexture = ForbiddenArcanus.location("block/liquid/" + flowing);
      }

      public static EssenceFluidBox.Type byEssenceType(EssenceType type) {
         EssenceFluidBox.Type[] var1 = values();
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            EssenceFluidBox.Type value = var1[var3];
            if (value.essenceType == type) {
               return value;
            }
         }

         return null;
      }

      public EssenceType getEssenceType() {
         return this.essenceType;
      }

      // $FF: synthetic method
      private static EssenceFluidBox.Type[] $values() {
         return new EssenceFluidBox.Type[]{AUREAL, BLOOD, EXPERIENCE};
      }
   }
}
