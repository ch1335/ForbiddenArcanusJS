package com.stal111.forbidden_arcanus.client.renderer.block;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.stal111.forbidden_arcanus.client.model.MagicCircleModel;
import com.stal111.forbidden_arcanus.common.block.entity.forge.HephaestusForgeBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.forge.MagicCircle;
import javax.annotation.Nonnull;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider.Context;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.NotNull;

public class HephaestusForgeRenderer implements BlockEntityRenderer<HephaestusForgeBlockEntity> {
   private final MagicCircleModel magicCircleModel;

   public HephaestusForgeRenderer(Context context) {
      this.magicCircleModel = new MagicCircleModel(context);
   }

   public void render(@Nonnull HephaestusForgeBlockEntity blockEntity, float partialTicks, @Nonnull PoseStack poseStack, @Nonnull MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
      MagicCircle magicCircle = blockEntity.getMagicCircleController().getMagicCircle();
      if (magicCircle != null) {
         magicCircle.render(poseStack, partialTicks, bufferSource, packedLight, this.magicCircleModel, blockEntity.getClientRitualDuration());
      }

      if (blockEntity.hasValidRitualIndicator()) {
         blockEntity.getValidRitualIndicator().render(poseStack, partialTicks, bufferSource, packedLight, this.magicCircleModel.validRitualIndicator());
      }

      ItemStack stack = blockEntity.getClientMainItem();
      if (!stack.isEmpty()) {
         poseStack.pushPose();
         poseStack.translate(0.5D, 1.3D, 0.5D);
         poseStack.mulPose(Axis.YP.rotation(((float)blockEntity.getDisplayCounter() + partialTicks) / 20.0F));
         poseStack.scale(0.5F, 0.5F, 0.5F);
         Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.FIXED, packedLight, packedOverlay, poseStack, bufferSource, blockEntity.getLevel(), 0);
         poseStack.popPose();
      }

   }

   public boolean shouldRenderOffScreen(@Nonnull HephaestusForgeBlockEntity blockEntity) {
      return this.useExpandedRenderBoundingBox(blockEntity);
   }

   @NotNull
   public AABB getRenderBoundingBox(@NotNull HephaestusForgeBlockEntity blockEntity) {
      AABB boundingBox = super.getRenderBoundingBox(blockEntity).expandTowards(0.0D, 1.0D, 0.0D);
      if (this.useExpandedRenderBoundingBox(blockEntity)) {
         boundingBox = boundingBox.inflate(2.5D, 0.0D, 2.5D);
      }

      return boundingBox;
   }

   public boolean useExpandedRenderBoundingBox(HephaestusForgeBlockEntity blockEntity) {
      return blockEntity.getRitualManager().isRitualActive() || blockEntity.hasValidRitualIndicator();
   }
}
