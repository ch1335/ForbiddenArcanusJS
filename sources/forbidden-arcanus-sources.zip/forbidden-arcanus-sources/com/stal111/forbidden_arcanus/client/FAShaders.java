package com.stal111.forbidden_arcanus.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import java.io.IOException;
import javax.annotation.Nullable;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.server.packs.resources.ResourceProvider;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;

@EventBusSubscriber(
   value = {Dist.CLIENT},
   bus = Bus.MOD
)
public class FAShaders {
   @Nullable
   private static ShaderInstance rendertypeEntityFullbrightCutout;
   @Nullable
   private static ShaderInstance rendertypeEntityFullbrightTranslucent;

   @SubscribeEvent
   public static void registerShaders(RegisterShadersEvent event) {
      try {
         ResourceProvider provider = event.getResourceProvider();
         event.registerShader(new ShaderInstance(provider, ForbiddenArcanus.location("rendertype_entity_fullbright_cutout"), DefaultVertexFormat.NEW_ENTITY), (shaderInstance) -> {
            rendertypeEntityFullbrightCutout = shaderInstance;
         });
         event.registerShader(new ShaderInstance(provider, ForbiddenArcanus.location("rendertype_entity_fullbright_translucent"), DefaultVertexFormat.NEW_ENTITY), (shaderInstance) -> {
            rendertypeEntityFullbrightTranslucent = shaderInstance;
         });
      } catch (IOException var2) {
         throw new RuntimeException("Could not reload F&A's shaders!", var2);
      }
   }

   @Nullable
   public static ShaderInstance getRendertypeEntityFullbrightCutout() {
      return rendertypeEntityFullbrightCutout;
   }

   @Nullable
   public static ShaderInstance getRendertypeEntityFullbrightTranslucent() {
      return rendertypeEntityFullbrightCutout;
   }
}
