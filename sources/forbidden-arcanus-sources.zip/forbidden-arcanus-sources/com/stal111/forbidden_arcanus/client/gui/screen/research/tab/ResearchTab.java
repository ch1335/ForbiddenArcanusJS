package com.stal111.forbidden_arcanus.client.gui.screen.research.tab;

import com.mojang.blaze3d.systems.RenderSystem;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.gui.screen.research.KnowledgeWidget;
import com.stal111.forbidden_arcanus.common.research.Knowledge;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.NotNull;

public class ResearchTab extends AbstractTab {
   private static final ResourceLocation BACKGROUND = ForbiddenArcanus.location("textures/gui/research/background.png");
   private static final ResourceLocation BACKGROUND_STARS = ForbiddenArcanus.location("textures/gui/research/background_stars.png");
   private static final ResourceLocation BACKGROUND_STELLAR_DUST_0 = ForbiddenArcanus.location("textures/gui/research/background_stellar_dust_0.png");
   private static final ResourceLocation BACKGROUND_STELLAR_DUST_1 = ForbiddenArcanus.location("textures/gui/research/background_stellar_dust_1.png");
   private final List<KnowledgeWidget> knowledgeWidgets = new ArrayList();
   private double scrollX;
   private double scrollY;
   private int minX = Integer.MAX_VALUE;
   private int minY = Integer.MAX_VALUE;
   private int maxX = Integer.MIN_VALUE;
   private int maxY = Integer.MIN_VALUE;

   public ResearchTab(int width, int height) {
      super(width, height);
   }

   public void init() {
      Iterator var1 = Minecraft.getInstance().level.registryAccess().registryOrThrow(FARegistries.KNOWLEDGE).iterator();

      while(var1.hasNext()) {
         Knowledge entry = (Knowledge)var1.next();
         this.knowledgeWidgets.add(new KnowledgeWidget(entry.displayInfo(), 0, 0));
      }

   }

   public void tick() {
      Iterator var1 = this.knowledgeWidgets.iterator();

      while(var1.hasNext()) {
         KnowledgeWidget widget = (KnowledgeWidget)var1.next();
         widget.tick();
      }

   }

   public void renderBg(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
      int i = Mth.floor(this.scrollX);
      int j = Mth.floor(this.scrollY);
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      guiGraphics.blit(BACKGROUND, 0, 0, (float)(-i) * 0.9F, (float)(-j) * 0.9F, this.getWidth(), this.getHeight(), 512, 512);
      guiGraphics.blit(BACKGROUND_STELLAR_DUST_0, (int)((float)i * 1.15F), (int)((float)j * 1.15F), 0.0F, 0.0F, 512, 512, 512, 512);
      guiGraphics.blit(BACKGROUND_STELLAR_DUST_1, (int)((float)(this.getWidth() / 2) + (float)i * 1.15F), (int)((float)(this.getHeight() / 2) + (float)j * 1.15F), 0.0F, 0.0F, 512, 512, 512, 512);
      guiGraphics.blit(BACKGROUND_STARS, 0, 0, (float)(-i) * 1.35F, (float)(-j) * 1.35F, this.getWidth(), this.getHeight(), 512, 512);
      RenderSystem.disableBlend();
      Iterator var7 = this.knowledgeWidgets.iterator();

      while(var7.hasNext()) {
         KnowledgeWidget widget = (KnowledgeWidget)var7.next();
         widget.render(guiGraphics, mouseX, mouseY, partialTick);
      }

   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      this.scroll(dragX, dragY);
      return false;
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      this.scroll(scrollX * 16.0D, scrollY * 16.0D);
      return false;
   }

   public void scroll(double dragX, double dragY) {
      this.scrollX += dragX;
      this.scrollY += dragY;
      Iterator var5 = this.knowledgeWidgets.iterator();

      while(var5.hasNext()) {
         KnowledgeWidget widget = (KnowledgeWidget)var5.next();
         widget.setX(widget.calculatePositionX((int)this.scrollX));
         widget.setY(widget.calculatePositionY((int)this.scrollY));
      }

   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      Iterator var6 = this.knowledgeWidgets.iterator();

      KnowledgeWidget widget;
      do {
         if (!var6.hasNext()) {
            return false;
         }

         widget = (KnowledgeWidget)var6.next();
      } while(!widget.mouseClicked(mouseX, mouseY, button));

      return true;
   }
}
