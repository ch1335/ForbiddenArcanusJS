package com.stal111.forbidden_arcanus.client.gui.label;

import net.minecraft.world.phys.EntityHitResult;

public interface EntityFlyingLabel extends FlyingLabel<EntityHitResult> {
}
