package com.stal111.forbidden_arcanus.client.gui.screen.research.tab;

import net.minecraft.client.gui.GuiGraphics;
import org.jetbrains.annotations.NotNull;

public abstract class AbstractTab {
   private final int width;
   private final int height;

   protected AbstractTab(int width, int height) {
      this.width = width;
      this.height = height;
   }

   public abstract void init();

   public void tick() {
   }

   public abstract void renderBg(@NotNull GuiGraphics var1, float var2, int var3, int var4);

   public abstract boolean mouseDragged(double var1, double var3, int var5, double var6, double var8);

   public abstract boolean mouseScrolled(double var1, double var3, double var5, double var7);

   public abstract boolean mouseClicked(double var1, double var3, int var5);

   public int getWidth() {
      return this.width;
   }

   public int getHeight() {
      return this.height;
   }
}
