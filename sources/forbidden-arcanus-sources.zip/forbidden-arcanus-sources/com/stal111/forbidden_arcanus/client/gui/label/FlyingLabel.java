package com.stal111.forbidden_arcanus.client.gui.label;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;

public interface FlyingLabel<R extends HitResult> {
   void render(GuiGraphics var1, ItemStack var2, DeltaTracker var3, int var4, int var5, R var6);
}
