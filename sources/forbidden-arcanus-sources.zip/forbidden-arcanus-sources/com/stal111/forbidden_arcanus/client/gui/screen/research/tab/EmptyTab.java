package com.stal111.forbidden_arcanus.client.gui.screen.research.tab;

import net.minecraft.client.gui.GuiGraphics;
import org.jetbrains.annotations.NotNull;

public class EmptyTab extends AbstractTab {
   public EmptyTab(int width, int height) {
      super(width, height);
   }

   public void init() {
   }

   public void renderBg(@NotNull GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      return false;
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      return false;
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      return false;
   }
}
