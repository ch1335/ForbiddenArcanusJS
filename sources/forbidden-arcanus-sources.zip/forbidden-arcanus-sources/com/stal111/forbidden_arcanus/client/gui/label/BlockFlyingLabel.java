package com.stal111.forbidden_arcanus.client.gui.label;

import net.minecraft.world.phys.BlockHitResult;

public interface BlockFlyingLabel extends FlyingLabel<BlockHitResult> {
}
