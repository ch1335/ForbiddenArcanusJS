package com.stal111.forbidden_arcanus;

import com.stal111.forbidden_arcanus.common.event.CapabilityEvents;
import com.stal111.forbidden_arcanus.common.event.DeathEvents;
import com.stal111.forbidden_arcanus.common.event.PlayerEvents;
import com.stal111.forbidden_arcanus.common.event.RecipeEvents;
import com.stal111.forbidden_arcanus.common.event.RegistryEvents;
import com.stal111.forbidden_arcanus.common.event.SpawnPlacementEvents;
import com.stal111.forbidden_arcanus.common.event.TooltipEvents;
import com.stal111.forbidden_arcanus.common.event.TradeEvents;
import com.stal111.forbidden_arcanus.common.network.NetworkEvents;
import net.neoforged.bus.api.IEventBus;
import net.valhelsia.valhelsia_core.core.neoforge.ValhelsiaForgeEventHandler;

public final class ModEventHandler extends ValhelsiaForgeEventHandler {
   public ModEventHandler(IEventBus modEventBus) {
      super(modEventBus);
   }

   public void registerModEvents(IEventBus eventBus) {
      eventBus.register(new SpawnPlacementEvents());
      eventBus.register(new RegistryEvents());
      eventBus.register(new NetworkEvents());
      eventBus.register(new CapabilityEvents());
   }

   public void registerForgeEvents(IEventBus eventBus) {
      eventBus.register(new DeathEvents());
      eventBus.register(new TooltipEvents());
      eventBus.register(new TradeEvents());
      eventBus.register(new PlayerEvents());
      eventBus.register(new RecipeEvents());
   }
}
