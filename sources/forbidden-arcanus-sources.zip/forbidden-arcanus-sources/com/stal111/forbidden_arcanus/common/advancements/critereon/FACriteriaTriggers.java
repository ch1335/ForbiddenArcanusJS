package com.stal111.forbidden_arcanus.common.advancements.critereon;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import java.util.function.Supplier;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.core.registries.Registries;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class FACriteriaTriggers {
   public static final MappedRegistryHelper<CriterionTrigger<?>> HELPER;
   public static final Supplier<RitualCompletedTrigger> RITUAL;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.TRIGGER_TYPE);
      RITUAL = HELPER.register("ritual_completed", RitualCompletedTrigger::new);
   }
}
