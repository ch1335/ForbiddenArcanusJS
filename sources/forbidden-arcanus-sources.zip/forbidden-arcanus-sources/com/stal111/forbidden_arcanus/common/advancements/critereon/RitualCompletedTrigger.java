package com.stal111.forbidden_arcanus.common.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger.SimpleInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

public class RitualCompletedTrigger extends SimpleCriterionTrigger<RitualCompletedTrigger.TriggerInstance> {
   public void trigger(ServerPlayer player, ResourceLocation ritualId) {
      this.trigger(player, (instance) -> {
         return instance.matches(ritualId);
      });
   }

   public Codec<RitualCompletedTrigger.TriggerInstance> codec() {
      return RitualCompletedTrigger.TriggerInstance.CODEC;
   }

   public static record TriggerInstance(Optional<ContextAwarePredicate> player, ResourceLocation ritualId) implements SimpleInstance {
      public static final Codec<RitualCompletedTrigger.TriggerInstance> CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(EntityPredicate.ADVANCEMENT_CODEC.optionalFieldOf("player").forGetter(RitualCompletedTrigger.TriggerInstance::player), ResourceLocation.CODEC.fieldOf("recipe_id").forGetter(RitualCompletedTrigger.TriggerInstance::ritualId)).apply(instance, RitualCompletedTrigger.TriggerInstance::new);
      });

      public TriggerInstance(Optional<ContextAwarePredicate> player, ResourceLocation ritualId) {
         this.player = player;
         this.ritualId = ritualId;
      }

      boolean matches(ResourceLocation ritualId) {
         return this.ritualId.equals(ritualId);
      }

      public Optional<ContextAwarePredicate> player() {
         return this.player;
      }

      public ResourceLocation ritualId() {
         return this.ritualId;
      }
   }
}
