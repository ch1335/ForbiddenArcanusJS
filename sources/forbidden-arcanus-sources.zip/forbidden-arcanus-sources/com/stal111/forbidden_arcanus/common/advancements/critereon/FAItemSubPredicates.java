package com.stal111.forbidden_arcanus.common.advancements.critereon;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import java.util.function.Supplier;
import net.minecraft.advancements.critereon.ItemSubPredicate.Type;
import net.minecraft.core.registries.Registries;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class FAItemSubPredicates {
   public static final MappedRegistryHelper<Type<?>> HELPER;
   public static final Supplier<Type<ItemModifierPredicate>> MODIFIER;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.ITEM_SUB_PREDICATE_TYPE);
      MODIFIER = HELPER.register("modifier", () -> {
         return new Type(ItemModifierPredicate.CODEC);
      });
   }
}
