package com.stal111.forbidden_arcanus.common.research.icon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

public final class TextureIcon implements IconProvider {
   public static final Codec<TextureIcon> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ResourceLocation.CODEC.fieldOf("texture").forGetter((info) -> {
         return info.texture;
      })).apply(instance, TextureIcon::new);
   });
   private final ResourceLocation texture;

   public TextureIcon(ResourceLocation texture) {
      this.texture = texture;
   }

   public void renderIcon(GuiGraphics guiGraphics, int x, int y) {
      guiGraphics.blit(this.texture, x, y, 0.0F, 0.0F, 16, 16, 16, 16);
   }
}
