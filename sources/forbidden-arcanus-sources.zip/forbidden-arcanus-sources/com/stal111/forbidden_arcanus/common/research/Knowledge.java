package com.stal111.forbidden_arcanus.common.research;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.resources.RegistryFileCodec;

public record Knowledge(DisplayInfo displayInfo, List<Holder<Knowledge>> parents) {
   public static final Codec<Knowledge> DIRECT_CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(DisplayInfo.CODEC.fieldOf("display_info").forGetter(Knowledge::displayInfo), Codec.lazyInitialized(() -> {
         return CODEC;
      }).listOf().fieldOf("requirements").forGetter(Knowledge::parents)).apply(instance, Knowledge::new);
   });
   public static final Codec<Holder<Knowledge>> CODEC;

   public Knowledge(DisplayInfo displayInfo, List<Holder<Knowledge>> parents) {
      this.displayInfo = displayInfo;
      this.parents = parents;
   }

   public DisplayInfo displayInfo() {
      return this.displayInfo;
   }

   public List<Holder<Knowledge>> parents() {
      return this.parents;
   }

   static {
      CODEC = RegistryFileCodec.create(FARegistries.KNOWLEDGE, DIRECT_CODEC);
   }
}
