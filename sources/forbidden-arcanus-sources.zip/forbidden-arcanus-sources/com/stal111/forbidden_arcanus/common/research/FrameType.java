package com.stal111.forbidden_arcanus.common.research;

import com.mojang.serialization.Codec;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.StringRepresentable;
import org.jetbrains.annotations.NotNull;

public enum FrameType implements StringRepresentable {
   DEFAULT("default"),
   ADVANCED("advanced"),
   MASTER("master");

   public static final Codec<FrameType> CODEC = StringRepresentable.fromEnum(FrameType::values);
   private final String name;
   private WidgetSprites sprites;

   private FrameType(String param3) {
      this.name = name;
   }

   @NotNull
   public String getSerializedName() {
      return this.name;
   }

   public ResourceLocation getFrameTexture(boolean locked, boolean highlighted) {
      return this.sprites.get(locked, highlighted);
   }

   // $FF: synthetic method
   private static FrameType[] $values() {
      return new FrameType[]{DEFAULT, ADVANCED, MASTER};
   }
}
