package com.stal111.forbidden_arcanus.common.research.icon;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import java.util.function.Function;
import net.minecraft.client.gui.GuiGraphics;

public interface IconProvider {
   Codec<IconProvider> CODEC = Codec.either(ItemIcon.CODEC, TextureIcon.CODEC).xmap((icon) -> {
      return (IconProvider)icon.map(Function.identity(), Function.identity());
   }, (iconProvider) -> {
      if (iconProvider instanceof ItemIcon) {
         ItemIcon itemIcon = (ItemIcon)iconProvider;
         return Either.left(itemIcon);
      } else {
         return Either.right((TextureIcon)iconProvider);
      }
   });

   void renderIcon(GuiGraphics var1, int var2, int var3);
}
