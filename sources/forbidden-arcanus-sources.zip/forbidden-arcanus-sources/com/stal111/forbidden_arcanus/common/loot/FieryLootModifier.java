package com.stal111.forbidden_arcanus.common.loot;

import com.google.common.base.Suppliers;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.function.Supplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemFunction;
import net.minecraft.world.level.storage.loot.functions.SmeltItemFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

public class FieryLootModifier extends LootModifier {
   public static final Supplier<MapCodec<FieryLootModifier>> CODEC = Suppliers.memoize(() -> {
      return RecordCodecBuilder.mapCodec((instance) -> {
         return codecStart(instance).apply(instance, FieryLootModifier::new);
      });
   });
   private final LootItemFunction smeltItemFunction = SmeltItemFunction.smelted().build();

   public FieryLootModifier(LootItemCondition[] conditions) {
      super(conditions);
   }

   @NotNull
   protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, @NotNull LootContext context) {
      ObjectArrayList<ItemStack> list = new ObjectArrayList();
      generatedLoot.forEach((stack) -> {
         list.add((ItemStack)this.smeltItemFunction.apply(stack, context));
      });
      return list;
   }

   @NotNull
   public MapCodec<? extends IGlobalLootModifier> codec() {
      return (MapCodec)CODEC.get();
   }
}
