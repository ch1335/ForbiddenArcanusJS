package com.stal111.forbidden_arcanus.common.loot;

import com.google.common.base.Suppliers;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.util.ModTags;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;

public class MagicalFarmlandLootModifier extends LootModifier {
   public static final Supplier<MapCodec<MagicalFarmlandLootModifier>> CODEC = Suppliers.memoize(() -> {
      return RecordCodecBuilder.mapCodec((instance) -> {
         return codecStart(instance).apply(instance, MagicalFarmlandLootModifier::new);
      });
   });

   public MagicalFarmlandLootModifier(LootItemCondition[] conditions) {
      super(conditions);
   }

   @Nonnull
   protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
      BlockState state = (BlockState)context.getParamOrNull(LootContextParams.BLOCK_STATE);
      Vec3 pos = (Vec3)context.getParamOrNull(LootContextParams.ORIGIN);
      Level level = context.getLevel();
      if (state != null && pos != null && state.is(BlockTags.CROPS) && !state.is(ModTags.Blocks.MAGICAL_FARMLAND_BLACKLISTED)) {
         if (level.getBlockState(BlockPos.containing(pos).below()).is((Block)ModBlocks.MAGICAL_FARMLAND.get())) {
            Block var7 = state.getBlock();
            if (var7 instanceof CropBlock) {
               CropBlock crop = (CropBlock)var7;
               if (!crop.isMaxAge(state)) {
                  return generatedLoot;
               }
            }

            generatedLoot.addAll(generatedLoot.stream().filter((stack) -> {
               return !stack.is(ModTags.Items.MAGICAL_FARMLAND_BLACKLISTED);
            }).toList());
         }

         return generatedLoot;
      } else {
         return generatedLoot;
      }
   }

   public MapCodec<? extends IGlobalLootModifier> codec() {
      return (MapCodec)CODEC.get();
   }
}
