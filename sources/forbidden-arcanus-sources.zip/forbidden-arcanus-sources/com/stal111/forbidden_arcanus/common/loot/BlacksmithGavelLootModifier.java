package com.stal111.forbidden_arcanus.common.loot;

import com.google.common.base.Suppliers;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.util.ModTags;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.function.Supplier;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.Tags.Blocks;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

public class BlacksmithGavelLootModifier extends LootModifier {
   public static final Supplier<MapCodec<BlacksmithGavelLootModifier>> CODEC = Suppliers.memoize(() -> {
      return RecordCodecBuilder.mapCodec((instance) -> {
         return codecStart(instance).apply(instance, BlacksmithGavelLootModifier::new);
      });
   });

   public BlacksmithGavelLootModifier(LootItemCondition[] conditions) {
      super(conditions);
   }

   @NotNull
   protected ObjectArrayList<ItemStack> doApply(@NotNull ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
      BlockState state = (BlockState)context.getParamOrNull(LootContextParams.BLOCK_STATE);
      ItemStack stack = (ItemStack)context.getParamOrNull(LootContextParams.TOOL);
      if (state != null && stack != null) {
         if (this.isValidGavel(stack, context.getLevel().registryAccess()) && state.is(Blocks.ORES) && !state.is(ModTags.Blocks.BLACKSMITH_GAVEL_UNAFFECTED)) {
            generatedLoot.addAll(generatedLoot.clone());
         }

         return generatedLoot;
      } else {
         return generatedLoot;
      }
   }

   private boolean isValidGavel(ItemStack stack, Provider lookupProvider) {
      return stack.is(ModTags.Items.BLACKSMITH_GAVEL) && stack.getEnchantmentLevel(lookupProvider.holderOrThrow(Enchantments.SILK_TOUCH)) == 0;
   }

   @NotNull
   public MapCodec<? extends IGlobalLootModifier> codec() {
      return (MapCodec)CODEC.get();
   }
}
