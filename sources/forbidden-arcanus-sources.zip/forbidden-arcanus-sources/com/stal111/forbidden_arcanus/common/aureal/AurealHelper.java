package com.stal111.forbidden_arcanus.common.aureal;

import com.stal111.forbidden_arcanus.common.entity.lostsoul.AbstractLostSoul;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;

public class AurealHelper {
   public static boolean canEntityBeAureal(LivingEntity livingEntity) {
      MobCategory category = livingEntity.getType().getCategory();
      if (livingEntity instanceof AbstractLostSoul) {
         return false;
      } else {
         return category == MobCategory.AMBIENT || category == MobCategory.CREATURE;
      }
   }
}
