package com.stal111.forbidden_arcanus.common.event;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.entity.attribute.FAAttributes;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.item.QuantumCatcherItem;
import com.stal111.forbidden_arcanus.common.item.modifier.SoulboundInventory;
import com.stal111.forbidden_arcanus.common.network.clientbound.UpdateEssencePayload;
import com.stal111.forbidden_arcanus.core.config.BlockConfig;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.other.ModAttachmentTypes;
import java.util.Iterator;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerRespawnEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.neoforged.neoforge.event.tick.PlayerTickEvent.Pre;
import net.neoforged.neoforge.network.PacketDistributor;

public class PlayerEvents {
   @SubscribeEvent
   public void onPlayerTick(Pre event) {
      Player player = event.getEntity();
      if (player.onClimbable() && !player.isCrouching() && player.getInBlockState().is((Block)ModBlocks.EDELWOOD_LADDER.get())) {
         double multiplier = (Double)BlockConfig.EDELWOOD_LADDER_SPEED.get();
         if (!player.horizontalCollision) {
            multiplier *= 0.30000001192092896D;
         }

         player.move(MoverType.SELF, new Vec3(0.0D, player.getDeltaMovement().y * multiplier, 0.0D));
      }

      if (!player.level().isClientSide() && player.level().getGameTime() % 100L == 0L) {
         EssenceHelper.getEssenceProvider(player).ifPresent((provider) -> {
            provider.updateAmount(EssenceType.AUREAL, (value) -> {
               return value + (int)player.getAttributeValue(FAAttributes.AUREAL_REGENERATION);
            });
         });
      }

   }

   @SubscribeEvent
   public void onEntityInteract(EntityInteract event) {
      Player player = event.getEntity();
      ItemStack stack = event.getItemStack();
      Entity var6 = event.getTarget();
      if (var6 instanceof LivingEntity) {
         LivingEntity entity = (LivingEntity)var6;
         Item var7 = stack.getItem();
         if (var7 instanceof QuantumCatcherItem) {
            QuantumCatcherItem item = (QuantumCatcherItem)var7;
            event.setCancellationResult(item.onEntityInteract(stack, player, entity));
            event.setCanceled(true);
         }
      }

   }

   @SubscribeEvent
   public void onPlayerJoinLevel(EntityJoinLevelEvent event) {
      Entity entity = event.getEntity();
      if (entity instanceof ServerPlayer) {
         ServerPlayer player = (ServerPlayer)entity;
         EssenceHelper.getEssenceProvider(player).ifPresent((provider) -> {
            PacketDistributor.sendToPlayer(player, new UpdateEssencePayload(provider.asStorage(EssenceType.AUREAL)), new CustomPacketPayload[0]);
         });
      }

   }

   @SubscribeEvent
   public void onPlayerRespawn(PlayerRespawnEvent event) {
      Player var3 = event.getEntity();
      if (var3 instanceof ServerPlayer) {
         ServerPlayer player = (ServerPlayer)var3;
         SoulboundInventory inventory = (SoulboundInventory)player.getData(ModAttachmentTypes.SOULBOUND_INVENTORY);
         Iterator var4 = inventory.entries().iterator();

         while(var4.hasNext()) {
            SoulboundInventory.Entry entry = (SoulboundInventory.Entry)var4.next();
            player.getInventory().setItem(entry.slot(), entry.stack());
         }
      }

   }
}
