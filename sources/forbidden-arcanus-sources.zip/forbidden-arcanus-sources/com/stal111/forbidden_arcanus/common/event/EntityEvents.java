package com.stal111.forbidden_arcanus.common.event;

import com.stal111.forbidden_arcanus.common.entity.attribute.FAAttributes;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.item.BloodTestTubeItem;
import com.stal111.forbidden_arcanus.common.item.modifier.ModifierHelper;
import com.stal111.forbidden_arcanus.common.item.modifier.SoulboundInventory;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.core.init.other.ModAttachmentTypes;
import com.stal111.forbidden_arcanus.data.ModItemModifiers;
import com.stal111.forbidden_arcanus.util.ModTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeModificationEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent.Post;

@EventBusSubscriber
public class EntityEvents {
   @SubscribeEvent
   public static void onAttributeModification(EntityAttributeModificationEvent event) {
      event.add(EntityType.PLAYER, FAAttributes.AUREAL_REGENERATION);
   }

   @SubscribeEvent
   public static void onEntityDamage(Post event) {
      DamageSource source = event.getSource();
      if (source.is(DamageTypes.PLAYER_ATTACK)) {
         Entity var3 = source.getEntity();
         if (var3 instanceof Player) {
            Player player = (Player)var3;
            if (!event.getEntity().getType().is(ModTags.EntityTypes.TEST_TUBE_BLACKLISTED)) {
               if (player.getOffhandItem().is(ModItems.TEST_TUBE)) {
                  player.setItemInHand(InteractionHand.OFF_HAND, ((BloodTestTubeItem)ModItems.BLOOD_TEST_TUBE.get()).getDefaultInstance());
               }

               ItemStack stack = player.getOffhandItem();
               if (stack.getItem() instanceof BloodTestTubeItem) {
                  EssenceHelper.getEssenceStorage(stack).ifPresent((storage) -> {
                     storage.addEssence(stack, (int)(20.0F * event.getNewDamage()));
                  });
               }
            }
         }
      }

   }

   @SubscribeEvent
   public static void onLivingDeath(LivingDeathEvent event) {
      LivingEntity var2 = event.getEntity();
      if (var2 instanceof ServerPlayer) {
         ServerPlayer player = (ServerPlayer)var2;
         SoulboundInventory inventory = SoulboundInventory.create();

         for(int i = 0; i < player.getInventory().getContainerSize(); ++i) {
            ItemStack stack = player.getInventory().getItem(i);
            if (ModifierHelper.hasModifier(stack, player.level().holderOrThrow(ModItemModifiers.SOULBOUND))) {
               inventory.add(i, stack);
               player.getInventory().setItem(i, ItemStack.EMPTY);
            }
         }

         player.setData(ModAttachmentTypes.SOULBOUND_INVENTORY, inventory);
      }

   }
}
