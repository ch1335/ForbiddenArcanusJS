package com.stal111.forbidden_arcanus.common.event;

import com.stal111.forbidden_arcanus.core.init.ModItems;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.Tags.Items;
import net.neoforged.neoforge.event.brewing.RegisterBrewingRecipesEvent;

public class RecipeEvents {
   @SubscribeEvent
   public void onRegisterBrewingRecipes(RegisterBrewingRecipesEvent event) {
      event.getBuilder().addRecipe(Ingredient.of(new ItemLike[]{(ItemLike)ModItems.AUREAL_BOTTLE.get()}), Ingredient.of(Items.GUNPOWDERS), new ItemStack((ItemLike)ModItems.SPLASH_AUREAL_BOTTLE.get()));
   }
}
