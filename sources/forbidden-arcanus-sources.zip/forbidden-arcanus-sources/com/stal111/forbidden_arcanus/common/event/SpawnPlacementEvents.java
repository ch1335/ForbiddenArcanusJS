package com.stal111.forbidden_arcanus.common.event;

import com.stal111.forbidden_arcanus.common.entity.lostsoul.AbstractLostSoul;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.Operation;

public class SpawnPlacementEvents {
   @SubscribeEvent
   public void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
      event.register((EntityType)ModEntities.LOST_SOUL.get(), SpawnPlacementTypes.ON_GROUND, Types.MOTION_BLOCKING_NO_LEAVES, AbstractLostSoul::canSpawn, Operation.REPLACE);
      event.register((EntityType)ModEntities.CORRUPT_LOST_SOUL.get(), SpawnPlacementTypes.ON_GROUND, Types.MOTION_BLOCKING_NO_LEAVES, AbstractLostSoul::canSpawn, Operation.REPLACE);
      event.register((EntityType)ModEntities.ENCHANTED_LOST_SOUL.get(), SpawnPlacementTypes.ON_GROUND, Types.MOTION_BLOCKING_NO_LEAVES, AbstractLostSoul::canSpawn, Operation.REPLACE);
   }
}
