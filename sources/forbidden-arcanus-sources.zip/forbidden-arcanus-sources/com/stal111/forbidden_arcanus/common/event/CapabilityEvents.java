package com.stal111.forbidden_arcanus.common.event;

import com.stal111.forbidden_arcanus.common.essence.EntityEssenceProvider;
import com.stal111.forbidden_arcanus.common.essence.EssenceProvider;
import com.stal111.forbidden_arcanus.common.item.bucket.CapacityBucketFluidHandler;
import com.stal111.forbidden_arcanus.common.item.bucket.CapacityFluidBucket;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities.FluidHandler;

public class CapabilityEvents {
   @SubscribeEvent
   public void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
      event.registerEntity(EssenceProvider.ENTITY_ESSENCE, EntityType.PLAYER, (player, context) -> {
         return new EntityEssenceProvider(player);
      });
      event.registerItem(FluidHandler.ITEM, (stack, context) -> {
         Item patt0$temp = stack.getItem();
         if (patt0$temp instanceof CapacityFluidBucket) {
            CapacityFluidBucket fluidHandler = (CapacityFluidBucket)patt0$temp;
            return new CapacityBucketFluidHandler(fluidHandler, stack);
         } else {
            return null;
         }
      }, new ItemLike[]{ModItems.EDELWOOD_BUCKET, ModItems.EDELWOOD_WATER_BUCKET, ModItems.EDELWOOD_LAVA_BUCKET, ModItems.EDELWOOD_MILK_BUCKET});
   }
}
