package com.stal111.forbidden_arcanus.common.event;

import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerHelper;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerTarget;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import net.minecraft.ChatFormatting;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

public class TooltipEvents {
   private static final ChatFormatting DESCRIPTION_FORMAT;
   private static final Component ENHANCER_COMPONENT;

   @SubscribeEvent
   public void onItemTooltip(ItemTooltipEvent event) {
      ItemStack stack = event.getItemStack();
      List<Component> tooltip = event.getToolTip();
      boolean advanced = event.getFlags().isAdvanced();
      EssenceHelper.getEssenceStorage(stack).ifPresent((essenceStorage) -> {
         if (essenceStorage.showInTooltip()) {
            essenceStorage.addToTooltip(event.getContext(), (component) -> {
               this.expandTooltip(advanced, tooltip, essenceStorage.value().type().getComponent().copy().withStyle(ChatFormatting.GRAY).append(component));
            }, event.getFlags());
         }

      });
      Provider registries = event.getContext().registries();
      if (registries != null) {
         EnhancerHelper.getEnhancer(registries, stack).ifPresent((definition) -> {
            this.expandTooltip(advanced, tooltip, ENHANCER_COMPONENT);
            this.expandTooltip(advanced, tooltip, CommonComponents.EMPTY);
            Iterator var4 = definition.description().entrySet().iterator();

            while(var4.hasNext()) {
               Entry<EnhancerTarget, Component> test = (Entry)var4.next();
               this.expandTooltip(advanced, tooltip, ((EnhancerTarget)test.getKey()).getTitle());
               this.expandTooltip(advanced, tooltip, Component.literal(" ").append((Component)test.getValue()).withStyle(DESCRIPTION_FORMAT));
            }

         });
      }
   }

   private void expandTooltip(boolean advanced, List<Component> tooltip, Component addition) {
      if (advanced) {
         tooltip.add(tooltip.size() - 2, addition);
      } else {
         tooltip.add(addition);
      }

   }

   static {
      DESCRIPTION_FORMAT = ChatFormatting.BLUE;
      ENHANCER_COMPONENT = Component.translatable("item.forbidden_arcanus.enhancer").withStyle(ChatFormatting.GOLD);
   }
}
