package com.stal111.forbidden_arcanus.common.entity;

import net.minecraft.world.entity.AnimationState;

public interface QuantumLightDoorAnimationProvider {
   AnimationState getAnimationState();
}
