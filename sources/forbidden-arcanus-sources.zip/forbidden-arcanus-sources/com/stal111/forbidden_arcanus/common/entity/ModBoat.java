package com.stal111.forbidden_arcanus.common.entity;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class ModBoat extends Boat implements CustomBoat {
   private static final EntityDataAccessor<Integer> DATA_ID_WOOD_TYPE;

   public ModBoat(EntityType<? extends Boat> entityType, Level level) {
      super(entityType, level);
   }

   public ModBoat(Level level, double x, double y, double z) {
      this((EntityType)ModEntities.BOAT.get(), level);
      this.setPos(x, y, z);
      this.xo = x;
      this.yo = y;
      this.zo = z;
   }

   protected void defineSynchedData(@NotNull Builder builder) {
      super.defineSynchedData(builder);
      builder.define(DATA_ID_WOOD_TYPE, 0);
   }

   protected void readAdditionalSaveData(@Nonnull CompoundTag tag) {
      super.readAdditionalSaveData(tag);
      if (tag.contains("Type", 8)) {
         this.setWoodType(ModBoat.Type.byName(tag.getString("Type")));
      }

   }

   protected void addAdditionalSaveData(@Nonnull CompoundTag tag) {
      super.addAdditionalSaveData(tag);
      tag.putString("Type", this.getWoodType().getSerializedName());
   }

   @Nonnull
   public Item getDropItem() {
      return (Item)this.getWoodType().getBoatItem().get();
   }

   public ModBoat.Type getWoodType() {
      return ModBoat.Type.byId((Integer)this.entityData.get(DATA_ID_WOOD_TYPE));
   }

   public void setWoodType(ModBoat.Type type) {
      this.entityData.set(DATA_ID_WOOD_TYPE, type.ordinal());
   }

   @Nonnull
   protected Component getTypeName() {
      return EntityType.BOAT.getDescription();
   }

   static {
      DATA_ID_WOOD_TYPE = SynchedEntityData.defineId(ModBoat.class, EntityDataSerializers.INT);
   }

   public static enum Type implements StringRepresentable {
      AURUM("aurum", ModItems.AURUM_BOAT, ModItems.AURUM_CHEST_BOAT),
      EDELWOOD("edelwood", ModItems.EDELWOOD_BOAT, ModItems.EDELWOOD_CHEST_BOAT);

      private final String name;
      private final Supplier<BoatItem> boatItem;
      private final Supplier<BoatItem> chestBoatItem;

      private Type(String param3, Supplier<BoatItem> param4, Supplier<BoatItem> param5) {
         this.name = name;
         this.boatItem = boatItem;
         this.chestBoatItem = chestBoatItem;
      }

      @Nonnull
      public String getSerializedName() {
         return this.name;
      }

      public Supplier<BoatItem> getBoatItem() {
         return this.boatItem;
      }

      public Supplier<BoatItem> getChestBoatItem() {
         return this.chestBoatItem;
      }

      public ResourceLocation getTexture(boolean hasChest) {
         return hasChest ? ForbiddenArcanus.location("textures/entity/chest_boat/" + this.name + ".png") : ForbiddenArcanus.location("textures/entity/boat/" + this.name + ".png");
      }

      public String getModelLocation() {
         return "boat/" + this.name;
      }

      public String getChestModelLocation() {
         return "chest_boat/" + this.name;
      }

      public static ModBoat.Type byId(int id) {
         ModBoat.Type[] values = values();
         if (id < 0 || id >= values.length) {
            id = 0;
         }

         return values[id];
      }

      public static ModBoat.Type byName(String name) {
         ModBoat.Type[] values = values();
         ModBoat.Type[] var2 = values;
         int var3 = values.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            ModBoat.Type value = var2[var4];
            if (value.getSerializedName().equals(name)) {
               return value;
            }
         }

         return values[0];
      }

      // $FF: synthetic method
      private static ModBoat.Type[] $values() {
         return new ModBoat.Type[]{AURUM, EDELWOOD};
      }
   }
}
