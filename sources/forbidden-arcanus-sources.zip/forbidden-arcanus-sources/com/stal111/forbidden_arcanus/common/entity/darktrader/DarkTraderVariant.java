package com.stal111.forbidden_arcanus.common.entity.darktrader;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.minecraft.resources.ResourceLocation;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryClass;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public record DarkTraderVariant(ResourceLocation texture) implements RegistryClass {
   public static final MappedRegistryHelper<DarkTraderVariant> HELPER;
   public static final RegistryEntry<DarkTraderVariant, DarkTraderVariant> BROOK;
   public static final RegistryEntry<DarkTraderVariant, DarkTraderVariant> IDRIL;
   public static final RegistryEntry<DarkTraderVariant, DarkTraderVariant> HOHENHEIM;

   public DarkTraderVariant(ResourceLocation texture) {
      this.texture = texture;
   }

   private static RegistryEntry<DarkTraderVariant, DarkTraderVariant> register(String name) {
      return HELPER.register(name, () -> {
         return new DarkTraderVariant(ForbiddenArcanus.location("textures/entity/dark_trader/" + name + ".png"));
      });
   }

   public ResourceLocation texture() {
      return this.texture;
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.DARK_TRADER_VARIANT);
      BROOK = register("brook");
      IDRIL = register("idril");
      HOHENHEIM = register("hohenheim");
   }
}
