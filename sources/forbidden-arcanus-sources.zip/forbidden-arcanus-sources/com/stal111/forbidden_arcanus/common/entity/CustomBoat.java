package com.stal111.forbidden_arcanus.common.entity;

public interface CustomBoat {
   void setWoodType(ModBoat.Type var1);

   ModBoat.Type getWoodType();
}
