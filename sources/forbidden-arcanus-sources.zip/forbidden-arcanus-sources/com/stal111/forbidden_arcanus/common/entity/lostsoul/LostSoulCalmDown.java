package com.stal111.forbidden_arcanus.common.entity.lostsoul;

import com.google.common.collect.ImmutableMap;
import java.util.function.Function;
import javax.annotation.Nonnull;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.behavior.Behavior;
import net.minecraft.world.entity.ai.behavior.VillagerPanicTrigger;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.level.pathfinder.PathType;

public class LostSoulCalmDown extends Behavior<AbstractLostSoul> {
   private static final int SAFE_DISTANCE_FROM_DANGER = 15;
   private static final Function<AbstractLostSoul, Boolean> CLOSE_TO_ENTITY_THAT_HURT = (lostSoul) -> {
      return lostSoul.getBrain().getMemory(MemoryModuleType.HURT_BY_ENTITY).filter((entity) -> {
         return entity.distanceTo(lostSoul) <= 15.0F;
      }).isPresent();
   };

   public LostSoulCalmDown() {
      super(ImmutableMap.of());
   }

   protected void start(@Nonnull ServerLevel level, @Nonnull AbstractLostSoul entity, long gameTime) {
      boolean flag = VillagerPanicTrigger.isHurt(entity) || VillagerPanicTrigger.hasHostile(entity) || (Boolean)CLOSE_TO_ENTITY_THAT_HURT.apply(entity);
      if (!flag) {
         entity.getBrain().eraseMemory(MemoryModuleType.HURT_BY);
         entity.getBrain().eraseMemory(MemoryModuleType.HURT_BY_ENTITY);
         entity.getEntityData().set(AbstractLostSoul.DATA_SCARED, false);
         entity.setPathfindingMalus(PathType.BLOCKED, 16.0F);
         entity.getBrain().useDefaultActivity();
      }

   }
}
