package com.stal111.forbidden_arcanus.common.entity.villager;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.entity.npc.VillagerTrades.ItemListing;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.neoforged.neoforge.common.BasicItemListing;

public final class FAVillagerTrades {
   public static final FAVillagerTrades INSTANCE = new FAVillagerTrades();
   private final List<ItemListing> wanderingTraderTrades = new ArrayList();

   private FAVillagerTrades() {
      this.buildTrades();
   }

   private void buildTrades() {
      this.addBasicTrade(3, new ItemStack((ItemLike)ModBlocks.FUNGYSS.get()), 5, 1);
      this.addBasicTrade(5, new ItemStack((ItemLike)ModBlocks.AURUM_SAPLING.get()), 8, 1);
      this.addBasicTrade(6, new ItemStack((ItemLike)ModBlocks.GROWING_EDELWOOD.get()), 8, 1);
      this.addBasicTrade(2, new ItemStack((ItemLike)ModBlocks.YELLOW_ORCHID.get()), 6, 1);
      this.addBasicTrade(18, new ItemStack((ItemLike)ModItems.ARTISAN_RELIC.get()), 2, 1);
   }

   private void addBasicTrade(int emeralds, ItemStack stack, int maxTrades, int experience) {
      this.wanderingTraderTrades.add(new BasicItemListing(emeralds, stack, maxTrades, experience));
   }

   public List<ItemListing> getWanderingTraderTrades() {
      return this.wanderingTraderTrades;
   }
}
