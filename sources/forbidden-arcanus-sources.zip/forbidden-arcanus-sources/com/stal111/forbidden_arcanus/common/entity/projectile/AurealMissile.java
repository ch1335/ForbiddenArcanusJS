package com.stal111.forbidden_arcanus.common.entity.projectile;

import com.stal111.forbidden_arcanus.common.network.clientbound.SpawnParticlePayload;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.core.init.ModParticles;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.event.EventHooks;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;

public class AurealMissile extends Projectile {
   public double accelerationPower = 0.03D;

   public AurealMissile(EntityType<? extends AurealMissile> entityType, Level level) {
      super(entityType, level);
   }

   public AurealMissile(LivingEntity livingEntity, Level level, double x, double y, double z) {
      super((EntityType)ModEntities.AUREAL_MISSILE.get(), level);
      this.setOwner(livingEntity);
      this.setPos(x, y, z);
   }

   protected void defineSynchedData(@NotNull Builder builder) {
   }

   public void tick() {
      super.tick();
      HitResult hitresult = ProjectileUtil.getHitResultOnMoveVector(this, (x$0) -> {
         return this.canHitEntity(x$0);
      });
      if (hitresult.getType() != Type.MISS && !EventHooks.onProjectileImpact(this, hitresult)) {
         this.hitTargetOrDeflectSelf(hitresult);
      }

      this.checkInsideBlocks();
      Vec3 vec3 = this.getDeltaMovement();
      double d0 = this.getX() + vec3.x;
      double d1 = this.getY() + vec3.y;
      double d2 = this.getZ() + vec3.z;
      ProjectileUtil.rotateTowardsMovement(this, 0.2F);
      float f;
      if (!this.isInWater()) {
         f = this.getInertia();
      } else {
         for(int i = 0; i < 4; ++i) {
            this.level().addParticle(ParticleTypes.BUBBLE, d0 - vec3.x * 0.25D, d1 - vec3.y * 0.25D, d2 - vec3.z * 0.25D, vec3.x, vec3.y, vec3.z);
         }

         f = this.getLiquidInertia();
      }

      this.setDeltaMovement(vec3.add(vec3.normalize().scale(this.accelerationPower)).scale((double)f));
      if (this.tickCount % 4 == 0) {
         this.level().addParticle((ParticleOptions)ModParticles.MAGIC_GLINT.get(), this.getX(), this.getY() + 0.2D, this.getZ(), 0.0D, 0.0D, 0.0D);
      }

      this.setPos(d0, d1, d2);
   }

   protected void onHitEntity(@NotNull EntityHitResult result) {
      super.onHitEntity(result);
      Level var3 = this.level();
      if (var3 instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)var3;
         Entity entity = result.getEntity();
         Entity var5 = this.getOwner();
         if (var5 instanceof LivingEntity) {
            LivingEntity owner = (LivingEntity)var5;
            owner.setLastHurtMob(entity);
         }

         DamageSource damagesource = this.damageSources().magic();
         if (entity.hurt(damagesource, 5.0F) && entity instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity)entity;
            EnchantmentHelper.doPostAttackEffects(serverLevel, livingEntity, damagesource);
         }
      }

   }

   protected void onHit(@NotNull HitResult result) {
      super.onHit(result);
      Level var3 = this.level();
      if (var3 instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)var3;
         PacketDistributor.sendToPlayersTrackingChunk(serverLevel, new ChunkPos(this.blockPosition()), new SpawnParticlePayload(this.getX(), this.getY(), this.getZ(), 2), new CustomPacketPayload[0]);
         this.discard();
      }

   }

   public boolean hurt(@NotNull DamageSource source, float amount) {
      return false;
   }

   public float getLightLevelDependentMagicValue() {
      return 1.0F;
   }

   private float getInertia() {
      return 0.95F;
   }

   private float getLiquidInertia() {
      return 0.8F;
   }
}
