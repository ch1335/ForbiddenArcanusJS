package com.stal111.forbidden_arcanus.common.entity.projectile;

import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.core.init.ModSounds;
import javax.annotation.Nonnull;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.event.EventHooks;
import org.jetbrains.annotations.NotNull;

public class EnergyBall extends Projectile {
   private static final float MOTION_FACTOR = 0.95F;
   private static final float MOTION_FACTOR_WATER = 0.8F;
   private static final float ROTATION_SPEED = 0.2F;
   private static final float DAMAGE_AMOUNT = 5.5F;
   private LivingEntity shootingEntity;
   private int ticksAlive;
   private double accelerationX;
   private double accelerationY;
   private double accelerationZ;

   public EnergyBall(Level level, LivingEntity shooter, double accelX, double accelY, double accelZ) {
      super((EntityType)ModEntities.ENERGY_BALL.get(), level);
      this.shootingEntity = shooter;
      this.moveTo(shooter.getX(), shooter.getY(), shooter.getZ(), shooter.yRotO, shooter.xRotO);
      this.setPos(this.getX(), this.getY(), this.getZ());
      this.setDeltaMovement(Vec3.ZERO);
      double d0 = (double)Mth.sqrt((float)(accelX * accelX + accelY * accelY + accelZ * accelZ));
      this.accelerationX = accelX / d0 * 0.1D;
      this.accelerationY = accelY / d0 * 0.1D;
      this.accelerationZ = accelZ / d0 * 0.1D;
   }

   public EnergyBall(EntityType<? extends EnergyBall> entityType, Level level) {
      super(entityType, level);
   }

   protected void defineSynchedData(@NotNull Builder builder) {
   }

   public boolean shouldRenderAtSqrDistance(double distance) {
      double d0 = this.getBoundingBox().getSize() * 4.0D;
      if (Double.isNaN(d0)) {
         d0 = 4.0D;
      }

      d0 *= 64.0D;
      return distance < d0 * d0;
   }

   public void tick() {
      super.tick();
      HitResult hitResult = ProjectileUtil.getHitResultOnMoveVector(this, (entity) -> {
         return entity.isAlive() && entity != this.shootingEntity;
      });
      if (hitResult.getType() != Type.MISS && !EventHooks.onProjectileImpact(this, hitResult)) {
         this.onImpact(hitResult);
      }

      Vec3 vec3 = this.getDeltaMovement();
      this.setPos(this.getX() + vec3.x, this.getY() + (vec3.y - 0.01D), this.getZ() + vec3.z);
      ProjectileUtil.rotateTowardsMovement(this, 0.2F);
      float motionFactor = 0.95F;
      if (this.isInWater()) {
         for(int i = 0; i < 4; ++i) {
            this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - vec3.x * 0.25D, this.getY() - vec3.y * 0.25D, this.getZ() - vec3.z * 0.25D, vec3.x, vec3.y, vec3.z);
         }

         motionFactor = 0.8F;
      }

      this.setDeltaMovement(vec3.add(this.accelerationX, this.accelerationY, this.accelerationZ).scale((double)motionFactor));
      this.setPos(this.getX(), this.getY(), this.getZ());
   }

   public void onImpact(HitResult result) {
      if (!this.level().isClientSide()) {
         if (result instanceof EntityHitResult) {
            EntityHitResult entityHitResult = (EntityHitResult)result;
            Entity entity = entityHitResult.getEntity();
            entity.hurt(this.level().damageSources().indirectMagic(this, this.shootingEntity), 5.5F);
            LightningBolt lightningBolt = new LightningBolt(EntityType.LIGHTNING_BOLT, this.level());
            lightningBolt.setPos(entity.getX(), entity.getY(), entity.getZ());
            this.level().addFreshEntity(lightningBolt);
         } else if (result.getType() == Type.BLOCK) {
            Vec3 vec3 = result.getLocation();
            this.level().playSound((Player)null, vec3.x(), vec3.y(), vec3.z(), (SoundEvent)ModSounds.ENERGY_BALL_HIT.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
         }

         this.discard();
      }
   }

   protected void addAdditionalSaveData(CompoundTag tag) {
      Vec3 vec3 = this.getDeltaMovement();
      tag.put("direction", this.newDoubleList(new double[]{vec3.x, vec3.y, vec3.z}));
      tag.put("power", this.newDoubleList(new double[]{this.accelerationX, this.accelerationY, this.accelerationZ}));
      tag.putInt("life", this.ticksAlive);
   }

   public void readAdditionalSaveData(CompoundTag tag) {
      ListTag list;
      if (tag.contains("power", 9)) {
         list = tag.getList("power", 6);
         if (list.size() == 3) {
            this.accelerationX = list.getDouble(0);
            this.accelerationY = list.getDouble(1);
            this.accelerationZ = list.getDouble(2);
         }
      }

      this.ticksAlive = tag.getInt("life");
      if (tag.contains("direction", 9) && tag.getList("direction", 6).size() == 3) {
         list = tag.getList("direction", 6);
         this.setDeltaMovement(list.getDouble(0), list.getDouble(1), list.getDouble(2));
      } else {
         this.discard();
      }

   }

   public boolean isPickable() {
      return true;
   }

   public float getPickRadius() {
      return 1.0F;
   }

   public boolean hurt(@Nonnull DamageSource source, float amount) {
      if (this.isInvulnerableTo(source)) {
         return false;
      } else {
         this.markHurt();
         if (source.getEntity() != null) {
            Vec3 vec3 = source.getEntity().getLookAngle();
            this.setDeltaMovement(vec3);
            this.accelerationX = vec3.x * 0.1D;
            this.accelerationY = vec3.y * 0.1D;
            this.accelerationZ = vec3.z * 0.1D;
            Entity var5 = source.getEntity();
            if (var5 instanceof LivingEntity) {
               LivingEntity livingEntity = (LivingEntity)var5;
               this.shootingEntity = livingEntity;
            }

            return true;
         } else {
            return false;
         }
      }
   }

   public float getLightLevelDependentMagicValue() {
      return 1.0F;
   }
}
