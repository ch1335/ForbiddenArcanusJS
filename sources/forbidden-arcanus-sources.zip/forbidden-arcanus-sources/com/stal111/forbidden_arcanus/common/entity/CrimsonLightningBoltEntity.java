package com.stal111.forbidden_arcanus.common.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;

public class CrimsonLightningBoltEntity extends LightningBolt {
   public CrimsonLightningBoltEntity(EntityType<? extends LightningBolt> entityType, Level world) {
      super(entityType, world);
   }
}
