package com.stal111.forbidden_arcanus.common.inventory;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

public class InputSlot extends SlotItemHandler {
   private final EssenceType inputType;

   public InputSlot(IItemHandler itemHandler, int index, int xPosition, int yPosition, EssenceType inputType) {
      super(itemHandler, index, xPosition, yPosition);
      this.inputType = inputType;
   }

   public EssenceType getInputType() {
      return this.inputType;
   }
}
