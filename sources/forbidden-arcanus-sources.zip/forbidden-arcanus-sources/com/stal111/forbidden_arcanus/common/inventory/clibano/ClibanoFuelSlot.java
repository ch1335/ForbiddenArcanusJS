package com.stal111.forbidden_arcanus.common.inventory.clibano;

import javax.annotation.Nonnull;
import net.minecraft.world.inventory.FurnaceFuelSlot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

public class ClibanoFuelSlot extends SlotItemHandler {
   private final ClibanoMenu menu;

   public ClibanoFuelSlot(ClibanoMenu menu, IItemHandler itemHandler, int index, int x, int y) {
      super(itemHandler, index, x, y);
      this.menu = menu;
   }

   public boolean mayPlace(@Nonnull ItemStack stack) {
      return this.menu.isFuel(stack) || FurnaceFuelSlot.isBucket(stack);
   }

   public int getMaxStackSize(@Nonnull ItemStack stack) {
      return FurnaceFuelSlot.isBucket(stack) ? 1 : super.getMaxStackSize(stack);
   }
}
