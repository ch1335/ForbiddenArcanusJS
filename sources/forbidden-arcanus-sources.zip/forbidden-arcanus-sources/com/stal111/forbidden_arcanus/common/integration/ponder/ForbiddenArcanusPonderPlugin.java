package com.stal111.forbidden_arcanus.common.integration.ponder;

import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.createmod.ponder.foundation.PonderIndex;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public class ForbiddenArcanusPonderPlugin implements PonderPlugin {
   public static void register() {
      PonderIndex.addPlugin(new ForbiddenArcanusPonderPlugin());
   }

   @NotNull
   public String getModId() {
      return "forbidden_arcanus";
   }

   public void registerScenes(@NotNull PonderSceneRegistrationHelper<ResourceLocation> helper) {
      FAPonderScenes.register(helper);
   }
}
