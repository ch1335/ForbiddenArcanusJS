package com.stal111.forbidden_arcanus.common.integration.hephaestus_forge;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssencesDefinition;
import java.util.Arrays;
import java.util.List;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.helpers.IGuiHelper;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public record EssenceInfo(IDrawableStatic drawable, EssenceType type, int posX, int posY) {
   private static final ResourceLocation TEXTURE = ForbiddenArcanus.location("textures/gui/jei/hephaestus_forge/essences.png");
   private static final int SIZE = 12;

   public EssenceInfo(IDrawableStatic drawable, EssenceType type, int posX, int posY) {
      this.drawable = drawable;
      this.type = type;
      this.posX = posX;
      this.posY = posY;
   }

   public static List<EssenceInfo> create(IGuiHelper helper, int startX, int startY) {
      return Arrays.stream(EssenceType.values()).map((type) -> {
         int index = type.ordinal();
         IDrawableStatic drawable = helper.drawableBuilder(TEXTURE, index * 13, 0, 12, 12).setTextureSize(64, 16).build();
         return new EssenceInfo(drawable, type, startX + 16 * index, startY);
      }).toList();
   }

   public boolean shouldDisplayTooltip(double mouseX, double mouseY) {
      return mouseX >= (double)this.posX && mouseY >= (double)this.posY && mouseX <= (double)(this.posX + 12) && mouseY <= (double)(this.posY + 12);
   }

   public Component getTooltip(EssencesDefinition definition) {
      return Component.translatable("jei.forbidden_arcanus.hephaestus_smithing.required_essence", new Object[]{this.type.getComponent(), definition.get(this.type)});
   }

   public IDrawableStatic drawable() {
      return this.drawable;
   }

   public EssenceType type() {
      return this.type;
   }

   public int posX() {
      return this.posX;
   }

   public int posY() {
      return this.posY;
   }
}
