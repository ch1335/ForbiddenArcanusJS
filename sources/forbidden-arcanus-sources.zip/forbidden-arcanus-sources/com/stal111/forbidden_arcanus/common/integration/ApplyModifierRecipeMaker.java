package com.stal111.forbidden_arcanus.common.integration;

import com.stal111.forbidden_arcanus.common.item.crafting.ApplyModifierRecipe;
import com.stal111.forbidden_arcanus.core.init.ModRecipeSerializers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmithingRecipe;
import net.minecraft.world.item.crafting.SmithingRecipeInput;
import net.minecraft.world.item.crafting.SmithingTransformRecipe;

public class ApplyModifierRecipeMaker {
   public static List<RecipeHolder<SmithingRecipe>> getRecipes() {
      ClientLevel level = Minecraft.getInstance().level;
      if (level == null) {
         return Collections.emptyList();
      } else {
         List<RecipeHolder<SmithingRecipe>> recipes = new ArrayList();
         List<RecipeHolder<ApplyModifierRecipe>> applyModifierRecipes = level.getRecipeManager().getAllRecipesFor(RecipeType.SMITHING).stream().filter((upgradeRecipe) -> {
            return ((SmithingRecipe)upgradeRecipe.value()).getSerializer() == ModRecipeSerializers.APPLY_MODIFIER.get();
         }).map((holder) -> {
            return new RecipeHolder(holder.id(), (ApplyModifierRecipe)holder.value());
         }).toList();
         Iterator var3 = BuiltInRegistries.ITEM.iterator();

         while(var3.hasNext()) {
            Item item = (Item)var3.next();
            ItemStack stack = item.getDefaultInstance();
            Iterator var6 = applyModifierRecipes.iterator();

            while(var6.hasNext()) {
               RecipeHolder<ApplyModifierRecipe> recipeHolder = (RecipeHolder)var6.next();
               ApplyModifierRecipe recipe = (ApplyModifierRecipe)recipeHolder.value();
               SmithingRecipeInput input = new SmithingRecipeInput(recipe.template().getItems()[0], stack, recipe.addition().getItems()[0]);
               if (recipe.matches((SmithingRecipeInput)input, level)) {
                  recipes.add(createRecipe(recipeHolder, input, stack, level.registryAccess()));
               }
            }
         }

         return recipes;
      }
   }

   private static RecipeHolder<SmithingRecipe> createRecipe(RecipeHolder<ApplyModifierRecipe> recipeHolder, SmithingRecipeInput input, ItemStack stack, RegistryAccess registryAccess) {
      ResourceLocation var10000 = recipeHolder.id();
      String var10001 = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
      ResourceLocation id = var10000.withSuffix("_" + var10001);
      ApplyModifierRecipe recipe = (ApplyModifierRecipe)recipeHolder.value();
      return new RecipeHolder(id, new SmithingTransformRecipe(recipe.template(), Ingredient.of(new ItemStack[]{stack}), recipe.addition(), recipe.assemble((SmithingRecipeInput)input, registryAccess)));
   }
}
