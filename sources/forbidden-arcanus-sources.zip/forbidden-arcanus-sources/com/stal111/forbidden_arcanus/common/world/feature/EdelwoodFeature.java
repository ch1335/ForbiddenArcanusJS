package com.stal111.forbidden_arcanus.common.world.feature;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.common.block.CarvedEdelwoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.EdelwoodBranchBlock;
import com.stal111.forbidden_arcanus.common.block.EdelwoodLogBlock;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

public class EdelwoodFeature extends Feature<NoneFeatureConfiguration> {
   private static final BlockState EDELWOOD_LOG;
   private static final BlockState CARVED_EDELWOOD_LOG;
   private static final BlockState EDELWOOD_BRANCH;
   private static final int MAX_HEIGHT = 4;
   private static final int MIN_HEIGHT = 2;

   public EdelwoodFeature(Codec<NoneFeatureConfiguration> codec) {
      super(codec);
   }

   public boolean place(@Nonnull FeaturePlaceContext<NoneFeatureConfiguration> context) {
      WorldGenLevel level = context.level();
      BlockPos pos = context.origin();
      MutableBlockPos mutable = pos.mutable();
      RandomSource random = context.random();
      if (level.isEmptyBlock(pos.above()) && level.getBlockState(pos.below()).is(BlockTags.DIRT)) {
         int height = 1;

         Direction direction;
         for(direction = Direction.from2DDataValue(random.nextInt(4)); level.isEmptyBlock(mutable) && height <= 4; ++height) {
            if (height == 4 || !level.isEmptyBlock(mutable.above()) || height >= 2 && random.nextDouble() < 0.35D) {
               level.setBlock(mutable, (BlockState)CARVED_EDELWOOD_LOG.setValue(BlockStateProperties.HORIZONTAL_FACING, direction), 2);
               break;
            }

            level.setBlock(mutable, EDELWOOD_LOG, 2);
            mutable.move(Direction.UP);
         }

         if (height >= 3 && random.nextDouble() < 0.65D) {
            direction = direction.getClockWise();
            mutable.move(Direction.DOWN).move(direction);
            level.setBlock(mutable, (BlockState)EDELWOOD_BRANCH.setValue(BlockStateProperties.HORIZONTAL_FACING, direction), 2);
            mutable.move(direction.getOpposite(), 2);
            level.setBlock(mutable, (BlockState)EDELWOOD_BRANCH.setValue(BlockStateProperties.HORIZONTAL_FACING, direction.getOpposite()), 2);
         }

         return true;
      } else {
         return false;
      }
   }

   static {
      EDELWOOD_LOG = ((EdelwoodLogBlock)ModBlocks.EDELWOOD_LOG.get()).defaultBlockState();
      CARVED_EDELWOOD_LOG = (BlockState)((CarvedEdelwoodLogBlock)ModBlocks.CARVED_EDELWOOD_LOG.get()).defaultBlockState().setValue(ModBlockStateProperties.LEAVES, true);
      EDELWOOD_BRANCH = ((EdelwoodBranchBlock)ModBlocks.EDELWOOD_BRANCH.get()).defaultBlockState();
   }
}
