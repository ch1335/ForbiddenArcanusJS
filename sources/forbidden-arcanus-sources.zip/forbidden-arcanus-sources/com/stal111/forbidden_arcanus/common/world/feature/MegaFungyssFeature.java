package com.stal111.forbidden_arcanus.common.world.feature;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.common.world.feature.config.BigFungyssFeatureConfig;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.HugeMushroomBlock;
import net.minecraft.world.level.block.PipeBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.neoforged.neoforge.common.Tags.Blocks;

public class MegaFungyssFeature extends Feature<BigFungyssFeatureConfig> {
   public MegaFungyssFeature(Codec<BigFungyssFeatureConfig> codec) {
      super(codec);
   }

   private int getRandomHeight(RandomSource random) {
      return random.nextInt(4) + 11;
   }

   private boolean canGenerate(LevelAccessor world, ChunkGenerator generator, BlockPos pos, int height, MutableBlockPos mutable) {
      if (pos.getY() >= 1 && pos.getY() + height + 1 < generator.getGenDepth()) {
         if (!world.getBlockState(pos.below()).is(Blocks.STONES)) {
            return false;
         } else {
            for(int i = 0; i <= height; ++i) {
               BlockState state = world.getBlockState(mutable.setWithOffset(pos, 0, i, 0));
               if (!state.isAir()) {
                  return false;
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public boolean place(@Nonnull FeaturePlaceContext<BigFungyssFeatureConfig> context) {
      LevelAccessor level = context.level();
      BlockPos pos = context.origin();
      RandomSource rand = context.random();
      int height = this.getRandomHeight(context.random());
      MutableBlockPos mutable = new MutableBlockPos();
      if (!this.canGenerate(level, context.chunkGenerator(), pos, height, mutable)) {
         return false;
      } else {
         this.placeStem(level, rand, pos, height, mutable, (BigFungyssFeatureConfig)context.config());
         this.placeCap(level, rand, pos, height, mutable, (BigFungyssFeatureConfig)context.config());
         return true;
      }
   }

   private void placeStem(LevelAccessor world, RandomSource random, BlockPos pos, int height, MutableBlockPos mutable, BigFungyssFeatureConfig config) {
      for(int i = 0; i < height; ++i) {
         this.placeStemBlock(world, config.stemProvider.getState(random, pos), mutable, pos, 0, i, 0);
         this.placeStemBlock(world, config.stemProvider.getState(random, pos), mutable, pos, 1, i, 0);
         this.placeStemBlock(world, config.stemProvider.getState(random, pos), mutable, pos, 1, i, 1);
         this.placeStemBlock(world, config.stemProvider.getState(random, pos), mutable, pos, 0, i, 1);
      }

   }

   private void placeStemBlock(LevelAccessor world, BlockState state, MutableBlockPos mutable, BlockPos pos, int xOffset, int yOffset, int zOffset) {
      mutable.set(pos).move(xOffset, yOffset, zOffset);
      if (!world.getBlockState(mutable).isSolidRender(world, mutable)) {
         this.setBlock(world, mutable, state);
      }

   }

   private void placeCap(LevelAccessor world, RandomSource random, BlockPos pos, int height, MutableBlockPos mutable, BigFungyssFeatureConfig config) {
      int i;
      for(i = height - 3; i <= height; ++i) {
         int distanceToStem = 2;

         int xOffset;
         int zOffset;
         for(xOffset = -distanceToStem; xOffset <= distanceToStem + 1; ++xOffset) {
            for(zOffset = -distanceToStem; zOffset <= distanceToStem + 1; ++zOffset) {
               boolean flag1 = i >= height && xOffset != -distanceToStem && xOffset != distanceToStem + 1 && zOffset != -distanceToStem && zOffset != distanceToStem + 1;
               boolean flag2 = i < height && (xOffset == -distanceToStem || xOffset == distanceToStem + 1 || zOffset == -distanceToStem || zOffset == distanceToStem + 1) && (xOffset != -distanceToStem && xOffset != distanceToStem + 1 || zOffset != -distanceToStem && zOffset != distanceToStem + 1);
               if (flag1 || flag2) {
                  mutable.setWithOffset(pos, xOffset, i, zOffset);
                  boolean moveDown = xOffset == -1 && zOffset == -1 || xOffset == -1 && zOffset == 2 || xOffset == 2 && zOffset == -1 || xOffset == 2 && zOffset == 2;
                  if (moveDown) {
                     mutable.move(Direction.DOWN);
                  }

                  BlockState state = i == height && !moveDown ? config.capProvider.getState(random, pos) : (BlockState)((BlockState)((BlockState)((BlockState)config.capProvider.getState(random, pos).setValue(HugeMushroomBlock.WEST, xOffset < 0)).setValue(HugeMushroomBlock.EAST, xOffset > 0)).setValue(HugeMushroomBlock.NORTH, zOffset < 0)).setValue(HugeMushroomBlock.SOUTH, zOffset > 0);
                  this.setBlock(world, mutable, state);
               }
            }
         }

         for(xOffset = 0; xOffset <= 1; ++xOffset) {
            for(zOffset = 0; zOffset <= 1; ++zOffset) {
               Direction[] var16 = Direction.values();
               int var17 = var16.length;

               for(int var18 = 0; var18 < var17; ++var18) {
                  Direction direction = var16[var18];
                  if (direction.getAxis() != Axis.Y) {
                     mutable.setWithOffset(pos, xOffset, height - 5, zOffset);
                     mutable.move(direction);
                     if (world.getBlockState(mutable).isAir()) {
                        this.setBlock(world, mutable, (BlockState)config.capProvider.getState(random, pos).setValue((Property)PipeBlock.PROPERTY_BY_DIRECTION.get(direction.getOpposite()), false));
                     }
                  }
               }
            }
         }
      }

      i = random.nextInt(2);
      int zOffset = random.nextInt(2);
      if (config.variant == 0) {
         this.placeSmallCap(world, random, pos, height, mutable, i, zOffset, config);
         this.placeSmallCap(world, random, pos, height - 2, mutable, i == 0 ? 1 : 0, zOffset == 0 ? 1 : 0, config);
      } else {
         this.placeSmallFungyss(world, random, pos, height - 1, mutable, i, zOffset, config);
         this.placeSmallFungyss(world, random, pos, height - 2, mutable, i == 0 ? 1 : 0, zOffset == 0 ? 1 : 0, config);
      }

   }

   private void placeSmallCap(LevelAccessor world, RandomSource random, BlockPos pos, int height, MutableBlockPos mutable, int xOffset, int zOffset, BigFungyssFeatureConfig config) {
      Direction direction = this.getDirectionFromOffset(xOffset, zOffset);
      mutable.setWithOffset(pos, xOffset, height - 8, zOffset);
      mutable.move(direction);
      this.setBlock(world, mutable, (BlockState)config.capProvider.getState(random, pos).setValue((Property)PipeBlock.PROPERTY_BY_DIRECTION.get(direction.getOpposite()), false));

      for(int i = 0; i <= 1; ++i) {
         direction = direction == Direction.SOUTH ? Direction.EAST : Direction.from2DDataValue(direction.get2DDataValue() - 1);
         mutable.move(direction);
         this.setBlock(world, mutable, (BlockState)config.capProvider.getState(random, pos).setValue((Property)PipeBlock.PROPERTY_BY_DIRECTION.get(direction.getOpposite().getClockWise()), false));
      }

   }

   private void placeSmallFungyss(LevelAccessor world, RandomSource random, BlockPos pos, int height, MutableBlockPos mutable, int xOffset, int zOffset, BigFungyssFeatureConfig config) {
      Direction direction = this.getDirectionFromOffset(xOffset, zOffset);
      int stemHeight = world.getRandom().nextInt(2) + 2;
      mutable.setWithOffset(pos, xOffset, height - 8, zOffset);
      mutable.move(direction);
      if (stemHeight == 3) {
         mutable.move(Direction.DOWN);
      }

      this.setBlock(world, mutable, (BlockState)config.stemProvider.getState(random, pos).setValue(BlockStateProperties.AXIS, direction.getAxis()));
      mutable.move(direction);
      this.setBlock(world, mutable, (BlockState)config.hyphaeProvider.getState(random, pos).setValue(BlockStateProperties.AXIS, direction.getAxis()));

      for(int i = 0; i < stemHeight; ++i) {
         mutable.move(Direction.UP);
         this.setBlock(world, mutable, (BlockState)config.stemProvider.getState(random, pos).setValue(BlockStateProperties.AXIS, Axis.Y));
      }

      pos = mutable.immutable();
      int distanceToStem = 1;

      for(int i = stemHeight; i <= stemHeight + 1; ++i) {
         for(int xPos = -distanceToStem; xPos <= distanceToStem; ++xPos) {
            for(int zPos = -distanceToStem; zPos <= distanceToStem; ++zPos) {
               if (i < stemHeight + 1 && (xPos != 0 || zPos != 0) || !this.isCorner(xPos, zPos, distanceToStem)) {
                  mutable.setWithOffset(pos, xPos, i - stemHeight, zPos);
                  this.setBlock(world, mutable, config.capProvider.getState(random, pos));
               }
            }
         }
      }

      this.setBlock(world, pos.above(), config.capProvider.getState(random, pos));
   }

   private Direction getDirectionFromOffset(int xOffset, int zOffset) {
      if (xOffset == 0 && zOffset == 0) {
         return Direction.NORTH;
      } else if (xOffset == 0 && zOffset == 1) {
         return Direction.WEST;
      } else {
         return xOffset == 1 && zOffset == 0 ? Direction.EAST : Direction.SOUTH;
      }
   }

   private boolean isCorner(int xOffset, int zOffset, int distanceToStem) {
      return (xOffset == -distanceToStem || xOffset == distanceToStem) == (zOffset == -distanceToStem || zOffset == distanceToStem);
   }
}
