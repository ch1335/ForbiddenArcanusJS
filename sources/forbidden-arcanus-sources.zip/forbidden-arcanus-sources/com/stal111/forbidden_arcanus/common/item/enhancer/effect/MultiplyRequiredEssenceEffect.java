package com.stal111.forbidden_arcanus.common.item.enhancer.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceModifier;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.core.init.other.ModEnhancerEffects;

public record MultiplyRequiredEssenceEffect(EssenceType essenceType, double multiplier) implements ValueModifierEffect<Integer>, EssenceModifier {
   public static final MapCodec<MultiplyRequiredEssenceEffect> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(EssenceType.CODEC.fieldOf("essence_type").forGetter(MultiplyRequiredEssenceEffect::essenceType), Codec.DOUBLE.fieldOf("multiplier").forGetter(MultiplyRequiredEssenceEffect::multiplier)).apply(instance, MultiplyRequiredEssenceEffect::new);
   });

   public MultiplyRequiredEssenceEffect(EssenceType essenceType, double multiplier) {
      this.essenceType = essenceType;
      this.multiplier = multiplier;
   }

   public Integer getModifiedValue(Integer originalValue) {
      return (int)((double)originalValue * this.multiplier);
   }

   public EssenceType getEssenceType() {
      return this.essenceType;
   }

   public EnhancerEffectType<? extends EnhancerEffect> getType() {
      return (EnhancerEffectType)ModEnhancerEffects.MULTIPLY_REQUIRED_ESSENCE.get();
   }

   public EssenceType essenceType() {
      return this.essenceType;
   }

   public double multiplier() {
      return this.multiplier;
   }
}
