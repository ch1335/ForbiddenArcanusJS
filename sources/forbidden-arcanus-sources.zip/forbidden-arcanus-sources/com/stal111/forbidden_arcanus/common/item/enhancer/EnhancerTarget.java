package com.stal111.forbidden_arcanus.common.item.enhancer;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.StringRepresentable.EnumCodec;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import org.jetbrains.annotations.NotNull;

public enum EnhancerTarget implements StringRepresentable {
   HEPHAESTUS_FORGE("hephaestus_forge", "item.forbidden_arcanus.enhancer.hephaestus_forge_effect"),
   CLIBANO("clibano", "item.forbidden_arcanus.enhancer.clibano_effect");

   public static final EnumCodec<EnhancerTarget> CODEC = StringRepresentable.fromEnum(EnhancerTarget::values);
   public static final StreamCodec<FriendlyByteBuf, EnhancerTarget> STREAM_CODEC = NeoForgeStreamCodecs.enumCodec(EnhancerTarget.class);
   private final String name;
   private final Component title;

   private EnhancerTarget(String param3, String param4) {
      this.name = name;
      this.title = Component.translatable(title).withStyle(ChatFormatting.GRAY);
   }

   @NotNull
   public String getSerializedName() {
      return this.name;
   }

   public Component getTitle() {
      return this.title;
   }

   // $FF: synthetic method
   private static EnhancerTarget[] $values() {
      return new EnhancerTarget[]{HEPHAESTUS_FORGE, CLIBANO};
   }
}
