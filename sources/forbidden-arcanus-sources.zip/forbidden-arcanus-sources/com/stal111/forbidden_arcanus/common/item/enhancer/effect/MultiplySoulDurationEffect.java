package com.stal111.forbidden_arcanus.common.item.enhancer.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.init.other.ModEnhancerEffects;

public record MultiplySoulDurationEffect(double multiplier) implements ValueModifierEffect<Integer> {
   public static final MapCodec<MultiplySoulDurationEffect> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(Codec.doubleRange(0.0D, 10.0D).fieldOf("multiplier").forGetter(MultiplySoulDurationEffect::multiplier)).apply(instance, MultiplySoulDurationEffect::new);
   });

   public MultiplySoulDurationEffect(double multiplier) {
      this.multiplier = multiplier;
   }

   public Integer getModifiedValue(Integer originalValue) {
      return (int)((double)originalValue * this.multiplier);
   }

   public EnhancerEffectType<? extends EnhancerEffect> getType() {
      return (EnhancerEffectType)ModEnhancerEffects.MULTIPLY_SOUL_DURATION.get();
   }

   public double multiplier() {
      return this.multiplier;
   }
}
