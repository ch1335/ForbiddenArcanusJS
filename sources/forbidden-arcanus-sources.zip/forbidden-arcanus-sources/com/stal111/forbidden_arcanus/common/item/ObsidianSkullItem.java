package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.block.skull.ObsidianSkullType;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.EnumMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.core.Direction;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.dispenser.DispenseItemBehavior;
import net.minecraft.core.dispenser.OptionalDispenseItemBehavior;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.StandingAndWallBlockItem;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import org.jetbrains.annotations.NotNull;

public class ObsidianSkullItem extends StandingAndWallBlockItem {
   public static final Map<ObsidianSkullType, Block> NEXT_SKULL_STAGE = (Map)Util.make(new EnumMap(ObsidianSkullType.class), (map) -> {
      map.put(ObsidianSkullType.DEFAULT, ModBlocks.CRACKED_OBSIDIAN_SKULL.getSkull());
      map.put(ObsidianSkullType.CRACKED, ModBlocks.FRAGMENTED_OBSIDIAN_SKULL.getSkull());
      map.put(ObsidianSkullType.FRAGMENTED, ModBlocks.FADING_OBSIDIAN_SKULL.getSkull());
      map.put(ObsidianSkullType.FADING, Blocks.SKELETON_SKULL);
   });
   public static final DispenseItemBehavior DISPENSE_ITEM_BEHAVIOR = new OptionalDispenseItemBehavior() {
      @NotNull
      protected ItemStack execute(@NotNull BlockSource source, @NotNull ItemStack stack) {
         this.setSuccess(ArmorItem.dispenseArmor(source, stack));
         return super.execute(source, stack);
      }
   };

   public ObsidianSkullItem(Block floorBlock, Block wallBlock, Properties properties) {
      super(floorBlock, wallBlock, properties, Direction.DOWN);
   }

   @Nullable
   public EquipmentSlot getEquipmentSlot(ItemStack stack) {
      return EquipmentSlot.HEAD;
   }

   public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
      if (slotId == 39 && entity instanceof Player) {
         Player player = (Player)entity;
         if (player.isOnFire()) {
            this.getType(stack).tick(stack, player);
         }
      }
   }

   public ObsidianSkullType getType(ItemStack stack) {
      return (ObsidianSkullType)stack.getOrDefault(ModDataComponents.OBSIDIAN_SKULL_TYPE, ObsidianSkullType.DEFAULT);
   }
}
