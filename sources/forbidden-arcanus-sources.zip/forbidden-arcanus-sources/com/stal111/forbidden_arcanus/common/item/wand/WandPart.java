package com.stal111.forbidden_arcanus.common.item.wand;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;

public record WandPart(Component materialName, WandStats stats) {
   public static final Codec<WandPart> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ComponentSerialization.CODEC.fieldOf("material_name").forGetter(WandPart::materialName), WandStats.CODEC.forGetter(WandPart::stats)).apply(instance, WandPart::new);
   });

   public WandPart(Component materialName, WandStats stats) {
      this.materialName = materialName;
      this.stats = stats;
   }

   public Component materialName() {
      return this.materialName;
   }

   public WandStats stats() {
      return this.stats;
   }
}
