package com.stal111.forbidden_arcanus.common.item.crafting;

import java.util.List;
import java.util.stream.Stream;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

public record ClibanoRecipeInput(ItemStack firstInput, ItemStack secondInput) implements RecipeInput {
   public ClibanoRecipeInput(ItemStack firstInput, ItemStack secondInput) {
      this.firstInput = firstInput;
      this.secondInput = secondInput;
   }

   public List<ItemStack> getInputs() {
      return Stream.of(this.firstInput, this.secondInput).filter((itemStack) -> {
         return !itemStack.isEmpty();
      }).toList();
   }

   public ItemStack getItem(int index) {
      return null;
   }

   public int size() {
      return 0;
   }

   public ItemStack firstInput() {
      return this.firstInput;
   }

   public ItemStack secondInput() {
      return this.secondInput;
   }
}
