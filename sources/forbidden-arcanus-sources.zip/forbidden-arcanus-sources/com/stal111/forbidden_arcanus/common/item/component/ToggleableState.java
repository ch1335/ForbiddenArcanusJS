package com.stal111.forbidden_arcanus.common.item.component;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;

public record ToggleableState(boolean active, boolean showInTooltip) implements TooltipProvider {
   public static final Codec<ToggleableState> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(Codec.BOOL.optionalFieldOf("active", true).forGetter(ToggleableState::active), Codec.BOOL.optionalFieldOf("showInTooltip", true).forGetter(ToggleableState::showInTooltip)).apply(instance, ToggleableState::new);
   });
   public static final StreamCodec<FriendlyByteBuf, ToggleableState> STREAM_CODEC;
   public static final ToggleableState DEFAULT;
   private static final Component TOGGLE;
   private static final Component TOGGLE_ACTIVATED;
   private static final Component TOGGLE_DEACTIVATED;

   public ToggleableState(boolean active, boolean showInTooltip) {
      this.active = active;
      this.showInTooltip = showInTooltip;
   }

   public ToggleableState toggle() {
      return new ToggleableState(!this.active, this.showInTooltip);
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> tooltipAdder, TooltipFlag tooltipFlag) {
      if (this.showInTooltip) {
         tooltipAdder.accept(this.active ? TOGGLE_ACTIVATED : TOGGLE_DEACTIVATED);
      }

   }

   public boolean active() {
      return this.active;
   }

   public boolean showInTooltip() {
      return this.showInTooltip;
   }

   static {
      STREAM_CODEC = StreamCodec.composite(ByteBufCodecs.BOOL, ToggleableState::active, ByteBufCodecs.BOOL, ToggleableState::showInTooltip, ToggleableState::new);
      DEFAULT = new ToggleableState(true, true);
      TOGGLE = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("toggle_state"))).withStyle(ChatFormatting.GRAY);
      TOGGLE_ACTIVATED = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("toggle_state.activated"))).withStyle(ChatFormatting.GREEN).append(" ").append(TOGGLE);
      TOGGLE_DEACTIVATED = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("toggle_state.deactivated"))).withStyle(ChatFormatting.RED).append(" ").append(TOGGLE);
   }
}
