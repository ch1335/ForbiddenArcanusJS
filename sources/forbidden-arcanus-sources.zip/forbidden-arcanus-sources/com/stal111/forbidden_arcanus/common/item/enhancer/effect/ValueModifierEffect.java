package com.stal111.forbidden_arcanus.common.item.enhancer.effect;

public interface ValueModifierEffect<T> extends EnhancerEffect {
   T getModifiedValue(T var1);
}
