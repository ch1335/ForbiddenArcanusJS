package com.stal111.forbidden_arcanus.common.item.mundabitur;

import com.stal111.forbidden_arcanus.core.config.ItemConfig;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Creeper;

public class ChargeCreeperInteraction extends EntityInteraction {
   public void interact(EntityInteraction.EntityInteractionContext context) {
      SynchedEntityData dataManager = context.entity().getEntityData();
      dataManager.set(Creeper.DATA_IS_POWERED, true);
   }

   public boolean canInteract(EntityInteraction.EntityInteractionContext context) {
      LivingEntity var3 = context.entity();
      boolean var10000;
      if (var3 instanceof Creeper) {
         Creeper creeper = (Creeper)var3;
         if (!creeper.isPowered() && (Boolean)ItemConfig.MUNDABITUR_DUST_CHARGE_CREEPER.get()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }
}
