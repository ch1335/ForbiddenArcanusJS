package com.stal111.forbidden_arcanus.common.item.mundabitur;

import com.stal111.forbidden_arcanus.common.block.ArcaneCrystalObeliskBlock;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.ObeliskPart;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.pattern.BlockPattern;

public class CreateObeliskInteraction extends TransformPatternInteraction {
   public CreateObeliskInteraction(Predicate<BlockState> predicate, BlockPattern pattern) {
      super(predicate, pattern);
   }

   public void interact(TransformPatternInteraction.TransformPatternContext context) {
      BlockPos pos = context.pos();

      Level level;
      for(level = context.level(); level.getBlockState(pos).is((Block)ModBlocks.ARCANE_CRYSTAL_BLOCK.get()); pos = pos.below()) {
      }

      BlockState obelisk = ((ArcaneCrystalObeliskBlock)ModBlocks.ARCANE_CRYSTAL_OBELISK.get()).defaultBlockState();
      this.placeBlock(level, pos, (BlockState)((BlockState)obelisk.setValue(ArcaneCrystalObeliskBlock.PART, ObeliskPart.LOWER)).setValue(ModBlockStateProperties.ACTIVE, ArcaneCrystalObeliskBlock.shouldActivate(level, pos)));
      this.placeBlock(level, pos.above(), (BlockState)obelisk.setValue(ArcaneCrystalObeliskBlock.PART, ObeliskPart.MIDDLE));
      this.placeBlock(level, pos.above(2), (BlockState)obelisk.setValue(ArcaneCrystalObeliskBlock.PART, ObeliskPart.UPPER));
   }
}
