package com.stal111.forbidden_arcanus.common.item.modifier;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.Iterator;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistryCodecs;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.RegistryFileCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;

public record ItemModifier(ItemPredicate predicate, HolderSet<Item> incompatibleItems, HolderSet<Enchantment> incompatibleEnchantments, HolderSet<DataComponentType<?>> componentsToRemove, ItemModifier.DisplaySettings displaySettings) {
   public static final Codec<ItemModifier> DIRECT_CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ItemPredicate.CODEC.fieldOf("predicate").forGetter(ItemModifier::predicate), RegistryCodecs.homogeneousList(Registries.ITEM).optionalFieldOf("incompatible_items", HolderSet.empty()).forGetter(ItemModifier::incompatibleItems), RegistryCodecs.homogeneousList(Registries.ENCHANTMENT).optionalFieldOf("incompatible_enchantments", HolderSet.empty()).forGetter(ItemModifier::incompatibleEnchantments), RegistryCodecs.homogeneousList(Registries.DATA_COMPONENT_TYPE).optionalFieldOf("components_to_remove", HolderSet.empty()).forGetter(ItemModifier::componentsToRemove), ItemModifier.DisplaySettings.CODEC.fieldOf("display").forGetter((modifier) -> {
         return modifier.displaySettings;
      })).apply(instance, ItemModifier::new);
   });
   public static final Codec<Holder<ItemModifier>> CODEC;
   public static final StreamCodec<RegistryFriendlyByteBuf, Holder<ItemModifier>> STREAM_CODEC;

   public ItemModifier(ItemPredicate predicate, HolderSet<Item> incompatibleItems, HolderSet<Enchantment> incompatibleEnchantments, HolderSet<DataComponentType<?>> componentsToRemove, ItemModifier.DisplaySettings displaySettings) {
      this.predicate = predicate;
      this.incompatibleItems = incompatibleItems;
      this.incompatibleEnchantments = incompatibleEnchantments;
      this.componentsToRemove = componentsToRemove;
      this.displaySettings = displaySettings;
   }

   public void onApplied(ItemStack stack) {
      if (!stack.has(DataComponents.CUSTOM_NAME)) {
         stack.update(DataComponents.ITEM_NAME, stack.getItem().getName(stack), (componentx) -> {
            return this.displaySettings.name.copy().append(" ").append(componentx);
         });
      }

      Iterator var2 = this.componentsToRemove.iterator();

      while(var2.hasNext()) {
         Holder<DataComponentType<?>> component = (Holder)var2.next();
         stack.remove((DataComponentType)component.value());
      }

   }

   public boolean isValidItem(ItemStack stack) {
      if (!stack.is(this.incompatibleItems) && this.predicate.test(stack) && !ModifierHelper.hasModifier(stack)) {
         Set<Holder<Enchantment>> enchantments = stack.getTagEnchantments().keySet();
         Stream var10000 = this.incompatibleEnchantments.stream();
         Objects.requireNonNull(enchantments);
         return var10000.noneMatch(enchantments::contains);
      } else {
         return false;
      }
   }

   public ItemPredicate predicate() {
      return this.predicate;
   }

   public HolderSet<Item> incompatibleItems() {
      return this.incompatibleItems;
   }

   public HolderSet<Enchantment> incompatibleEnchantments() {
      return this.incompatibleEnchantments;
   }

   public HolderSet<DataComponentType<?>> componentsToRemove() {
      return this.componentsToRemove;
   }

   public ItemModifier.DisplaySettings displaySettings() {
      return this.displaySettings;
   }

   static {
      CODEC = RegistryFileCodec.create(FARegistries.ITEM_MODIFIER, DIRECT_CODEC);
      STREAM_CODEC = ByteBufCodecs.holderRegistry(FARegistries.ITEM_MODIFIER);
   }

   public static record DisplaySettings(Component name, ResourceLocation texture, Pair<Integer, Integer> tooltipColor) {
      public static final Codec<ItemModifier.DisplaySettings> CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(ComponentSerialization.CODEC.fieldOf("name").forGetter(ItemModifier.DisplaySettings::name), ResourceLocation.CODEC.fieldOf("texture").forGetter(ItemModifier.DisplaySettings::texture), Codec.pair(Codec.INT.fieldOf("start").codec(), Codec.INT.fieldOf("end").codec()).fieldOf("tooltip_color").forGetter(ItemModifier.DisplaySettings::tooltipColor)).apply(instance, ItemModifier.DisplaySettings::new);
      });

      public DisplaySettings(Component name, ResourceLocation texture, Pair<Integer, Integer> tooltipColor) {
         this.name = name;
         this.texture = texture;
         this.tooltipColor = tooltipColor;
      }

      public Component name() {
         return this.name;
      }

      public ResourceLocation texture() {
         return this.texture;
      }

      public Pair<Integer, Integer> tooltipColor() {
         return this.tooltipColor;
      }
   }
}
