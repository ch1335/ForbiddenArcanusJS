package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceStorage;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import org.jetbrains.annotations.NotNull;

public class BloodTestTubeItem extends Item {
   public static final int MAX_BLOOD = 3000;
   public static final EssenceStorage DEFAULT_DATA;

   public BloodTestTubeItem(Properties properties) {
      super(properties);
   }

   @NotNull
   public String getDescriptionId(@NotNull ItemStack stack) {
      return ((Item)ModItems.TEST_TUBE.get()).getDescriptionId();
   }

   static {
      DEFAULT_DATA = new EssenceStorage(EssenceValue.createEmpty(EssenceType.BLOOD), 3000, true);
   }
}
