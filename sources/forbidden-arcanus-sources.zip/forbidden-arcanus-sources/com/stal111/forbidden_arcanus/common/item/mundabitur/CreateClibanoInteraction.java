package com.stal111.forbidden_arcanus.common.item.mundabitur;

import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoCenterBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoCornerBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoMainPartBlock;
import com.stal111.forbidden_arcanus.common.block.clibano.ClibanoSideBlock;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFrameBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoMainBlockEntity;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.clibano.ClibanoCenterType;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

public class CreateClibanoInteraction extends TransformPatternInteraction {
   private BlockPos centerPos;

   public CreateClibanoInteraction(Predicate<BlockState> predicate, BlockPattern pattern) {
      super(predicate, pattern);
   }

   public void interact(TransformPatternInteraction.TransformPatternContext context) {
      Direction clickedFace = context.clickedFace();
      BlockPos pos = context.pos();
      Level level = context.level();
      this.centerPos = pos.relative(clickedFace.getOpposite());
      BlockPos bottomPos = pos.below().relative(clickedFace.getClockWise());
      BlockState cornerState = ((ClibanoCornerBlock)ModBlocks.CLIBANO_CORNER.get()).defaultBlockState();
      this.placeBlock(level, bottomPos, (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace));
      this.placeBlock(level, bottomPos.relative(clickedFace.getOpposite(), 2), (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace.getClockWise()));
      this.placeBlock(level, bottomPos.relative(clickedFace.getOpposite(), 2).relative(clickedFace.getCounterClockWise(), 2), (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace.getOpposite()));
      this.placeBlock(level, bottomPos.relative(clickedFace.getCounterClockWise(), 2), (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace.getCounterClockWise()));
      BlockPos topPos = pos.above().relative(clickedFace.getClockWise());
      cornerState = (BlockState)cornerState.setValue(BlockStateProperties.BOTTOM, false);
      this.placeBlock(level, topPos, (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace));
      this.placeBlock(level, topPos.relative(clickedFace.getOpposite(), 2), (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace.getClockWise()));
      this.placeBlock(level, topPos.relative(clickedFace.getOpposite(), 2).relative(clickedFace.getCounterClockWise(), 2), (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace.getOpposite()));
      this.placeBlock(level, topPos.relative(clickedFace.getCounterClockWise(), 2), (BlockState)cornerState.setValue(BlockStateProperties.HORIZONTAL_FACING, clickedFace.getCounterClockWise()));
      BlockState centerState = ((ClibanoCenterBlock)ModBlocks.CLIBANO_CENTER.get()).defaultBlockState();
      BlockState horizontalSideState = ((ClibanoSideBlock)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get()).defaultBlockState();
      BlockState verticalSideState = ((ClibanoSideBlock)ModBlocks.CLIBANO_SIDE_VERTICAL.get()).defaultBlockState();
      Direction[] var11 = Direction.values();
      int var12 = var11.length;

      for(int var13 = 0; var13 < var12; ++var13) {
         Direction direction = var11[var13];
         BlockPos relativePos = this.centerPos.relative(direction);
         this.placeBlock(level, relativePos, (BlockState)((BlockState)centerState.setValue(ModBlockStateProperties.CLIBANO_CENTER_TYPE, ClibanoCenterType.getFromDirection(direction, clickedFace))).setValue(BlockStateProperties.FACING, direction));
         if (direction.getAxis() != Axis.Y) {
            this.placeBlock(level, relativePos.relative(direction.getClockWise()), (BlockState)((BlockState)horizontalSideState.setValue(BlockStateProperties.HORIZONTAL_FACING, direction)).setValue(ModBlockStateProperties.MIRRORED, direction == clickedFace.getCounterClockWise()));
            this.placeBlock(level, relativePos.relative(Direction.UP), (BlockState)verticalSideState.setValue(BlockStateProperties.HORIZONTAL_FACING, direction));
            this.placeBlock(level, relativePos.relative(Direction.DOWN), (BlockState)((BlockState)verticalSideState.setValue(BlockStateProperties.HORIZONTAL_FACING, direction)).setValue(ModBlockStateProperties.MIRRORED, true));
         }
      }

      level.setBlock(this.centerPos, ((ClibanoMainPartBlock)ModBlocks.CLIBANO_MAIN_PART.get()).defaultBlockState(), 2);
      if (level instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)level;
         BlockEntity var21 = serverLevel.getBlockEntity(this.centerPos);
         if (var21 instanceof ClibanoMainBlockEntity) {
            ClibanoMainBlockEntity blockEntity = (ClibanoMainBlockEntity)var21;
            blockEntity.setFrontDirection(clickedFace);
            Direction[] var22 = Direction.values();
            int var23 = var22.length;

            for(int var24 = 0; var24 < var23; ++var24) {
               Direction direction = var22[var24];
               BlockEntity var18 = serverLevel.getBlockEntity(this.centerPos.relative(direction));
               if (var18 instanceof ClibanoFrameBlockEntity) {
                  ClibanoFrameBlockEntity clibanoBlockEntity = (ClibanoFrameBlockEntity)var18;
                  clibanoBlockEntity.setMainDirection(direction.getOpposite());
               }
            }
         }
      }

   }

   public void placeBlock(Level level, BlockPos pos, BlockState state) {
      BlockState oldState = level.getBlockState(pos);
      super.placeBlock(level, pos, state);
      BlockEntity var6 = level.getBlockEntity(pos);
      if (var6 instanceof ClibanoFrameBlockEntity) {
         ClibanoFrameBlockEntity blockEntity = (ClibanoFrameBlockEntity)var6;
         blockEntity.setFrameData(new ClibanoFrameBlockEntity.FrameData(oldState, this.centerPos));
      }

   }
}
