package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.entity.projectile.AurealMissile;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import com.stal111.forbidden_arcanus.core.init.ModSounds;
import java.util.List;
import java.util.Objects;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.level.Level;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;

public class MagicWandItem extends Item {
   private static final float CHARGE_DURATION = 30.0F;

   public MagicWandItem(Properties properties) {
      super(properties);
   }

   public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> components, TooltipFlag flag) {
      RegistryEntry var10001 = ModDataComponents.WAND_PARTS;
      Objects.requireNonNull(components);
      stack.addToTooltip(var10001, context, components::add, flag);
   }

   public int getUseDuration(ItemStack stack, LivingEntity entity) {
      return 72000;
   }

   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand usedHand) {
      ItemStack stack = player.getItemInHand(usedHand);
      if (EssenceHelper.hasEnoughAureal(level, player, stack)) {
         player.startUsingItem(usedHand);
         return InteractionResultHolder.consume(player.getItemInHand(usedHand));
      } else {
         return super.use(level, player, usedHand);
      }
   }

   public void releaseUsing(ItemStack stack, Level level, LivingEntity livingEntity, int timeLeft) {
      if (!level.isClientSide() && (float)(stack.getUseDuration(livingEntity) - timeLeft) >= 30.0F && EssenceHelper.hasEnoughAureal(level, livingEntity, stack)) {
         this.shootProjectile(level, livingEntity);
         EssenceHelper.consumeAureal(livingEntity, stack);
      }

   }

   private void shootProjectile(Level level, LivingEntity livingEntity) {
      AurealMissile aurealMissile = new AurealMissile(livingEntity, level, livingEntity.position().x(), livingEntity.getEyePosition().y(), livingEntity.position().z());
      aurealMissile.shootFromRotation(livingEntity, livingEntity.getXRot(), livingEntity.getYRot(), 0.0F, 1.1F, 0.5F);
      level.addFreshEntity(aurealMissile);
      level.playSound((Player)null, livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(), (SoundEvent)ModSounds.MAGIC_WAND_CAST.get(), livingEntity.getSoundSource(), 1.0F, 1.0F + (level.random.nextFloat() - level.random.nextFloat()) * 0.2F);
   }

   public static float getUseProgress(ItemStack stack, LivingEntity entity) {
      return entity.isUsingItem() ? Math.min(30.0F, (float)(stack.getUseDuration(entity) - entity.getUseItemRemainingTicks())) / 30.0F : 0.0F;
   }
}
