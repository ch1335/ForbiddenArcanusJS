package com.stal111.forbidden_arcanus.common.item.enhancer.condition;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.Objects;
import net.minecraft.core.Registry;
import net.minecraft.world.level.Level;

public abstract class EffectCondition {
   public static final Codec<EffectCondition> DIRECT_CODEC;

   public abstract boolean test(Level var1);

   public abstract EffectConditionType<? extends EffectCondition> getType();

   static {
      Registry var10000 = FARegistries.ENHANCER_EFFECT_CONDITION_REGISTRY;
      Objects.requireNonNull(var10000);
      DIRECT_CODEC = Codec.lazyInitialized(var10000::byNameCodec).dispatch(EffectCondition::getType, EffectConditionType::codec);
   }
}
