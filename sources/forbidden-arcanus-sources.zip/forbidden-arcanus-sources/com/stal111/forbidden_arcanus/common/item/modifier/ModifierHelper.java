package com.stal111.forbidden_arcanus.common.item.modifier;

import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;

public class ModifierHelper {
   public static Optional<ItemModifier> getModifier(ItemStack stack) {
      return Optional.ofNullable((Holder)stack.get(ModDataComponents.ITEM_MODIFIER)).map(Holder::value);
   }

   public static void setModifier(ItemStack stack, Holder<ItemModifier> modifier) {
      stack.set(ModDataComponents.ITEM_MODIFIER, modifier);
      ((ItemModifier)modifier.value()).onApplied(stack);
   }

   public static boolean hasModifier(ItemStack stack) {
      return getModifier(stack).isPresent();
   }

   public static boolean hasModifier(ItemStack stack, Holder<ItemModifier> modifier) {
      return (Boolean)getModifier(stack).map((itemModifier) -> {
         return itemModifier == modifier.value();
      }).orElse(false);
   }
}
