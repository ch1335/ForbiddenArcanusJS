package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;

public class DarkMatterItem extends Item {
   public DarkMatterItem(Properties properties) {
      super(properties);
   }

   public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
      Level level = entity.getCommandSenderWorld();
      BlockPos pos = entity.blockPosition();
      List<ItemEntity> itemEntities = level.getEntitiesOfClass(ItemEntity.class, (new AABB(pos)).inflate(0.5D));
      Iterator var6 = itemEntities.iterator();

      while(var6.hasNext()) {
         ItemEntity itemEntity = (ItemEntity)var6.next();
         if (itemEntity.getItem().is((Item)ModItems.CORRUPTI_DUST.get()) && level.getBlockState(pos).isAir()) {
            entity.getItem().shrink(1);
            itemEntity.getItem().shrink(1);
            level.setBlockAndUpdate(pos, ((Block)ModBlocks.BLACK_HOLE.get()).defaultBlockState());
         }
      }

      return false;
   }
}
