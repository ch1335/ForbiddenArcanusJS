package com.stal111.forbidden_arcanus.common.item.mundabitur;

import com.stal111.forbidden_arcanus.common.block.HephaestusForgeBlock;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.entity.CrimsonLightningBoltEntity;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.pattern.BlockPattern;

public class CreateForgeInteraction extends TransformPatternInteraction {
   public CreateForgeInteraction(Predicate<BlockState> predicate, BlockPattern pattern) {
      super(predicate, pattern);
   }

   public void interact(TransformPatternInteraction.TransformPatternContext context) {
      Level level = context.level();
      BlockPos pos = context.pos();
      this.placeBlock(level, pos, (BlockState)((HephaestusForgeBlock)ModBlocks.HEPHAESTUS_FORGE_TIER_1.get()).defaultBlockState().setValue(ModBlockStateProperties.ACTIVATED, true));
      CrimsonLightningBoltEntity entity = new CrimsonLightningBoltEntity((EntityType)ModEntities.CRIMSON_LIGHTNING_BOLT.get(), level);
      entity.setPos((double)pos.getX() + 0.5D, (double)pos.getY() + 1.0D, (double)pos.getZ() + 0.5D);
      entity.setVisualOnly(true);
      level.addFreshEntity(entity);
   }
}
