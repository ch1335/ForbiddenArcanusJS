package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.entity.projectile.BoomArrow;
import com.stal111.forbidden_arcanus.common.entity.projectile.DracoArcanusArrow;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import javax.annotation.Nonnull;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ModArrowItem extends ArrowItem {
   public ModArrowItem(Properties properties) {
      super(properties);
   }

   @Nonnull
   public AbstractArrow createArrow(@Nonnull Level level, @Nonnull ItemStack pickupStack, @Nonnull LivingEntity shooter, @Nullable ItemStack stack) {
      if (this == ModItems.BOOM_ARROW.get()) {
         return new BoomArrow(level, shooter, pickupStack.copyWithCount(1), stack);
      } else {
         return (AbstractArrow)(this == ModItems.DRACO_ARCANUS_ARROW.get() ? new DracoArcanusArrow(level, shooter, pickupStack.copyWithCount(1), stack) : super.createArrow(level, pickupStack, shooter, stack));
      }
   }
}
