package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.block.pedestal.MagnetizedPedestalBlock;
import com.stal111.forbidden_arcanus.common.network.clientbound.TransformPedestalPayload;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.gameevent.GameEvent.Context;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;

public class FerrogneticMixtureItem extends Item {
   public FerrogneticMixtureItem(Properties properties) {
      super(properties);
   }

   @NotNull
   public InteractionResult useOn(@NotNull UseOnContext context) {
      Level level = context.getLevel();
      BlockPos pos = context.getClickedPos();
      BlockState state = level.getBlockState(pos);
      ItemStack stack = context.getItemInHand();
      if (state.is((Block)ModBlocks.DARKSTONE_PEDESTAL.get())) {
         Player player = context.getPlayer();
         state = ((MagnetizedPedestalBlock)ModBlocks.MAGNETIZED_DARKSTONE_PEDESTAL.get()).defaultBlockState();
         stack.shrink(1);
         level.setBlock(pos, state, 11);
         level.gameEvent(GameEvent.BLOCK_CHANGE, pos, Context.of(player, state));
         if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            PacketDistributor.sendToPlayersTrackingChunk(serverLevel, new ChunkPos(pos), new TransformPedestalPayload(pos), new CustomPacketPayload[0]);
         }

         return InteractionResult.sidedSuccess(level.isClientSide());
      } else {
         return super.useOn(context);
      }
   }
}
