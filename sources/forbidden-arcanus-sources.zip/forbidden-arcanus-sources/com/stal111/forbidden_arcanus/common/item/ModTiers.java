package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;

public enum ModTiers implements Tier {
   DRACO_ARCANUS(2661, 12.0F, 7.0F, 20, () -> {
      return Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()});
   }),
   REINFORCED_DEORUM(2561, 9.0F, 3.5F, 26, () -> {
      return Ingredient.of(new ItemLike[]{(ItemLike)ModItems.STELLARITE_PIECE.get()});
   }),
   BONE(131, 4.0F, 1.0F, 5, () -> {
      return Ingredient.of(new ItemLike[]{Items.BONE});
   }),
   SLIMEC(2061, 13.0F, 2.5F, 20, () -> {
      return Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DEORUM_INGOT.get()});
   });

   private final int uses;
   private final float speed;
   private final float damage;
   private final int enchantmentValue;
   private final Supplier<Ingredient> repairIngredient;

   private ModTiers(int param3, float param4, float param5, int param6, Supplier<Ingredient> param7) {
      this.uses = uses;
      this.speed = speed;
      this.damage = damage;
      this.enchantmentValue = enchantmentValue;
      this.repairIngredient = repairIngredient;
   }

   public int getUses() {
      return this.uses;
   }

   public float getSpeed() {
      return this.speed;
   }

   public float getAttackDamageBonus() {
      return this.damage;
   }

   public TagKey<Block> getIncorrectBlocksForDrops() {
      return BlockTags.INCORRECT_FOR_DIAMOND_TOOL;
   }

   public int getEnchantmentValue() {
      return this.enchantmentValue;
   }

   @Nonnull
   public Ingredient getRepairIngredient() {
      return (Ingredient)this.repairIngredient.get();
   }

   // $FF: synthetic method
   private static ModTiers[] $values() {
      return new ModTiers[]{DRACO_ARCANUS, REINFORCED_DEORUM, BONE, SLIMEC};
   }
}
