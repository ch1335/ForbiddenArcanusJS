package com.stal111.forbidden_arcanus.common.item.enhancer.effect;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerTarget;

public record EnhancerEffectType<T extends EnhancerEffect>(MapCodec<ConditionalEnhancerEffect<T>> codec, EnhancerTarget target) {
   public EnhancerEffectType(MapCodec<ConditionalEnhancerEffect<T>> codec, EnhancerTarget target) {
      this.codec = codec;
      this.target = target;
   }

   public MapCodec<ConditionalEnhancerEffect<T>> codec() {
      return this.codec;
   }

   public EnhancerTarget target() {
      return this.target;
   }
}
