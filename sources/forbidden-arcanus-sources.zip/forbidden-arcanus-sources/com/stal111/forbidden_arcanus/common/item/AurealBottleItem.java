package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.essence.EssenceProvider;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;

public class AurealBottleItem extends Item {
   private static final int USE_DURATION = 32;

   public AurealBottleItem(Properties properties) {
      super(properties);
   }

   public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity livingEntity) {
      if (livingEntity instanceof ServerPlayer) {
         ServerPlayer player = (ServerPlayer)livingEntity;
         CriteriaTriggers.CONSUME_ITEM.trigger(player, stack);
         player.awardStat(Stats.ITEM_USED.get(this));
      }

      if (!level.isClientSide()) {
         int aurealAmount = EssenceHelper.getEssenceAmount(stack, EssenceType.AUREAL);
         EssenceHelper.getEssenceProvider(livingEntity).ifPresent((provider) -> {
            provider.updateAmount(EssenceType.AUREAL, (amount) -> {
               return amount + aurealAmount;
            });
         });
      }

      stack.consume(1, livingEntity);
      return stack;
   }

   public int getUseDuration(ItemStack stack, LivingEntity entity) {
      return 32;
   }

   public UseAnim getUseAnimation(ItemStack stack) {
      return UseAnim.DRINK;
   }

   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
      EssenceProvider essenceProvider = (EssenceProvider)EssenceHelper.getEssenceProvider(player).orElse((Object)null);
      return essenceProvider != null && !essenceProvider.isFull(EssenceType.AUREAL) ? ItemUtils.startUsingInstantly(level, player, hand) : super.use(level, player, hand);
   }
}
