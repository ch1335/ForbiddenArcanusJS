package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.entity.CustomBoat;
import com.stal111.forbidden_arcanus.common.entity.ModBoat;
import com.stal111.forbidden_arcanus.common.entity.ModChestBoat;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import javax.annotation.Nonnull;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.vehicle.Boat.Type;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class ModBoatItem extends BoatItem {
   private static final Predicate<Entity> ENTITY_PREDICATE;
   private final ModBoat.Type woodType;
   private final boolean hasChest;

   public ModBoatItem(boolean hasChest, ModBoat.Type woodType, Properties properties) {
      super(hasChest, Type.OAK, properties);
      this.woodType = woodType;
      this.hasChest = hasChest;
   }

   @Nonnull
   public InteractionResultHolder<ItemStack> use(@Nonnull Level level, Player player, @Nonnull InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      HitResult hitResult = getPlayerPOVHitResult(level, player, Fluid.ANY);
      if (hitResult.getType() != net.minecraft.world.phys.HitResult.Type.MISS) {
         Vec3 vec3 = player.getViewVector(1.0F);
         List<Entity> list = level.getEntities(player, player.getBoundingBox().expandTowards(vec3.scale(5.0D)).inflate(1.0D), ENTITY_PREDICATE);
         if (!list.isEmpty()) {
            Vec3 vec31 = player.getEyePosition();
            Iterator var9 = list.iterator();

            while(var9.hasNext()) {
               Entity entity = (Entity)var9.next();
               if (entity.getBoundingBox().inflate((double)entity.getPickRadius()).contains(vec31)) {
                  return InteractionResultHolder.pass(stack);
               }
            }
         }

         if (hitResult.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            CustomBoat customBoat = this.getBoat(level, hitResult);
            customBoat.setWoodType(this.woodType);
            if (customBoat instanceof Boat) {
               Boat boat = (Boat)customBoat;
               boat.setYRot(player.getYRot());
               if (!level.noCollision(boat, boat.getBoundingBox())) {
                  return InteractionResultHolder.fail(stack);
               }

               if (!level.isClientSide()) {
                  level.addFreshEntity(boat);
                  level.gameEvent(player, GameEvent.ENTITY_PLACE, hitResult.getLocation());
                  stack.consume(1, player);
               }

               player.awardStat(Stats.ITEM_USED.get(this));
               return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
            }

            return InteractionResultHolder.pass(stack);
         }
      }

      return InteractionResultHolder.pass(stack);
   }

   private CustomBoat getBoat(Level level, HitResult hitResult) {
      return (CustomBoat)(this.hasChest ? new ModChestBoat(level, hitResult.getLocation().x, hitResult.getLocation().y, hitResult.getLocation().z) : new ModBoat(level, hitResult.getLocation().x, hitResult.getLocation().y, hitResult.getLocation().z));
   }

   static {
      ENTITY_PREDICATE = EntitySelector.NO_SPECTATORS.and(Entity::isPickable);
   }
}
