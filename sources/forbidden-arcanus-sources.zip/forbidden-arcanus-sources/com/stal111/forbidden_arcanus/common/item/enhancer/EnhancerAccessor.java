package com.stal111.forbidden_arcanus.common.item.enhancer;

import net.minecraft.core.HolderSet;

public interface EnhancerAccessor {
   HolderSet<EnhancerDefinition> getEnhancers();
}
