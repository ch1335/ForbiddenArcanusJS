package com.stal111.forbidden_arcanus.common.item.enhancer.condition;

import com.mojang.serialization.MapCodec;

public record EffectConditionType<T extends EffectCondition>(MapCodec<T> codec) {
   public EffectConditionType(MapCodec<T> codec) {
      this.codec = codec;
   }

   public MapCodec<T> codec() {
      return this.codec;
   }
}
