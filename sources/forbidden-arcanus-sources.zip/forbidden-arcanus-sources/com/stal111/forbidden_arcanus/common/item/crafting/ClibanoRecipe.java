package com.stal111.forbidden_arcanus.common.item.crafting;

import com.google.errorprone.annotations.DoNotCall;
import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoCookingTimes;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFireType;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.residue.ResidueChance;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModRecipeSerializers;
import com.stal111.forbidden_arcanus.core.init.ModRecipeTypes;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.NonNullList;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CookingBookCategory;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.util.RecipeMatcher;
import org.jetbrains.annotations.NotNull;

public record ClibanoRecipe(String group, CookingBookCategory category, Either<Ingredient, Pair<Ingredient, Ingredient>> ingredients, ItemStack result, float experience, ClibanoCookingTimes cookingTimes, Optional<ResidueChance> residueChance, ClibanoFireType requiredFireType, Optional<Holder<EnhancerDefinition>> requiredEnhancer) implements Recipe<ClibanoRecipeInput> {
   public static final ClibanoCookingTimes DEFAULT_COOKING_TIMES = ClibanoCookingTimes.of(100);

   public ClibanoRecipe(String group, CookingBookCategory category, Either<Ingredient, Pair<Ingredient, Ingredient>> ingredients, ItemStack result, float experience, ClibanoCookingTimes cookingTimes, Optional<ResidueChance> residueChance, ClibanoFireType requiredFireType, Optional<Holder<EnhancerDefinition>> requiredEnhancer) {
      this.group = group;
      this.category = category;
      this.ingredients = ingredients;
      this.result = result;
      this.experience = experience;
      this.cookingTimes = cookingTimes;
      this.residueChance = residueChance;
      this.requiredFireType = requiredFireType;
      this.requiredEnhancer = requiredEnhancer;
   }

   public boolean matches(@NotNull ClibanoRecipeInput recipeInput, @NotNull Level level, HolderSet<EnhancerDefinition> enhancers) {
      return !this.enhancerMatches(enhancers) ? false : this.matches(recipeInput, level);
   }

   private boolean enhancerMatches(HolderSet<EnhancerDefinition> enhancers) {
      return this.requiredEnhancer.isEmpty() || enhancers.contains((Holder)this.requiredEnhancer.get());
   }

   @DoNotCall
   public boolean matches(@NotNull ClibanoRecipeInput recipeInput, @NotNull Level level) {
      List<ItemStack> inputs = new ArrayList(recipeInput.getInputs());
      List<Ingredient> list = (List)this.ingredients.map(List::of, (pair) -> {
         return List.of((Ingredient)pair.getFirst(), (Ingredient)pair.getSecond());
      });
      return RecipeMatcher.findMatches(inputs, list) != null;
   }

   @NotNull
   public ItemStack assemble(@NotNull ClibanoRecipeInput recipeInput, @NotNull Provider lookupProvider) {
      return this.result.copy();
   }

   public boolean canCraftInDimensions(int width, int height) {
      return true;
   }

   @NotNull
   public ItemStack getResultItem(@NotNull Provider lookupProvider) {
      return this.result;
   }

   @NotNull
   public NonNullList<Ingredient> getIngredients() {
      return (NonNullList)this.ingredients.map((ingredient) -> {
         return NonNullList.of(Ingredient.EMPTY, new Ingredient[]{ingredient});
      }, (pair) -> {
         return NonNullList.of(Ingredient.EMPTY, new Ingredient[]{(Ingredient)pair.getFirst(), (Ingredient)pair.getSecond()});
      });
   }

   public int getDefaultCookingTime() {
      return this.cookingTimes.get(this.requiredFireType);
   }

   public float getExperience() {
      return this.experience;
   }

   public boolean isDoubleRecipe() {
      return this.ingredients.right().isPresent();
   }

   @NotNull
   public RecipeSerializer<?> getSerializer() {
      return (RecipeSerializer)ModRecipeSerializers.CLIBANO_SERIALIZER.get();
   }

   @NotNull
   public RecipeType<?> getType() {
      return (RecipeType)ModRecipeTypes.CLIBANO_COMBUSTION.get();
   }

   @NotNull
   public ItemStack getToastSymbol() {
      return new ItemStack((ItemLike)ModBlocks.CLIBANO_CORE.get());
   }

   public String group() {
      return this.group;
   }

   public CookingBookCategory category() {
      return this.category;
   }

   public Either<Ingredient, Pair<Ingredient, Ingredient>> ingredients() {
      return this.ingredients;
   }

   public ItemStack result() {
      return this.result;
   }

   public float experience() {
      return this.experience;
   }

   public ClibanoCookingTimes cookingTimes() {
      return this.cookingTimes;
   }

   public Optional<ResidueChance> residueChance() {
      return this.residueChance;
   }

   public ClibanoFireType requiredFireType() {
      return this.requiredFireType;
   }

   public Optional<Holder<EnhancerDefinition>> requiredEnhancer() {
      return this.requiredEnhancer;
   }

   public static class Serializer implements RecipeSerializer<ClibanoRecipe> {
      private static final MapCodec<ClibanoRecipe> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
         return instance.group(Codec.STRING.optionalFieldOf("group", "").forGetter(ClibanoRecipe::group), CookingBookCategory.CODEC.fieldOf("category").orElse(CookingBookCategory.MISC).forGetter(ClibanoRecipe::category), Codec.either(Ingredient.CODEC_NONEMPTY, Codec.mapPair(Ingredient.MAP_CODEC_NONEMPTY.fieldOf("first"), Ingredient.MAP_CODEC_NONEMPTY.fieldOf("second")).codec()).fieldOf("ingredients").forGetter(ClibanoRecipe::ingredients), ItemStack.STRICT_CODEC.fieldOf("result").forGetter(ClibanoRecipe::result), Codec.FLOAT.fieldOf("experience").orElse(0.0F).forGetter(ClibanoRecipe::experience), ClibanoCookingTimes.CODEC.fieldOf("cooking_time").orElse(ClibanoRecipe.DEFAULT_COOKING_TIMES).forGetter(ClibanoRecipe::cookingTimes), ResidueChance.CODEC.optionalFieldOf("residue").forGetter(ClibanoRecipe::residueChance), ClibanoFireType.CODEC.fieldOf("fire_type").orElse(ClibanoFireType.FIRE).forGetter(ClibanoRecipe::requiredFireType), EnhancerDefinition.REFERENCE_CODEC.optionalFieldOf("enhancer").forGetter(ClibanoRecipe::requiredEnhancer)).apply(instance, ClibanoRecipe::new);
      });
      public static final StreamCodec<RegistryFriendlyByteBuf, ClibanoRecipe> STREAM_CODEC;

      @NotNull
      public MapCodec<ClibanoRecipe> codec() {
         return CODEC;
      }

      @NotNull
      public StreamCodec<RegistryFriendlyByteBuf, ClibanoRecipe> streamCodec() {
         return STREAM_CODEC;
      }

      static {
         STREAM_CODEC = ByteBufCodecs.fromCodecWithRegistries(CODEC.codec());
      }
   }
}
