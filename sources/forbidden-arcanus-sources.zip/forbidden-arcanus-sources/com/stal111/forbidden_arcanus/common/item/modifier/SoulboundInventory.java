package com.stal111.forbidden_arcanus.common.item.modifier;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.item.ItemStack;

public record SoulboundInventory(List<SoulboundInventory.Entry> entries) {
   public static final Codec<SoulboundInventory> CODEC;

   public SoulboundInventory(List<SoulboundInventory.Entry> entries) {
      this.entries = entries;
   }

   public static SoulboundInventory create() {
      return new SoulboundInventory(new ArrayList());
   }

   public void add(int slot, ItemStack stack) {
      this.entries.add(new SoulboundInventory.Entry(slot, stack));
   }

   public boolean isEmpty() {
      return this.entries.isEmpty();
   }

   public List<SoulboundInventory.Entry> entries() {
      return this.entries;
   }

   static {
      CODEC = SoulboundInventory.Entry.CODEC.listOf().xmap(SoulboundInventory::new, SoulboundInventory::entries);
   }

   public static record Entry(int slot, ItemStack stack) {
      public static final Codec<SoulboundInventory.Entry> CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(Codec.INT.fieldOf("slot").forGetter(SoulboundInventory.Entry::slot), ItemStack.CODEC.fieldOf("stack").forGetter(SoulboundInventory.Entry::stack)).apply(instance, SoulboundInventory.Entry::new);
      });

      public Entry(int slot, ItemStack stack) {
         this.slot = slot;
         this.stack = stack;
      }

      public int slot() {
         return this.slot;
      }

      public ItemStack stack() {
         return this.stack;
      }
   }
}
