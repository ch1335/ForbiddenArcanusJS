package com.stal111.forbidden_arcanus.common.item.component;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import io.netty.buffer.ByteBuf;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.TooltipProvider;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public record StoredEntity(CustomData data) implements TooltipProvider {
   private static final List<String> IGNORED_TAGS = Arrays.asList("Air", "Brain", "FallDistance", "FallFlying", "Fire", "HurtByTimestamp", "HurtTime", "Motion", "OnGround", "PortalCooldown", "Pos", "Rotation", "SleepingX", "SleepingY", "SleepingZ", "Passengers", "leash", "UUID");
   public static final Codec<StoredEntity> CODEC;
   public static final StreamCodec<ByteBuf, StoredEntity> STREAM_CODEC;
   private static final MapCodec<EntityType<?>> ENTITY_TYPE_FIELD_CODEC;
   private static final MapCodec<Component> DISPLAY_NAME_FIELD_CODEC;
   private static final String STORED_ENTITY_KEY;
   private static final String STORED_ENTITY_WITH_NAME_KEY;

   public StoredEntity(CustomData data) {
      this.data = data;
   }

   public static StoredEntity of(LivingEntity entity) {
      entity.stopRiding();
      entity.ejectPassengers();
      CompoundTag tag = new CompoundTag();
      entity.save(tag);
      List var10000 = IGNORED_TAGS;
      Objects.requireNonNull(tag);
      var10000.forEach(tag::remove);
      return new StoredEntity(CustomData.of(tag));
   }

   @Nullable
   public Entity createEntity(Level level) {
      return EntityType.loadEntityRecursive(this.data.copyTag(), level, Function.identity());
   }

   public Optional<EntityType<?>> getEntityType() {
      return this.data.read(ENTITY_TYPE_FIELD_CODEC).result();
   }

   public Optional<Component> getDisplayName() {
      return this.data.read(DISPLAY_NAME_FIELD_CODEC).result();
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> consumer, TooltipFlag flag) {
      this.getEntityType().map((type) -> {
         return Component.translatable(type.getDescriptionId());
      }).ifPresent((type) -> {
         MutableComponent component = (MutableComponent)this.getDisplayName().map((name) -> {
            return Component.translatable(STORED_ENTITY_WITH_NAME_KEY, new Object[]{type, name});
         }).orElse(Component.translatable(STORED_ENTITY_KEY, new Object[]{type}));
         component.withStyle(ChatFormatting.GRAY);
         consumer.accept(component);
      });
   }

   public CustomData data() {
      return this.data;
   }

   static {
      CODEC = CustomData.CODEC_WITH_ID.xmap(StoredEntity::new, StoredEntity::data);
      STREAM_CODEC = CustomData.STREAM_CODEC.map(StoredEntity::new, StoredEntity::data);
      ENTITY_TYPE_FIELD_CODEC = BuiltInRegistries.ENTITY_TYPE.byNameCodec().fieldOf("id");
      DISPLAY_NAME_FIELD_CODEC = ComponentSerialization.FLAT_CODEC.fieldOf("CustomName");
      STORED_ENTITY_KEY = Util.makeDescriptionId("item", ForbiddenArcanus.location("stored_entity"));
      STORED_ENTITY_WITH_NAME_KEY = Util.makeDescriptionId("item", ForbiddenArcanus.location("stored_entity.with_name"));
   }
}
