package com.stal111.forbidden_arcanus.common.item.bucket;

import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.function.Supplier;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import org.jetbrains.annotations.Nullable;

public interface CapacityBucket {
   default int getCapacity(ItemStack stack) {
      return (Integer)stack.getOrDefault(ModDataComponents.BUCKET_CAPACITY, 0);
   }

   BucketFamily getFamily();

   default Item getEmptyBucket() {
      return (Item)((Supplier)this.getFamily().fluidBuckets().get(Fluids.EMPTY)).get();
   }

   @Nullable
   default Item getFilledBucket(Fluid fluid) {
      return !this.getFamily().fluidBuckets().containsKey(fluid) ? null : (Item)((Supplier)this.getFamily().fluidBuckets().get(fluid)).get();
   }

   default Item getMilkBucket() {
      return (Item)this.getFamily().milkBucket().get();
   }

   default int getFullness(ItemStack stack) {
      return Math.max(1, (Integer)stack.getOrDefault(ModDataComponents.STORED_FLUID_AMOUNT, 1));
   }

   default ItemStack setFullness(ItemStack stack, int fullness) {
      if (fullness <= 0) {
         return this.getEmptyBucket().getDefaultInstance();
      } else {
         stack.set(ModDataComponents.STORED_FLUID_AMOUNT, Mth.clamp(fullness, 1, this.getCapacity(stack)));
         return stack;
      }
   }

   default boolean isFull(ItemStack stack) {
      if (this.getCapacity(stack) == 0) {
         return false;
      } else {
         return this.getFullness(stack) >= this.getCapacity(stack);
      }
   }
}
