package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.block.MagicalFarmlandBlock;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.neoforged.neoforge.event.EventHooks;
import net.neoforged.neoforge.event.entity.player.BonemealEvent;

public class ArcaneBoneMealItem extends BoneMealItem {
   public ArcaneBoneMealItem(Properties builder) {
      super(builder);
   }

   @Nonnull
   public InteractionResult useOn(@Nonnull UseOnContext context) {
      Level level = context.getLevel();
      BlockPos pos = context.getClickedPos();
      BlockPos offsetPos = pos.relative(context.getClickedFace());
      BlockState state = level.getBlockState(pos);
      Player player = context.getPlayer();
      ItemStack stack = context.getItemInHand();
      if (state.is(Blocks.FARMLAND)) {
         level.setBlockAndUpdate(pos, (BlockState)((MagicalFarmlandBlock)ModBlocks.MAGICAL_FARMLAND.get()).defaultBlockState().setValue(BlockStateProperties.MOISTURE, (Integer)state.getValue(BlockStateProperties.MOISTURE)));
         level.levelEvent(player, 2001, pos, Block.getId(state));
         stack.consume(1, player);
         return InteractionResult.sidedSuccess(level.isClientSide());
      } else if (applyBoneMeal(stack, level, pos, player)) {
         if (!level.isClientSide()) {
            level.levelEvent(2005, pos, 0);
         }

         return InteractionResult.sidedSuccess(level.isClientSide());
      } else {
         boolean flag = state.isFaceSturdy(level, pos, context.getClickedFace());
         if (flag && growWaterPlant(stack, level, offsetPos, context.getClickedFace())) {
            if (!level.isClientSide()) {
               level.levelEvent(2005, offsetPos, 0);
            }

            return InteractionResult.sidedSuccess(level.isClientSide());
         } else {
            return InteractionResult.PASS;
         }
      }
   }

   public static boolean applyBoneMeal(ItemStack stack, Level level, BlockPos pos, @Nullable Player player) {
      BonemealEvent event = EventHooks.fireBonemealEvent(player, level, pos, level.getBlockState(pos), stack);
      if (event.isCanceled()) {
         return event.isSuccessful();
      } else if (canGrow(level, pos)) {
         grow(level, pos);
         stack.shrink(1);
         return true;
      } else {
         return false;
      }
   }

   private static boolean canGrow(Level world, BlockPos pos) {
      BlockState state = world.getBlockState(pos);
      return state.getBlock() instanceof BonemealableBlock ? ((BonemealableBlock)state.getBlock()).isValidBonemealTarget(world, pos, state) : false;
   }

   private static void grow(Level world, BlockPos pos) {
      if (!world.isClientSide()) {
         for(int i = 0; i < 1000; ++i) {
            if (!canGrow(world, pos) || world.isClientSide()) {
               return;
            }

            ((BonemealableBlock)world.getBlockState(pos).getBlock()).performBonemeal((ServerLevel)world, world.random, pos, world.getBlockState(pos));
         }

      }
   }
}
