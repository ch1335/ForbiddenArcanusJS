package com.stal111.forbidden_arcanus.common.item.enhancer.condition;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.init.other.ModEnhancerEffectConditions;
import net.minecraft.world.level.Level;

public class TimeCondition extends EffectCondition {
   public static final MapCodec<TimeCondition> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(Codec.INT.fieldOf("start").forGetter((condition) -> {
         return condition.startTime;
      }), Codec.INT.fieldOf("end").forGetter((condition) -> {
         return condition.endTime;
      })).apply(instance, TimeCondition::new);
   });
   private final int startTime;
   private final int endTime;

   public TimeCondition(int startTime, int endTime) {
      this.startTime = startTime;
      this.endTime = endTime;
      if (startTime >= endTime) {
         throw new IllegalArgumentException("The ending time needs to be higher than the starting time!");
      }
   }

   public boolean test(Level level) {
      long dayTime = level.getDayTime();
      return dayTime >= (long)this.startTime && dayTime <= (long)this.endTime;
   }

   public EffectConditionType<? extends EffectCondition> getType() {
      return (EffectConditionType)ModEnhancerEffectConditions.TIME.get();
   }
}
