package com.stal111.forbidden_arcanus.common.item.bucket;

import net.minecraft.world.level.material.Fluid;

public interface CapacityFluidBucket extends CapacityBucket {
   Fluid getFluid();
}
