package com.stal111.forbidden_arcanus.common.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item.Properties;

public class EdelwoodOilItem extends Item {
   public EdelwoodOilItem(Properties properties) {
      super(properties);
   }

   public boolean hasCraftingRemainingItem(ItemStack stack) {
      return true;
   }

   public ItemStack getCraftingRemainingItem(ItemStack itemStack) {
      return new ItemStack(Items.GLASS_BOTTLE);
   }
}
