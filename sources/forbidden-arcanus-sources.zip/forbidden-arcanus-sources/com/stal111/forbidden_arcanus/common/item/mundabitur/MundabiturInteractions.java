package com.stal111.forbidden_arcanus.common.item.mundabitur;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.ModBlockPatterns;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.predicate.BlockStatePredicate;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class MundabiturInteractions {
   public static final MappedRegistryHelper<MundabiturInteraction<?>> HELPER;
   public static final RegistryEntry<MundabiturInteraction<?>, ChargeCreeperInteraction> CHARGE_CREEPER;
   public static final RegistryEntry<MundabiturInteraction<?>, TransformPatternInteraction> CREATE_HEPHAESTUS_FORGE;
   public static final RegistryEntry<MundabiturInteraction<?>, TransformPatternInteraction> CREATE_OBELISK;
   public static final RegistryEntry<MundabiturInteraction<?>, TransformPatternInteraction> CREATE_CLIBANO;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.MUNDABITUR_INTERACTION);
      CHARGE_CREEPER = HELPER.register("charge_creeper", ChargeCreeperInteraction::new);
      CREATE_HEPHAESTUS_FORGE = HELPER.register("create_hephaestus_forge", () -> {
         return new CreateForgeInteraction(BlockStatePredicate.forBlock(Blocks.SMITHING_TABLE), ModBlockPatterns.HEPHAESTUS_PATTERN);
      });
      CREATE_OBELISK = HELPER.register("create_obelisk", () -> {
         return new CreateObeliskInteraction(BlockStatePredicate.forBlock((Block)ModBlocks.ARCANE_CRYSTAL_BLOCK.get()).or(BlockStatePredicate.forBlock((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE.get())), ModBlockPatterns.ARCANE_CRYSTAL_OBELISK_PATTERN);
      });
      CREATE_CLIBANO = HELPER.register("create_clibano", () -> {
         return new CreateClibanoInteraction(BlockStatePredicate.forBlock((Block)ModBlocks.CLIBANO_CORE.get()), ModBlockPatterns.CLIBANO_COMBUSTION_BASE);
      });
   }
}
