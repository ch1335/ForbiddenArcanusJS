package com.stal111.forbidden_arcanus.common.item.mundabitur;

import net.minecraft.core.BlockPos;

public interface MundabiturInteraction<T extends MundabiturInteraction.Context> {
   void interact(T var1);

   boolean canInteract(T var1);

   public interface Context {
      BlockPos getPos();
   }
}
