package com.stal111.forbidden_arcanus.common.item.enhancer;

import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;

public class EnhancerHelper {
   public static Optional<EnhancerDefinition> getEnhancer(Provider lookupProvider, ItemStack stack) {
      return getEnhancerHolder(lookupProvider, stack).map(Holder::value);
   }

   public static Optional<Holder<EnhancerDefinition>> getEnhancerHolder(Provider lookupProvider, ItemStack stack) {
      Optional var10000 = Optional.ofNullable((ResourceKey)stack.get(ModDataComponents.ENHANCER));
      Objects.requireNonNull(lookupProvider);
      return var10000.flatMap(lookupProvider::holder);
   }
}
