package com.stal111.forbidden_arcanus.common.item.bucket;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BucketPickup;
import net.minecraft.world.level.block.PowderSnowBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult.Type;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;
import net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction;
import org.jetbrains.annotations.NotNull;

public class CapacityBucketItem extends BucketItem implements CapacityFluidBucket {
   private static final double BURN_CHANCE = 0.005D;
   private final Fluid fluid;
   private final BucketFamily family;

   public CapacityBucketItem(Fluid fluid, BucketFamily family, Properties builder) {
      super(fluid, builder);
      this.fluid = fluid;
      this.family = family;
   }

   @NotNull
   public InteractionResult interactLivingEntity(@NotNull ItemStack stack, @NotNull Player player, @NotNull LivingEntity livingEntity, @NotNull InteractionHand hand) {
      return CapacityMilkBucketItem.tryMilk(stack.copy(), player, livingEntity, hand, this);
   }

   public void inventoryTick(@NotNull ItemStack stack, @NotNull Level level, @NotNull Entity entity, int slot, boolean isSelected) {
      if (!level.isClientSide() && entity instanceof LivingEntity) {
         LivingEntity livingEntity = (LivingEntity)entity;
         if (this.getFluid().isSame(Fluids.LAVA) && level.getRandom().nextDouble() < 0.005D && !livingEntity.hasInfiniteMaterials()) {
            livingEntity.getSlot(slot).set(Items.CHARCOAL.getDefaultInstance());
            level.setBlockAndUpdate(entity.blockPosition(), this.getFluid().defaultFluidState().createLegacyBlock());
         }

      }
   }

   @NotNull
   public InteractionResultHolder<ItemStack> use(@NotNull Level level, @NotNull Player player, @NotNull InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      BlockHitResult hitResult = getPlayerPOVHitResult(level, player, !this.getFluid().isSame(Fluids.EMPTY) && this.isFull(stack) ? net.minecraft.world.level.ClipContext.Fluid.NONE : net.minecraft.world.level.ClipContext.Fluid.SOURCE_ONLY);
      if (hitResult.getType() != Type.BLOCK) {
         return InteractionResultHolder.pass(stack);
      } else {
         BlockPos pos = hitResult.getBlockPos();
         Direction direction = hitResult.getDirection();
         BlockPos relativePos = pos.relative(direction);
         if (level.mayInteract(player, pos) && player.mayUseItemAt(relativePos, direction, stack)) {
            IFluidHandlerItem fluidHandlerItem = (IFluidHandlerItem)FluidUtil.getFluidHandler(stack.copyWithCount(1)).orElseThrow(() -> {
               return new IllegalStateException("CapacityBucketItem did not have a fluid handler capability!");
            });
            BlockState state = level.getBlockState(pos);
            FluidState fluid = level.getFluidState(pos);
            boolean isEmpty = this.getFluid().isSame(Fluids.EMPTY);
            ItemStack result;
            if (isEmpty || !this.isFull(stack)) {
               Block var14 = state.getBlock();
               if (var14 instanceof BucketPickup) {
                  BucketPickup bucketPickup = (BucketPickup)var14;
                  if (!fluid.isEmpty() || bucketPickup instanceof PowderSnowBlock) {
                     result = this.fillBucket(fluidHandlerItem, fluid, bucketPickup, player, level, pos, state);
                     return InteractionResultHolder.sidedSuccess(ItemUtils.createFilledResult(stack, player, result), level.isClientSide());
                  }
               }
            }

            BlockPos placePos = this.canBlockContainFluid(player, level, pos, state) ? pos : relativePos;
            if (this.emptyContents(player, level, placePos, hitResult, stack)) {
               this.checkExtraContent(player, level, stack, placePos);
               fluidHandlerItem.drain(1000, FluidAction.EXECUTE);
               if (player instanceof ServerPlayer) {
                  ServerPlayer serverPlayer = (ServerPlayer)player;
                  CriteriaTriggers.PLACED_BLOCK.trigger(serverPlayer, placePos, stack);
               }

               player.awardStat(Stats.ITEM_USED.get(this));
               result = player.getAbilities().instabuild ? stack : fluidHandlerItem.getContainer();
               return InteractionResultHolder.sidedSuccess(result, level.isClientSide());
            } else {
               return InteractionResultHolder.fail(stack);
            }
         } else {
            return InteractionResultHolder.fail(stack);
         }
      }
   }

   private ItemStack fillBucket(IFluidHandlerItem fluidHandlerItem, FluidState fluid, BucketPickup bucketPickup, Player player, Level level, BlockPos pos, BlockState state) {
      bucketPickup.pickupBlock(player, level, pos, state);
      ItemStack filledBucket;
      if (!fluid.isEmpty() && fluidHandlerItem.isFluidValid(0, new FluidStack(fluid.getType(), 1000))) {
         fluidHandlerItem.fill(new FluidStack(fluid.getType(), 1000), FluidAction.EXECUTE);
         filledBucket = fluidHandlerItem.getContainer().copy();
      } else {
         filledBucket = new ItemStack((ItemLike)this.family.powderSnowBucket().get());
      }

      bucketPickup.getPickupSound(state).ifPresent((soundEvent) -> {
         player.playSound(soundEvent, 1.0F, 1.0F);
      });
      level.gameEvent(player, GameEvent.FLUID_PICKUP, pos);
      player.awardStat(Stats.ITEM_USED.get(this));
      if (player instanceof ServerPlayer) {
         ServerPlayer serverPlayer = (ServerPlayer)player;
         CriteriaTriggers.FILLED_BUCKET.trigger(serverPlayer, filledBucket);
      }

      return filledBucket;
   }

   public BucketFamily getFamily() {
      return this.family;
   }

   public Fluid getFluid() {
      return this.fluid;
   }
}
