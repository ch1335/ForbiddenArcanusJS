package com.stal111.forbidden_arcanus.common.item.bucket;

import com.google.common.collect.ImmutableMap;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;

public record BucketFamily(Map<Fluid, Supplier<? extends Item>> fluidBuckets, Supplier<? extends Item> milkBucket, Supplier<? extends Item> powderSnowBucket) {
   public static final BucketFamily EDELWOOD_BUCKET;

   public BucketFamily(Map<Fluid, Supplier<? extends Item>> fluidBuckets, Supplier<? extends Item> milkBucket, Supplier<? extends Item> powderSnowBucket) {
      this.fluidBuckets = fluidBuckets;
      this.milkBucket = milkBucket;
      this.powderSnowBucket = powderSnowBucket;
   }

   public Map<Fluid, Supplier<? extends Item>> fluidBuckets() {
      return this.fluidBuckets;
   }

   public Supplier<? extends Item> milkBucket() {
      return this.milkBucket;
   }

   public Supplier<? extends Item> powderSnowBucket() {
      return this.powderSnowBucket;
   }

   static {
      EDELWOOD_BUCKET = new BucketFamily(ImmutableMap.of(Fluids.EMPTY, ModItems.EDELWOOD_BUCKET, Fluids.WATER, ModItems.EDELWOOD_WATER_BUCKET, Fluids.LAVA, ModItems.EDELWOOD_LAVA_BUCKET), ModItems.EDELWOOD_MILK_BUCKET, ModItems.EDELWOOD_POWDER_SNOW_BUCKET);
   }
}
