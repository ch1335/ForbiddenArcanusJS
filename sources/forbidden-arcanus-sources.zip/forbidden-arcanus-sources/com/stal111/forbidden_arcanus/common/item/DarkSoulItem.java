package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.common.block.GrowingEdelwoodBlock;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import javax.annotation.Nonnull;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class DarkSoulItem extends Item {
   public DarkSoulItem(Properties properties) {
      super(properties);
   }

   @Nonnull
   public InteractionResult useOn(@Nonnull UseOnContext context) {
      Level level = context.getLevel();
      BlockPos pos = context.getClickedPos();
      BlockState state = level.getBlockState(pos);
      Player player = context.getPlayer();
      ItemStack stack = context.getItemInHand();
      if (!state.is(Blocks.OAK_SAPLING) && !state.is(Blocks.DEAD_BUSH)) {
         return super.useOn(context);
      } else {
         level.setBlock(pos, ((GrowingEdelwoodBlock)ModBlocks.GROWING_EDELWOOD.get()).defaultBlockState(), 11);
         Player var8 = context.getPlayer();
         if (var8 instanceof ServerPlayer) {
            ServerPlayer serverPlayer = (ServerPlayer)var8;
            CriteriaTriggers.ITEM_USED_ON_BLOCK.trigger(serverPlayer, pos, stack);
         }

         stack.consume(1, player);
         return InteractionResult.sidedSuccess(level.isClientSide());
      }
   }
}
