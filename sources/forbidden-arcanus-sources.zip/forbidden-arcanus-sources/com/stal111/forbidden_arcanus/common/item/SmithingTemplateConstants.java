package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.item.SmithingTemplateItem;

public class SmithingTemplateConstants {
   private static final ChatFormatting TITLE_FORMAT;
   private static final ChatFormatting DESCRIPTION_FORMAT;
   private static final Component DARKSTONE_UPGRADE;
   private static final Component DARKSTONE_UPGRADE_APPLIES_TO;
   private static final Component DARKSTONE_UPGRADE_INGREDIENTS;
   private static final Component DARKSTONE_UPGRADE_ADDITIONS_SLOT_DESCRIPTION;
   private static final Component DARKSTONE_UPGRADE_BASE_SLOT_DESCRIPTION;
   private static final ResourceLocation EMPTY_SLOT_HELMET;
   private static final ResourceLocation EMPTY_SLOT_CHESTPLATE;
   private static final ResourceLocation EMPTY_SLOT_LEGGINGS;
   private static final ResourceLocation EMPTY_SLOT_BOOTS;
   private static final ResourceLocation EMPTY_SLOT_HOE;
   private static final ResourceLocation EMPTY_SLOT_AXE;
   private static final ResourceLocation EMPTY_SLOT_SWORD;
   private static final ResourceLocation EMPTY_SLOT_SHOVEL;
   private static final ResourceLocation EMPTY_SLOT_PICKAXE;
   private static final ResourceLocation EMPTY_SLOT_INGOT;

   public static SmithingTemplateItem createApplyModifierTemplate() {
      return new SmithingTemplateItem(DARKSTONE_UPGRADE_APPLIES_TO, DARKSTONE_UPGRADE_INGREDIENTS, DARKSTONE_UPGRADE, DARKSTONE_UPGRADE_BASE_SLOT_DESCRIPTION, DARKSTONE_UPGRADE_ADDITIONS_SLOT_DESCRIPTION, createDarkstoneUpgradeIconList(), createDarkstoneUpgradeMaterialList(), new FeatureFlag[0]);
   }

   private static List<ResourceLocation> createDarkstoneUpgradeIconList() {
      return List.of(EMPTY_SLOT_HELMET, EMPTY_SLOT_SWORD, EMPTY_SLOT_CHESTPLATE, EMPTY_SLOT_PICKAXE, EMPTY_SLOT_LEGGINGS, EMPTY_SLOT_AXE, EMPTY_SLOT_BOOTS, EMPTY_SLOT_HOE, EMPTY_SLOT_SHOVEL);
   }

   private static List<ResourceLocation> createDarkstoneUpgradeMaterialList() {
      return List.of(EMPTY_SLOT_INGOT);
   }

   static {
      TITLE_FORMAT = ChatFormatting.GRAY;
      DESCRIPTION_FORMAT = ChatFormatting.BLUE;
      DARKSTONE_UPGRADE = Component.translatable(Util.makeDescriptionId("upgrade", ForbiddenArcanus.location("darkstone_upgrade"))).withStyle(TITLE_FORMAT);
      DARKSTONE_UPGRADE_APPLIES_TO = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("smithing_template.darkstone_upgrade.applies_to"))).withStyle(DESCRIPTION_FORMAT);
      DARKSTONE_UPGRADE_INGREDIENTS = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("smithing_template.darkstone_upgrade.ingredients"))).withStyle(DESCRIPTION_FORMAT);
      DARKSTONE_UPGRADE_ADDITIONS_SLOT_DESCRIPTION = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("smithing_template.darkstone_upgrade.additions_slot_description")));
      DARKSTONE_UPGRADE_BASE_SLOT_DESCRIPTION = Component.translatable(Util.makeDescriptionId("item", ForbiddenArcanus.location("smithing_template.darkstone_upgrade.base_slot_description")));
      EMPTY_SLOT_HELMET = ResourceLocation.withDefaultNamespace("item/empty_armor_slot_helmet");
      EMPTY_SLOT_CHESTPLATE = ResourceLocation.withDefaultNamespace("item/empty_armor_slot_chestplate");
      EMPTY_SLOT_LEGGINGS = ResourceLocation.withDefaultNamespace("item/empty_armor_slot_leggings");
      EMPTY_SLOT_BOOTS = ResourceLocation.withDefaultNamespace("item/empty_armor_slot_boots");
      EMPTY_SLOT_HOE = ResourceLocation.withDefaultNamespace("item/empty_slot_hoe");
      EMPTY_SLOT_AXE = ResourceLocation.withDefaultNamespace("item/empty_slot_axe");
      EMPTY_SLOT_SWORD = ResourceLocation.withDefaultNamespace("item/empty_slot_sword");
      EMPTY_SLOT_SHOVEL = ResourceLocation.withDefaultNamespace("item/empty_slot_shovel");
      EMPTY_SLOT_PICKAXE = ResourceLocation.withDefaultNamespace("item/empty_slot_pickaxe");
      EMPTY_SLOT_INGOT = ResourceLocation.withDefaultNamespace("item/empty_slot_ingot");
   }
}
