package com.stal111.forbidden_arcanus.common.item.bucket;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;
import net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction;
import org.jetbrains.annotations.NotNull;

public class CapacityBucketFluidHandler implements IFluidHandlerItem {
   private final CapacityFluidBucket bucket;
   private ItemStack container;

   public CapacityBucketFluidHandler(CapacityFluidBucket bucket, ItemStack container) {
      this.bucket = bucket;
      this.container = container;
   }

   private int getFullness() {
      return this.bucket.getFullness(this.container);
   }

   private void setFluid(@NotNull FluidStack fluidStack) {
      Item item = this.bucket.getFilledBucket(fluidStack.getFluid());
      if (item != null) {
         this.container = new ItemStack(item);
      }

   }

   @NotNull
   public ItemStack getContainer() {
      return this.container;
   }

   public int getTanks() {
      return 1;
   }

   @NotNull
   public FluidStack getFluidInTank(int tank) {
      return new FluidStack(this.bucket.getFluid(), 1000 * this.getFullness());
   }

   public int getTankCapacity(int tank) {
      return this.bucket.getCapacity(this.container);
   }

   public boolean isFluidValid(int tank, @NotNull FluidStack stack) {
      FluidStack fluidStack = this.getFluidInTank(tank);
      if (fluidStack.isEmpty()) {
         return this.bucket.getFilledBucket(stack.getFluid()) != null;
      } else {
         return FluidStack.isSameFluidSameComponents(stack, fluidStack);
      }
   }

   public int fill(FluidStack resource, FluidAction action) {
      if (this.container.getCount() == 1 && resource.getAmount() >= 1000 && !this.bucket.isFull(this.container)) {
         if (action.execute()) {
            int fullness = this.getFullness();
            if (this.container.is(this.bucket.getEmptyBucket())) {
               this.setFluid(resource);
               return 1000;
            } else {
               int fillAmount = Math.min(this.bucket.getCapacity(this.container) - fullness, resource.getAmount() / 1000);
               this.bucket.setFullness(this.container, fullness + fillAmount);
               return fillAmount * 1000;
            }
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }

   @NotNull
   public FluidStack drain(FluidStack resource, FluidAction action) {
      return this.container.getCount() == 1 && resource.getAmount() >= 1000 && FluidStack.isSameFluidSameComponents(resource, this.getFluidInTank(0)) ? this.drain(resource.getAmount(), action) : FluidStack.EMPTY;
   }

   @NotNull
   public FluidStack drain(int maxDrain, FluidAction action) {
      if (this.container.getCount() == 1 && maxDrain >= 1000) {
         int fullness = this.getFullness();
         if (action.execute() && fullness != 0) {
            int drainAmount = Math.min(fullness, maxDrain / 1000);
            this.bucket.setFullness(this.container, fullness - drainAmount);
            if (fullness - drainAmount <= 0) {
               this.setFluid(FluidStack.EMPTY);
            }

            return new FluidStack(this.bucket.getFluid(), drainAmount * 1000);
         } else {
            return FluidStack.EMPTY;
         }
      } else {
         return FluidStack.EMPTY;
      }
   }
}
