package com.stal111.forbidden_arcanus.common.item.enhancer.effect;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceModifier;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.core.init.other.ModEnhancerEffects;

public record ModifyRequiredEssenceEffect(EssenceType essenceType, int value) implements ValueModifierEffect<Integer>, EssenceModifier {
   public static final MapCodec<ModifyRequiredEssenceEffect> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(EssenceType.CODEC.fieldOf("essence_type").forGetter(ModifyRequiredEssenceEffect::essenceType), Codec.INT.fieldOf("value").forGetter(ModifyRequiredEssenceEffect::value)).apply(instance, ModifyRequiredEssenceEffect::new);
   });

   public ModifyRequiredEssenceEffect(EssenceType essenceType, int value) {
      this.essenceType = essenceType;
      this.value = value;
   }

   public Integer getModifiedValue(Integer originalValue) {
      return Math.max(0, originalValue + this.value);
   }

   public EssenceType getEssenceType() {
      return this.essenceType;
   }

   public EnhancerEffectType<? extends EnhancerEffect> getType() {
      return (EnhancerEffectType)ModEnhancerEffects.MODIFY_REQUIRED_ESSENCE.get();
   }

   public EssenceType essenceType() {
      return this.essenceType;
   }

   public int value() {
      return this.value;
   }
}
