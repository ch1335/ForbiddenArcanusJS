package com.stal111.forbidden_arcanus.common.item.mundabitur;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;

public abstract class EntityInteraction implements MundabiturInteraction<EntityInteraction.EntityInteractionContext> {
   public static record EntityInteractionContext(LivingEntity entity, InteractionHand hand) implements MundabiturInteraction.Context {
      public EntityInteractionContext(LivingEntity entity, InteractionHand hand) {
         this.entity = entity;
         this.hand = hand;
      }

      public static EntityInteraction.EntityInteractionContext of(LivingEntity entity, InteractionHand hand) {
         return new EntityInteraction.EntityInteractionContext(entity, hand);
      }

      public BlockPos getPos() {
         return this.entity.blockPosition();
      }

      public LivingEntity entity() {
         return this.entity;
      }

      public InteractionHand hand() {
         return this.hand;
      }
   }
}
