package com.stal111.forbidden_arcanus.common.item.modifier;

import com.mojang.datafixers.util.Pair;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ClientboundBlockDestructionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;

public class DemolishingModifierBlockBreaker {
   private static final Map<UUID, DemolishingModifierBlockBreaker> ACTIVE_BREAKERS = new HashMap();
   private static final Map<UUID, DemolishingModifierBlockBreaker> ACTIVE_CLIENT_BREAKERS = new HashMap();
   private final Level level;
   private final BlockPos pos;
   private final BlockState state;
   private final Player player;
   private final Map<BlockPos, Integer> idFromPos;

   private DemolishingModifierBlockBreaker(Level level, BlockPos pos, BlockState state, Player player, List<BlockPos> positions) {
      this.level = level;
      this.pos = pos;
      this.state = state;
      this.player = player;
      this.idFromPos = (Map)positions.stream().collect(Collectors.toMap(Function.identity(), (offsetPos) -> {
         return player.getRandom().nextInt(5000);
      }));
   }

   public static DemolishingModifierBlockBreaker getOrCreate(Level level, BlockPos pos, BlockState state, Player player) {
      UUID uuid = player.getUUID();
      boolean createBreaker = !containsBreaker(level, uuid);
      if (!createBreaker && !getBreaker(level, uuid).getPos().equals(pos)) {
         createBreaker = true;
         getBreaker(level, uuid).stop();
      }

      if (createBreaker) {
         create(level, pos, state, player);
      }

      return getBreaker(level, uuid);
   }

   private static void create(Level level, BlockPos pos, BlockState state, Player player) {
      List<BlockPos> positions = (new DemolishingModifierBlockBreaker.BlockScanner(pos)).getValidPositions(level, calculateBlockSide(level, player), (offsetState) -> {
         return offsetState.is(state.getBlock());
      });
      putBreaker(level, player.getUUID(), new DemolishingModifierBlockBreaker(level, pos, state, player, positions));
   }

   private static Direction calculateBlockSide(Level level, Player player) {
      Vec3 eyePosition = player.getEyePosition();
      Vec3 viewVector = player.getViewVector(1.0F);
      double reach = player.getAttributeValue(Attributes.BLOCK_INTERACTION_RANGE);
      Vec3 combined = eyePosition.add(viewVector.x * reach, viewVector.y * reach, viewVector.z * reach);
      BlockHitResult hitResult = level.clip(new ClipContext(eyePosition, combined, Block.OUTLINE, Fluid.NONE, player));
      return hitResult.getType() != Type.BLOCK ? Direction.NORTH : hitResult.getDirection();
   }

   private static DemolishingModifierBlockBreaker getBreaker(Level level, UUID uuid) {
      return level.isClientSide() ? (DemolishingModifierBlockBreaker)ACTIVE_CLIENT_BREAKERS.getOrDefault(uuid, (Object)null) : (DemolishingModifierBlockBreaker)ACTIVE_BREAKERS.getOrDefault(uuid, (Object)null);
   }

   private static boolean containsBreaker(Level level, UUID uuid) {
      return level.isClientSide() ? ACTIVE_CLIENT_BREAKERS.containsKey(uuid) : ACTIVE_BREAKERS.containsKey(uuid);
   }

   private static void putBreaker(Level level, UUID uuid, DemolishingModifierBlockBreaker breaker) {
      if (level.isClientSide()) {
         ACTIVE_CLIENT_BREAKERS.put(uuid, breaker);
      } else {
         ACTIVE_BREAKERS.put(uuid, breaker);
      }
   }

   private static void removeBreaker(Level level, UUID uuid) {
      if (level.isClientSide()) {
         ACTIVE_CLIENT_BREAKERS.remove(uuid);
      } else {
         ACTIVE_BREAKERS.remove(uuid);
      }
   }

   public static Optional<DemolishingModifierBlockBreaker> get(Level level, Player player) {
      return Optional.ofNullable(getBreaker(level, player.getUUID()));
   }

   public void update(int destroyProgress) {
      if (this.checkPositions()) {
         Iterator var2 = this.idFromPos.keySet().iterator();

         while(var2.hasNext()) {
            BlockPos offsetPos = (BlockPos)var2.next();
            if (destroyProgress >= 10) {
               return;
            }

            this.updateBreakingProgress(offsetPos, destroyProgress);
         }

      }
   }

   private boolean checkPositions() {
      Iterator iterator = this.idFromPos.entrySet().iterator();

      while(iterator.hasNext()) {
         BlockPos pos = (BlockPos)((Entry)iterator.next()).getKey();
         if (!this.level.getBlockState(pos).is(this.state.getBlock())) {
            iterator.remove();
         }
      }

      if (this.idFromPos.isEmpty()) {
         this.stop();
         return false;
      } else {
         return true;
      }
   }

   public void stop() {
      this.idFromPos.forEach((offsetPos, integer) -> {
         this.updateBreakingProgress(offsetPos, -1);
      });
      removeBreaker(this.level, this.player.getUUID());
   }

   public void breakBlocks(ServerPlayer player) {
      this.stop();
      Set var10000 = this.idFromPos.keySet();
      ServerPlayerGameMode var10001 = player.gameMode;
      Objects.requireNonNull(var10001);
      var10000.forEach(var10001::destroyBlock);
   }

   private void updateBreakingProgress(BlockPos pos, int progress) {
      int id = (Integer)this.idFromPos.get(pos);
      Level var5 = this.level;
      if (var5 instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)var5;
         Iterator var13 = serverLevel.getServer().getPlayerList().getPlayers().iterator();

         while(var13.hasNext()) {
            ServerPlayer serverPlayer = (ServerPlayer)var13.next();
            if (serverPlayer != null && serverPlayer.level() == serverLevel && serverPlayer.getId() != this.player.getId()) {
               double d0 = (double)pos.getX() - serverPlayer.getX();
               double d1 = (double)pos.getY() - serverPlayer.getY();
               double d2 = (double)pos.getZ() - serverPlayer.getZ();
               if (d0 * d0 + d1 * d1 + d2 * d2 < 1024.0D) {
                  serverPlayer.connection.send(new ClientboundBlockDestructionPacket(id, pos, progress));
               }
            }
         }

      } else {
         this.level.destroyBlockProgress(id, pos, progress);
      }
   }

   public BlockPos getPos() {
      return this.pos;
   }

   private static record BlockScanner(BlockPos centerPos) {
      private BlockScanner(BlockPos centerPos) {
         this.centerPos = centerPos;
      }

      private List<BlockPos> getValidPositions(Level level, Direction facing, Predicate<BlockState> predicate) {
         int data3d = facing.get3DDataValue();
         Pair<BlockPos, BlockPos> cornerPositions = this.getCornerPositions(Direction.from3DDataValue(data3d + 2), Direction.from3DDataValue(data3d + 4));
         return BlockPos.betweenClosedStream((BlockPos)cornerPositions.getFirst(), (BlockPos)cornerPositions.getSecond()).filter((pos) -> {
            return predicate.test(level.getBlockState(pos));
         }).filter((pos) -> {
            return !pos.equals(this.centerPos);
         }).map(BlockPos::immutable).toList();
      }

      private Pair<BlockPos, BlockPos> getCornerPositions(Direction first, Direction second) {
         return Pair.of(this.centerPos.relative(first, 1).relative(second, 1), this.centerPos.relative(first, -1).relative(second, -1));
      }

      public BlockPos centerPos() {
         return this.centerPos;
      }
   }
}
