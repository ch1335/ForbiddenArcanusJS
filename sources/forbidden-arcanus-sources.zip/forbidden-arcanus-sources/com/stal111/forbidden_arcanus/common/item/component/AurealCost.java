package com.stal111.forbidden_arcanus.common.item.component;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.common.advancements.critereon.EssenceValueEntityPredicate;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import io.netty.buffer.ByteBuf;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.EntityPredicate.Builder;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public record AurealCost(int value) {
   public static final Codec<AurealCost> CODEC;
   public static final StreamCodec<ByteBuf, AurealCost> STREAM_CODEC;
   public static final AurealCost ZERO;

   public AurealCost(int value) {
      this.value = value;
   }

   public boolean hasEnough(ServerLevel level, LivingEntity livingEntity) {
      EntityPredicate predicate = Builder.entity().subPredicate(new EssenceValueEntityPredicate(new EssenceValue(EssenceType.AUREAL, this.value))).build();
      return predicate.matches(level, (Vec3)null, livingEntity);
   }

   public int value() {
      return this.value;
   }

   static {
      CODEC = ExtraCodecs.POSITIVE_INT.fieldOf("value").xmap(AurealCost::new, AurealCost::value).codec();
      STREAM_CODEC = ByteBufCodecs.VAR_INT.map(AurealCost::new, AurealCost::value);
      ZERO = new AurealCost(0);
   }
}
