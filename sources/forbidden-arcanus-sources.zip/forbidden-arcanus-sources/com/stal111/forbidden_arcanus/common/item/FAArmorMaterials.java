package com.stal111.forbidden_arcanus.common.item;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.ArmorMaterial.Layer;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class FAArmorMaterials {
   public static final MappedRegistryHelper<ArmorMaterial> HELPER;
   public static final Holder<ArmorMaterial> DRACO_ARCANUS;
   public static final Holder<ArmorMaterial> TYR;
   public static final Holder<ArmorMaterial> MORTEM;

   public static Holder<ArmorMaterial> register(String name, EnumMap<Type, Integer> protectionFunctionForType, int enchantmentValue, Holder<SoundEvent> sound, Supplier<Ingredient> repairIngredient, float toughness, float knockbackResistance) {
      return HELPER.register(name, () -> {
         return new ArmorMaterial(protectionFunctionForType, enchantmentValue, sound, repairIngredient, List.of(new Layer(ForbiddenArcanus.location(name))), toughness, knockbackResistance);
      });
   }

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(Registries.ARMOR_MATERIAL);
      DRACO_ARCANUS = register("draco_arcanus", (EnumMap)Util.make(new EnumMap(Type.class), (map) -> {
         map.put(Type.BOOTS, 6);
         map.put(Type.LEGGINGS, 8);
         map.put(Type.CHESTPLATE, 10);
         map.put(Type.HELMET, 6);
      }), 15, SoundEvents.ARMOR_EQUIP_GENERIC, () -> {
         return Ingredient.of(new ItemLike[]{(ItemLike)ModItems.DRAGON_SCALE.get()});
      }, 2.0F, 0.0F);
      TYR = register("tyr", (EnumMap)Util.make(new EnumMap(Type.class), (map) -> {
         map.put(Type.BOOTS, 7);
         map.put(Type.LEGGINGS, 10);
         map.put(Type.CHESTPLATE, 12);
         map.put(Type.HELMET, 8);
      }), 15, SoundEvents.ARMOR_EQUIP_GENERIC, () -> {
         return Ingredient.of(new ItemLike[]{(ItemLike)ModItems.GOLDEN_DRAGON_SCALE.get(), (ItemLike)ModItems.AQUATIC_DRAGON_SCALE.get()});
      }, 3.0F, 0.1F);
      MORTEM = register("mortem", (EnumMap)Util.make(new EnumMap(Type.class), (map) -> {
         map.put(Type.BOOTS, 1);
         map.put(Type.LEGGINGS, 4);
         map.put(Type.CHESTPLATE, 5);
         map.put(Type.HELMET, 1);
      }), 6, SoundEvents.ARMOR_EQUIP_GENERIC, () -> {
         return Ingredient.EMPTY;
      }, 1.0F, 0.0F);
   }
}
