package com.stal111.forbidden_arcanus.common.item.component;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.item.wand.WandPart;
import com.stal111.forbidden_arcanus.common.item.wand.WandStats;
import java.util.function.Consumer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;

public record WandParts(WandPart tip, WandPart transition, WandPart pommel) implements TooltipProvider {
   public static final Codec<WandParts> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(WandPart.CODEC.fieldOf("tip").forGetter(WandParts::tip), WandPart.CODEC.fieldOf("transition").forGetter(WandParts::transition), WandPart.CODEC.fieldOf("pommel").forGetter(WandParts::pommel)).apply(instance, WandParts::new);
   });

   public WandParts(WandPart tip, WandPart transition, WandPart pommel) {
      this.tip = tip;
      this.transition = transition;
      this.pommel = pommel;
   }

   public WandStats getCombinedStats() {
      return new WandStats(this.tip.stats().damageBonus() + this.transition.stats().damageBonus() + this.pommel.stats().damageBonus(), this.tip.stats().speedBonus() + this.transition.stats().speedBonus() + this.pommel.stats().speedBonus(), this.tip.stats().aimBonus() + this.transition.stats().aimBonus() + this.pommel.stats().aimBonus());
   }

   public void addToTooltip(TooltipContext context, Consumer<Component> tooltipAdder, TooltipFlag tooltipFlag) {
   }

   public WandPart tip() {
      return this.tip;
   }

   public WandPart transition() {
      return this.transition;
   }

   public WandPart pommel() {
      return this.pommel;
   }
}
