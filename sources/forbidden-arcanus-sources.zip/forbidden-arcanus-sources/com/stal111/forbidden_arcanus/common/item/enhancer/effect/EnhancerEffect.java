package com.stal111.forbidden_arcanus.common.item.enhancer.effect;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.Objects;
import net.minecraft.core.Registry;

public interface EnhancerEffect {
   Codec<ConditionalEnhancerEffect<? extends EnhancerEffect>> DIRECT_CODEC;

   EnhancerEffectType<? extends EnhancerEffect> getType();

   static {
      Registry var10000 = FARegistries.ENHANCER_EFFECT_REGISTRY;
      Objects.requireNonNull(var10000);
      DIRECT_CODEC = Codec.lazyInitialized(var10000::byNameCodec).dispatch((effect) -> {
         return effect.effect().getType();
      }, EnhancerEffectType::codec);
   }
}
