package com.stal111.forbidden_arcanus.common.network.clientbound;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.ClientPayloadHandler;
import com.stal111.forbidden_arcanus.common.essence.EssenceStorage;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record UpdateEssencePayload(EssenceStorage storage) implements CustomPacketPayload {
   public static final Type<UpdateEssencePayload> TYPE = new Type(ForbiddenArcanus.location("update_aureal"));
   public static final StreamCodec<FriendlyByteBuf, UpdateEssencePayload> STREAM_CODEC;

   public UpdateEssencePayload(EssenceStorage storage) {
      this.storage = storage;
   }

   public void handle(IPayloadContext context) {
      ClientPayloadHandler.getInstance().handle(this, context);
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public EssenceStorage storage() {
      return this.storage;
   }

   static {
      STREAM_CODEC = EssenceStorage.STREAM_CODEC.map(UpdateEssencePayload::new, UpdateEssencePayload::storage);
   }
}
