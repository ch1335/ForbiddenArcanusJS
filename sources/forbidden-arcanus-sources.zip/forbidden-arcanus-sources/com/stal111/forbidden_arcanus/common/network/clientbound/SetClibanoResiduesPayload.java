package com.stal111.forbidden_arcanus.common.network.clientbound;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.ClientPayloadHandler;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ResiduesStorage;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SetClibanoResiduesPayload(ResiduesStorage residueAmounts) implements CustomPacketPayload {
   public static final Type<SetClibanoResiduesPayload> TYPE = new Type(ForbiddenArcanus.location("set_clibano_residues"));
   public static final StreamCodec<RegistryFriendlyByteBuf, SetClibanoResiduesPayload> STREAM_CODEC;

   public SetClibanoResiduesPayload(ResiduesStorage residueAmounts) {
      this.residueAmounts = residueAmounts;
   }

   public void handle(IPayloadContext context) {
      ClientPayloadHandler.getInstance().handle(this, context);
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public ResiduesStorage residueAmounts() {
      return this.residueAmounts;
   }

   static {
      STREAM_CODEC = StreamCodec.composite(ResiduesStorage.STREAM_CODEC, SetClibanoResiduesPayload::residueAmounts, SetClibanoResiduesPayload::new);
   }
}
