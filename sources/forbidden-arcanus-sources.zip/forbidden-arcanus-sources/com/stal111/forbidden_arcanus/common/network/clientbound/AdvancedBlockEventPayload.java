package com.stal111.forbidden_arcanus.common.network.clientbound;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.ClientPayloadHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record AdvancedBlockEventPayload(BlockPos pos, Block block, int b1, int b2) implements CustomPacketPayload {
   public static final Type<AdvancedBlockEventPayload> TYPE = new Type(ForbiddenArcanus.location("block_event"));
   public static final StreamCodec<RegistryFriendlyByteBuf, AdvancedBlockEventPayload> STREAM_CODEC;

   public AdvancedBlockEventPayload(BlockPos pos, Block block, int b1, int b2) {
      this.pos = pos;
      this.block = block;
      this.b1 = b1;
      this.b2 = b2;
   }

   public void handle(IPayloadContext context) {
      ClientPayloadHandler.getInstance().handle(this, context);
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public BlockPos pos() {
      return this.pos;
   }

   public Block block() {
      return this.block;
   }

   public int b1() {
      return this.b1;
   }

   public int b2() {
      return this.b2;
   }

   static {
      STREAM_CODEC = StreamCodec.composite(BlockPos.STREAM_CODEC, AdvancedBlockEventPayload::pos, ByteBufCodecs.registry(Registries.BLOCK), AdvancedBlockEventPayload::block, ByteBufCodecs.INT, AdvancedBlockEventPayload::b1, ByteBufCodecs.INT, AdvancedBlockEventPayload::b2, AdvancedBlockEventPayload::new);
   }
}
