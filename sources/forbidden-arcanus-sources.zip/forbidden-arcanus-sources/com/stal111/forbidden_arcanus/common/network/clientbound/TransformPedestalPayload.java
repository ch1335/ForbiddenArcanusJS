package com.stal111.forbidden_arcanus.common.network.clientbound;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.client.ClientPayloadHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload.Type;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record TransformPedestalPayload(BlockPos pos) implements CustomPacketPayload {
   public static final Type<TransformPedestalPayload> TYPE = new Type(ForbiddenArcanus.location("transform_pedestal"));
   public static final StreamCodec<FriendlyByteBuf, TransformPedestalPayload> STREAM_CODEC;

   public TransformPedestalPayload(BlockPos pos) {
      this.pos = pos;
   }

   public void handle(IPayloadContext context) {
      ClientPayloadHandler.getInstance().handle(this, context);
   }

   public Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }

   public BlockPos pos() {
      return this.pos;
   }

   static {
      STREAM_CODEC = StreamCodec.composite(BlockPos.STREAM_CODEC, TransformPedestalPayload::pos, TransformPedestalPayload::new);
   }
}
