package com.stal111.forbidden_arcanus.common.network;

import com.stal111.forbidden_arcanus.common.network.clientbound.AdvancedBlockEventPayload;
import com.stal111.forbidden_arcanus.common.network.clientbound.SetClibanoResiduesPayload;
import com.stal111.forbidden_arcanus.common.network.clientbound.SpawnParticlePayload;
import com.stal111.forbidden_arcanus.common.network.clientbound.TransformPedestalPayload;
import com.stal111.forbidden_arcanus.common.network.clientbound.UpdateEssencePayload;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class NetworkEvents {
   @SubscribeEvent
   private void registerPackets(RegisterPayloadHandlersEvent event) {
      PayloadRegistrar registrar = event.registrar("forbidden_arcanus").versioned("1.0");
      registrar.playToClient(SetClibanoResiduesPayload.TYPE, SetClibanoResiduesPayload.STREAM_CODEC, SetClibanoResiduesPayload::handle);
      registrar.playToClient(TransformPedestalPayload.TYPE, TransformPedestalPayload.STREAM_CODEC, TransformPedestalPayload::handle);
      registrar.playToClient(SpawnParticlePayload.TYPE, SpawnParticlePayload.STREAM_CODEC, SpawnParticlePayload::handle);
      registrar.playToClient(UpdateEssencePayload.TYPE, UpdateEssencePayload.STREAM_CODEC, UpdateEssencePayload::handle);
      registrar.playToClient(AdvancedBlockEventPayload.TYPE, AdvancedBlockEventPayload.STREAM_CODEC, AdvancedBlockEventPayload::handle);
   }
}
