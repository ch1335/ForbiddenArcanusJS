package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.entity.BlackHoleBlockEntity;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class BlackHoleBlock extends Block implements EntityBlock {
   protected static final VoxelShape SHAPE = Block.box(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);

   public BlackHoleBlock(Properties properties) {
      super(properties);
   }

   @Nullable
   public BlockEntity newBlockEntity(@Nonnull BlockPos pos, @Nonnull BlockState state) {
      return new BlackHoleBlockEntity(pos, state);
   }

   @Nonnull
   public VoxelShape getShape(@Nonnull BlockState state, @Nonnull BlockGetter level, @Nonnull BlockPos pos, @Nonnull CollisionContext context) {
      return SHAPE;
   }

   @Nonnull
   public RenderShape getRenderShape(@Nonnull BlockState state) {
      return RenderShape.INVISIBLE;
   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(@Nonnull Level level, @Nonnull BlockState state, @Nonnull BlockEntityType<T> blockEntityType) {
      return level.isClientSide() ? BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.BLACK_HOLE.get(), BlackHoleBlockEntity::clientTick) : BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.BLACK_HOLE.get(), BlackHoleBlockEntity::serverTick);
   }

   public void animateTick(@Nonnull BlockState state, @Nonnull Level level, @Nonnull BlockPos pos, @Nonnull RandomSource random) {
      for(int i = 0; i < 3; ++i) {
         int j = random.nextInt(2) * 2 - 1;
         int k = random.nextInt(2) * 2 - 1;
         double x = (double)pos.getX() + 0.5D + 0.25D * (double)j;
         double y = (double)pos.getY() + 0.5D;
         double z = (double)pos.getZ() + 0.5D + 0.25D * (double)k;
         level.addParticle(ParticleTypes.PORTAL, x, y, z, (double)(random.nextFloat() * (float)j), ((double)random.nextFloat() - 0.5D) * 0.125D, (double)(random.nextFloat() * (float)k));
      }

   }
}
