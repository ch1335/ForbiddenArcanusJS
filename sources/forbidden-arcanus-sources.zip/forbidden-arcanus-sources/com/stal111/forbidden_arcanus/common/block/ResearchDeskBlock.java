package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.entity.desk.ResearchDeskBlockEntity;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public class ResearchDeskBlock extends DeskBlock implements EntityBlock {
   public ResearchDeskBlock(Properties properties) {
      super(properties);
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new ResearchDeskBlockEntity(pos, state);
   }

   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult result) {
      if (player.isShiftKeyDown()) {
         BlockState newState = (BlockState)((BlockState)((DeskBlock)ModBlocks.DESK.get()).defaultBlockState().setValue(FACING, (Direction)state.getValue(FACING))).setValue(WATERLOGGED, (Boolean)state.getValue(WATERLOGGED));
         level.setBlockAndUpdate(pos, newState);
         ItemStack forbiddenomicon = new ItemStack((ItemLike)ModBlocks.FORBIDDENOMICON.get());
         if (!player.addItem(forbiddenomicon)) {
            player.drop(forbiddenomicon, false);
         }

         return InteractionResult.sidedSuccess(level.isClientSide());
      } else {
         if (!level.isClientSide()) {
            BlockEntity var7 = level.getBlockEntity(pos);
            if (var7 instanceof ResearchDeskBlockEntity) {
               ResearchDeskBlockEntity blockEntity = (ResearchDeskBlockEntity)var7;
               player.openMenu(blockEntity);
            }
         }

         return InteractionResult.sidedSuccess(level.isClientSide());
      }
   }

   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
      return level.isClientSide() ? BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.RESEARCH_DESK.get(), ResearchDeskBlockEntity::clientTick) : null;
   }
}
