package com.stal111.forbidden_arcanus.common.block.entity;

import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.util.ModTags;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

public class BlackHoleBlockEntity extends BlockEntity {
   private static final double DAMAGE_DISTANCE = 0.6D;
   private static final int PLAYER_SEARCH_DISTANCE = 6;
   private final List<ItemEntity> thrownOutItems = new ArrayList();
   private double stored_xp;
   public int rotation = 0;
   public int tickCounter;
   public int auraTexture = 0;

   public BlackHoleBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.BLACK_HOLE.get(), pos, state);
   }

   public static void clientTick(Level level, BlockPos pos, BlockState state, BlackHoleBlockEntity blockEntity) {
      ++blockEntity.rotation;
      ++blockEntity.tickCounter;
      if (blockEntity.tickCounter != 5 && blockEntity.tickCounter != 10) {
         if (blockEntity.tickCounter == 15) {
            blockEntity.tickCounter = 0;
            blockEntity.auraTexture = 0;
         }
      } else {
         ++blockEntity.auraTexture;
      }

   }

   public static void serverTick(Level level, BlockPos pos, BlockState state, BlackHoleBlockEntity blockEntity) {
      List<Entity> entities = level.getEntities((Entity)null, new AABB((double)pos.getX() + 0.5D - 5.0D, (double)pos.getY() + 0.5D - 5.0D, (double)pos.getZ() + 0.5D - 5.0D, (double)pos.getX() + 0.5D + 5.0D, (double)pos.getY() + 0.5D + 5.0D, (double)pos.getZ() + 0.5D + 5.0D));
      Iterator var5 = entities.iterator();

      while(true) {
         Entity entity;
         ItemEntity itemEntity;
         do {
            do {
               if (!var5.hasNext()) {
                  blockEntity.thrownOutItems.removeIf((itemEntityx) -> {
                     return !itemEntityx.isAlive();
                  });
                  return;
               }

               entity = (Entity)var5.next();
            } while(!entity.getType().is(ModTags.EntityTypes.BLACK_HOLE_AFFECTED));

            if (!(entity instanceof ItemEntity)) {
               break;
            }

            itemEntity = (ItemEntity)entity;
         } while(!blockEntity.isAffectedItem(itemEntity));

         double distance = entity.position().distanceTo(pos.getCenter());
         double movementFactor = blockEntity.getMovementFactor(distance);
         entity.push(((double)pos.getX() + 0.5D - entity.getX()) * movementFactor, ((double)pos.getY() + 0.5D - entity.getY() + 1.25D) * movementFactor, ((double)pos.getZ() + 0.5D - entity.getZ()) * movementFactor);
         if (distance <= 0.6D) {
            if (entity instanceof ExperienceOrb) {
               ExperienceOrb experienceOrb = (ExperienceOrb)entity;
               blockEntity.stored_xp += (double)experienceOrb.getValue();
               if (blockEntity.stored_xp >= 60.0D) {
                  blockEntity.throwOutItemStack(level, new ItemStack((ItemLike)ModItems.XPETRIFIED_ORB.get()), pos.getCenter());
                  blockEntity.stored_xp = 0.0D;
               }

               experienceOrb.kill();
            } else {
               entity.hurt(level.damageSources().magic(), 4.0F);
            }
         }
      }
   }

   public boolean isAffectedItem(ItemEntity entity) {
      return !this.thrownOutItems.contains(entity) && !entity.getItem().is(ModTags.Items.BLACK_HOLE_UNAFFECTED);
   }

   private void throwOutItemStack(Level level, ItemStack stack, Vec3 pos) {
      ItemEntity item = new ItemEntity(level, pos.x(), pos.y(), pos.z(), stack);
      Player nearestPlayer = level.getNearestPlayer(pos.x(), pos.y(), pos.z(), 6.0D, false);
      if (nearestPlayer == null) {
         this.setRandomVelocity(item, level.getRandom());
      } else {
         item.push((nearestPlayer.getX() - item.getX()) * 0.09D, (nearestPlayer.getY() - item.getY() + 1.25D) * 0.09D, (nearestPlayer.getZ() - item.getZ()) * 0.09D);
      }

      this.thrownOutItems.add(item);
      level.addFreshEntity(item);
   }

   private double getMovementFactor(double distance) {
      return distance <= 3.0D ? 0.035D : 0.02D;
   }

   private void setRandomVelocity(ItemEntity itemEntity, RandomSource random) {
      double x = random.nextDouble();
      double y = random.nextDouble();
      double z = random.nextDouble();
      itemEntity.setDeltaMovement(random.nextBoolean() ? x : -x, random.nextBoolean() ? y : -y, random.nextBoolean() ? z : -z);
   }

   protected void loadAdditional(@NotNull CompoundTag tag, @NotNull Provider lookupProvider) {
      super.loadAdditional(tag, lookupProvider);
      this.stored_xp = tag.getDouble("StoredXP");
   }

   public void saveAdditional(@Nonnull CompoundTag tag, @NotNull Provider lookupProvider) {
      super.saveAdditional(tag, lookupProvider);
      tag.putDouble("StoredXP", this.stored_xp);
   }
}
