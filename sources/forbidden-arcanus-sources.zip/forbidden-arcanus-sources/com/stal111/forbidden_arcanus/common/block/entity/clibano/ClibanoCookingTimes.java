package com.stal111.forbidden_arcanus.common.block.entity.clibano;

import com.mojang.serialization.Codec;
import java.util.Arrays;
import java.util.List;
import net.minecraft.util.ExtraCodecs;

public record ClibanoCookingTimes(List<Integer> cookingTimes) {
   public static final Codec<ClibanoCookingTimes> CODEC;

   public ClibanoCookingTimes(List<Integer> cookingTimes) {
      this.cookingTimes = cookingTimes;
   }

   public static ClibanoCookingTimes of(int defaultTime) {
      List<Integer> list = Arrays.stream(ClibanoFireType.values()).map((fireType) -> {
         return (int)((double)defaultTime / fireType.getCookingSpeedMultiplier());
      }).toList();
      return new ClibanoCookingTimes(list);
   }

   public int get(ClibanoFireType fireType) {
      return (Integer)this.cookingTimes().get(fireType.ordinal());
   }

   public List<Integer> cookingTimes() {
      return this.cookingTimes;
   }

   static {
      CODEC = ExtraCodecs.POSITIVE_INT.xmap(ClibanoCookingTimes::of, (clibanoCookingTimes) -> {
         return (Integer)clibanoCookingTimes.cookingTimes().getFirst();
      });
   }
}
