package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.PillarType;
import java.util.EnumMap;
import java.util.Objects;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.valhelsia.valhelsia_core.api.common.helper.VoxelShapeHelper;

public class PillarBlock extends RotatedPillarBlock implements SimpleWaterloggedBlock {
   public static final EnumProperty<PillarType> TYPE;
   public static final BooleanProperty WATERLOGGED;
   private static final VoxelShape[] SHAPE_PARTS;
   private static final EnumMap<PillarType, EnumMap<Axis, VoxelShape>> SHAPES;

   public PillarBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.getStateDefinition().any()).setValue(TYPE, PillarType.SINGLE)).setValue(AXIS, Axis.Y)).setValue(WATERLOGGED, false));
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return (VoxelShape)((EnumMap)SHAPES.get(state.getValue(TYPE))).get(state.getValue(AXIS));
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
      return (BlockState)((BlockState)Objects.requireNonNull(super.getStateForPlacement(context))).setValue(WATERLOGGED, flag);
   }

   public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
      if ((Boolean)state.getValue(WATERLOGGED)) {
         level.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return direction.getAxis() != state.getValue(AXIS) ? state : (BlockState)state.setValue(TYPE, calculatePillarType(state, level, currentPos));
   }

   private static PillarType calculatePillarType(BlockState state, LevelAccessor level, BlockPos pos) {
      Axis axis = (Axis)state.getValue(AXIS);
      BlockState stateDown = level.getBlockState(pos.relative(Direction.get(AxisDirection.NEGATIVE, axis)));
      BlockState stateUp = level.getBlockState(pos.relative(Direction.get(AxisDirection.POSITIVE, axis)));
      boolean axisUpEqual = stateUp.is(state.getBlock()) && stateUp.getValue(AXIS) == axis;
      boolean axisDownEqual = stateDown.is(state.getBlock()) && stateDown.getValue(AXIS) == axis;
      return PillarType.getTypeForConnections(axisUpEqual, axisDownEqual);
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{TYPE, AXIS, WATERLOGGED});
   }

   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return false;
   }

   public FluidState getFluidState(BlockState state) {
      return (Boolean)state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   static {
      TYPE = ModBlockStateProperties.PILLAR_TYPE;
      WATERLOGGED = BlockStateProperties.WATERLOGGED;
      SHAPE_PARTS = new VoxelShape[]{Block.box(0.0D, 14.0D, 0.0D, 16.0D, 16.0D, 16.0D), Block.box(1.0D, 13.0D, 1.0D, 15.0D, 14.0D, 15.0D), Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D), Block.box(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), Block.box(1.0D, 2.0D, 1.0D, 15.0D, 3.0D, 15.0D)};
      SHAPES = (EnumMap)Util.make(new EnumMap(PillarType.class), (map) -> {
         map.put(PillarType.MIDDLE, VoxelShapeHelper.rotateAxis(SHAPE_PARTS[2]));
         map.put(PillarType.TOP, VoxelShapeHelper.rotateAxis(Shapes.or(SHAPE_PARTS[0], new VoxelShape[]{SHAPE_PARTS[1], SHAPE_PARTS[2]})));
         map.put(PillarType.BOTTOM, VoxelShapeHelper.rotateAxis(Shapes.or(SHAPE_PARTS[3], new VoxelShape[]{SHAPE_PARTS[4], SHAPE_PARTS[2]})));
         map.put(PillarType.SINGLE, VoxelShapeHelper.rotateAxis(VoxelShapeHelper.combineAll(SHAPE_PARTS)));
      });
   }
}
