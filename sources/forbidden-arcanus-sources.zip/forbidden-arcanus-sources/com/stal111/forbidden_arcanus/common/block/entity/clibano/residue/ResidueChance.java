package com.stal111.forbidden_arcanus.common.block.entity.clibano.residue;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.Holder;

public record ResidueChance(Holder<ResidueType> type, double chance) {
   public static final Codec<ResidueChance> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ResidueType.CODEC.fieldOf("type").forGetter(ResidueChance::type), Codec.DOUBLE.fieldOf("chance").forGetter(ResidueChance::chance)).apply(instance, ResidueChance::new);
   });

   public ResidueChance(Holder<ResidueType> type, double chance) {
      this.type = type;
      this.chance = chance;
   }

   public Holder<ResidueType> type() {
      return this.type;
   }

   public double chance() {
      return this.chance;
   }
}
