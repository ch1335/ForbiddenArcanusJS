package com.stal111.forbidden_arcanus.common.block.skull;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.item.ObsidianSkullItem;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import com.stal111.forbidden_arcanus.core.init.ModSounds;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.SkullBlock.Type;
import org.jetbrains.annotations.NotNull;

public enum ObsidianSkullType implements Type, StringRepresentable {
   DEFAULT("obsidian_skull", ObsidianSkullType.TickFunctions.DEFAULT),
   CRACKED("cracked_obsidian_skull", ObsidianSkullType.TickFunctions.DEFAULT),
   FRAGMENTED("fragmented_obsidian_skull", ObsidianSkullType.TickFunctions.DEFAULT),
   FADING("fading_obsidian_skull", ObsidianSkullType.TickFunctions.DEFAULT),
   AUREALIC("aurealic_obsidian_skull", ObsidianSkullType.TickFunctions.AUREALIC),
   ETERNAL("eternal_obsidian_skull", ObsidianSkullType.TickFunctions.EMPTY);

   public static final Codec<ObsidianSkullType> CODEC = StringRepresentable.fromValues(ObsidianSkullType::values);
   private final String name;
   private final ObsidianSkullType.TickFunction tickFunction;

   private ObsidianSkullType(String param3, ObsidianSkullType.TickFunction param4) {
      this.name = name;
      this.tickFunction = tickFunction;
   }

   public ResourceLocation getTextureLocation() {
      return ForbiddenArcanus.location("textures/block/obsidian_skull/" + this.getSerializedName() + ".png");
   }

   @NotNull
   public String getSerializedName() {
      return this.name;
   }

   public void tick(ItemStack stack, Player player) {
      this.tickFunction.tick(this, stack, player);
   }

   // $FF: synthetic method
   private static ObsidianSkullType[] $values() {
      return new ObsidianSkullType[]{DEFAULT, CRACKED, FRAGMENTED, FADING, AUREALIC, ETERNAL};
   }

   @FunctionalInterface
   public interface TickFunction {
      void tick(ObsidianSkullType var1, ItemStack var2, Player var3);
   }

   public static class TickFunctions {
      public static final UniformInt STAGE_DURATION = UniformInt.of(8, 13);
      public static final ObsidianSkullType.TickFunction EMPTY = (type, stack, player) -> {
      };
      public static final ObsidianSkullType.TickFunction DEFAULT = (type, stack, player) -> {
         int remainingTicks = (Integer)stack.getOrDefault(ModDataComponents.TICKS_TILL_NEXT_STAGE, STAGE_DURATION.sample(player.getRandom()) * 20);
         --remainingTicks;
         if (remainingTicks <= 0) {
            player.setItemSlot(EquipmentSlot.HEAD, new ItemStack((ItemLike)ObsidianSkullItem.NEXT_SKULL_STAGE.get(type)));
            player.level().playSound(player, player.blockPosition(), (SoundEvent)ModSounds.OBSIDIAN_SKULL_CRACK.get(), player.getSoundSource(), 0.9F, player.level().getRandom().nextFloat() * 0.15F + 0.9F);
         } else {
            stack.set(ModDataComponents.TICKS_TILL_NEXT_STAGE, remainingTicks);
         }
      };
      public static final ObsidianSkullType.TickFunction AUREALIC = (type, stack, player) -> {
         EssenceHelper.getEssenceProvider(player).ifPresent((provider) -> {
            provider.updateAmount(EssenceType.AUREAL, (amount) -> {
               return amount - 1;
            });
         });
      };
   }
}
