package com.stal111.forbidden_arcanus.common.block.entity;

import com.stal111.forbidden_arcanus.common.block.pedestal.effect.PedestalEffectTrigger;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import com.stal111.forbidden_arcanus.core.init.ModSounds;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.gameevent.GameEvent.Context;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PedestalBlockEntity extends BlockEntity {
   public static final int DEFAULT_ITEM_HEIGHT = 120;
   private ItemStack stack;
   private final float hoverStart;
   private int ticksExisted;
   private int itemHeight;
   private int heightTarget;

   public PedestalBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.PEDESTAL.get(), pos, state);
      this.stack = ItemStack.EMPTY;
      this.itemHeight = 120;
      this.heightTarget = 120;
      this.hoverStart = (float)(Math.random() * 3.141592653589793D * 2.0D);
   }

   public static void clientTick(Level level, BlockPos pos, BlockState state, PedestalBlockEntity blockEntity) {
      ++blockEntity.ticksExisted;
   }

   public static void serverTick(Level level, BlockPos pos, BlockState state, PedestalBlockEntity blockEntity) {
      if (blockEntity.itemHeight != blockEntity.heightTarget) {
         if (blockEntity.itemHeight < blockEntity.heightTarget) {
            ++blockEntity.itemHeight;
         } else {
            --blockEntity.itemHeight;
         }

         blockEntity.markUpdated();
      }

   }

   public void onLoad() {
      super.onLoad();
      Level var2 = this.getLevel();
      if (var2 instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)var2;
         FARegistries.PEDESTAL_EFFECT_REGISTRY.stream().filter((pedestalEffect) -> {
            return pedestalEffect.shouldExecute(PedestalEffectTrigger.LOAD);
         }).forEach((pedestalEffect) -> {
            pedestalEffect.execute(serverLevel, this.getBlockPos(), this.stack);
         });
      }

   }

   public void setStack(ItemStack stack, @Nullable Player player, PedestalEffectTrigger trigger) {
      this.stack = stack;
      this.markUpdated();
      Level var5 = this.level;
      if (var5 instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)var5;
         serverLevel.gameEvent(GameEvent.BLOCK_CHANGE, this.getBlockPos(), Context.of(player, this.getBlockState()));
         FARegistries.PEDESTAL_EFFECT_REGISTRY.stream().filter((pedestalEffect) -> {
            return pedestalEffect.shouldExecute(trigger);
         }).forEach((pedestalEffect) -> {
            pedestalEffect.execute(serverLevel, this.getBlockPos(), stack);
         });
         this.level.playSound((Player)null, this.getBlockPos(), (SoundEvent)ModSounds.PEDESTAL_INTERACT.get(), SoundSource.BLOCKS, 0.8F, this.level.getRandom().nextFloat() * 0.15F + 0.9F - (stack.isEmpty() ? 0.3F : 0.0F));
      }

   }

   public ItemStack getStack() {
      return this.stack;
   }

   public boolean hasStack() {
      return !this.stack.isEmpty();
   }

   public void clearStack(@Nullable Player player, PedestalEffectTrigger trigger) {
      this.itemHeight = 120;
      this.setStack(ItemStack.EMPTY, player, trigger);
   }

   public float getItemHover(float partialTicks) {
      return ((float)this.ticksExisted + partialTicks) / 20.0F + this.hoverStart;
   }

   public int getItemHeight() {
      return this.itemHeight;
   }

   public void setItemHeightTarget(int heightTarget) {
      this.heightTarget = heightTarget;
   }

   protected void loadAdditional(@NotNull CompoundTag tag, @NotNull Provider lookupProvider) {
      super.loadAdditional(tag, lookupProvider);
      this.stack = tag.contains("Stack", 10) ? ItemStack.parseOptional(lookupProvider, tag.getCompound("Stack")) : ItemStack.EMPTY;
      this.itemHeight = tag.getInt("ItemHeight");
   }

   public void saveAdditional(@Nonnull CompoundTag compound, @NotNull Provider lookupProvider) {
      super.saveAdditional(compound, lookupProvider);
      if (!this.stack.isEmpty()) {
         compound.put("Stack", this.stack.save(lookupProvider));
      }

      compound.putInt("ItemHeight", this.itemHeight);
   }

   private void markUpdated() {
      this.setChanged();
      this.getLevel().sendBlockUpdated(this.getBlockPos(), this.getBlockState(), this.getBlockState(), 3);
   }

   @Nullable
   public ClientboundBlockEntityDataPacket getUpdatePacket() {
      return ClientboundBlockEntityDataPacket.create(this);
   }

   @NotNull
   public CompoundTag getUpdateTag(@NotNull Provider lookupProvider) {
      return this.saveWithoutMetadata(lookupProvider);
   }
}
