package com.stal111.forbidden_arcanus.common.block.entity.forge.essence;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.util.ExtraCodecs;

public record EssencesDefinition(int aureal, int souls, int blood, int experience) {
   public static final EssencesDefinition EMPTY = new EssencesDefinition(0, 0, 0, 0);
   public static final Codec<EssencesDefinition> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("aureal", 0).forGetter(EssencesDefinition::aureal), ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("souls", 0).forGetter(EssencesDefinition::souls), ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("blood", 0).forGetter(EssencesDefinition::blood), ExtraCodecs.NON_NEGATIVE_INT.optionalFieldOf("experience", 0).forGetter(EssencesDefinition::experience)).apply(instance, EssencesDefinition::new);
   });

   public EssencesDefinition(int aureal, int souls, int blood, int experience) {
      this.aureal = aureal;
      this.souls = souls;
      this.blood = blood;
      this.experience = experience;
   }

   public static EssencesDefinition of(int aureal, int souls, int blood, int experience) {
      return new EssencesDefinition(aureal, souls, blood, experience);
   }

   public int get(EssenceType type) {
      int var10000;
      switch(type) {
      case AUREAL:
         var10000 = this.aureal;
         break;
      case SOULS:
         var10000 = this.souls;
         break;
      case BLOOD:
         var10000 = this.blood;
         break;
      case EXPERIENCE:
         var10000 = this.experience;
         break;
      default:
         throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void forEach(BiConsumer<EssenceType, Integer> consumer) {
      EssenceType[] var2 = EssenceType.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         EssenceType type = var2[var4];
         consumer.accept(type, this.get(type));
      }

   }

   public boolean hasMoreThan(EssencesDefinition definition) {
      EssenceType[] var2 = EssenceType.values();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         EssenceType type = var2[var4];
         if (this.get(type) < definition.get(type)) {
            return false;
         }
      }

      return true;
   }

   public EssencesDefinition applyModifiers(List<EssenceModifier> modifiers) {
      EssencesStorage storage = this.mutable();
      storage.applyModifiers(modifiers);
      return storage.immutable();
   }

   public EssencesStorage mutable() {
      return new EssencesStorage(this.aureal, this.souls, this.blood, this.experience);
   }

   public String toString() {
      return "EssencesDefinition{aureal=" + this.aureal + ", souls=" + this.souls + ", blood=" + this.blood + ", experience=" + this.experience + "}";
   }

   public int aureal() {
      return this.aureal;
   }

   public int souls() {
      return this.souls;
   }

   public int blood() {
      return this.blood;
   }

   public int experience() {
      return this.experience;
   }
}
