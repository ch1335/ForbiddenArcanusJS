package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.EssenceUtremJarBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.forge.input.HephaestusForgeInput;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.Iterator;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.valhelsia.valhelsia_core.api.common.helper.VoxelShapeHelper;
import org.jetbrains.annotations.Nullable;

public class UtremJarBlock extends Block implements SimpleWaterloggedBlock {
   private static final String DESCRIPTION_ID = Util.makeDescriptionId("block", ForbiddenArcanus.location("utrem_jar"));
   public static final BooleanProperty WATERLOGGED;
   private static final VoxelShape SHAPE;

   public UtremJarBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)this.stateDefinition.any()).setValue(WATERLOGGED, false));
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return SHAPE;
   }

   public String getDescriptionId() {
      return DESCRIPTION_ID;
   }

   @Nullable
   public BlockState getStateForPlacement(BlockPlaceContext context) {
      boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
      return (BlockState)this.defaultBlockState().setValue(WATERLOGGED, flag);
   }

   protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult result) {
      Iterator var8 = FARegistries.FORGE_INPUT_REGISTRY.iterator();

      HephaestusForgeInput input;
      EssenceValue inputValue;
      do {
         if (!var8.hasNext()) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
         }

         input = (HephaestusForgeInput)var8.next();
         inputValue = input.getMaxInputValue(stack, level.getRandom());
      } while(inputValue == EssenceValue.EMPTY);

      BlockState essenceJar = (BlockState)((BlockState)((EssenceUtremJarBlock)ModBlocks.ESSENCE_UTREM_JAR.get()).defaultBlockState().setValue(WATERLOGGED, (Boolean)state.getValue(WATERLOGGED))).setValue(ModBlockStateProperties.ESSENCE_TYPE, inputValue.type());
      level.setBlockAndUpdate(pos, essenceJar);
      BlockEntity var13 = level.getBlockEntity(pos);
      if (var13 instanceof EssenceUtremJarBlockEntity) {
         EssenceUtremJarBlockEntity blockEntity = (EssenceUtremJarBlockEntity)var13;
         blockEntity.addEssence(inputValue.amount());
         player.setItemInHand(hand, input.finishInput(stack, Math.min(inputValue.amount(), blockEntity.getLimit())));
      }

      return ItemInteractionResult.SUCCESS;
   }

   public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
      if ((Boolean)state.getValue(WATERLOGGED)) {
         level.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return super.updateShape(state, direction, neighborState, level, currentPos, neighborPos);
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{WATERLOGGED});
   }

   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return false;
   }

   public FluidState getFluidState(BlockState state) {
      return (Boolean)state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   static {
      WATERLOGGED = BlockStateProperties.WATERLOGGED;
      SHAPE = VoxelShapeHelper.combineAll(new VoxelShape[]{Block.box(3.0D, 0.0D, 3.0D, 13.0D, 13.0D, 13.0D), Block.box(5.0D, 13.0D, 5.0D, 11.0D, 15.0D, 11.0D)});
   }
}
