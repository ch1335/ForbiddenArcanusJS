package com.stal111.forbidden_arcanus.common.block.clibano;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFireType;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.clibano.ClibanoSideType;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;

public class ClibanoSideBlock extends AbstractClibanoFrameBlock {
   public static final MapCodec<ClibanoSideBlock> CODEC = simpleCodec(ClibanoSideBlock::new);
   private static final EnumProperty<ClibanoSideType> TYPE;
   private static final BooleanProperty MIRRORED;

   public ClibanoSideBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(this.getFacingProperty(), Direction.NORTH)).setValue(TYPE, ClibanoSideType.OFF)).setValue(MIRRORED, false));
   }

   public DirectionProperty getFacingProperty() {
      return BlockStateProperties.HORIZONTAL_FACING;
   }

   public BlockState updateAppearance(BlockState state, boolean isLit, ClibanoFireType fireType) {
      return (BlockState)state.setValue(TYPE, isLit ? ClibanoSideType.valueOf(fireType.name()) : ClibanoSideType.OFF);
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{this.getFacingProperty(), TYPE, MIRRORED});
   }

   static {
      TYPE = ModBlockStateProperties.CLIBANO_SIDE_TYPE;
      MIRRORED = ModBlockStateProperties.MIRRORED;
   }
}
