package com.stal111.forbidden_arcanus.common.block.properties;

import javax.annotation.Nonnull;
import net.minecraft.util.StringRepresentable;

public enum ObeliskPart implements StringRepresentable {
   UPPER("upper"),
   MIDDLE("middle"),
   LOWER("lower");

   private final String name;

   private ObeliskPart(String param3) {
      this.name = name;
   }

   @Nonnull
   public String getSerializedName() {
      return this.name;
   }

   // $FF: synthetic method
   private static ObeliskPart[] $values() {
      return new ObeliskPart[]{UPPER, MIDDLE, LOWER};
   }
}
