package com.stal111.forbidden_arcanus.common.block.entity.forge.input;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.essence.EssenceStorage;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import net.minecraft.core.Holder;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class EssenceStorageInput implements HephaestusForgeInput {
   public static final int EXTRACTION_SPEED = 10;

   public boolean canInput(EssenceType type, ItemStack stack) {
      return (Boolean)EssenceHelper.getEssenceStorage(stack).map((storage) -> {
         return storage.value().type() == type;
      }).orElse(false);
   }

   public EssenceValue getInputValue(ItemStack stack, RandomSource random) {
      EssenceValue data = this.getMaxInputValue(stack, random);
      return EssenceValue.of(data.type(), Math.min(data.amount(), 10));
   }

   public EssenceValue getMaxInputValue(ItemStack stack, RandomSource random) {
      return ((EssenceStorage)EssenceHelper.getEssenceStorage(stack).orElse(EssenceStorage.EMPTY)).value();
   }

   public ItemStack finishInput(ItemStack stack, int inputValue) {
      return (ItemStack)EssenceHelper.getEssenceStorage(stack).map((storage) -> {
         int amount = storage.value().amount();
         storage.addEssence(stack, -inputValue);
         if (amount - inputValue <= 0) {
            Holder<Item> itemHolder = (Holder)stack.get(ModDataComponents.EMPTY_ITEM);
            if (itemHolder != null) {
               return new ItemStack(itemHolder);
            }
         }

         return stack;
      }).orElse(stack);
   }
}
