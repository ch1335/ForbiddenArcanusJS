package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.entity.QuantumInjectorBlockEntity;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class QuantumInjectorBlock extends Block implements EntityBlock, SimpleWaterloggedBlock {
   public static final BooleanProperty ENABLED;
   public static final BooleanProperty WATERLOGGED;

   public QuantumInjectorBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)this.getStateDefinition().any()).setValue(ENABLED, false)).setValue(WATERLOGGED, false));
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new QuantumInjectorBlockEntity(pos, state);
   }

   protected VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
      return (Boolean)state.getValue(ENABLED) ? Shapes.empty() : super.getOcclusionShape(state, level, pos);
   }

   protected VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
      return (Boolean)state.getValue(ENABLED) ? Shapes.empty() : super.getBlockSupportShape(state, level, pos);
   }

   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult result) {
      level.setBlockAndUpdate(pos, (BlockState)state.cycle(ENABLED));
      level.getBlockEntity(pos, (BlockEntityType)ModBlockEntities.QUANTUM_INJECTOR.get()).ifPresent(QuantumInjectorBlockEntity::startAnimation);
      return InteractionResult.sidedSuccess(level.isClientSide());
   }

   @Nullable
   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(WATERLOGGED, context.getLevel().getFluidState(context.getClickedPos()).is(Fluids.WATER));
   }

   public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos currentPos, BlockPos neighborPos) {
      if ((Boolean)state.getValue(WATERLOGGED)) {
         level.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return state;
   }

   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
      return level.isClientSide() ? BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.QUANTUM_INJECTOR.get(), QuantumInjectorBlockEntity::clientTick) : BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.QUANTUM_INJECTOR.get(), QuantumInjectorBlockEntity::serverTick);
   }

   protected RenderShape getRenderShape(BlockState state) {
      return (Boolean)state.getValue(ENABLED) ? RenderShape.ENTITYBLOCK_ANIMATED : RenderShape.MODEL;
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{ENABLED, WATERLOGGED});
   }

   public FluidState getFluidState(BlockState state) {
      return (Boolean)state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   static {
      ENABLED = BlockStateProperties.ENABLED;
      WATERLOGGED = BlockStateProperties.WATERLOGGED;
   }
}
