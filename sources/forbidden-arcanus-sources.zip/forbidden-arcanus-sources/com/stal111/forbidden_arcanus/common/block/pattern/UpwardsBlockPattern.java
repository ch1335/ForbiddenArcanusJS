package com.stal111.forbidden_arcanus.common.block.pattern;

import java.util.Iterator;
import java.util.function.Predicate;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Plane;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.pattern.BlockPatternBuilder;
import net.minecraft.world.level.block.state.pattern.BlockPattern.BlockPatternMatch;

public class UpwardsBlockPattern extends BlockPattern {
   public UpwardsBlockPattern(Predicate<BlockInWorld>[][][] pattern) {
      super(pattern);
   }

   public static UpwardsBlockPattern of(BlockPatternBuilder blockPatternBuilder) {
      return new UpwardsBlockPattern(blockPatternBuilder.createPattern());
   }

   @Nullable
   public BlockPatternMatch find(@Nonnull LevelReader level, @Nonnull BlockPos pos) {
      int i = Math.max(this.getWidth(), this.getDepth());
      Iterator var4 = BlockPos.betweenClosed(pos.offset(-i + 1, 0, -i + 1), pos.offset(i - 1, this.getHeight(), i - 1)).iterator();

      while(var4.hasNext()) {
         BlockPos blockPos = (BlockPos)var4.next();
         Iterator var6 = Plane.HORIZONTAL.iterator();

         while(var6.hasNext()) {
            Direction direction = (Direction)var6.next();
            BlockPatternMatch patternMatch = this.matches(level, blockPos, direction, Direction.UP);
            if (patternMatch != null) {
               return patternMatch;
            }
         }
      }

      return null;
   }
}
