package com.stal111.forbidden_arcanus.common.block.properties;

import javax.annotation.Nonnull;
import net.minecraft.util.StringRepresentable;

public enum PillarType implements StringRepresentable {
   SINGLE("single"),
   TOP("top"),
   MIDDLE("middle"),
   BOTTOM("bottom");

   private final String name;

   private PillarType(String param3) {
      this.name = name;
   }

   @Nonnull
   public String getSerializedName() {
      return this.name;
   }

   public static PillarType getTypeForConnections(boolean connectUp, boolean connectDown) {
      if (connectUp && connectDown) {
         return MIDDLE;
      } else if (connectUp) {
         return BOTTOM;
      } else {
         return connectDown ? TOP : SINGLE;
      }
   }

   public PillarType getOpposite() {
      PillarType var10000;
      switch(this.ordinal()) {
      case 0:
         var10000 = SINGLE;
         break;
      case 1:
         var10000 = BOTTOM;
         break;
      case 2:
         var10000 = MIDDLE;
         break;
      case 3:
         var10000 = TOP;
         break;
      default:
         throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   // $FF: synthetic method
   private static PillarType[] $values() {
      return new PillarType[]{SINGLE, TOP, MIDDLE, BOTTOM};
   }
}
