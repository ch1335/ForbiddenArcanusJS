package com.stal111.forbidden_arcanus.common.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.valhelsia.valhelsia_core.api.common.helper.VoxelShapeHelper;
import org.jetbrains.annotations.NotNull;

public class ArcaneDragonEggBlock extends FallingBlock {
   public static final MapCodec<ArcaneDragonEggBlock> CODEC = simpleCodec(ArcaneDragonEggBlock::new);
   private static final VoxelShape SHAPE = VoxelShapeHelper.combineAll(new VoxelShape[]{Block.box(4.0D, 0.0D, 4.0D, 12.0D, 15.0D, 12.0D), Block.box(3.0D, 1.0D, 3.0D, 13.0D, 13.0D, 13.0D), Block.box(2.0D, 3.0D, 2.0D, 14.0D, 11.0D, 14.0D), Block.box(5.0D, 15.0D, 5.0D, 11.0D, 16.0D, 11.0D)});

   public ArcaneDragonEggBlock(Properties properties) {
      super(properties);
   }

   @NotNull
   protected MapCodec<? extends FallingBlock> codec() {
      return CODEC;
   }

   @Nonnull
   public VoxelShape getShape(@Nonnull BlockState state, @Nonnull BlockGetter level, @Nonnull BlockPos pos, @Nonnull CollisionContext context) {
      return SHAPE;
   }

   protected int getDelayAfterPlace() {
      return 5;
   }

   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return false;
   }
}
