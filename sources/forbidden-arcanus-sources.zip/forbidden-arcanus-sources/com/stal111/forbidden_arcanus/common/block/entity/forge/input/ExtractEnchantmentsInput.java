package com.stal111.forbidden_arcanus.common.block.entity.forge.input;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.Iterator;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;

public class ExtractEnchantmentsInput implements HephaestusForgeInput {
   public static final MapCodec<ExtractEnchantmentsInput> CODEC = MapCodec.unit(ExtractEnchantmentsInput::new);

   public boolean canInput(EssenceType type, ItemStack stack) {
      return type == EssenceType.EXPERIENCE && stack.isEnchanted();
   }

   public EssenceValue getInputValue(ItemStack stack, RandomSource random) {
      int xp = this.getExperienceFromItem(stack);
      if (xp <= 0) {
         return EssenceValue.EMPTY;
      } else {
         int i = (int)Math.ceil((double)xp / 2.0D);
         return EssenceValue.of(EssenceType.EXPERIENCE, i + random.nextInt(i));
      }
   }

   public ItemStack finishInput(ItemStack stack, int inputValue) {
      return inputValue != 0 ? this.removeNonCursesFrom(stack) : stack;
   }

   private int getExperienceFromItem(ItemStack stack) {
      int xp = 0;
      ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
      Iterator var4 = enchantments.entrySet().iterator();

      while(var4.hasNext()) {
         Entry<Holder<Enchantment>> entry = (Entry)var4.next();
         Holder<Enchantment> enchantment = (Holder)entry.getKey();
         int level = entry.getIntValue();
         if (!enchantment.is(EnchantmentTags.CURSE)) {
            xp += ((Enchantment)enchantment.value()).getMinCost(level);
         }
      }

      return xp;
   }

   private ItemStack removeNonCursesFrom(ItemStack stack) {
      ItemEnchantments enchantments = EnchantmentHelper.updateEnchantments(stack, (mutable) -> {
         mutable.removeIf((enchantmentHolder) -> {
            return !enchantmentHolder.is(EnchantmentTags.CURSE);
         });
      });
      if (stack.is(Items.ENCHANTED_BOOK) && enchantments.isEmpty()) {
         stack = stack.transmuteCopy(Items.BOOK, stack.getCount());
      }

      int repairCost = 0;

      for(int j = 0; j < enchantments.size(); ++j) {
         repairCost = AnvilMenu.calculateIncreasedRepairCost(repairCost);
      }

      stack.set(DataComponents.REPAIR_COST, repairCost);
      return stack;
   }
}
