package com.stal111.forbidden_arcanus.common.block.entity.forge;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.world.item.ItemStack;

public record ForgeDataCache(ArrayList<ForgeDataCache.IngredientEntry> cachedIngredients, ItemStack mainIngredient, List<Holder<EnhancerDefinition>> enhancers) {
   public static final Codec<ForgeDataCache> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ForgeDataCache.IngredientEntry.CODEC.listOf().xmap(ArrayList::new, UnaryOperator.identity()).fieldOf("ingredients").forGetter(ForgeDataCache::cachedIngredients), ItemStack.OPTIONAL_CODEC.fieldOf("main_ingredient").forGetter(ForgeDataCache::mainIngredient), EnhancerDefinition.REFERENCE_CODEC.listOf().fieldOf("enhancers").forGetter(ForgeDataCache::enhancers)).apply(instance, ForgeDataCache::new);
   });

   public ForgeDataCache(ArrayList<ForgeDataCache.IngredientEntry> cachedIngredients, ItemStack mainIngredient, List<Holder<EnhancerDefinition>> enhancers) {
      this.cachedIngredients = cachedIngredients;
      this.mainIngredient = mainIngredient;
      this.enhancers = enhancers;
   }

   public ForgeDataCache setMainIngredient(ItemStack mainIngredient) {
      return new ForgeDataCache(this.cachedIngredients, mainIngredient, this.enhancers);
   }

   public ForgeDataCache setEnhancers(List<Holder<EnhancerDefinition>> enhancers) {
      return new ForgeDataCache(this.cachedIngredients, this.mainIngredient, enhancers);
   }

   public HolderSet<EnhancerDefinition> getEnhancers() {
      return HolderSet.direct(UnaryOperator.identity(), this.enhancers);
   }

   public void setIngredient(BlockPos pos, ItemStack stack) {
      this.cachedIngredients.removeIf((entry) -> {
         return entry.pos().equals(pos);
      });
      if (!stack.isEmpty()) {
         this.cachedIngredients.add(new ForgeDataCache.IngredientEntry(pos, stack));
      }

   }

   public List<ItemStack> getIngredients() {
      return this.cachedIngredients.stream().map(ForgeDataCache.IngredientEntry::stack).toList();
   }

   public ArrayList<ForgeDataCache.IngredientEntry> cachedIngredients() {
      return this.cachedIngredients;
   }

   public ItemStack mainIngredient() {
      return this.mainIngredient;
   }

   public List<Holder<EnhancerDefinition>> enhancers() {
      return this.enhancers;
   }

   public static record IngredientEntry(BlockPos pos, ItemStack stack) {
      public static final Codec<ForgeDataCache.IngredientEntry> CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(BlockPos.CODEC.fieldOf("pos").forGetter(ForgeDataCache.IngredientEntry::pos), ItemStack.SINGLE_ITEM_CODEC.fieldOf("stack").forGetter(ForgeDataCache.IngredientEntry::stack)).apply(instance, ForgeDataCache.IngredientEntry::new);
      });

      public IngredientEntry(BlockPos pos, ItemStack stack) {
         this.pos = pos;
         this.stack = stack;
      }

      public BlockPos pos() {
         return this.pos;
      }

      public ItemStack stack() {
         return this.stack;
      }
   }
}
