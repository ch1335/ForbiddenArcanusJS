package com.stal111.forbidden_arcanus.common.block.pedestal.effect;

import com.stal111.forbidden_arcanus.common.block.entity.PedestalBlockEntity;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import net.minecraft.commands.arguments.EntityAnchorArgument.Anchor;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacementType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import org.jetbrains.annotations.Nullable;

public class SummonEntityEffect<T extends LivingEntity> extends PedestalEffect {
   private final BiPredicate<ServerLevel, ItemStack> spawnCondition;
   private final RegistryEntry<EntityType<?>, EntityType<T>> entityType;
   private final int spawnRadius;
   private final boolean consumeItem;

   public SummonEntityEffect(BiPredicate<ServerLevel, ItemStack> spawnCondition, RegistryEntry<EntityType<?>, EntityType<T>> entityType, int spawnRadius, boolean consumeItem) {
      super(PedestalEffectTrigger.PLAYER_PLACE_ITEM);
      this.spawnCondition = spawnCondition;
      this.entityType = entityType;
      this.spawnRadius = spawnRadius;
      this.consumeItem = consumeItem;
   }

   public void execute(ServerLevel level, BlockPos pos, ItemStack stack) {
      if (this.spawnCondition.test(level, stack)) {
         BlockPos spawnPos = this.findSpawnPositionNear(level, pos, this.spawnRadius);
         if (spawnPos != null) {
            T entity = (LivingEntity)((EntityType)this.entityType.get()).create(level, (Consumer)null, spawnPos, MobSpawnType.MOB_SUMMONED, false, false);
            if (entity != null) {
               entity.lookAt(Anchor.EYES, pos.getCenter());
               level.addFreshEntity(entity);
            }
         }

         if (this.consumeItem) {
            BlockEntity var6 = level.getBlockEntity(pos);
            if (var6 instanceof PedestalBlockEntity) {
               PedestalBlockEntity blockEntity = (PedestalBlockEntity)var6;
               blockEntity.clearStack((Player)null, PedestalEffectTrigger.ENTITY_SUMMONED);
            }
         }

      }
   }

   @Nullable
   private BlockPos findSpawnPositionNear(ServerLevel level, BlockPos pos, int maxDistance) {
      BlockPos spawnPos = null;
      SpawnPlacementType spawnPlacementType = SpawnPlacements.getPlacementType((EntityType)this.entityType.get());

      for(int i = 0; i < 10; ++i) {
         int j = pos.getX() + level.getRandom().nextInt(maxDistance * 2) - maxDistance;
         int k = pos.getZ() + level.getRandom().nextInt(maxDistance * 2) - maxDistance;
         int l = level.getHeight(Types.WORLD_SURFACE, j, k);
         BlockPos blockpos1 = new BlockPos(j, l, k);
         if (spawnPlacementType.isSpawnPositionOk(level, blockpos1, (EntityType)this.entityType.get())) {
            spawnPos = blockpos1;
            break;
         }
      }

      return spawnPos;
   }
}
