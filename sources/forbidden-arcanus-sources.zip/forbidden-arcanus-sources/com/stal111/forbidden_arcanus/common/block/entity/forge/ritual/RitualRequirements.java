package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.forge.TierPredicate;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssencesDefinition;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;

public record RitualRequirements(EssencesDefinition essences, TierPredicate tier, HolderSet<EnhancerDefinition> enhancers) {
   public static final RitualRequirements NONE;
   public static final MapCodec<RitualRequirements> CODEC;

   public RitualRequirements(EssencesDefinition essences, TierPredicate tier, HolderSet<EnhancerDefinition> enhancers) {
      this.essences = essences;
      this.tier = tier;
      this.enhancers = enhancers;
   }

   public static RitualRequirements.Builder builder(EssencesDefinition essences) {
      return new RitualRequirements.Builder(essences);
   }

   public boolean checkRequirements(int forgeTier, HolderSet<EnhancerDefinition> enhancers) {
      if (!this.tier.test(forgeTier)) {
         return false;
      } else {
         Stream var10000 = this.enhancers.stream();
         Objects.requireNonNull(enhancers);
         return var10000.allMatch(enhancers::contains);
      }
   }

   public EssencesDefinition essences() {
      return this.essences;
   }

   public TierPredicate tier() {
      return this.tier;
   }

   public HolderSet<EnhancerDefinition> enhancers() {
      return this.enhancers;
   }

   static {
      NONE = new RitualRequirements(EssencesDefinition.EMPTY, TierPredicate.ANY, HolderSet.empty());
      CODEC = RecordCodecBuilder.mapCodec((instance) -> {
         return instance.group(EssencesDefinition.CODEC.fieldOf("essences").forGetter(RitualRequirements::essences), TierPredicate.CODEC.forGetter(RitualRequirements::tier), EnhancerDefinition.LIST_CODEC.optionalFieldOf("enhancers", HolderSet.empty()).forGetter(RitualRequirements::enhancers)).apply(instance, RitualRequirements::new);
      });
   }

   public static class Builder {
      private final EssencesDefinition essences;
      private TierPredicate tier;
      private HolderSet<EnhancerDefinition> enhancers;

      private Builder(EssencesDefinition essences) {
         this.tier = TierPredicate.ANY;
         this.enhancers = HolderSet.empty();
         this.essences = essences;
      }

      public RitualRequirements.Builder tier(TierPredicate tier) {
         this.tier = tier;
         return this;
      }

      public RitualRequirements.Builder enhancer(Holder<EnhancerDefinition> enhancer) {
         this.enhancers = HolderSet.direct(new Holder[]{enhancer});
         return this;
      }

      public RitualRequirements.Builder enhancers(HolderSet<EnhancerDefinition> enhancers) {
         this.enhancers = enhancers;
         return this;
      }

      public RitualRequirements build() {
         return new RitualRequirements(this.essences, this.tier, this.enhancers);
      }
   }
}
