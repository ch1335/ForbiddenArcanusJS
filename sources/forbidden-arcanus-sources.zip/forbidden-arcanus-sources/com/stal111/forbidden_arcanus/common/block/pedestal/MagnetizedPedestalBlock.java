package com.stal111.forbidden_arcanus.common.block.pedestal;

import com.stal111.forbidden_arcanus.common.block.entity.PedestalBlockEntity;
import com.stal111.forbidden_arcanus.common.block.pedestal.effect.PedestalEffectTrigger;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class MagnetizedPedestalBlock extends PedestalBlock {
   private static final VoxelShape ABOVE_SHAPE = Block.box(1.0D, 14.0D, 1.0D, 15.0D, 18.0D, 15.0D);

   public MagnetizedPedestalBlock(Properties properties) {
      super(properties);
   }

   public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
      BlockEntity var6 = level.getBlockEntity(pos);
      if (var6 instanceof PedestalBlockEntity) {
         PedestalBlockEntity blockEntity = (PedestalBlockEntity)var6;
         if (!blockEntity.hasStack()) {
            if (entity instanceof ItemEntity) {
               ItemEntity itemEntity = (ItemEntity)entity;
               if (Shapes.joinIsNotEmpty(Shapes.create(entity.getBoundingBox().move((double)(-pos.getX()), (double)(-pos.getY()), (double)(-pos.getZ()))), ABOVE_SHAPE, BooleanOp.AND)) {
                  blockEntity.setStack(itemEntity.getItem().split(1), (Player)null, PedestalEffectTrigger.MAGNETIZED_PICKUP);
               }
            }

            return;
         }
      }

   }
}
