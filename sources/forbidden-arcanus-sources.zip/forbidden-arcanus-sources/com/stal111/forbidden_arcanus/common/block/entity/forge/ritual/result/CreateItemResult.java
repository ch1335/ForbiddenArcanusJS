package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.init.ModRitualResultTypes;
import net.minecraft.world.item.ItemStack;

public record CreateItemResult(ItemStack result) implements RitualResult {
   public static final MapCodec<CreateItemResult> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(ItemStack.CODEC.fieldOf("result_item").forGetter(CreateItemResult::result)).apply(instance, CreateItemResult::new);
   });

   public CreateItemResult(ItemStack result) {
      this.result = result;
   }

   public ItemStack getResultItem(ItemStack mainInput) {
      return this.result.copy();
   }

   public RitualResultType<? extends RitualResult> getType() {
      return (RitualResultType)ModRitualResultTypes.CREATE_ITEM.get();
   }

   public ItemStack result() {
      return this.result;
   }
}
