package com.stal111.forbidden_arcanus.common.block.entity.clibano;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import java.util.Objects;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ClibanoFrameBlockEntity extends BlockEntity {
   @Nullable
   private Direction mainDirection;
   private ClibanoFrameBlockEntity.FrameData frameData;

   public ClibanoFrameBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.CLIBANO.get(), pos, state);
      this.frameData = ClibanoFrameBlockEntity.FrameData.EMPTY;
   }

   public void setFrameData(ClibanoFrameBlockEntity.FrameData frameData) {
      this.frameData = frameData;
   }

   public ClibanoFrameBlockEntity.FrameData getFrameData() {
      return this.frameData;
   }

   public void setMainDirection(@Nullable Direction mainDirection) {
      this.mainDirection = mainDirection;
   }

   protected void saveAdditional(@NotNull CompoundTag tag, @NotNull Provider lookupProvider) {
      super.saveAdditional(tag, lookupProvider);
      if (this.frameData != ClibanoFrameBlockEntity.FrameData.EMPTY) {
         ClibanoFrameBlockEntity.FrameData.CODEC.encodeStart(NbtOps.INSTANCE, this.frameData).ifSuccess((tag1) -> {
            tag.merge((CompoundTag)tag1);
         }).ifError((result) -> {
            ForbiddenArcanus.LOGGER.warn("Failed to encode Clibano FrameData {}", result.message());
         });
      }

      if (this.mainDirection != null) {
         tag.putString("main_direction", this.mainDirection.getName());
      }

   }

   public void loadAdditional(@Nonnull CompoundTag tag, @NotNull Provider lookupProvider) {
      super.loadAdditional(tag, lookupProvider);
      DataResult var10000 = ClibanoFrameBlockEntity.FrameData.CODEC.parse(NbtOps.INSTANCE, tag);
      Logger var10001 = ForbiddenArcanus.LOGGER;
      Objects.requireNonNull(var10001);
      var10000.resultOrPartial(var10001::error).ifPresent((frameData) -> {
         this.frameData = frameData;
      });
      if (tag.contains("main_direction")) {
         this.mainDirection = Direction.byName(tag.getString("main_direction"));
      }

   }

   public static record FrameData(BlockState replaceState, BlockPos mainPos) {
      public static final ClibanoFrameBlockEntity.FrameData EMPTY;
      private static final Codec<ClibanoFrameBlockEntity.FrameData> CODEC;

      public FrameData(BlockState replaceState, BlockPos mainPos) {
         this.replaceState = replaceState;
         this.mainPos = mainPos;
      }

      public BlockState replaceState() {
         return this.replaceState;
      }

      public BlockPos mainPos() {
         return this.mainPos;
      }

      static {
         EMPTY = new ClibanoFrameBlockEntity.FrameData(Blocks.AIR.defaultBlockState(), BlockPos.ZERO);
         CODEC = RecordCodecBuilder.create((instance) -> {
            return instance.group(BlockState.CODEC.fieldOf("replace_state").forGetter(ClibanoFrameBlockEntity.FrameData::replaceState), BlockPos.CODEC.fieldOf("main_pos").forGetter(ClibanoFrameBlockEntity.FrameData::mainPos)).apply(instance, ClibanoFrameBlockEntity.FrameData::new);
         });
      }
   }
}
