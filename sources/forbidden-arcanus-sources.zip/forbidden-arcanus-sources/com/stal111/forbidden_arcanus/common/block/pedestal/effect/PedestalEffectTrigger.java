package com.stal111.forbidden_arcanus.common.block.pedestal.effect;

public enum PedestalEffectTrigger {
   PLAYER_PLACE_ITEM,
   PLAYER_REMOVE_ITEM,
   RITUAL_FINISHED,
   MAGNETIZED_PICKUP,
   ENTITY_SUMMONED,
   LOAD;

   // $FF: synthetic method
   private static PedestalEffectTrigger[] $values() {
      return new PedestalEffectTrigger[]{PLAYER_PLACE_ITEM, PLAYER_REMOVE_ITEM, RITUAL_FINISHED, MAGNETIZED_PICKUP, ENTITY_SUMMONED, LOAD};
   }
}
