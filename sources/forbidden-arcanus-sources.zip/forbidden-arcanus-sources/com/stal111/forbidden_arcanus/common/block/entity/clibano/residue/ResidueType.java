package com.stal111.forbidden_arcanus.common.block.entity.clibano.residue;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.resources.RegistryFileCodec;
import net.minecraft.world.item.ItemStack;

public record ResidueType(Component name, ResidueType.CombineInfo combineInfo) {
   public static final Codec<ResidueType> DIRECT_CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(ComponentSerialization.CODEC.fieldOf("name").forGetter((info) -> {
         return info.name;
      }), ResidueType.CombineInfo.CODEC.fieldOf("combine_info").forGetter((info) -> {
         return info.combineInfo;
      })).apply(instance, ResidueType::new);
   });
   public static final Codec<Holder<ResidueType>> CODEC;

   public ResidueType(Component name, ResidueType.CombineInfo combineInfo) {
      this.name = name;
      this.combineInfo = combineInfo;
   }

   public static ResidueType withDefaultKey(String name, int requiredAmount, ItemStack result) {
      return new ResidueType(Component.translatable("residue.forbidden_arcanus." + name), new ResidueType.CombineInfo(requiredAmount, result));
   }

   public Component name() {
      return this.name;
   }

   public ResidueType.CombineInfo combineInfo() {
      return this.combineInfo;
   }

   static {
      CODEC = RegistryFileCodec.create(FARegistries.RESIDUE_TYPE, DIRECT_CODEC);
   }

   public static record CombineInfo(int requiredAmount, ItemStack result) {
      public static final Codec<ResidueType.CombineInfo> CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(Codec.INT.fieldOf("required_amount").forGetter((info) -> {
            return info.requiredAmount;
         }), ItemStack.CODEC.fieldOf("result").forGetter((info) -> {
            return info.result;
         })).apply(instance, ResidueType.CombineInfo::new);
      });

      public CombineInfo(int requiredAmount, ItemStack result) {
         this.requiredAmount = requiredAmount;
         this.result = result;
      }

      public int requiredAmount() {
         return this.requiredAmount;
      }

      public ItemStack result() {
         return this.result;
      }
   }
}
