package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.common.ItemAbilities;

public class CarvedEdelwoodLogBlock extends EdelwoodLogBlock {
   public static final BooleanProperty LEAVES;
   public static final DirectionProperty FACING;

   public CarvedEdelwoodLogBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.getStateDefinition().any()).setValue(FACING, Direction.NORTH)).setValue(LEAVES, false)).setValue(OILY, false)).setValue(WATERLOGGED, false));
   }

   @Nonnull
   public VoxelShape getShape(@Nonnull BlockState state, @Nonnull BlockGetter level, @Nonnull BlockPos pos, @Nonnull CollisionContext context) {
      return !context.isHoldingItem(((EdelwoodLogBlock)ModBlocks.EDELWOOD_LOG.get()).asItem()) && !context.isHoldingItem(((CarvedEdelwoodLogBlock)ModBlocks.CARVED_EDELWOOD_LOG.get()).asItem()) ? (VoxelShape)SHAPES.get(Axis.Y) : Shapes.block();
   }

   public BlockState getStateForPlacement(@Nonnull BlockPlaceContext context) {
      boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
      return (BlockState)((BlockState)this.defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite())).setValue(WATERLOGGED, flag);
   }

   protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult result) {
      if (stack.canPerformAction(ItemAbilities.SHEARS_HARVEST) && (Boolean)state.getValue(LEAVES)) {
         stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
         level.playSound(player, player.getX(), player.getY(), player.getZ(), SoundEvents.SHEEP_SHEAR, SoundSource.BLOCKS, 1.0F, 1.0F);
         level.gameEvent(player, GameEvent.SHEAR, pos);
         level.setBlockAndUpdate(pos, (BlockState)state.setValue(LEAVES, false));
         return ItemInteractionResult.sidedSuccess(level.isClientSide());
      } else if (stack.getItem() instanceof BoneMealItem && !(Boolean)state.getValue(LEAVES)) {
         stack.consume(1, player);
         level.playSound(player, player.getX(), player.getY(), player.getZ(), SoundEvents.BONE_MEAL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
         level.gameEvent(player, GameEvent.BLOCK_CHANGE, pos);
         level.setBlockAndUpdate(pos, (BlockState)state.setValue(LEAVES, true));
         return ItemInteractionResult.sidedSuccess(level.isClientSide());
      } else {
         return super.useItemOn(stack, state, level, pos, player, hand, result);
      }
   }

   @Nonnull
   public BlockState rotate(BlockState state, @Nonnull Rotation rotation) {
      return (BlockState)state.setValue(FACING, rotation.rotate((Direction)state.getValue(FACING)));
   }

   @Nonnull
   public BlockState mirror(BlockState state, Mirror mirror) {
      return state.rotate(mirror.getRotation((Direction)state.getValue(FACING)));
   }

   protected void createBlockStateDefinition(@Nonnull Builder<Block, BlockState> builder) {
      builder.add(new Property[]{FACING, OILY, LEAVES, WATERLOGGED});
   }

   protected boolean isCarved() {
      return true;
   }

   static {
      LEAVES = ModBlockStateProperties.LEAVES;
      FACING = BlockStateProperties.HORIZONTAL_FACING;
   }
}
