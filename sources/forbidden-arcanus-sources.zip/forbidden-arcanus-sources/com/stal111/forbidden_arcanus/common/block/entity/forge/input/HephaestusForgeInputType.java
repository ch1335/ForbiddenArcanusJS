package com.stal111.forbidden_arcanus.common.block.entity.forge.input;

import com.mojang.serialization.MapCodec;

public record HephaestusForgeInputType<T extends HephaestusForgeInput>(MapCodec<T> codec) {
   public HephaestusForgeInputType(MapCodec<T> codec) {
      this.codec = codec;
   }

   public MapCodec<T> codec() {
      return this.codec;
   }
}
