package com.stal111.forbidden_arcanus.common.block.entity.clibano;

import com.stal111.forbidden_arcanus.common.inventory.clibano.ClibanoMenu;
import it.unimi.dsi.fastutil.ints.Int2BooleanFunction;
import java.util.Arrays;
import java.util.function.IntConsumer;

public enum ClibanoInputSlot {
   FIRST(new int[]{(Integer)ClibanoMenu.INPUT_SLOTS.getFirst()}),
   SECOND(new int[]{(Integer)ClibanoMenu.INPUT_SLOTS.getSecond()}),
   BOTH(new int[]{(Integer)ClibanoMenu.INPUT_SLOTS.getFirst(), (Integer)ClibanoMenu.INPUT_SLOTS.getSecond()});

   private final int[] index;
   private final int[] slots;

   private ClibanoInputSlot(int... param3) {
      this.index = Arrays.stream(slots).map((slot) -> {
         return slot - 3;
      }).toArray();
      this.slots = slots;
   }

   public void apply(IntConsumer consumer) {
      int[] var2 = this.slots;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         int slot = var2[var4];
         consumer.accept(slot);
      }

   }

   public boolean apply(Int2BooleanFunction function) {
      int[] var2 = this.slots;
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         int slot = var2[var4];
         if (!(Boolean)function.apply(slot)) {
            return false;
         }
      }

      return true;
   }

   public int[] getIndex() {
      return this.index;
   }

   // $FF: synthetic method
   private static ClibanoInputSlot[] $values() {
      return new ClibanoInputSlot[]{FIRST, SECOND, BOTH};
   }
}
