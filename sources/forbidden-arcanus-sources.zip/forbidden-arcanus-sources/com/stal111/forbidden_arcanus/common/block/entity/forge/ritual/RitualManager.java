package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual;

import com.mojang.serialization.DataResult;
import com.stal111.forbidden_arcanus.common.advancements.critereon.FACriteriaTriggers;
import com.stal111.forbidden_arcanus.common.advancements.critereon.RitualCompletedTrigger;
import com.stal111.forbidden_arcanus.common.block.entity.PedestalBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ForgeDataCache;
import com.stal111.forbidden_arcanus.common.block.entity.forge.circle.MagicCircleController;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceModifier;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssencesDefinition;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssencesStorage;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.RitualResult;
import com.stal111.forbidden_arcanus.common.block.pedestal.effect.PedestalEffectTrigger;
import com.stal111.forbidden_arcanus.common.entity.CrimsonLightningBoltEntity;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerDefinition;
import com.stal111.forbidden_arcanus.common.item.enhancer.EnhancerTarget;
import com.stal111.forbidden_arcanus.common.network.clientbound.AdvancedBlockEventPayload;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.core.init.ModParticles;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.RegistryOps;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.network.PacketDistributor;
import org.apache.commons.lang3.BooleanUtils;
import org.jetbrains.annotations.Nullable;

public class RitualManager {
   public static final String TAG_ACTIVE_RITUAL = "active_ritual";
   public static final int PEDESTAL_ITEM_HEIGHT = 140;
   public static final int LIGHTNING_COUNTER_THRESHOLD = 300;
   private final MagicCircleController magicCircleController;
   private ForgeDataCache dataCache;
   private ServerLevel level;
   private BlockPos pos;
   private int forgeTier;
   @Nullable
   private Holder<Ritual> validRitual;
   @Nullable
   private ActiveRitualData activeRitualData;

   public RitualManager(MagicCircleController circleController, int forgeTier, ForgeDataCache dataCache) {
      this.magicCircleController = circleController;
      this.forgeTier = forgeTier;
      this.dataCache = dataCache;
   }

   public void setup(ServerLevel level, BlockPos pos) {
      this.level = level;
      this.pos = pos;
   }

   public void setForgeTier(int forgeTier) {
      this.forgeTier = forgeTier;
   }

   public Optional<Holder<Ritual>> getValidRitual() {
      return Optional.ofNullable(this.validRitual);
   }

   private Optional<ActiveRitualData> getActiveRitualData() {
      return Optional.ofNullable(this.activeRitualData);
   }

   private void setActiveRitual(@Nullable Holder<Ritual> ritual, UUID startedBy) {
      this.activeRitualData = ritual != null ? ActiveRitualData.create(ritual, startedBy) : null;
      int duration = ritual != null ? ((Ritual)ritual.value()).duration() : 0;
      PacketDistributor.sendToPlayersTrackingChunk(this.level, new ChunkPos(this.pos), new AdvancedBlockEventPayload(this.pos, this.level.getBlockState(this.pos).getBlock(), 3, duration), new CustomPacketPayload[0]);
   }

   public boolean isRitualActive() {
      return this.level != null && this.getActiveRitualData().isPresent();
   }

   public void onDataChanged(ForgeDataCache dataCache, EssencesDefinition essencesDefinition, Provider lookupProvider) {
      this.dataCache = dataCache;
      this.getActiveRitualData().ifPresent((data) -> {
         if (!data.getRitual().checkIngredients(this.dataCache.getIngredients(), this.dataCache.mainIngredient())) {
            this.failRitual();
         }

      });
      this.updateValidRitual(essencesDefinition, lookupProvider);
   }

   public void updateValidRitual(EssencesDefinition definition, Provider lookupProvider) {
      boolean oldValue = this.validRitual != null;
      Iterator var4 = lookupProvider.lookupOrThrow(FARegistries.RITUAL).listElements().toList().iterator();

      Holder ritual;
      do {
         if (!var4.hasNext()) {
            this.validRitual = null;
            if (oldValue && !this.isRitualActive()) {
               this.updateRitualIndicator(false);
            }

            return;
         }

         ritual = (Holder)var4.next();
      } while(!this.canStartRitual((Ritual)ritual.value(), definition));

      if (!oldValue) {
         this.updateRitualIndicator(true);
      }

      this.validRitual = ritual;
   }

   private boolean canStartRitual(Ritual ritual, EssencesDefinition definition) {
      List<EssenceModifier> modifiers = this.dataCache.getEnhancers().stream().flatMap((enhancerDefinition) -> {
         return ((EnhancerDefinition)enhancerDefinition.value()).getEffects(EnhancerTarget.HEPHAESTUS_FORGE);
      }).filter((effect) -> {
         return effect instanceof EssenceModifier;
      }).map((effect) -> {
         return (EssenceModifier)effect;
      }).toList();
      EssencesDefinition updatedEssences = ritual.requirements().essences().applyModifiers(modifiers);
      return definition.hasMoreThan(updatedEssences) && ritual.canStart(this.dataCache, this.forgeTier);
   }

   public boolean startRitual(ServerPlayer player, EssencesStorage storage) {
      return (Boolean)this.getValidRitual().map((ritual) -> {
         this.setActiveRitual(ritual, player.getUUID());
         this.magicCircleController.createMagicCircle(this.level, this.pos, ((Ritual)ritual.value()).magicCircleType());
         storage.reduce(((Ritual)ritual.value()).requirements().essences());
         this.forEachPedestal(PedestalBlockEntity::hasStack, (blockEntity) -> {
            blockEntity.setItemHeightTarget(140);
         });
         return true;
      }).orElse(false);
   }

   public Optional<ItemStack> tick() {
      ActiveRitualData data = (ActiveRitualData)this.getActiveRitualData().orElse((Object)null);
      if (data == null) {
         return Optional.empty();
      } else {
         RandomSource random = this.level.getRandom();
         float progress = data.calculateRitualProgress();
         data.incrementCounter();
         this.handleLightningCounter(data);
         this.dataCache.cachedIngredients().forEach((entry) -> {
            this.addItemParticles(entry.pos(), Math.min(120 + data.getCounter(), 140), entry.stack());
         });
         if (progress == 0.5F && random.nextDouble() <= this.getFailureChance() * 2.0D) {
            CrimsonLightningBoltEntity entity = new CrimsonLightningBoltEntity((EntityType)ModEntities.CRIMSON_LIGHTNING_BOLT.get(), this.level);
            entity.setPos((double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 1.0D, (double)this.pos.getZ() + 0.5D);
            entity.setVisualOnly(true);
            this.level.addFreshEntity(entity);
            data.incrementLightningCounter();
            this.forEachPedestal(PedestalBlockEntity::hasStack, (pedestalBlockEntity) -> {
               if (random.nextBoolean()) {
                  ItemStack stack = pedestalBlockEntity.getStack().copy();
                  BlockPos pedestalPos = pedestalBlockEntity.getBlockPos();
                  this.level.addFreshEntity(new ItemEntity(this.level, (double)pedestalPos.getX() + 0.5D, (double)((float)pedestalPos.getY() + (float)pedestalBlockEntity.getItemHeight() / 100.0F), (double)pedestalPos.getZ() + 0.5D, stack));
                  pedestalBlockEntity.clearStack((Player)null, PedestalEffectTrigger.RITUAL_FINISHED);
               }

            });
         }

         if (progress == 1.0F) {
            return random.nextDouble() > this.getFailureChance() ? Optional.of(this.finishRitual(data)) : Optional.of(this.failRitual());
         } else {
            return Optional.empty();
         }
      }
   }

   private void handleLightningCounter(ActiveRitualData data) {
      if (data.getLightningCounter() != 0) {
         data.incrementLightningCounter();
         if (data.getLightningCounter() == 300) {
            List<ItemStack> list = new ArrayList();
            this.forEachPedestal(PedestalBlockEntity::hasStack, (pedestalBlockEntity) -> {
               list.add(pedestalBlockEntity.getStack());
            });
            if (!data.getRitual().checkIngredients(list, this.dataCache.mainIngredient())) {
               this.failRitual();
            }
         }
      }

   }

   private ItemStack finishRitual(ActiveRitualData data) {
      this.reset();
      Player player = this.level.getPlayerByUUID(data.getStartedBy());
      if (player instanceof ServerPlayer) {
         ServerPlayer serverPlayer = (ServerPlayer)player;
         if (data.getRitualId() != null) {
            ((RitualCompletedTrigger)FACriteriaTriggers.RITUAL.get()).trigger(serverPlayer, data.getRitualId());
         }
      }

      RitualResult result = data.getRitual().result();
      result.executeLevelEffect(this.level, this.pos);
      return result.getResultItem(this.dataCache.mainIngredient());
   }

   private ItemStack failRitual() {
      ItemStack stack = this.dataCache.mainIngredient();
      this.reset();
      if (!stack.isEmpty()) {
         this.level.addFreshEntity(new ItemEntity(this.level, (double)this.pos.getX() + 0.5D, (double)(this.pos.getY() + 1), (double)this.pos.getZ() + 0.5D, stack));
      }

      this.level.sendParticles((SimpleParticleType)ModParticles.HUGE_MAGIC_EXPLOSION.get(), (double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D, 0, 1.0D, 0.0D, 0.0D, 0.0D);
      this.level.playSound((Player)null, (double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D, (SoundEvent)SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, 4.0F, (1.0F + (this.level.getRandom().nextFloat() - this.level.getRandom().nextFloat()) * 0.2F) * 0.7F);
      return ItemStack.EMPTY;
   }

   private void clearPedestals() {
      this.forEachPedestal(PedestalBlockEntity::hasStack, (blockEntity) -> {
         blockEntity.clearStack((Player)null, PedestalEffectTrigger.RITUAL_FINISHED);
      });
      this.dataCache.cachedIngredients().clear();
   }

   private void addItemParticles(BlockPos pedestalPos, int itemHeight, ItemStack stack) {
      double posX = (double)pedestalPos.getX() + 0.5D;
      double posY = (double)pedestalPos.getY() + 0.1D + (double)((float)itemHeight / 100.0F);
      double posZ = (double)pedestalPos.getZ() + 0.5D;
      double xSpeed = 0.1D * (double)(this.pos.getX() - pedestalPos.getX());
      double ySpeed = 0.22D;
      double zSpeed = 0.1D * (double)(this.pos.getZ() - pedestalPos.getZ());
      if (this.level.getRandom().nextDouble() < 0.6D) {
         this.level.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, stack), posX, posY, posZ, 0, xSpeed, ySpeed, zSpeed, 0.9D);
      }

   }

   private void reset() {
      this.validRitual = null;
      this.setActiveRitual((Holder)null, (UUID)null);
      this.magicCircleController.removeMagicCircle(this.level, this.pos);
      this.updateRitualIndicator(false);
      this.clearPedestals();
   }

   private double getFailureChance() {
      return 0.0D;
   }

   public CompoundTag save(CompoundTag tag, Provider lookupProvider) {
      this.getActiveRitualData().flatMap((data) -> {
         return ActiveRitualData.CODEC.encodeStart(RegistryOps.create(NbtOps.INSTANCE, lookupProvider), this.activeRitualData).result();
      }).ifPresent((dataTag) -> {
         tag.put("active_ritual", dataTag);
      });
      return tag;
   }

   public void load(CompoundTag tag, Provider lookupProvider) {
      if (tag.contains("active_ritual")) {
         DataResult var10001 = ActiveRitualData.CODEC.parse(RegistryOps.create(NbtOps.INSTANCE, lookupProvider), tag.get("active_ritual"));
         PrintStream var10002 = System.err;
         Objects.requireNonNull(var10002);
         this.activeRitualData = (ActiveRitualData)var10001.resultOrPartial(var10002::println).orElse((Object)null);
      }

   }

   private void forEachPedestal(Predicate<PedestalBlockEntity> predicate, Consumer<PedestalBlockEntity> consumer) {
      Iterator var3 = this.dataCache.cachedIngredients().iterator();

      while(var3.hasNext()) {
         ForgeDataCache.IngredientEntry entry = (ForgeDataCache.IngredientEntry)var3.next();
         BlockEntity var6 = this.level.getBlockEntity(entry.pos());
         if (var6 instanceof PedestalBlockEntity) {
            PedestalBlockEntity blockEntity = (PedestalBlockEntity)var6;
            if (predicate.test(blockEntity)) {
               consumer.accept(blockEntity);
            }
         }
      }

   }

   private void updateRitualIndicator(boolean show) {
      if (this.level != null) {
         this.level.blockEvent(this.pos, this.level.getBlockState(this.pos).getBlock(), 1, BooleanUtils.toInteger(show));
      }

   }
}
