package com.stal111.forbidden_arcanus.common.block.pedestal.effect;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

public abstract class PedestalEffect {
   private final List<PedestalEffectTrigger> triggers;

   protected PedestalEffect(PedestalEffectTrigger... triggers) {
      this.triggers = List.of(triggers);
   }

   public abstract void execute(ServerLevel var1, BlockPos var2, ItemStack var3);

   public boolean shouldExecute(PedestalEffectTrigger trigger) {
      return this.triggers.contains(trigger);
   }
}
