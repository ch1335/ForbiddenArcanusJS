package com.stal111.forbidden_arcanus.common.block.clibano;

import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFrameBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoMainBlockEntity;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import java.util.Iterator;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.Vec3;

public class ClibanoMainPartBlock extends Block implements EntityBlock {
   public ClibanoMainPartBlock(Properties properties) {
      super(properties);
   }

   @Nullable
   public BlockEntity newBlockEntity(@Nonnull BlockPos pos, @Nonnull BlockState state) {
      return new ClibanoMainBlockEntity(pos, state);
   }

   @Nonnull
   public RenderShape getRenderShape(@Nonnull BlockState state) {
      return RenderShape.INVISIBLE;
   }

   public void onRemove(@Nonnull BlockState state, @Nonnull Level level, @Nonnull BlockPos pos, @Nonnull BlockState newState, boolean isMoving) {
      if (!state.is(newState.getBlock())) {
         if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            BlockEntity var8 = serverLevel.getBlockEntity(pos);
            if (var8 instanceof ClibanoMainBlockEntity) {
               ClibanoMainBlockEntity blockEntity = (ClibanoMainBlockEntity)var8;
               Containers.dropContents(level, pos, blockEntity.getStacks());
               blockEntity.getRecipesToAwardAndPopExperience(serverLevel, Vec3.atCenterOf(pos));
               super.onRemove(state, level, pos, newState, isMoving);
            }
         }

         dismantle(level, pos);
      }
   }

   public static void dismantle(Level level, BlockPos mainPos) {
      Iterable<BlockPos> positions = BlockPos.betweenClosed(mainPos.offset(-1, -1, -1), mainPos.offset(1, 1, 1));
      Iterator var3 = positions.iterator();

      while(var3.hasNext()) {
         BlockPos pos = (BlockPos)var3.next();
         BlockEntity var6 = level.getBlockEntity(pos);
         if (var6 instanceof ClibanoFrameBlockEntity) {
            ClibanoFrameBlockEntity blockEntity = (ClibanoFrameBlockEntity)var6;
            if (!level.getBlockState(pos).isAir()) {
               level.levelEvent(2001, pos, Block.getId(level.getBlockState(pos)));
               level.setBlockAndUpdate(pos, blockEntity.getFrameData().replaceState());
            }
         }
      }

   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(@Nonnull Level level, @Nonnull BlockState state, @Nonnull BlockEntityType<T> blockEntityType) {
      return level.isClientSide() ? null : BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.CLIBANO_MAIN.get(), ClibanoMainBlockEntity::serverTick);
   }
}
