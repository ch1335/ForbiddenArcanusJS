package com.stal111.forbidden_arcanus.common.block.clibano;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.Property;

public class ClibanoCornerBlock extends AbstractClibanoFrameBlock {
   public static final MapCodec<ClibanoCornerBlock> CODEC = simpleCodec(ClibanoCornerBlock::new);
   private static final BooleanProperty BOTTOM;

   public ClibanoCornerBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(this.getFacingProperty(), Direction.NORTH)).setValue(BOTTOM, true));
   }

   public DirectionProperty getFacingProperty() {
      return BlockStateProperties.HORIZONTAL_FACING;
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(this.getFacingProperty(), context.getHorizontalDirection().getOpposite());
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{this.getFacingProperty(), BOTTOM});
   }

   static {
      BOTTOM = BlockStateProperties.BOTTOM;
   }
}
