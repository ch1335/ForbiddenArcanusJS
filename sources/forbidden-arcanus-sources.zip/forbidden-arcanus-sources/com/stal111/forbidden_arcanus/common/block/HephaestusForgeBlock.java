package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.HephaestusForgeBlockEntity;
import com.stal111.forbidden_arcanus.common.block.entity.forge.HephaestusForgeLevel;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.item.component.RitualStarter;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.pattern.BlockPattern.BlockPatternMatch;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.valhelsia.valhelsia_core.api.common.helper.VoxelShapeHelper;
import org.jetbrains.annotations.Nullable;

public class HephaestusForgeBlock extends Block implements SimpleWaterloggedBlock, EntityBlock {
   private static final String DESCRIPTION_ID = Util.makeDescriptionId("block", ForbiddenArcanus.location("hephaestus_forge"));
   private static final String TIER_ID = Util.makeDescriptionId("block", ForbiddenArcanus.location("hephaestus_forge.tier"));
   public static final BooleanProperty ACTIVATED;
   public static final BooleanProperty WATERLOGGED;
   private static final VoxelShape SHAPE;
   private final HephaestusForgeLevel level;

   public HephaestusForgeBlock(HephaestusForgeLevel level, Properties properties) {
      super(properties);
      this.level = level;
      this.registerDefaultState((BlockState)((BlockState)((BlockState)this.getStateDefinition().any()).setValue(ACTIVATED, false)).setValue(WATERLOGGED, false));
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new HephaestusForgeBlockEntity(pos, state);
   }

   public String getDescriptionId() {
      return DESCRIPTION_ID;
   }

   public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> components, TooltipFlag flag) {
      components.add(Component.translatable(TIER_ID, new Object[]{this.level.getAsInt()}).withStyle(ChatFormatting.GRAY));
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return SHAPE;
   }

   @Nullable
   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(WATERLOGGED, context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER);
   }

   public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
      level.getBlockEntity(pos, (BlockEntityType)ModBlockEntities.HEPHAESTUS_FORGE.get()).ifPresent((blockEntity) -> {
         blockEntity.setForgeLevel(this.level);
      });
   }

   public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor level, BlockPos currentPos, BlockPos facingPos) {
      if ((Boolean)state.getValue(WATERLOGGED)) {
         level.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return super.updateShape(state, facing, facingState, level, currentPos, facingPos);
   }

   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult result) {
      this.updateState(state, level, pos);
      if ((Boolean)state.getValue(ACTIVATED)) {
         if (!level.isClientSide()) {
            BlockEntity var7 = level.getBlockEntity(pos);
            if (var7 instanceof HephaestusForgeBlockEntity) {
               HephaestusForgeBlockEntity blockEntity = (HephaestusForgeBlockEntity)var7;
               player.openMenu(blockEntity);
            }
         }

         return InteractionResult.sidedSuccess(level.isClientSide());
      } else {
         return super.useWithoutItem(state, level, pos, player, result);
      }
   }

   protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult result) {
      this.updateState(state, level, pos);
      RitualStarter ritualStarter = (RitualStarter)stack.get(ModDataComponents.RITUAL_STARTER);
      if ((Boolean)state.getValue(ACTIVATED) && ritualStarter != null) {
         BlockEntity var10 = level.getBlockEntity(pos);
         if (var10 instanceof HephaestusForgeBlockEntity) {
            HephaestusForgeBlockEntity blockEntity = (HephaestusForgeBlockEntity)var10;
            level.playSound(player, pos, (SoundEvent)ritualStarter.soundEvent().value(), SoundSource.PLAYERS, 0.85F, level.getRandom().nextFloat() * 0.15F + 0.9F);
            if (player instanceof ServerPlayer) {
               ServerPlayer serverPlayer = (ServerPlayer)player;
               if (blockEntity.getRitualManager().startRitual(serverPlayer, blockEntity.getEssenceManager().getStorage())) {
                  stack.hurtAndBreak(ritualStarter.damagePerRitual(), player, LivingEntity.getSlotForHand(hand));
               }
            }

            return ItemInteractionResult.sidedSuccess(level.isClientSide());
         }
      }

      return super.useItemOn(stack, state, level, pos, player, hand, result);
   }

   public void updateState(BlockState state, Level level, BlockPos pos) {
      BlockPatternMatch patternHelper = ModBlockPatterns.BASE_HEPHAESTUS_PATTERN.find(level, pos.below());
      if (patternHelper == null) {
         if ((Boolean)state.getValue(ACTIVATED)) {
            level.setBlockAndUpdate(pos, (BlockState)state.setValue(ACTIVATED, false));
         }
      } else if (!(Boolean)state.getValue(ACTIVATED)) {
         level.setBlockAndUpdate(pos, (BlockState)state.setValue(ACTIVATED, true));
      }

   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
      return level.isClientSide() ? BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.HEPHAESTUS_FORGE.get(), HephaestusForgeBlockEntity::clientTick) : BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.HEPHAESTUS_FORGE.get(), HephaestusForgeBlockEntity::serverTick);
   }

   public boolean triggerEvent(BlockState state, Level level, BlockPos pos, int id, int param) {
      super.triggerEvent(state, level, pos, id, param);
      BlockEntity blockEntity = level.getBlockEntity(pos);
      return blockEntity != null && blockEntity.triggerEvent(id, param);
   }

   public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
      if (!(newState.getBlock() instanceof HephaestusForgeBlock)) {
         if (level instanceof ServerLevel) {
            ServerLevel serverLevel = (ServerLevel)level;
            BlockEntity var8 = serverLevel.getBlockEntity(pos);
            if (var8 instanceof HephaestusForgeBlockEntity) {
               HephaestusForgeBlockEntity blockEntity = (HephaestusForgeBlockEntity)var8;
               Containers.dropContents(level, pos, blockEntity.getStacks());
            }
         }

         super.onRemove(state, level, pos, newState, movedByPiston);
      }
   }

   public HephaestusForgeLevel getLevel() {
      return this.level;
   }

   public FluidState getFluidState(BlockState state) {
      return (Boolean)state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{ACTIVATED, WATERLOGGED});
   }

   static {
      ACTIVATED = ModBlockStateProperties.ACTIVATED;
      WATERLOGGED = BlockStateProperties.WATERLOGGED;
      SHAPE = Shapes.join(VoxelShapeHelper.combineAll(new VoxelShape[]{box(1.0D, 0.0D, 1.0D, 15.0D, 3.0D, 15.0D), box(2.0D, 3.0D, 2.0D, 14.0D, 4.0D, 14.0D), box(4.0D, 4.0D, 4.0D, 12.0D, 8.0D, 12.0D), box(0.0D, 8.0D, 0.0D, 16.0D, 16.0D, 16.0D)}), VoxelShapeHelper.combineAll(new VoxelShape[]{box(0.0D, 15.0D, 3.0D, 16.0D, 16.0D, 13.0D), box(3.0D, 15.0D, 0.0D, 13.0D, 16.0D, 16.0D)}), BooleanOp.ONLY_FIRST);
   }
}
