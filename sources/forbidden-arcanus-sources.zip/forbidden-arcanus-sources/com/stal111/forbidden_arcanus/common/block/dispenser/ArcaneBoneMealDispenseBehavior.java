package com.stal111.forbidden_arcanus.common.block.dispenser;

import com.stal111.forbidden_arcanus.common.block.MagicalFarmlandBlock;
import com.stal111.forbidden_arcanus.common.item.ArcaneBoneMealItem;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.dispenser.OptionalDispenseItemBehavior;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

public class ArcaneBoneMealDispenseBehavior extends OptionalDispenseItemBehavior {
   @Nonnull
   protected ItemStack execute(@Nonnull BlockSource source, @Nonnull ItemStack stack) {
      Level level = source.level();
      BlockPos pos = source.pos().relative((Direction)source.state().getValue(DispenserBlock.FACING));
      BlockState state = level.getBlockState(pos);
      this.setSuccess(true);
      if (state.is(Blocks.FARMLAND)) {
         stack.shrink(1);
         level.setBlockAndUpdate(pos, (BlockState)((MagicalFarmlandBlock)ModBlocks.MAGICAL_FARMLAND.get()).defaultBlockState().setValue(BlockStateProperties.MOISTURE, (Integer)state.getValue(BlockStateProperties.MOISTURE)));
         level.levelEvent((Player)null, 2001, pos, Block.getId(state));
      } else if (ArcaneBoneMealItem.applyBoneMeal(stack, level, pos, (Player)null)) {
         if (!level.isClientSide()) {
            level.levelEvent(2005, pos, 0);
         }
      } else {
         this.setSuccess(false);
      }

      return stack;
   }
}
