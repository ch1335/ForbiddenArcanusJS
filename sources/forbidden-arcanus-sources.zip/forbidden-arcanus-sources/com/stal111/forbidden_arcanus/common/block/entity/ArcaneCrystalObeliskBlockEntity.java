package com.stal111.forbidden_arcanus.common.block.entity;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import com.stal111.forbidden_arcanus.core.init.other.ModPOITypes;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.village.poi.PoiManager.Occupancy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class ArcaneCrystalObeliskBlockEntity extends BlockEntity {
   public ArcaneCrystalObeliskBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.ARCANE_CRYSTAL_OBELISK.get(), pos, state);
   }

   public static void serverTick(Level level, BlockPos pos, BlockState state, ArcaneCrystalObeliskBlockEntity blockEntity) {
      if (level.getGameTime() % 100L == 0L && level instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)level;
         serverLevel.getPoiManager().findClosest((poiTypeHolder) -> {
            return poiTypeHolder.value() == ModPOITypes.HEPHAESTUS_FORGE.get();
         }, pos, 4, Occupancy.ANY).flatMap((forgePos) -> {
            return serverLevel.getBlockEntity(forgePos, (BlockEntityType)ModBlockEntities.HEPHAESTUS_FORGE.get());
         }).ifPresent((forgeBlockEntity) -> {
            forgeBlockEntity.getEssenceManager().increaseEssence(EssenceType.AUREAL, 1);
         });
      }
   }
}
