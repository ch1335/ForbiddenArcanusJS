package com.stal111.forbidden_arcanus.common.block.entity.desk;

import com.stal111.forbidden_arcanus.common.inventory.research.ResearchDeskMenu;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.valueproviders.IntProvider;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.items.IItemHandler;
import net.valhelsia.valhelsia_core.api.common.block.entity.MenuCreationContext;
import net.valhelsia.valhelsia_core.api.common.block.entity.neoforge.ValhelsiaContainerBlockEntity;
import org.jetbrains.annotations.NotNull;

public class ResearchDeskBlockEntity extends ValhelsiaContainerBlockEntity<ResearchDeskBlockEntity> {
   private static final int ANIMATION_LENGTH = 1000;
   private static final IntProvider TICKS_TILL_NEXT_PAGE_FLIP = UniformInt.of(140, 280);
   private int tickCount;
   public final AnimationState stillAnimation = new AnimationState();
   public final AnimationState openingAnimation = new AnimationState();
   public final AnimationState closingAnimation = new AnimationState();
   public final AnimationState levitateAnimation = new AnimationState();
   public final AnimationState pageAnimation = new AnimationState();
   private ResearchDeskBlockEntity.BookState bookState;
   public float rot;
   public float oRot;
   public float tRot;
   private int pageFlipCounter;

   public ResearchDeskBlockEntity(BlockPos pos, BlockState state) {
      super((BlockEntityType)ModBlockEntities.RESEARCH_DESK.get(), pos, state, 0);
      this.bookState = ResearchDeskBlockEntity.BookState.CLOSED;
   }

   public static void clientTick(Level level, BlockPos pos, BlockState state, ResearchDeskBlockEntity blockEntity) {
      Player player = level.getNearestPlayer((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D, 4.0D, false);
      Vec3 center = pos.getCenter();
      blockEntity.bookState = blockEntity.updateBookState(player != null);
      blockEntity.stillAnimation.animateWhen(blockEntity.bookState == ResearchDeskBlockEntity.BookState.CLOSED, blockEntity.tickCount);
      blockEntity.openingAnimation.animateWhen(blockEntity.bookState == ResearchDeskBlockEntity.BookState.OPENING, blockEntity.tickCount);
      blockEntity.closingAnimation.animateWhen(blockEntity.bookState == ResearchDeskBlockEntity.BookState.CLOSING, blockEntity.tickCount);
      blockEntity.levitateAnimation.animateWhen(blockEntity.bookState == ResearchDeskBlockEntity.BookState.OPEN, blockEntity.tickCount);
      blockEntity.pageAnimation.animateWhen(blockEntity.bookState == ResearchDeskBlockEntity.BookState.OPEN && blockEntity.pageFlipCounter != 0, blockEntity.tickCount);
      if (blockEntity.pageFlipCounter == 0) {
         blockEntity.pageFlipCounter = TICKS_TILL_NEXT_PAGE_FLIP.sample(level.getRandom());
      }

      --blockEntity.pageFlipCounter;
      blockEntity.oRot = blockEntity.rot;
      if (player != null) {
         blockEntity.tRot = (float)(Mth.atan2(player.getZ() - center.z(), player.getX() - center.x()) + 1.5707963267948966D);
      } else {
         blockEntity.tRot = blockEntity.calculateBaseRotation(state, pos);
      }

      blockEntity.adjustRotation();
      ++blockEntity.tickCount;
   }

   @NotNull
   private ResearchDeskBlockEntity.BookState updateBookState(boolean playerNearby) {
      boolean currentlyChanging = this.openingAnimation.isStarted() || this.closingAnimation.isStarted();
      ResearchDeskBlockEntity.BookState newState = ResearchDeskBlockEntity.BookState.CLOSED;
      if (this.bookState == ResearchDeskBlockEntity.BookState.CLOSED && playerNearby && !currentlyChanging || this.bookState == ResearchDeskBlockEntity.BookState.OPENING && this.openingAnimation.getAccumulatedTime() < 1000L) {
         newState = ResearchDeskBlockEntity.BookState.OPENING;
         if (this.bookState == ResearchDeskBlockEntity.BookState.CLOSED && this.level != null) {
         }
      } else if ((this.bookState != ResearchDeskBlockEntity.BookState.OPENING || this.openingAnimation.getAccumulatedTime() < 1000L) && (this.bookState != ResearchDeskBlockEntity.BookState.OPEN || !playerNearby)) {
         if (this.bookState == ResearchDeskBlockEntity.BookState.OPEN || this.bookState == ResearchDeskBlockEntity.BookState.CLOSING && this.closingAnimation.getAccumulatedTime() < 1000L) {
            newState = ResearchDeskBlockEntity.BookState.CLOSING;
            if (this.bookState == ResearchDeskBlockEntity.BookState.OPEN && this.level != null) {
            }
         }
      } else {
         newState = ResearchDeskBlockEntity.BookState.OPEN;
      }

      return newState;
   }

   public void onLoad() {
      if (this.level != null && this.level.isClientSide()) {
         this.rot = this.calculateBaseRotation(this.getBlockState(), this.getBlockPos());
         this.stillAnimation.startIfStopped(this.tickCount);
      }

   }

   private void adjustRotation() {
      while((double)this.rot >= 3.141592653589793D) {
         this.rot -= 6.2831855F;
      }

      while((double)this.rot < -3.141592653589793D) {
         this.rot += 6.2831855F;
      }

      while((double)this.tRot >= 3.141592653589793D) {
         this.tRot -= 6.2831855F;
      }

      while((double)this.tRot < -3.141592653589793D) {
         this.tRot += 6.2831855F;
      }

      float f2;
      for(f2 = this.tRot - this.rot; (double)f2 >= 3.141592653589793D; f2 -= 6.2831855F) {
      }

      while((double)f2 < -3.141592653589793D) {
         f2 += 6.2831855F;
      }

      this.rot += f2 * 0.4F;
   }

   public float calculateBaseRotation(BlockState state, BlockPos pos) {
      Vec3 center = pos.getCenter();
      Direction direction = ((Direction)state.getValue(BlockStateProperties.HORIZONTAL_FACING)).getClockWise();
      Vec3 offsetPos = center.relative(direction, 1.0D);
      return (float)Mth.atan2(offsetPos.z() - center.z(), offsetPos.x() - center.x());
   }

   public int getTickCount() {
      return this.tickCount;
   }

   protected Component getDefaultName() {
      return Component.empty();
   }

   protected AbstractContainerMenu createMenu(int containerId, @NotNull MenuCreationContext<ResearchDeskBlockEntity, IItemHandler> menuCreationContext) {
      return new ResearchDeskMenu(containerId, menuCreationContext);
   }

   private static enum BookState {
      CLOSED,
      OPENING,
      OPEN,
      CLOSING;

      // $FF: synthetic method
      private static ResearchDeskBlockEntity.BookState[] $values() {
         return new ResearchDeskBlockEntity.BookState[]{CLOSED, OPENING, OPEN, CLOSING};
      }
   }
}
