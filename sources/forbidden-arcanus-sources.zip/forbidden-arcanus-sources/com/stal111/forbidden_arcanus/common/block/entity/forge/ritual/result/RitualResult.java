package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result;

import com.mojang.serialization.Codec;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public interface RitualResult {
   Codec<RitualResult> DIRECT_CODEC;

   ItemStack getResultItem(ItemStack var1);

   default void executeLevelEffect(Level level, BlockPos pos) {
   }

   RitualResultType<? extends RitualResult> getType();

   static {
      Registry var10000 = FARegistries.RITUAL_RESULT_TYPE_REGISTRY;
      Objects.requireNonNull(var10000);
      DIRECT_CODEC = Codec.lazyInitialized(var10000::byNameCodec).dispatch(RitualResult::getType, RitualResultType::codec);
   }
}
