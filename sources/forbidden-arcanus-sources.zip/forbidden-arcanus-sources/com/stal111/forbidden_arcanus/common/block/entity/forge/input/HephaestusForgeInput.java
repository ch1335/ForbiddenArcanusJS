package com.stal111.forbidden_arcanus.common.block.entity.forge.input;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;

public interface HephaestusForgeInput {
   boolean canInput(EssenceType var1, ItemStack var2);

   EssenceValue getInputValue(ItemStack var1, RandomSource var2);

   default EssenceValue getMaxInputValue(ItemStack stack, RandomSource random) {
      return this.getInputValue(stack, random);
   }

   ItemStack finishInput(ItemStack var1, int var2);
}
