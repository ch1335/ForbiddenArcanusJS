package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result;

import com.mojang.serialization.MapCodec;

public record RitualResultType<T extends RitualResult>(MapCodec<T> codec) {
   public RitualResultType(MapCodec<T> codec) {
      this.codec = codec;
   }

   public MapCodec<T> codec() {
      return this.codec;
   }
}
