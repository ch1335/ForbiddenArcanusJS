package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.entity.ArcaneCrystalObeliskBlockEntity;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.ObeliskPart;
import com.stal111.forbidden_arcanus.core.init.ModBlockEntities;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class ArcaneCrystalObeliskBlock extends Block implements SimpleWaterloggedBlock, EntityBlock {
   public static final EnumProperty<ObeliskPart> PART;
   public static final BooleanProperty ACTIVE;
   public static final BooleanProperty WATERLOGGED;
   private static final Map<ObeliskPart, VoxelShape> SHAPES;

   public ArcaneCrystalObeliskBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.getStateDefinition().any()).setValue(PART, ObeliskPart.LOWER)).setValue(ACTIVE, false)).setValue(WATERLOGGED, false));
   }

   @Nullable
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return (Boolean)state.getValue(ACTIVE) && state.getValue(PART) == ObeliskPart.LOWER ? new ArcaneCrystalObeliskBlockEntity(pos, state) : null;
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return (VoxelShape)SHAPES.get(state.getValue(PART));
   }

   @Nullable
   public BlockState getStateForPlacement(BlockPlaceContext context) {
      BlockPos pos = context.getClickedPos();
      Level level = context.getLevel();
      return pos.getY() <= level.getMaxBuildHeight() - 3 && level.getBlockState(pos.above()).canBeReplaced(context) && level.getBlockState(pos.above(2)).canBeReplaced(context) ? (BlockState)((BlockState)this.defaultBlockState().setValue(ACTIVE, shouldActivate(level, pos))).setValue(WATERLOGGED, level.getFluidState(pos).getType() == Fluids.WATER) : null;
   }

   public BlockState updateShape(BlockState state, Direction facing, BlockState facingState, LevelAccessor level, BlockPos pos, BlockPos facingPos) {
      if ((Boolean)state.getValue(WATERLOGGED)) {
         level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      ObeliskPart part = (ObeliskPart)state.getValue(PART);
      if (facing.getAxis() != Axis.Y) {
         return state;
      } else if (part == ObeliskPart.LOWER != (facing == Direction.UP) && part != ObeliskPart.MIDDLE) {
         return part == ObeliskPart.LOWER && facing == Direction.DOWN && !state.canSurvive(level, pos) ? Blocks.AIR.defaultBlockState() : state;
      } else {
         return facingState.is(this) && facingState.getValue(PART) != part ? state : Blocks.AIR.defaultBlockState();
      }
   }

   public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean isMoving) {
      if (fromPos.equals(pos.below())) {
         boolean flag = shouldActivate(level, pos);
         if ((Boolean)state.getValue(ACTIVE) != flag) {
            level.setBlockAndUpdate(pos, (BlockState)state.setValue(ACTIVE, flag));
         }

      }
   }

   public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
      if (!level.isClientSide() && (player.isCreative() || !player.hasCorrectToolForDrops(state))) {
         ObeliskPart part = (ObeliskPart)state.getValue(PART);
         if (part != ObeliskPart.LOWER) {
            BlockPos offsetPos = pos.below(part == ObeliskPart.MIDDLE ? 1 : 2);
            BlockState offsetState = level.getBlockState(offsetPos);
            level.setBlock(offsetPos, offsetState.getFluidState().is(Fluids.WATER) ? Blocks.WATER.defaultBlockState() : Blocks.AIR.defaultBlockState(), 35);
            level.levelEvent(player, 2001, offsetPos, Block.getId(offsetState));
         }
      }

      return super.playerWillDestroy(level, pos, state, player);
   }

   public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity entity, ItemStack stack) {
      level.setBlockAndUpdate(pos.above(), (BlockState)((BlockState)state.setValue(PART, ObeliskPart.MIDDLE)).setValue(WATERLOGGED, level.getFluidState(pos.above()).getType() == Fluids.WATER));
      level.setBlockAndUpdate(pos.above(2), (BlockState)((BlockState)state.setValue(PART, ObeliskPart.UPPER)).setValue(WATERLOGGED, level.getFluidState(pos.above(2)).getType() == Fluids.WATER));
   }

   public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
      BlockPos posDown = pos.below();
      BlockState stateDown = level.getBlockState(posDown);
      return state.getValue(PART) == ObeliskPart.LOWER ? stateDown.isFaceSturdy(level, posDown, Direction.UP) : stateDown.is(this);
   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> blockEntityType) {
      return !level.isClientSide() ? BaseEntityBlock.createTickerHelper(blockEntityType, (BlockEntityType)ModBlockEntities.ARCANE_CRYSTAL_OBELISK.get(), ArcaneCrystalObeliskBlockEntity::serverTick) : null;
   }

   public static boolean shouldActivate(Level level, BlockPos pos) {
      return level.getBlockState(pos.below()).is((Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get());
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{PART, ACTIVE, WATERLOGGED});
   }

   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return false;
   }

   public FluidState getFluidState(BlockState state) {
      return (Boolean)state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   static {
      PART = ModBlockStateProperties.OBELISK_PART;
      ACTIVE = ModBlockStateProperties.ACTIVE;
      WATERLOGGED = BlockStateProperties.WATERLOGGED;
      SHAPES = (Map)Util.make(new EnumMap(ObeliskPart.class), (map) -> {
         map.put(ObeliskPart.LOWER, Shapes.or(Block.box(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.box(1.0D, 8.0D, 1.0D, 15.0D, 16.0D, 15.0D)));
         map.put(ObeliskPart.MIDDLE, Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D));
         map.put(ObeliskPart.UPPER, Block.box(3.0D, 0.0D, 3.0D, 13.0D, 14.0D, 13.0D));
      });
   }
}
