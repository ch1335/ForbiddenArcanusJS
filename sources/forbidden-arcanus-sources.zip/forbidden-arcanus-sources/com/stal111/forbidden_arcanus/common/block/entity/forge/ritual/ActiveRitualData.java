package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.UUID;
import net.minecraft.core.Holder;
import net.minecraft.core.UUIDUtil;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

public class ActiveRitualData {
   public static final Codec<ActiveRitualData> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(Ritual.CODEC.fieldOf("ritual").forGetter((data) -> {
         return data.ritual;
      }), Codec.INT.fieldOf("counter").forGetter((data) -> {
         return data.counter;
      }), Codec.INT.fieldOf("lightning_counter").forGetter((data) -> {
         return data.lightningCounter;
      }), UUIDUtil.CODEC.fieldOf("started_by").forGetter((data) -> {
         return data.startedBy;
      })).apply(instance, ActiveRitualData::new);
   });
   private final Holder<Ritual> ritual;
   private int counter;
   private int lightningCounter;
   private final UUID startedBy;

   public ActiveRitualData(Holder<Ritual> ritual, int counter, int lightningCounter, UUID startedBy) {
      this.ritual = ritual;
      this.counter = counter;
      this.lightningCounter = lightningCounter;
      this.startedBy = startedBy;
   }

   public static ActiveRitualData create(Holder<Ritual> ritual, UUID startedBy) {
      return new ActiveRitualData(ritual, 0, 0, startedBy);
   }

   public float calculateRitualProgress() {
      return (float)this.counter / (float)((Ritual)this.ritual.value()).duration();
   }

   public Ritual getRitual() {
      return (Ritual)this.ritual.value();
   }

   public int getCounter() {
      return this.counter;
   }

   public void incrementCounter() {
      ++this.counter;
   }

   public int getLightningCounter() {
      return this.lightningCounter;
   }

   public void incrementLightningCounter() {
      ++this.lightningCounter;
   }

   public UUID getStartedBy() {
      return this.startedBy;
   }

   @Nullable
   public ResourceLocation getRitualId() {
      return (ResourceLocation)this.ritual.unwrapKey().map(ResourceKey::location).orElse((Object)null);
   }
}
