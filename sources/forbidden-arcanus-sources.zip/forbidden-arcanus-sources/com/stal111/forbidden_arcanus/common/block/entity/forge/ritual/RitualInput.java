package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.item.crafting.Ingredient;

public record RitualInput(Ingredient ingredient, int amount) {
   public static final Codec<RitualInput> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(Ingredient.CODEC_NONEMPTY.fieldOf("ingredient").forGetter((input) -> {
         return input.ingredient;
      }), ExtraCodecs.POSITIVE_INT.optionalFieldOf("amount").forGetter((input) -> {
         return Optional.of(input.amount);
      })).apply(instance, (name, amount) -> {
         return new RitualInput(name, (Integer)amount.orElse(1));
      });
   });

   public RitualInput(Ingredient ingredient, int amount) {
      this.ingredient = ingredient;
      this.amount = amount;
   }

   public Ingredient ingredient() {
      return this.ingredient;
   }

   public int amount() {
      return this.amount;
   }
}
