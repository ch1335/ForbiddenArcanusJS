package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.pattern.UpwardsBlockPattern;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.util.ModTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour.BlockStateBase;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;
import net.minecraft.world.level.block.state.pattern.BlockPattern;
import net.minecraft.world.level.block.state.pattern.BlockPatternBuilder;
import net.minecraft.world.level.block.state.predicate.BlockPredicate;
import net.minecraft.world.level.block.state.predicate.BlockStatePredicate;

public class ModBlockPatterns {
   public static final BlockPattern HEPHAESTUS_PATTERN;
   public static final BlockPattern BASE_HEPHAESTUS_PATTERN;
   public static final BlockPattern ARCANE_CRYSTAL_OBELISK_PATTERN;
   public static final BlockPattern CLIBANO_COMBUSTION_BASE;
   public static final BlockPattern CLIBANO_COMBUSTION;

   static {
      HEPHAESTUS_PATTERN = UpwardsBlockPattern.of(BlockPatternBuilder.start().aisle(new String[]{"***~~~***", "***PPP***"}).aisle(new String[]{"*~~~#~~~*", "*PPPAPPP*"}).aisle(new String[]{"*~#~~~#~*", "*PAPPPAP*"}).aisle(new String[]{"~~~~~~~~~", "PPPPCPPPP"}).aisle(new String[]{"~#~~^~~#~", "PAPCACPAP"}).aisle(new String[]{"~~~~~~~~~", "PPPPCPPPP"}).aisle(new String[]{"*~#~~~#~*", "*PAPPPAP*"}).aisle(new String[]{"*~~~#~~~*", "*PPPAPPP*"}).aisle(new String[]{"***~~~***", "***PPP***"}).where('^', BlockInWorld.hasState(BlockStatePredicate.forBlock(Blocks.SMITHING_TABLE))).where('A', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get()))).where('C', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.CHISELED_ARCANE_POLISHED_DARKSTONE.get()))).where('P', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.POLISHED_DARKSTONE.get()))).where('~', BlockInWorld.hasState(BlockStateBase::isAir)).where('#', BlockInWorld.hasState((state) -> {
         return state.is(ModTags.Blocks.PEDESTALS) || state.isAir();
      })).where('*', BlockInWorld.hasState(BlockStatePredicate.ANY)));
      BASE_HEPHAESTUS_PATTERN = UpwardsBlockPattern.of(BlockPatternBuilder.start().aisle(new String[]{"***PPP***"}).aisle(new String[]{"*PPPAPPP*"}).aisle(new String[]{"*PAPPPAP*"}).aisle(new String[]{"PPPPCPPPP"}).aisle(new String[]{"PAPCACPAP"}).aisle(new String[]{"PPPPCPPPP"}).aisle(new String[]{"*PAPPPAP*"}).aisle(new String[]{"*PPPAPPP*"}).aisle(new String[]{"***PPP***"}).where('A', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.GILDED_CHISELED_POLISHED_DARKSTONE.get()))).where('C', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.CHISELED_ARCANE_POLISHED_DARKSTONE.get()))).where('P', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.POLISHED_DARKSTONE.get()))).where('*', BlockInWorld.hasState(BlockStatePredicate.ANY)));
      ARCANE_CRYSTAL_OBELISK_PATTERN = UpwardsBlockPattern.of(BlockPatternBuilder.start().aisle(new String[]{"#", "#", "X"}).where('#', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.ARCANE_CRYSTAL_BLOCK.get()))).where('X', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.ARCANE_POLISHED_DARKSTONE.get()))));
      CLIBANO_COMBUSTION_BASE = UpwardsBlockPattern.of(BlockPatternBuilder.start().aisle(new String[]{"PBP", "BBB", "PBP"}).aisle(new String[]{"BBB", "BAB", "BBB"}).aisle(new String[]{"PBP", "BCB", "PBP"}).where('P', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.POLISHED_DARKSTONE.get()))).where('B', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.POLISHED_DARKSTONE_BRICKS.get()))).where('C', BlockInWorld.hasState(BlockStatePredicate.forBlock((Block)ModBlocks.CLIBANO_CORE.get()))).where('A', (blockInWorld) -> {
         return blockInWorld.getState().isAir();
      }));
      CLIBANO_COMBUSTION = UpwardsBlockPattern.of(BlockPatternBuilder.start().aisle(new String[]{"CVC", "HXH", "CVC"}).aisle(new String[]{"VXV", "XMX", "VXV"}).aisle(new String[]{"CVC", "HXH", "CVC"}).where('C', BlockInWorld.hasState(BlockPredicate.forBlock((Block)ModBlocks.CLIBANO_CORNER.get()))).where('V', BlockInWorld.hasState(BlockPredicate.forBlock((Block)ModBlocks.CLIBANO_SIDE_VERTICAL.get()))).where('H', BlockInWorld.hasState(BlockPredicate.forBlock((Block)ModBlocks.CLIBANO_SIDE_HORIZONTAL.get()))).where('M', BlockInWorld.hasState(BlockPredicate.forBlock((Block)ModBlocks.CLIBANO_MAIN_PART.get()))).where('X', BlockInWorld.hasState(BlockPredicate.forBlock((Block)ModBlocks.CLIBANO_CENTER.get()))));
   }
}
