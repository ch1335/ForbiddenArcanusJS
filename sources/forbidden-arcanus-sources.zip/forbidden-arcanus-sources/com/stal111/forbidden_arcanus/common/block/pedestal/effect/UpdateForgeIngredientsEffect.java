package com.stal111.forbidden_arcanus.common.block.pedestal.effect;

import com.stal111.forbidden_arcanus.common.block.entity.forge.HephaestusForgeBlockEntity;
import com.stal111.forbidden_arcanus.core.init.other.ModPOITypes;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.village.poi.PoiRecord;
import net.minecraft.world.entity.ai.village.poi.PoiManager.Occupancy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

public class UpdateForgeIngredientsEffect extends PedestalEffect {
   public UpdateForgeIngredientsEffect() {
      super(PedestalEffectTrigger.PLAYER_PLACE_ITEM, PedestalEffectTrigger.PLAYER_REMOVE_ITEM, PedestalEffectTrigger.ENTITY_SUMMONED, PedestalEffectTrigger.MAGNETIZED_PICKUP, PedestalEffectTrigger.LOAD);
   }

   public void execute(ServerLevel level, BlockPos pos, ItemStack stack) {
      findHephaestusForge(level, pos).ifPresent((forgePos) -> {
         BlockEntity patt0$temp = level.getBlockEntity(forgePos);
         if (patt0$temp instanceof HephaestusForgeBlockEntity) {
            HephaestusForgeBlockEntity blockEntity = (HephaestusForgeBlockEntity)patt0$temp;
            blockEntity.updatePedestalStack(pos, stack);
         }

      });
   }

   private static Optional<BlockPos> findHephaestusForge(ServerLevel level, BlockPos pos) {
      return level.getPoiManager().getInRange((poiTypeHolder) -> {
         return poiTypeHolder.value() == ModPOITypes.HEPHAESTUS_FORGE.get();
      }, pos, 4, Occupancy.ANY).map(PoiRecord::getPos).findFirst();
   }
}
