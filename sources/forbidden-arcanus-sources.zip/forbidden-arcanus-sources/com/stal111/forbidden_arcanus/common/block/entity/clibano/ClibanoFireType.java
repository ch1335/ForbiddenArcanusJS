package com.stal111.forbidden_arcanus.common.block.entity.clibano;

import com.stal111.forbidden_arcanus.util.ModTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.StringRepresentable;
import net.minecraft.util.StringRepresentable.EnumCodec;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public enum ClibanoFireType implements StringRepresentable {
   FIRE("fire", 13, 1.0D, (TagKey)null),
   SOUL_FIRE("soul_fire", 9, 1.5D, ModTags.Items.CLIBANO_CREATES_SOUL_FIRE),
   ENCHANTED_FIRE("enchanted_fire", 14, 2.5D, ModTags.Items.CLIBANO_CREATES_ENCHANTED_FIRE);

   public static final EnumCodec<ClibanoFireType> CODEC = StringRepresentable.fromEnum(ClibanoFireType::values);
   private final String name;
   private final int lightLevel;
   private final double cookingSpeedMultiplier;
   private final TagKey<Item> tagKey;

   private ClibanoFireType(String param3, int param4, double param5, @Nullable TagKey<Item> param7) {
      this.name = name;
      this.lightLevel = lightLevel;
      this.cookingSpeedMultiplier = cookingSpeedMultiplier;
      this.tagKey = tagKey;
   }

   @NotNull
   public String getSerializedName() {
      return this.name;
   }

   public int getLightLevel() {
      return this.lightLevel;
   }

   public double getCookingSpeedMultiplier() {
      return this.cookingSpeedMultiplier;
   }

   @Nullable
   public TagKey<Item> getTagKey() {
      return this.tagKey;
   }

   public static ClibanoFireType fromItem(ItemStack stack) {
      ClibanoFireType[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         ClibanoFireType type = var1[var3];
         if (type.getTagKey() != null && stack.is(type.getTagKey())) {
            return type;
         }
      }

      return FIRE;
   }

   // $FF: synthetic method
   private static ClibanoFireType[] $values() {
      return new ClibanoFireType[]{FIRE, SOUL_FIRE, ENCHANTED_FIRE};
   }
}
