package com.stal111.forbidden_arcanus.common.block.entity.forge.essence;

public interface EssencesContainer {
   void setEssencesLimit(EssencesDefinition var1);

   EssencesDefinition getEssences();

   void setEssences(EssencesDefinition var1);
}
