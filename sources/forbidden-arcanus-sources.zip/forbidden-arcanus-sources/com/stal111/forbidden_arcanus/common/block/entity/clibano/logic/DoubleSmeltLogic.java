package com.stal111.forbidden_arcanus.common.block.entity.clibano.logic;

import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFireType;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoInputSlot;
import com.stal111.forbidden_arcanus.common.item.crafting.ClibanoRecipe;
import java.util.List;
import net.minecraft.world.item.crafting.RecipeHolder;
import org.jetbrains.annotations.Nullable;

public class DoubleSmeltLogic extends ClibanoSmeltLogic {
   @Nullable
   private RecipeHolder<ClibanoRecipe> recipe;

   public DoubleSmeltLogic(ClibanoAccessor clibano, @Nullable RecipeHolder<ClibanoRecipe> recipe) {
      super(clibano);
      this.recipe = recipe;
   }

   public void tick(boolean isLit) {
      super.tick(isLit);
      if (this.canSmelt()) {
         this.cookingDuration[0] = this.clibano.getCookingTime(this.recipe);
         this.cookingDuration[1] = this.clibano.getCookingTime(this.recipe);
         int var10002 = this.cookingProgress[0]++;
         var10002 = this.cookingProgress[1]++;
         if (this.cookingProgress[0] == this.cookingDuration[0]) {
            this.clibano.finishRecipe(this.recipe, ClibanoInputSlot.BOTH);
         }
      } else {
         this.resetCookingProgress(0);
         this.resetCookingProgress(1);
      }

   }

   public boolean canSmelt() {
      return this.clibano.canSmelt(this.recipe, ClibanoInputSlot.BOTH);
   }

   public void onFireTypeChange(ClibanoFireType fireType) {
      this.updateCookingProgress(fireType, this.recipe, 0);
      this.updateCookingProgress(fireType, this.recipe, 1);
   }

   public void updateRecipes(List<RecipeHolder<ClibanoRecipe>> recipeHolders) {
      this.recipe = recipeHolders.isEmpty() ? null : (RecipeHolder)recipeHolders.getFirst();
   }
}
