package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.core.init.ModRitualResultTypes;
import net.minecraft.core.Holder;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public record TransmuteInputResult(Holder<Item> result) implements RitualResult {
   public static final MapCodec<TransmuteInputResult> CODEC = RecordCodecBuilder.mapCodec((instance) -> {
      return instance.group(ItemStack.ITEM_NON_AIR_CODEC.fieldOf("result_item").forGetter(TransmuteInputResult::result)).apply(instance, TransmuteInputResult::new);
   });

   public TransmuteInputResult(Holder<Item> result) {
      this.result = result;
   }

   public ItemStack getResultItem(ItemStack mainInput) {
      return mainInput.transmuteCopy((ItemLike)this.result.value());
   }

   public RitualResultType<? extends RitualResult> getType() {
      return (RitualResultType)ModRitualResultTypes.TRANSMUTE_INPUT.get();
   }

   public Holder<Item> result() {
      return this.result;
   }
}
