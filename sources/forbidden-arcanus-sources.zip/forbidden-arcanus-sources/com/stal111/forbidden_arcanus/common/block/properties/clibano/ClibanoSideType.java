package com.stal111.forbidden_arcanus.common.block.properties.clibano;

import javax.annotation.Nonnull;
import net.minecraft.util.StringRepresentable;

public enum ClibanoSideType implements StringRepresentable {
   OFF("off"),
   FIRE("fire"),
   SOUL_FIRE("soul_fire"),
   ENCHANTED_FIRE("enchanted_fire");

   private final String name;

   private ClibanoSideType(String param3) {
      this.name = name;
   }

   @Nonnull
   public String getSerializedName() {
      return this.name;
   }

   // $FF: synthetic method
   private static ClibanoSideType[] $values() {
      return new ClibanoSideType[]{OFF, FIRE, SOUL_FIRE, ENCHANTED_FIRE};
   }
}
