package com.stal111.forbidden_arcanus.common.block;

import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class MysterywoodLogBlock extends RotatedPillarBlock {
   private static final double PARTICLE_SPEED_MODIFIER = 0.3D;

   public MysterywoodLogBlock(Properties properties) {
      super(properties);
   }

   public void animateTick(@Nonnull BlockState state, @Nonnull Level level, @Nonnull BlockPos pos, @Nonnull RandomSource random) {
      double xSpeed = ((double)random.nextFloat() - 0.5D) * 0.3D;
      double ySpeed = ((double)random.nextFloat() - 0.5D) * 0.3D;
      double zSpeed = ((double)random.nextFloat() - 0.5D) * 0.3D;
      level.addParticle(ParticleTypes.END_ROD, (double)((float)pos.getX() + random.nextFloat()), (double)((float)pos.getY() + random.nextFloat()), (double)((float)pos.getZ() + random.nextFloat()), xSpeed, ySpeed, zSpeed);
   }
}
