package com.stal111.forbidden_arcanus.common.block.entity.forge.ritual;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ForgeDataCache;
import com.stal111.forbidden_arcanus.common.block.entity.forge.circle.MagicCircleType;
import com.stal111.forbidden_arcanus.common.block.entity.forge.ritual.result.RitualResult;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.resources.RegistryFileCodec;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

public record Ritual(List<RitualInput> inputs, Ingredient mainIngredient, RitualResult result, RitualRequirements requirements, Holder<MagicCircleType> magicCircleType, int duration) {
   public static final int DEFAULT_DURATION = 500;
   public static final Codec<Ritual> DIRECT_CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(RitualInput.CODEC.listOf(1, 8).fieldOf("inputs").forGetter((ritual) -> {
         return ritual.inputs;
      }), Ingredient.CODEC_NONEMPTY.fieldOf("main_ingredient").forGetter((ritual) -> {
         return ritual.mainIngredient;
      }), RitualResult.DIRECT_CODEC.fieldOf("result").forGetter((ritual) -> {
         return ritual.result;
      }), RitualRequirements.CODEC.forGetter((ritual) -> {
         return ritual.requirements;
      }), MagicCircleType.CODEC.fieldOf("magic_circle").forGetter((ritual) -> {
         return ritual.magicCircleType;
      }), ExtraCodecs.POSITIVE_INT.optionalFieldOf("duration", 500).forGetter((ritual) -> {
         return ritual.duration;
      })).apply(instance, Ritual::new);
   });
   public static final Codec<Holder<Ritual>> CODEC;
   public static final Codec<Ritual> NETWORK_CODEC;

   public Ritual(List<RitualInput> inputs, Ingredient mainIngredient, RitualResult result, RitualRequirements requirements, Holder<MagicCircleType> magicCircleType, int duration) {
      this.inputs = inputs;
      this.mainIngredient = mainIngredient;
      this.result = result;
      this.requirements = requirements;
      this.magicCircleType = magicCircleType;
      this.duration = duration;
   }

   public boolean canStart(ForgeDataCache dataCache, int forgeTier) {
      return !this.requirements.checkRequirements(forgeTier, dataCache.getEnhancers()) ? false : this.checkIngredients(dataCache.getIngredients(), dataCache.mainIngredient());
   }

   public boolean checkIngredients(Collection<ItemStack> list, ItemStack mainIngredient) {
      if (!this.mainIngredient().test(mainIngredient)) {
         return false;
      } else {
         List<ItemStack> ingredients = new ArrayList(list);
         Iterator var4 = this.inputs().iterator();

         label27:
         while(var4.hasNext()) {
            RitualInput input = (RitualInput)var4.next();
            int amount = 0;
            Iterator iterator = ingredients.iterator();

            while(iterator.hasNext()) {
               if (input.ingredient().test((ItemStack)iterator.next())) {
                  iterator.remove();
                  ++amount;
                  if (amount == input.amount()) {
                     continue label27;
                  }
               }
            }

            return false;
         }

         return ingredients.stream().filter((stack) -> {
            return !stack.isEmpty();
         }).toList().isEmpty();
      }
   }

   public List<RitualInput> inputs() {
      return this.inputs;
   }

   public Ingredient mainIngredient() {
      return this.mainIngredient;
   }

   public RitualResult result() {
      return this.result;
   }

   public RitualRequirements requirements() {
      return this.requirements;
   }

   public Holder<MagicCircleType> magicCircleType() {
      return this.magicCircleType;
   }

   public int duration() {
      return this.duration;
   }

   static {
      CODEC = RegistryFileCodec.create(FARegistries.RITUAL, DIRECT_CODEC);
      NETWORK_CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(RitualInput.CODEC.listOf().fieldOf("inputs").forGetter((ritual) -> {
            return ritual.inputs;
         }), Ingredient.CODEC_NONEMPTY.fieldOf("main_ingredient").forGetter((ritual) -> {
            return ritual.mainIngredient;
         }), RitualResult.DIRECT_CODEC.fieldOf("result").forGetter((ritual) -> {
            return ritual.result;
         }), RitualRequirements.CODEC.forGetter((ritual) -> {
            return ritual.requirements;
         }), ExtraCodecs.POSITIVE_INT.optionalFieldOf("duration", 500).forGetter((ritual) -> {
            return ritual.duration;
         })).apply(instance, (inputs, mainIngredient, result, requirements, duration) -> {
            return new Ritual(inputs, mainIngredient, result, requirements, (Holder)null, duration);
         });
      });
   }
}
