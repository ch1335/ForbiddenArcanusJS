package com.stal111.forbidden_arcanus.common.block.pedestal.effect;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.core.init.ModEntities;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.core.registry.FARegistries;
import net.minecraft.world.item.Item;
import net.valhelsia.valhelsia_core.api.common.registry.RegistryEntry;
import net.valhelsia.valhelsia_core.api.common.registry.helper.MappedRegistryHelper;

public class PedestalEffects {
   public static final MappedRegistryHelper<PedestalEffect> HELPER;
   public static final RegistryEntry<PedestalEffect, PedestalEffect> UPDATE_FORGE_INGREDIENTS;
   public static final RegistryEntry<PedestalEffect, PedestalEffect> SUMMON_DARK_TRADER;

   static {
      HELPER = (MappedRegistryHelper)ForbiddenArcanus.REGISTRY_MANAGER.getHelper(FARegistries.PEDESTAL_EFFECT);
      UPDATE_FORGE_INGREDIENTS = HELPER.register("update_forge_ingredients", UpdateForgeIngredientsEffect::new);
      SUMMON_DARK_TRADER = HELPER.register("summon_dark_trader", () -> {
         return new SummonEntityEffect((level, stack) -> {
            return stack.is((Item)ModItems.OMEGA_ARCOIN.get());
         }, ModEntities.DARK_TRADER, 10, false);
      });
   }
}
