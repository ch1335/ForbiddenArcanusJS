package com.stal111.forbidden_arcanus.common.block;

import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class MagicalFarmlandBlock extends FarmBlock {
   public MagicalFarmlandBlock(Properties properties) {
      super(properties);
   }
}
