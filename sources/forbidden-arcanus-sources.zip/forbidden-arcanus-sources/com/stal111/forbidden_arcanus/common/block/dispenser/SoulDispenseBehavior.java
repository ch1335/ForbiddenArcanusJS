package com.stal111.forbidden_arcanus.common.block.dispenser;

import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.state.BlockState;

public class SoulDispenseBehavior extends DefaultDispenseItemBehavior {
   @Nonnull
   protected ItemStack execute(@Nonnull BlockSource source, @Nonnull ItemStack stack) {
      Level level = source.level();
      BlockPos pos = source.pos().relative((Direction)source.state().getValue(DispenserBlock.FACING));
      BlockState state = level.getBlockState(pos);
      if (state.is((Block)ModBlocks.SOULLESS_SAND.get())) {
         stack.shrink(1);
         level.setBlockAndUpdate(pos, Blocks.SOUL_SAND.defaultBlockState());
         level.levelEvent((Player)null, 2001, pos, Block.getId(state));
         return stack;
      } else {
         return super.execute(source, stack);
      }
   }
}
