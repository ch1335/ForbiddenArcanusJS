package com.stal111.forbidden_arcanus.common.block.clibano;

import com.mojang.serialization.MapCodec;
import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoFireType;
import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.common.block.properties.clibano.ClibanoCenterType;
import com.stal111.forbidden_arcanus.core.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import org.jetbrains.annotations.NotNull;

public class ClibanoCenterBlock extends AbstractClibanoFrameBlock {
   public static final MapCodec<ClibanoCenterBlock> CODEC = simpleCodec(ClibanoCenterBlock::new);
   private static final EnumProperty<ClibanoCenterType> TYPE;

   public ClibanoCenterBlock(Properties properties) {
      super(properties);
      this.registerDefaultState((BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(this.getFacingProperty(), Direction.NORTH)).setValue(TYPE, ClibanoCenterType.SIDE));
   }

   public DirectionProperty getFacingProperty() {
      return BlockStateProperties.FACING;
   }

   public BlockState updateAppearance(BlockState state, boolean isLit, ClibanoFireType fireType) {
      return ((ClibanoCenterType)state.getValue(TYPE)).isFront() ? (BlockState)state.setValue(TYPE, isLit ? ClibanoCenterType.valueOf("FRONT_" + String.valueOf(fireType)) : ClibanoCenterType.FRONT_OFF) : super.updateAppearance(state, isLit, fireType);
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(this.getFacingProperty(), context.getClickedFace());
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{this.getFacingProperty(), TYPE});
   }

   public void animateTick(@NotNull BlockState state, @NotNull Level level, @NotNull BlockPos pos, @NotNull RandomSource random) {
      if (((ClibanoCenterType)state.getValue(TYPE)).getFireType() != null) {
         double x = (double)pos.getX() + 0.5D;
         double y = (double)pos.getY();
         double z = (double)pos.getZ() + 0.5D;
         if (random.nextDouble() < 0.18D) {
            SoundEvent soundEvent = state.getValue(TYPE) == ClibanoCenterType.FRONT_FIRE ? (SoundEvent)ModSounds.CLIBANO_FIRE_CRACKLE.get() : (SoundEvent)ModSounds.CLIBANO_SOUL_FIRE_CRACKLE.get();
            level.playLocalSound(x, y, z, soundEvent, SoundSource.BLOCKS, 0.2F, 1.0F, false);
         }

         Direction direction = (Direction)state.getValue(this.getFacingProperty());
         Axis axis = direction.getAxis();
         double d4 = random.nextDouble() * 0.6D - 0.3D;
         double d5 = axis == Axis.X ? (double)direction.getStepX() * 0.52D : d4;
         double d6 = random.nextDouble() * 9.0D / 16.0D;
         double d7 = axis == Axis.Z ? (double)direction.getStepZ() * 0.52D : d4;
         level.addParticle(ParticleTypes.SMOKE, x + d5, y + d6, z + d7, 0.0D, 0.0D, 0.0D);
      }

   }

   static {
      TYPE = ModBlockStateProperties.CLIBANO_CENTER_TYPE;
   }
}
