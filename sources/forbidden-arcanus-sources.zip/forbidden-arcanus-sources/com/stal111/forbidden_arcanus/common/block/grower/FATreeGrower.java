package com.stal111.forbidden_arcanus.common.block.grower;

import com.stal111.forbidden_arcanus.core.init.world.ModConfiguredFeatures;
import java.util.Optional;
import net.minecraft.world.level.block.grower.TreeGrower;

public class FATreeGrower {
   public static final TreeGrower AURUM;

   static {
      AURUM = new TreeGrower("aurum", Optional.empty(), Optional.of(ModConfiguredFeatures.AURUM), Optional.empty());
   }
}
