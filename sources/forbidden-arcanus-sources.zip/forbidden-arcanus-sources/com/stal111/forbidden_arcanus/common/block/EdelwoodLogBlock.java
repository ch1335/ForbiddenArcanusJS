package com.stal111.forbidden_arcanus.common.block;

import com.stal111.forbidden_arcanus.common.block.properties.ModBlockStateProperties;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import com.stal111.forbidden_arcanus.core.init.ModItems;
import com.stal111.forbidden_arcanus.util.ModTags;
import java.util.EnumMap;
import javax.annotation.Nonnull;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.biome.Biome.Precipitation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.common.ItemAbilities;
import net.valhelsia.valhelsia_core.api.common.helper.VoxelShapeHelper;

public class EdelwoodLogBlock extends Block implements SimpleWaterloggedBlock {
   public static final EnumProperty<Axis> AXIS;
   public static final BooleanProperty OILY;
   public static final BooleanProperty WATERLOGGED;
   protected static final EnumMap<Axis, VoxelShape> SHAPES;
   private static final float RAIN_FILL_CHANCE = 0.15F;
   private static final float OILY_CHANCE = 0.025F;

   public EdelwoodLogBlock(Properties properties) {
      super(properties);
      if (this.getStateDefinition().getProperties().contains(AXIS)) {
         this.registerDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.getStateDefinition().any()).setValue(AXIS, Axis.Y)).setValue(OILY, false)).setValue(WATERLOGGED, false));
      }

   }

   @Nonnull
   public VoxelShape getShape(@Nonnull BlockState state, @Nonnull BlockGetter level, @Nonnull BlockPos pos, @Nonnull CollisionContext context) {
      return !context.isHoldingItem(((EdelwoodLogBlock)ModBlocks.EDELWOOD_LOG.get()).asItem()) && !context.isHoldingItem(((CarvedEdelwoodLogBlock)ModBlocks.CARVED_EDELWOOD_LOG.get()).asItem()) ? (VoxelShape)SHAPES.get(state.getValue(AXIS)) : Shapes.block();
   }

   public BlockState getStateForPlacement(@Nonnull BlockPlaceContext context) {
      boolean flag = context.getLevel().getFluidState(context.getClickedPos()).getType() == Fluids.WATER;
      return (BlockState)((BlockState)this.defaultBlockState().setValue(AXIS, context.getClickedFace().getAxis())).setValue(WATERLOGGED, flag);
   }

   @Nonnull
   public BlockState updateShape(@Nonnull BlockState state, @Nonnull Direction direction, @Nonnull BlockState neighborState, @Nonnull LevelAccessor level, @Nonnull BlockPos currentPos, @Nonnull BlockPos neighborPos) {
      if ((Boolean)state.getValue(WATERLOGGED)) {
         level.scheduleTick(currentPos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return state;
   }

   public void randomTick(@Nonnull BlockState state, @Nonnull ServerLevel level, @Nonnull BlockPos pos, @Nonnull RandomSource random) {
      if (random.nextDouble() < 0.02500000037252903D && level.isAreaLoaded(pos, 4)) {
         level.setBlock(pos, (BlockState)state.setValue(OILY, true), 2);
      }

      super.randomTick(state, level, pos, random);
   }

   public boolean isRandomlyTicking(@Nonnull BlockState state) {
      return !(Boolean)state.getValue(OILY);
   }

   protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult result) {
      if (stack.is(Items.GLASS_BOTTLE) && (Boolean)state.getValue(OILY)) {
         ItemStack oil = new ItemStack((ItemLike)ModItems.EDELWOOD_OIL.get());
         stack.consume(1, player);
         level.playSound(player, player.getX(), player.getY(), player.getZ(), SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
         level.gameEvent(player, GameEvent.FLUID_PICKUP, pos);
         if (stack.isEmpty()) {
            player.setItemInHand(hand, oil);
         } else if (!player.getInventory().add(oil)) {
            player.drop(oil, false);
         }

         level.setBlockAndUpdate(pos, (BlockState)state.setValue(OILY, false));
         return ItemInteractionResult.sidedSuccess(level.isClientSide());
      } else if (stack.canPerformAction(ItemAbilities.AXE_STRIP) && !this.isCarved() && state.getValue(AXIS) == Axis.Y) {
         Direction direction = result.getDirection().getAxis() == Axis.Y ? player.getDirection().getOpposite() : result.getDirection();
         stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
         if (!level.isClientSide()) {
            CriteriaTriggers.ITEM_USED_ON_BLOCK.trigger((ServerPlayer)player, pos, stack);
         }

         level.playSound(player, player.getX(), player.getY(), player.getZ(), SoundEvents.AXE_STRIP, SoundSource.BLOCKS, 1.0F, 1.0F);
         level.setBlockAndUpdate(pos, (BlockState)((BlockState)((BlockState)((CarvedEdelwoodLogBlock)ModBlocks.CARVED_EDELWOOD_LOG.get()).defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, direction)).setValue(OILY, (Boolean)state.getValue(OILY))).setValue(WATERLOGGED, (Boolean)state.getValue(WATERLOGGED)));
         return ItemInteractionResult.sidedSuccess(level.isClientSide());
      } else {
         return super.useItemOn(stack, state, level, pos, player, hand, result);
      }
   }

   protected boolean shouldHandlePrecipitation(BlockState state, Level level, Precipitation precipitation) {
      if (!(Boolean)state.getValue(WATERLOGGED) && (!state.hasProperty(AXIS) || state.getValue(AXIS) == Axis.Y) && precipitation == Precipitation.RAIN) {
         return level.getRandom().nextFloat() < 0.15F;
      } else {
         return false;
      }
   }

   public void handlePrecipitation(@Nonnull BlockState state, @Nonnull Level level, @Nonnull BlockPos pos, @Nonnull Precipitation precipitation) {
      if (this.shouldHandlePrecipitation(state, level, precipitation)) {
         int i = 0;

         for(BlockState belowState = level.getBlockState(pos.below(i + 1)); belowState.is(ModTags.Blocks.EDELWOOD_LOGS) && (!belowState.hasProperty(AXIS) || belowState.getValue(AXIS) == Axis.Y) && !(Boolean)belowState.getValue(WATERLOGGED); belowState = level.getBlockState(pos.below(i + 1))) {
            ++i;
         }

         level.setBlockAndUpdate(pos.below(i), (BlockState)level.getBlockState(pos.below(i)).setValue(WATERLOGGED, true));
         level.gameEvent((Entity)null, GameEvent.FLUID_PLACE, pos.below(i));
      }

   }

   @Nonnull
   public BlockState rotate(BlockState state, @Nonnull Rotation rotation) {
      BlockState var10000;
      switch(rotation) {
      case COUNTERCLOCKWISE_90:
      case CLOCKWISE_90:
         switch((Axis)state.getValue(AXIS)) {
         case X:
            var10000 = (BlockState)state.setValue(AXIS, Axis.Z);
            return var10000;
         case Z:
            var10000 = (BlockState)state.setValue(AXIS, Axis.X);
            return var10000;
         default:
            var10000 = state;
            return var10000;
         }
      default:
         var10000 = state;
         return var10000;
      }
   }

   protected void createBlockStateDefinition(@Nonnull Builder<Block, BlockState> builder) {
      builder.add(new Property[]{AXIS, OILY, WATERLOGGED});
   }

   protected boolean isCarved() {
      return false;
   }

   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return false;
   }

   @Nonnull
   public FluidState getFluidState(BlockState state) {
      return (Boolean)state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   static {
      AXIS = BlockStateProperties.AXIS;
      OILY = ModBlockStateProperties.OILY;
      WATERLOGGED = BlockStateProperties.WATERLOGGED;
      SHAPES = VoxelShapeHelper.rotateAxis(Shapes.join(Shapes.block(), Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D), BooleanOp.ONLY_FIRST));
   }
}
