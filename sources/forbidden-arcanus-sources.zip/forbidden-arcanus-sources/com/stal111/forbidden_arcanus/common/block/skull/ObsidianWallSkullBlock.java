package com.stal111.forbidden_arcanus.common.block.skull;

import com.stal111.forbidden_arcanus.common.block.entity.ObsidianSkullBlockEntity;
import com.stal111.forbidden_arcanus.core.init.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.level.block.WallSkullBlock;
import net.minecraft.world.level.block.SkullBlock.Type;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import org.jetbrains.annotations.NotNull;

public class ObsidianWallSkullBlock extends WallSkullBlock {
   public ObsidianWallSkullBlock(Type type, Properties properties) {
      super(type, properties);
   }

   public BlockEntity newBlockEntity(@NotNull BlockPos pos, @NotNull BlockState state) {
      return new ObsidianSkullBlockEntity(pos, state);
   }

   public boolean isEnabled(FeatureFlagSet enabledFeatures) {
      return this != ModBlocks.AUREALIC_OBSIDIAN_SKULL.getWallSkull() && this != ModBlocks.ETERNAL_OBSIDIAN_SKULL.getWallSkull();
   }
}
