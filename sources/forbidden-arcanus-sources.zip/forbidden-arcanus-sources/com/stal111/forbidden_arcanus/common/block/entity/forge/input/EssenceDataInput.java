package com.stal111.forbidden_arcanus.common.block.entity.forge.input;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.essence.EssenceHelper;
import com.stal111.forbidden_arcanus.common.essence.EssenceValue;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;

public class EssenceDataInput implements HephaestusForgeInput {
   public boolean canInput(EssenceType type, ItemStack stack) {
      return (Boolean)EssenceHelper.getEssenceValue(stack).map((data) -> {
         return data.type() == type;
      }).orElse(false);
   }

   public EssenceValue getInputValue(ItemStack stack, RandomSource random) {
      return (EssenceValue)EssenceHelper.getEssenceValue(stack).orElse(EssenceValue.EMPTY);
   }

   public ItemStack finishInput(ItemStack stack, int inputValue) {
      stack.shrink(1);
      return stack;
   }
}
