package com.stal111.forbidden_arcanus.common.block.entity.forge.essence;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.UnaryOperator;

public class EssencesStorage extends EnumMap<EssenceType, Integer> {
   public static final Codec<EssencesStorage> CODEC = RecordCodecBuilder.create((instance) -> {
      return instance.group(Codec.INT.fieldOf("aureal").forGetter((data) -> {
         return (Integer)data.getOrDefault(EssenceType.AUREAL, 0);
      }), Codec.INT.fieldOf("souls").forGetter((data) -> {
         return (Integer)data.getOrDefault(EssenceType.SOULS, 0);
      }), Codec.INT.fieldOf("blood").forGetter((data) -> {
         return (Integer)data.getOrDefault(EssenceType.BLOOD, 0);
      }), Codec.INT.fieldOf("experience").forGetter((data) -> {
         return (Integer)data.getOrDefault(EssenceType.EXPERIENCE, 0);
      })).apply(instance, EssencesStorage::new);
   });

   public EssencesStorage() {
      super(EssenceType.class);
   }

   public EssencesStorage(int aureal, int souls, int blood, int experience) {
      super(EssenceType.class);
      this.put(EssenceType.AUREAL, aureal);
      this.put(EssenceType.SOULS, souls);
      this.put(EssenceType.BLOOD, blood);
      this.put(EssenceType.EXPERIENCE, experience);
   }

   public void reduce(EssencesDefinition definition) {
      definition.forEach((type, integer) -> {
         this.put(type, (Integer)this.getOrDefault(type, 0) - integer);
      });
   }

   public Integer put(EssenceType key, Integer value) {
      return (Integer)super.put(key, Math.max(value, 0));
   }

   public void modify(EssenceType type, UnaryOperator<Integer> modifier) {
      this.put(type, (Integer)modifier.apply((Integer)this.get(type)));
   }

   public void applyModifiers(List<EssenceModifier> modifiers) {
      Iterator var2 = modifiers.iterator();

      while(var2.hasNext()) {
         EssenceModifier modifier = (EssenceModifier)var2.next();
         EssenceType var10001 = modifier.getEssenceType();
         Objects.requireNonNull(modifier);
         this.modify(var10001, modifier::getModifiedValue);
      }

   }

   public EssencesDefinition immutable() {
      return new EssencesDefinition((Integer)this.getOrDefault(EssenceType.AUREAL, 0), (Integer)this.getOrDefault(EssenceType.SOULS, 0), (Integer)this.getOrDefault(EssenceType.BLOOD, 0), (Integer)this.getOrDefault(EssenceType.EXPERIENCE, 0));
   }
}
