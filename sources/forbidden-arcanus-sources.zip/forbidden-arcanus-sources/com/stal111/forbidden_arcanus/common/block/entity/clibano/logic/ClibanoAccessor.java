package com.stal111.forbidden_arcanus.common.block.entity.clibano.logic;

import com.stal111.forbidden_arcanus.common.block.entity.clibano.ClibanoInputSlot;
import com.stal111.forbidden_arcanus.common.item.crafting.ClibanoRecipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import org.jetbrains.annotations.Nullable;

public interface ClibanoAccessor {
   boolean canSmelt(@Nullable RecipeHolder<ClibanoRecipe> var1, ClibanoInputSlot var2);

   void finishRecipe(RecipeHolder<ClibanoRecipe> var1, ClibanoInputSlot var2);

   int getCookingTime(RecipeHolder<ClibanoRecipe> var1);
}
