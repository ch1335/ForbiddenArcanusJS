package com.stal111.forbidden_arcanus.common.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class QuantumCoreBlock extends Block {
   public QuantumCoreBlock(Properties properties) {
      super(properties);
   }
}
