package com.stal111.forbidden_arcanus.common.essence;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.network.clientbound.UpdateEssencePayload;
import com.stal111.forbidden_arcanus.core.init.other.ModAttachmentTypes;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.Util;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.network.PacketDistributor;

public class EntityEssenceProvider<T extends LivingEntity> implements EssenceProvider {
   private static final Map<EssenceType, AttachmentType<EssenceStorage>> ATTACHMENT_BY_TYPE = (Map)Util.make(new EnumMap(EssenceType.class), (map) -> {
      map.put(EssenceType.AUREAL, (AttachmentType)ModAttachmentTypes.AUREAL.get());
      map.put(EssenceType.SOULS, (AttachmentType)ModAttachmentTypes.SOULS.get());
      map.put(EssenceType.BLOOD, (AttachmentType)ModAttachmentTypes.BLOOD.get());
      map.put(EssenceType.EXPERIENCE, (AttachmentType)ModAttachmentTypes.EXPERIENCE.get());
   });
   final T entity;

   public EntityEssenceProvider(T entity) {
      this.entity = entity;
   }

   public EssenceStorage asStorage(EssenceType type) {
      return (EssenceStorage)this.entity.getData((AttachmentType)ATTACHMENT_BY_TYPE.get(type));
   }

   public void setStorage(EssenceStorage storage) {
      this.entity.setData((AttachmentType)ATTACHMENT_BY_TYPE.get(storage.value().type()), storage);
      LivingEntity var3 = this.entity;
      if (var3 instanceof ServerPlayer) {
         ServerPlayer player = (ServerPlayer)var3;
         PacketDistributor.sendToPlayer(player, new UpdateEssencePayload(storage), new CustomPacketPayload[0]);
      }

   }
}
