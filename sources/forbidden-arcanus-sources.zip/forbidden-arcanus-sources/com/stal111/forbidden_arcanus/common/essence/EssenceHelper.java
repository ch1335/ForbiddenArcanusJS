package com.stal111.forbidden_arcanus.common.essence;

import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.common.item.component.AurealCost;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class EssenceHelper {
   public static Optional<EssenceValue> getEssenceValue(ItemStack stack) {
      return Optional.ofNullable((EssenceValue)stack.get(ModDataComponents.ESSENCE_VALUE));
   }

   public static int getEssenceAmount(ItemStack stack, EssenceType type) {
      return (Integer)getEssenceValue(stack).filter((essenceValue) -> {
         return essenceValue.type() == type;
      }).map(EssenceValue::amount).orElse(0);
   }

   public static Optional<EssenceStorage> getEssenceStorage(ItemStack stack) {
      return Optional.ofNullable((EssenceStorage)stack.get(ModDataComponents.ESSENCE_STORAGE));
   }

   public static Optional<EssenceProvider> getEssenceProvider(Entity entity) {
      return Optional.ofNullable((EssenceProvider)entity.getCapability(EssenceProvider.ENTITY_ESSENCE));
   }

   public static boolean hasEnoughAureal(Level level, LivingEntity livingEntity, ItemStack stack) {
      if (level instanceof ServerLevel) {
         ServerLevel serverLevel = (ServerLevel)level;
         return ((AurealCost)stack.getOrDefault(ModDataComponents.AUREAL_COST, AurealCost.ZERO)).hasEnough(serverLevel, livingEntity);
      } else {
         return false;
      }
   }

   public static void consumeAureal(LivingEntity livingEntity, ItemStack stack) {
      getEssenceProvider(livingEntity).ifPresent((provider) -> {
         provider.updateAmount(EssenceType.AUREAL, (amount) -> {
            return amount - ((AurealCost)stack.getOrDefault(ModDataComponents.AUREAL_COST, AurealCost.ZERO)).value();
         });
      });
   }

   public static ItemStack createStorageItem(Item item, EssenceType type, int amount, int limit) {
      ItemStack stack = new ItemStack(item);
      stack.set(ModDataComponents.ESSENCE_STORAGE, new EssenceStorage(EssenceValue.of(type, amount), limit, true));
      return stack;
   }
}
