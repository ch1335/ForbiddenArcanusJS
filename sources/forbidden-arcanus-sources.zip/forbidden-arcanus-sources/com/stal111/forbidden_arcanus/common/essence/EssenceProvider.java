package com.stal111.forbidden_arcanus.common.essence;

import com.stal111.forbidden_arcanus.ForbiddenArcanus;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import java.util.function.UnaryOperator;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.capabilities.EntityCapability;
import net.neoforged.neoforge.capabilities.ItemCapability;

public interface EssenceProvider {
   ItemCapability<EssenceProvider, Void> ITEM_ESSENCE = ItemCapability.createVoid(ForbiddenArcanus.location("essence_provider"), EssenceProvider.class);
   EntityCapability<EssenceProvider, Void> ENTITY_ESSENCE = EntityCapability.createVoid(ForbiddenArcanus.location("essence_provider"), EssenceProvider.class);

   EssenceStorage asStorage(EssenceType var1);

   void setStorage(EssenceStorage var1);

   default int getAmount(EssenceType type) {
      return this.asStorage(type).value().amount();
   }

   default void setAmount(EssenceType type, int amount) {
      EssenceStorage storage = this.asStorage(type);
      this.setStorage(new EssenceStorage(EssenceValue.of(type, Mth.clamp(amount, 0, storage.limit())), storage.limit(), storage.showInTooltip()));
   }

   default void updateAmount(EssenceType type, UnaryOperator<Integer> operator) {
      this.setAmount(type, (Integer)operator.apply(this.getAmount(type)));
   }

   default int getLimit(EssenceType type) {
      return this.asStorage(type).limit();
   }

   default void setLimit(EssenceType type, int limit) {
      EssenceStorage storage = this.asStorage(type);
      this.setStorage(new EssenceStorage(storage.value(), limit, storage.showInTooltip()));
   }

   default boolean isFull(EssenceType type) {
      return this.asStorage(type).isFull();
   }
}
