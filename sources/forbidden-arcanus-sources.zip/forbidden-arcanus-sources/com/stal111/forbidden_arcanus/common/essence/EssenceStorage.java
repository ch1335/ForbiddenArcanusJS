package com.stal111.forbidden_arcanus.common.essence;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.stal111.forbidden_arcanus.common.block.entity.forge.essence.EssenceType;
import com.stal111.forbidden_arcanus.core.init.ModDataComponents;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.item.component.TooltipProvider;
import org.jetbrains.annotations.NotNull;

public record EssenceStorage(EssenceValue value, int limit, boolean showInTooltip) implements TooltipProvider {
   public static final EssenceStorage EMPTY;
   public static final Codec<EssenceStorage> FULL_CODEC;
   public static final Codec<EssenceStorage> CODEC;
   public static final StreamCodec<FriendlyByteBuf, EssenceStorage> STREAM_CODEC;

   public EssenceStorage(EssenceValue value, int limit, boolean showInTooltip) {
      this.value = value;
      this.limit = limit;
      this.showInTooltip = showInTooltip;
   }

   public static Codec<EssenceStorage> codec(EssenceType type) {
      return RecordCodecBuilder.create((instance) -> {
         return instance.group(ExtraCodecs.NON_NEGATIVE_INT.fieldOf("amount").forGetter((storage) -> {
            return storage.value.amount();
         }), ExtraCodecs.NON_NEGATIVE_INT.fieldOf("limit").forGetter(EssenceStorage::limit)).apply(instance, (amount, limit1) -> {
            return new EssenceStorage(EssenceValue.of(type, amount), limit1, true);
         });
      });
   }

   public static EssenceStorage createEmpty(EssenceType type, int limit) {
      return new EssenceStorage(EssenceValue.of(type, 0), limit, true);
   }

   public float getFillPercentage() {
      return (float)this.value.amount() / (float)this.limit;
   }

   public void addToTooltip(@NotNull TooltipContext context, @NotNull Consumer<Component> consumer, @NotNull TooltipFlag flag) {
      int var10001 = this.value.amount();
      consumer.accept(Component.literal(": " + var10001 + "/" + this.limit).withStyle(ChatFormatting.GRAY));
   }

   public void addEssence(ItemStack stack, int amount) {
      EssenceHelper.getEssenceStorage(stack).ifPresent((storage) -> {
         stack.set(ModDataComponents.ESSENCE_STORAGE, new EssenceStorage(EssenceValue.of(storage.value.type(), Math.min(storage.value.amount() + amount, storage.limit())), storage.limit(), storage.showInTooltip()));
      });
   }

   public boolean isFull() {
      return this.value.amount() >= this.limit;
   }

   public boolean isEmpty() {
      return this.value.amount() <= 0;
   }

   public EssenceValue value() {
      return this.value;
   }

   public int limit() {
      return this.limit;
   }

   public boolean showInTooltip() {
      return this.showInTooltip;
   }

   static {
      EMPTY = new EssenceStorage(EssenceValue.EMPTY, 0, true);
      FULL_CODEC = RecordCodecBuilder.create((instance) -> {
         return instance.group(EssenceValue.CODEC.fieldOf("data").forGetter(EssenceStorage::value), ExtraCodecs.NON_NEGATIVE_INT.fieldOf("limit").forGetter(EssenceStorage::limit), Codec.BOOL.optionalFieldOf("show_in_tooltip", true).forGetter(EssenceStorage::showInTooltip)).apply(instance, EssenceStorage::new);
      });
      CODEC = Codec.withAlternative(FULL_CODEC, RecordCodecBuilder.create((instance) -> {
         return instance.group(EssenceValue.CODEC.fieldOf("data").forGetter(EssenceStorage::value), ExtraCodecs.NON_NEGATIVE_INT.fieldOf("limit").forGetter(EssenceStorage::limit)).apply(instance, (data, limit) -> {
            return new EssenceStorage(data, limit, true);
         });
      }));
      STREAM_CODEC = StreamCodec.composite(EssenceValue.STREAM_CODEC, EssenceStorage::value, ByteBufCodecs.INT, EssenceStorage::limit, ByteBufCodecs.BOOL, EssenceStorage::showInTooltip, EssenceStorage::new);
   }
}
